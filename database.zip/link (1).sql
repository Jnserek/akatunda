-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2018 at 03:47 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `link`
--

-- --------------------------------------------------------

--
-- Table structure for table `adverts`
--

CREATE TABLE IF NOT EXISTS `adverts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `info` tinytext NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT '0',
  `file_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `adverts`
--

INSERT INTO `adverts` (`id`, `info`, `publish`, `file_name`) VALUES
(2, 'mzxmzx zxmzmx zmxz', 0, '1527608021.JPG'),
(3, 'mukwano group of companies', 0, '1527608496.JPG'),
(4, 'asasa', 0, '1527609917.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE IF NOT EXISTS `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `info` tinytext NOT NULL,
  `name` varchar(20) NOT NULL,
  `dtype` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `user`, `info`, `name`, `dtype`) VALUES
(1, 1, '1524741180.pdf', 'asas', 1);

-- --------------------------------------------------------

--
-- Table structure for table `document_types`
--

CREATE TABLE IF NOT EXISTS `document_types` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `docname` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `document_types`
--

INSERT INTO `document_types` (`id`, `docname`) VALUES
(1, 'Recommendation Letter (Intern)'),
(2, 'CV'),
(3, 'Application Letter');

-- --------------------------------------------------------

--
-- Table structure for table `fruit_bank`
--

CREATE TABLE IF NOT EXISTS `fruit_bank` (
  `fruit_id` int(11) NOT NULL AUTO_INCREMENT,
  `fruit_type` varchar(30) NOT NULL,
  `cost_price` int(11) NOT NULL,
  `expiry_date` date NOT NULL,
  `sold` int(11) NOT NULL DEFAULT '0',
  `agent_id` int(11) DEFAULT NULL,
  `selling_price` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `date_sold` date DEFAULT NULL,
  PRIMARY KEY (`fruit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `fruit_bank`
--

INSERT INTO `fruit_bank` (`fruit_id`, `fruit_type`, `cost_price`, `expiry_date`, `sold`, `agent_id`, `selling_price`, `order_id`, `date_sold`) VALUES
(1, '1', 5000, '2017-03-29', 1, 1, 1000, 9, '2017-03-23'),
(2, '1', 5000, '2017-03-29', 1, 1, 1000, 9, '2017-03-23'),
(3, '1', 5000, '2017-03-29', 1, 1, 1000, 9, '2017-03-23'),
(4, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(5, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(6, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(7, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(8, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(9, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(10, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(11, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(12, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(13, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(14, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(15, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(16, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(17, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(18, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(19, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(20, '1', 5000, '2017-03-29', 3, NULL, NULL, NULL, NULL),
(21, '2', 5500, '2017-03-30', 2, 1, 6000, 10, '2017-03-23'),
(22, '2', 5500, '2017-03-30', 2, 1, 6000, 10, '2017-03-23'),
(23, '2', 5500, '2017-03-30', 2, 1, 6000, 10, '2017-03-23'),
(24, '2', 5500, '2017-03-30', 1, 1, 6000, 11, '2017-03-23'),
(25, '2', 5500, '2017-03-30', 1, 1, 6000, 11, '2017-03-23'),
(26, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(27, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(28, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(29, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(30, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(31, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(32, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(33, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(34, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(35, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(36, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(37, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(38, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(39, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(40, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(41, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(42, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(43, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(44, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(45, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(46, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(47, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(48, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(49, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL),
(50, '2', 5500, '2017-03-30', 3, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `item_types`
--

CREATE TABLE IF NOT EXISTS `item_types` (
  `type_name` tinytext NOT NULL,
  `description` tinytext NOT NULL,
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `item_types`
--

INSERT INTO `item_types` (`type_name`, `description`, `type_id`) VALUES
('Katunda1', 'Local', 1),
('Pine Apple', 'cool type', 2);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization` int(11) NOT NULL,
  `tittle` varchar(50) NOT NULL,
  `descriptions` text NOT NULL,
  `deadline` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `positions` tinyint(3) DEFAULT NULL,
  `department` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `organization`, `tittle`, `descriptions`, `deadline`, `status`, `positions`, `department`) VALUES
(1, 1, 'finance admin strator', 'D. Opera\r\n9. The Android phone is renowned for high data usage. Explain 3 measures you can undertake to reduce internet data usage (3marks)\r\nRestrict background data, restrict app updates on wifi, set data usage limit\r\n10. Explain three measures you can employ to prevent you from installing harmful apps in an android phone. (3 marks)\r\nby always install appsa from google play, avoid jail brake the phone, allways update the apps\r\n11. Battery life in android devices is a major issue of concern and the biggest drawback to almost all the smartphones. What are the ways you can employ to improve battery life? (3 marks)\r\nlimit data usage, \r\n12. How would you trouble shoot lack of internet connectivity on an Android phone? (3 marks)\r\ncheck if mobile data is on if off then put it on, see if APN is properly set, Check and see if the phone is not in air plane mode, also see that mobile data limit is not exceed and see if you have mobile bundles or WiFi connectivity with a key.\r\n13. Explain at least two measures you can employ to ensure safety of data in a phone or laptop. (2 marks)\r\nuse strong password, update the apps, use antivirus or a strong firewall.\r\n14. When an end user says a file went missing from their computer, what possible explanations come to mind? (3 marks)\r\nit may be corrupted of the file format was changed by a virus.\r\nSuccessful candidates will be contacted again and given details of the interview venue. Unfortunately we will not be able to accommodate you if you are not available to attend.Please let us know if you have any feedback on your experience with our recruitment process so far.\r\nis fair\r\nYou are now finished with the assessment -- well done!\r\nPage 1 of 1\r\nNever submit passwords through Google Forms.\r\nThis content is neither created nor endorsed by Google. Report Abuse - Terms of Service - Additional Terms\r\nGoogle Forms', '2018-03-29', 1, NULL, NULL),
(2, 1, 'asasas', 'asas', '2018-04-20', 1, 2, 'asasas');

-- --------------------------------------------------------

--
-- Table structure for table `member_types`
--

CREATE TABLE IF NOT EXISTS `member_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `fee` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `member_types`
--

INSERT INTO `member_types` (`id`, `name`, `fee`) VALUES
(1, 'Internship', 30000),
(2, 'Job', 50000),
(3, 'Research', 50000),
(4, 'Volunteer', 50000);

-- --------------------------------------------------------

--
-- Table structure for table `mobile_tranactions`
--

CREATE TABLE IF NOT EXISTS `mobile_tranactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone_no` varchar(12) NOT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `ext_ref` varchar(20) NOT NULL,
  `ammount` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `period` varchar(20) NOT NULL,
  `network_ref` int(20) DEFAULT NULL,
  `msisdn` varchar(20) DEFAULT NULL,
  `network_time` varchar(20) DEFAULT NULL,
  `ammount_paid` int(11) DEFAULT NULL,
  `narative` varchar(50) DEFAULT NULL,
  `initial_time` datetime DEFAULT NULL,
  `transaction_reference` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `my_applications`
--

CREATE TABLE IF NOT EXISTS `my_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `jobs` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `my_applications`
--

INSERT INTO `my_applications` (`id`, `user`, `jobs`) VALUES
(1, 7, 1),
(2, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `organisations`
--

CREATE TABLE IF NOT EXISTS `organisations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `location` varchar(50) DEFAULT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '1',
  `plot_no` varchar(20) DEFAULT NULL,
  `box_no` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `tel` varchar(30) NOT NULL,
  `website` varchar(50) DEFAULT NULL,
  `type` tinyint(4) NOT NULL,
  `deals_in` varchar(50) DEFAULT NULL,
  `branches` text,
  `intrests` varchar(20) DEFAULT NULL,
  `working_hours` tinyint(4) DEFAULT NULL,
  `reporting_date` date DEFAULT NULL,
  `contact_person` varchar(50) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(20) DEFAULT NULL,
  `renumerations` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `organisations`
--

INSERT INTO `organisations` (`id`, `name`, `location`, `state`, `plot_no`, `box_no`, `email`, `tel`, `website`, `type`, `deals_in`, `branches`, `intrests`, `working_hours`, `reporting_date`, `contact_person`, `telephone`, `contact_email`, `renumerations`) VALUES
(1, 'mtn Uganda', 'kampala uganda', 1, 'plot no', 'box number', 'email address', '', 'website', 0, 'ict', 'kamapala uganda', '50', NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'nbs tv', 'kampala uganda', 1, 'plot no', 'box number', 'email address', '', 'website', 0, 'ict', 'kamapala uganda', '50', NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'airtell uganda', 'kampala uganda', 1, 'plot ni', 'box no', 'email address', 'adress', 'website', 0, 'ict', 'kampala', '50', 0, '0000-00-00', 'some', '', '', ''),
(4, 'warid tel', 'kampala uganda', 1, 'plot no', 'box number', 'email address', '', 'website', 0, 'ict', 'kamapala uganda', '50', NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'web info', 'kampala uganda', 1, 'plot ni', 'box no', 'email address', 'adress', 'website', 0, 'ict', 'kampala', '50', 0, '0000-00-00', 'some', '', '', ''),
(6, 'asasa', 'kamapala', 1, '', '', '', '0777555040', '', 0, '', '', '', 0, '0000-00-00', '', '', '', ''),
(7, 'asasa', 'kamapala', 1, '', '', '', '0777555040', '', 0, '', '', '', 0, '0000-00-00', '', '', '', ''),
(8, 'asasa', 'kamapala', 1, '', '', '', '0777555040', '', 1, '', '', '', 0, '0000-00-00', '', '', '', ''),
(9, 'nsereko', 'kamapala road', 1, '', '', '', '0777555040', '', 2, '', 'branh 1 , ndndnd, 3', '', NULL, '0000-00-00', '', '', '', ''),
(10, 'masas', 'scscscs', 1, 'plot', 'box', 'jnserekk@gmail.com', 'plot', 'website', 1, 'description of the company', 'vranc hsnsm m,s,s', '50', 4, '0000-00-00', 'magala edmond', 'katugga', 'k@gmail.com', 'fsnds smdnsdnsmdnsd sdnmsnds');

-- --------------------------------------------------------

--
-- Table structure for table `organisation_types`
--

CREATE TABLE IF NOT EXISTS `organisation_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `organisation_types`
--

INSERT INTO `organisation_types` (`id`, `name`) VALUES
(1, 'ICT'),
(2, 'Branding'),
(3, 'Media company'),
(4, 'NGO'),
(5, 'Civil and Construction '),
(6, 'Electrical'),
(7, 'Ministry / Government Organisation'),
(8, 'Health Facility'),
(9, 'Security Company'),
(10, 'Tours and Travel'),
(11, 'Hotel and Hospitality'),
(12, 'Transport'),
(13, 'Tourism'),
(14, 'Chemicals and Manufacturing'),
(15, 'School '),
(16, 'Auditors'),
(17, 'Court');

-- --------------------------------------------------------

--
-- Table structure for table `organizatin_allocations`
--

CREATE TABLE IF NOT EXISTS `organizatin_allocations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `organisation_id` int(11) NOT NULL,
  `approval_state` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `organizatin_allocations`
--

INSERT INTO `organizatin_allocations` (`id`, `user_id`, `organisation_id`, `approval_state`) VALUES
(16, 7, 4, 0),
(18, 7, 2, 0),
(19, 7, 3, 0),
(21, 8, 1, 0),
(22, 8, 2, 0),
(23, 8, 3, 0),
(24, 8, 4, 0),
(25, 7, 1, 0),
(26, 21, 1, 0),
(27, 21, 2, 0),
(28, 21, 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment_modes`
--

CREATE TABLE IF NOT EXISTS `payment_modes` (
  `pay_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `pay_name` varchar(10) NOT NULL,
  `pay_state` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pay_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `payment_modes`
--

INSERT INTO `payment_modes` (`pay_id`, `pay_name`, `pay_state`) VALUES
(1, 'Cash sale', 1),
(2, 'Credit', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `client_details` tinytext NOT NULL,
  `cleared` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `service_fee`
--

CREATE TABLE IF NOT EXISTS `service_fee` (
  `id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `member` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `service_fee_transactions`
--

CREATE TABLE IF NOT EXISTS `service_fee_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone_no` varchar(12) NOT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `ext_ref` varchar(20) NOT NULL,
  `ammount` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `period` varchar(20) NOT NULL,
  `network_ref` int(20) DEFAULT NULL,
  `msisdn` varchar(20) DEFAULT NULL,
  `network_time` varchar(20) DEFAULT NULL,
  `ammount_paid` int(11) DEFAULT NULL,
  `narative` varchar(50) DEFAULT NULL,
  `initial_time` datetime DEFAULT NULL,
  `transaction_reference` tinytext,
  `member` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `password` tinytext NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `phone_no` varchar(13) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `role` tinyint(2) NOT NULL,
  `provisional_code` varchar(12) DEFAULT NULL,
  `logged_in` tinyint(1) DEFAULT '1',
  `location` varchar(30) DEFAULT NULL,
  `nationality` int(3) NOT NULL DEFAULT '1',
  `university` tinytext,
  `pass_id` varchar(30) DEFAULT NULL,
  `registration_no` varchar(30) DEFAULT NULL,
  `year_of_admission` year(4) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `next_of_kin` varchar(50) DEFAULT NULL,
  `duration_one` date DEFAULT NULL,
  `duration_two` date DEFAULT NULL,
  `supervisor` varchar(50) DEFAULT NULL,
  `supervisor_number` varchar(30) DEFAULT NULL,
  `supervisor_email` varchar(30) DEFAULT NULL,
  `intern_type` tinyint(4) DEFAULT NULL,
  `next_em` varchar(50) DEFAULT NULL,
  `next_fon` varchar(15) DEFAULT NULL,
  `profile_update` tinyint(4) NOT NULL DEFAULT '0',
  `other_info` tinytext,
  `matched` int(11) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `match_comment` tinytext,
  `working` varchar(5) DEFAULT NULL,
  `years_working` int(3) DEFAULT NULL,
  `about` text,
  `additional` text,
  `org1` varchar(60) DEFAULT NULL,
  `org1resp` tinytext,
  `org2` varchar(60) DEFAULT NULL,
  `org2resp` tinytext,
  `org3` varchar(60) DEFAULT NULL,
  `org3resp` tinytext,
  `period` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `fname`, `lname`, `phone_no`, `status`, `role`, `provisional_code`, `logged_in`, `location`, `nationality`, `university`, `pass_id`, `registration_no`, `year_of_admission`, `course`, `email_address`, `next_of_kin`, `duration_one`, `duration_two`, `supervisor`, `supervisor_number`, `supervisor_email`, `intern_type`, `next_em`, `next_fon`, `profile_update`, `other_info`, `matched`, `match_date`, `match_comment`, `working`, `years_working`, `about`, `additional`, `org1`, `org1resp`, `org2`, `org2resp`, `org3`, `org3resp`, `period`) VALUES
(1, '0777949459', '$2y$10$KLrCmvmeGzgdnlLYbCTOIulDE8jjYWsiOWjV3foUMg20PmgPwBA/6', 'Admin', 'Admin', '07779494591', 1, 1, '', 1, 'Loca', 2, 'Kumi', 'Nin', 'Reg', 0000, 'Course', 'jnserek@gmail.com', 'Next', '2018-03-26', '2018-04-04', 'asasasa', '', NULL, 1, '', '', 1, '', NULL, NULL, NULL, NULL, NULL, 'additional', 'other', 'org1', 'odosdskds', '', '', 'org3', 'res3', NULL),
(15, 'wasike', '$2y$10$95EV0.dU/NcvgU4l2O6B9ucLa4x3VRwKlj1l3KrSz8Lvjy5Ss47Jy', 'Wasike', 'Melckzedeck', '0701387597', 1, 3, '', 1, 'Kampala', 0, '0', '10073231/4/1', '07042018', 0000, 'Buz Admin', 'wmelck@yahoo.com', 'Flavia', '2018-04-12', '2918-09-09', 'Flavia', 'sup no', 'sup em', 0, 'next em', 'next fon', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 'rose', '$2y$10$5O5FIJ5G/Xx/D1vKt7Rp9uw9YULB4a4dmG7vKwvYuXgOex7EJwjLe', 'ROSE', 'TEKIBAKYOMU', '0774583787', 1, 3, '', 1, 'KILEKA-NAMUGONGO', 0, '0', 'B1020986', '8/4/2018', 2017, 'PUBLIC ADMINISTRATION AND MANAGEMENT', 'rosette.nambooze@gmail.com', 'MR MOSES MUTUMBA', '2018-04-15', '2018-05-20', 'Mr wasike Egugu', '0701387597', NULL, 0, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, '0705669324', '$2y$10$x8Z7ZEki.DPrr6Qj4WBztuir4OC/KpKHxyk/o1WZ81cDP0raigZCK', 'uname', 'email', '0705669324', 1, 3, '', 1, 'll', 0, '0', '', 'sasa', 0000, 'asa', 'jnserekk@gmail.com', 'Kampala - Entebbe Rd', '2019-12-31', '2018-02-02', '', '', NULL, 0, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'Admin2', '$2y$10$dSKmEBUTI00CImu2H9daeOr9F6.j/4586VgixaJXaxgaPBJQcmVBe', 'wesike', 'Admin', '0414375177', 1, 1, '', 1, 'head office', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'roland', '$2y$10$8JHc64TEaTc.2zFqalvHBelxNgcrERg1iPotVjzJ8GWKtzP6vpLke', 'Sseruyima', 'Roland', '0705367213', 1, 3, '', 1, 'Kampala', 0, '0', '1600301140', '16/1/315/D/443', 2016, 'Bachelors Degree in Journalism and Mass Communicat', 'sserod2@gmail.com', 'Mr. Kasumba Gabriel', '2018-06-01', '2018-07-31', 'Ms. Jane Mercy Muthoni', '0772376320', NULL, 0, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, '0754070674', '$2y$10$7fFBjtTx5yF9uZayfYeXF.w1xT903FaEk/5RBzJOCr4bimUM9ihNW', 'ss', 'ss', '0754070674', 1, 3, '', 1, 'location', 1, 'cc', '', 'cc', 0000, 'cc', 'jnserekkx@gmail.com', 'cc', '0000-00-00', '0000-00-00', '', '', NULL, 1, '', '', 1, '', 1, '2018-05-24', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, '0787324863', '$2y$10$u85eNRjZIVAn316.e42itu/RQFJAm/eksjQ0WtmQT99oiUbq22/4i', '0787324863', '0787324863', '0787324863', 1, 3, '', 1, 'kampala', 1, 'uni', '', 'reg', 0000, 'course', NULL, 'next', '0000-00-00', '0000-00-00', '', '', NULL, 1, '', '', 1, '', 4, '2018-05-24', 'Mmmmn mnmnmnm  mmnm', 'Yes', NULL, '', '', '', '', '', '', '', '', NULL),
(22, '0757740573', '$2y$10$mkuoY0i0TCLUO/jzEFBUUehy/yprmXDYkIJmvZ0BKJFnN1cURfJDy', '0757740573', '0757740573', '0757740573', 1, 3, '', 1, 'banda', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, '0759681351', '$2y$10$l5t0LFR5B8j1E0t/Wh.IKuFPdUHTHKCHWmQ.3LvJi9.TyLkUF5pce', '0759681351', '0759681351', '0759681351', 1, 3, '', 1, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, '0751115764', '$2y$10$mJWf1aMR40IateG5J3tG/u34dJhPr4tOYOp1vdEX2SrT2fwfQHg12', 'NAMYALO', 'JOAN', '0751115764', 1, 3, '', 1, 'MAKERERE', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, '0701006434', '$2y$10$7I/bfotEU7OZgWC3BBmCYuCrgUB3kSjPvZKtG5FfSb2vueFbshFLm', '0701006434', '0701006434', '0701006434', 1, 3, '', 1, '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, '0702557170', '$2y$10$fx.36.nMhQH00v9BHV9ZfO3E7YljKUvb2aTFiPnRZOwvwSpO5TR92', 'jack', 'ok', '0702557170', 1, 3, '', 1, 'location', 0, '0', '', 'mama', 2000, 'course', 'email@gmail.com', 'next', '2018-12-12', '2018-02-02', 'supervisor', '', NULL, 0, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, '0704397192', '$2y$10$Q15HdvjyXTPpgjM4EsNta..NFvGi6rbOR3ZxCDtV.tvcHRIvzw8X2', 'brivia', 'nalubega', '0704397192', 1, 3, '', 1, 'kiwatule', 0, '0', '1500200988', '15/U/BSAF/1476/K/DAY', 2015, 'bachelors of science in accounting and finance', 'scarletakivia8@gmail.com', '0705494414', '2018-06-20', '2018-08-20', 'Mr.Kyagulanyi Ronald', '', NULL, 0, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users2`
--

CREATE TABLE IF NOT EXISTS `users2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `password` tinytext NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `phone_no` varchar(13) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `role` tinyint(2) NOT NULL,
  `provisional_code` varchar(12) DEFAULT NULL,
  `logged_in` tinyint(1) DEFAULT '1',
  `location` varchar(30) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `university` smallint(6) DEFAULT NULL,
  `pass_id` varchar(30) DEFAULT NULL,
  `registration_no` varchar(30) DEFAULT NULL,
  `year_of_admission` year(4) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `next_of_kin` varchar(50) DEFAULT NULL,
  `duration_one` date DEFAULT NULL,
  `duration_two` date DEFAULT NULL,
  `supervisor` varchar(50) DEFAULT NULL,
  `supervisor_number` varchar(30) DEFAULT NULL,
  `supervisor_email` varchar(30) DEFAULT NULL,
  `intern_type` tinyint(4) DEFAULT NULL,
  `next_em` varchar(50) DEFAULT NULL,
  `next_fon` varchar(15) DEFAULT NULL,
  `profile_update` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `users2`
--

INSERT INTO `users2` (`id`, `user_name`, `password`, `fname`, `lname`, `phone_no`, `status`, `role`, `provisional_code`, `logged_in`, `location`, `nationality`, `university`, `pass_id`, `registration_no`, `year_of_admission`, `course`, `email_address`, `next_of_kin`, `duration_one`, `duration_two`, `supervisor`, `supervisor_number`, `supervisor_email`, `intern_type`, `next_em`, `next_fon`, `profile_update`) VALUES
(1, 'admin', '$2y$10$rbswcKQT7QxRw9LFdJzzXuPsbTWFr9GDPzGahxWkTjWTzgVwltSFi', 'Admin', 'Admin', '0777949459', 1, 1, NULL, 1, 'Kampala', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(7, '0777949450', '$2y$10$Cobu4UDboFhew.dSUFh5vO6Cnr3u2O0R6Uxnhw42cqFyKSwym4xia', 'sasasa', 'sasas', '0777949450', 1, 3, NULL, 1, 'location', 'UGANDAN', 0, 'NIN', 'reg', 2015, 'course', 'jnserekk@gmail.com', 'nextt', '2018-03-01', '2018-03-31', 'sup', 'supno', NULL, 0, NULL, NULL, 1),
(8, '0701387597', '$2y$10$SHrSKG78FC/1BCTC4PyGYOUaDMLhLJ2S/Hm3K5ZsRI61lY6sSLhsm', 'wesike', 'melck', '0701387597', 1, 3, NULL, 1, 'kamapala uganda', 'UGANDAN', 0, '0870987', 'reg', 2015, 'biz admin', 'wmelck@yahoo.com', 'Jackson', '2018-03-29', '2018-04-28', 'wycliffe', '0776514158', NULL, 0, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users3`
--

CREATE TABLE IF NOT EXISTS `users3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `password` tinytext NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `phone_no` varchar(13) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1',
  `role` tinyint(2) NOT NULL,
  `provisional_code` varchar(12) DEFAULT NULL,
  `logged_in` tinyint(1) DEFAULT '1',
  `location` varchar(30) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `university` smallint(6) DEFAULT NULL,
  `pass_id` varchar(30) DEFAULT NULL,
  `registration_no` varchar(30) DEFAULT NULL,
  `year_of_admission` year(4) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `next_of_kin` varchar(50) DEFAULT NULL,
  `duration_one` date DEFAULT NULL,
  `duration_two` date DEFAULT NULL,
  `supervisor` varchar(50) DEFAULT NULL,
  `supervisor_number` varchar(30) DEFAULT NULL,
  `supervisor_email` varchar(30) DEFAULT NULL,
  `intern_type` tinyint(4) DEFAULT NULL,
  `next_em` varchar(50) DEFAULT NULL,
  `next_fon` varchar(15) DEFAULT NULL,
  `profile_update` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users3`
--

INSERT INTO `users3` (`id`, `user_name`, `password`, `fname`, `lname`, `phone_no`, `status`, `role`, `provisional_code`, `logged_in`, `location`, `nationality`, `university`, `pass_id`, `registration_no`, `year_of_admission`, `course`, `email_address`, `next_of_kin`, `duration_one`, `duration_two`, `supervisor`, `supervisor_number`, `supervisor_email`, `intern_type`, `next_em`, `next_fon`, `profile_update`) VALUES
(1, '07779494591', '$2y$10$SU8eQ537CFiHhbxudW89LuaGXsMHJQqVxGkK/SCAWFKPmqYeswxaW', 'jackson', 'nsereko', '07779494591', 1, 3, '', 1, 'Kamapala', 'ugandan', 0, 'id', '10/12', 2017, 'course', 'jnserekk@gmail.com', 'next', '2018-05-05', '2018-05-05', 'jak', 'jak', NULL, 0, NULL, NULL, 0),
(15, 'wasike1', '$2y$10$rbswcKQT7QxRw9LFdJzzXuPsbTWFr9GDPzGahxWkTjWTzgVwltSFi', 'wasike', 'wasike', '0701387597', 1, 3, '', 1, 'kamapala uganda', 'UGANDAN', 0, '1232', 'reg', 2015, 'course', 'wmelck@yahoo.com', 'next name', '2018-04-18', '2018-04-19', 'sup', '', NULL, 0, NULL, NULL, 0),
(16, 'rose', '$2y$10$5O5FIJ5G/Xx/D1vKt7Rp9uw9YULB4a4dmG7vKwvYuXgOex7EJwjLe', 'ROSE', 'TEKIBAKYOMU', '0774583787', 1, 3, NULL, 1, 'KILEKA-NAMUGONGO', 'UGANDAN', 0, 'B1020986', '8/4/2018', 2017, 'PUBLIC ADMINISTRATION AND MANAGEMENT', 'rosette.nambooze@gmail.com', 'MR MOSES MUTUMBA', '2018-04-15', '2018-05-20', 'Mr wasike Egugu', '0701387597', NULL, 0, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `role_name`) VALUES
(1, 'Admin'),
(2, 'Accountant'),
(3, 'Users');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
