<?php
    $config['protocol'] = 'smtp';
    $config['smtp_host'] = 'ssl://smtp.gmail.com'; //change this
    $config['smtp_port'] = '465';
    $config['smtp_user'] = 'jnserek'; //change this
    $config['smtp_pass'] = '210009424'; //change this
    $config['mailtype'] = 'html';
    $config['charset'] = 'iso-8859-1';//Serv@2020
    $config['wordwrap'] = TRUE;
    $config['newline'] = "\r\n"; //use double quotes to comply with RFC 822 standard
?>