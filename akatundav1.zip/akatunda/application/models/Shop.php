	<?php class Shop extends CI_Model {
			/**
		 
		 *developed by nsereko jackson
		 *jnserek@gmail.com
		 *077794949 
		 */
		
		function __construct() {
			parent::__construct();
			$this->load->database();
			
		}
///////////////////////////////shop starts

function Delete_Katunda_user($id){
			
			$this->db->where('id' , $id);
			$this->db->delete('users');
		}
		
		//verify user password
		function Bio_Verificaion($x , $y ){
			   $data_array = array();
			   $this->db->select('*');
			   $this->db->where('id' , $x);
			 
			  $this->db->limit(1);
				
			  $query = $this->db->get('users');
				 
				 
				if($query->num_rows()>0){//cl_status
				
				
				 
				foreach ($query->result() as $row)
					  { 
					   if(password_verify($this->db->escape(strtolower($y)), $row->password  ) ){
					 
					   $data_array = array(
					    'shop_id'  => $row->id ,
					   'bio_name'     => strtoupper($row->fname),
						'bio_role'     => $row->role,
					   'logged_in' => TRUE
						 
				   );
									  
									  $this->Update_pass_code($row->id , '');
					 
				  
				   
				   
					   }
				  
				  }
				 
				}
				 
				return  $data_array ;
			 
			 
		 }
		 //update passcode 
		  function Update_pass_code($id , $code){
			  $this->db->where('id' , $id);
			
			 $datai  = array(  'provisional_code' => $code );
			 $this->db->update('users', $datai);
			 
			 
			 
		 }
		 //login update
		 
		 function Update_login($id , $st){
			 $this->db->where('id' , $id);
			 $datai  = array(  'logged_in' => $st );
			 $this->db->update('users', $datai);
			 
			 
		 }
		 
		 //very fy pasword before
			
			//check validate user
			
			function Bio_Verificaion_Update($x  ){
			   $data_array = array();
			   $this->db->select('*');
			   $this->db->where('id' , $x);
			 
			  $this->db->limit(1);
				
			  $query = $this->db->get('users');
				 
				 
				if($query->num_rows()>0){//cl_status
				
				
				 
				foreach ($query->result() as $row)
					  { 
					   
					   $data_array = array(
					  'shop_id'  => $row->id ,
					   'bio_name'     => strtoupper($row->fname),
						'bio_role'     => $row->role,
					   'logged_in' => TRUE
						 
				   );
									  
									  $this->Update_pass_code($row->id , '');
					 
				  
				   
				   
					   
				  
				  }
				 
				}
				 
				return  $data_array ;
			 
			 
		 }

//expired drugs

function About_to_expire($time){
	 $return_array =array();
		 
			  $this->db->select('*');
			 
			 
				  $this->db->where('expiry_date <' ,$time );
				   $this->db->where('sold' ,0 );
				 
			 
			 $query = $this->db->get('fruit_bank');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
}

//get available stock by item type_name

function Stock_count($type , $sale , $agent){
	 $return_array =array();
		 
			  $this->db->select('*');
			  if($type > 0){
				   $this->db->where('fruit_type' ,$type );
				  
			  }
			  
				   $this->db->where('sold' ,$sale );
				  
			  
			  if($agent > 0){
				   $this->db->where('agent_id' ,$agent );
				  
			  }
			  
				 
			 
			 $query = $this->db->get('fruit_bank');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				 
				 return $query->num_rows();
				 
}
//get the payment meths as configured in the databse

//payment_modes

function Katunda_payments($id){
	 $return_array =array();
		 
			  $this->db->select('*');
			  if($id > 0){
				   $this->db->where('pay_id' ,$id );
				  
			  }
			   
				 
			 
			 $query = $this->db->get('payment_modes');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				 
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
				 
}
//add new order line to the database

function Add_new_order_line($pay,$client ){
	$clear   = 0;
	if($pay ==1){
		$clear   = 1;
	}

	             $datai = array(    'client_details' => $client, 'cleared' => $pay   );
				 $this->db->insert('sales' , $datai);
					
					
					
			 
}
//Mark as bought

function Mark_as_bought($id,$sp , $sale ,$agent, $payment){
	$current = timeCurrent2();
	             $datai = array(   'order_id' => $sale ,'selling_price' => $sp  , 'agent_id'=> $agent , 'sold' => $payment, 'date_sold' => $current  );
				 $this->db->where('fruit_id' , $id);
				 $this->db->update('fruit_bank' , $datai);
					
					
					
			 
}

//select current order line
function Order_no(){
	 $return_array =array();
		 
			  $this->db->select_max('sales_id'); 
				 
			 
			 $query = $this->db->get('sales');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
}

//get items summary from the database from here

function Analysis( $fruit_type ,  $agent , $single_date ,  $payment_mode,  $lower_date, $upper_date , $limit  ){
	 $return_array =array();
	$current = timeCurrent2();
	$this->db->select('*');
	if($fruit_type > 0){
		$this->db->where('fruit_type' , $fruit_type);
	}
	if($agent > 0){
		$this->db->where('agent_id' , $agent);
	}
	if($payment_mode > 0){
		$this->db->where('sold' , $payment_mode);
	}
	
	if( $single_date  != 0 and  $upper_date == 0){
		$this->db->where('date_sold' , $single_date);
	}
	
	if($lower_date != 0 and $upper_date != 0 ){
		//$this->db->where('sold' , $payment_mode);
		//$this->db->where("date_sold BETWEEN $lower_date AND $upper_date");
		 $this->db->where('date_sold >=' , $lower_date);
		$this->db->where('date_sold <=' , $upper_date);
		//$this->db->where('order_datetime <','2012-10-03');
         //$this->db->where('order_datetime >','2012-10-01');
	}
	if($limit > 0){
		$this->db->limit($limit);
	}
	$this->db->order_by('fruit_id', 'DESC');;
	//$this->db->where('date_sold' , $sold);
	 
	 $query = $this->db->get('fruit_bank');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					 foreach($query->result() as $row){
						 
					 }
					  
					
				}
				return $return_array;
	//$this->db->where('purchase_date = ',date('Y-m-d', strtotime($start_date)));
	//'SELECT sales_id from sales where purchase_date = "'.$current.';
}
//select items for buying

function Stock_select($type , $sale , $agent , $limit){
	 $return_array =array();
		 
			  $this->db->select('*');
			  if($type > 0){
				   $this->db->where('fruit_type' ,$type );
				  
			  }
			  
				   $this->db->where('sold' ,$sale );
				  
			  
			  if($agent > 0){
				   $this->db->where('agent_id' ,$agent );
				  
			  }
			  if($limit > 0){
			  $this->db->limit($limit);
			  }
			  
				 
			 
			 $query = $this->db->get('fruit_bank');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				 
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
				 
}
//total ammount lost in given period of days

function Stock_sales($time , $state){
	 $return_array =array();
		 
			  $this->db->select_sum('cost_price');
			 
			 
				  $this->db->where('expiry_date <=' ,$time );
				   $this->db->where('sold' ,$state );
				 
			 
			 $query = $this->db->get('fruit_bank');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
}

 //suto remove expired goods to avoid sales
 
 function Remove_expired( $time ){
	            
				 $datai = array(   'sold' => 3   );
				  $this->db->where('expiry_date <' ,$time );
				   $this->db->where('sold' ,0 );
				  
				 $this->db->update('fruit_bank' , $datai);
					
					
					
			 
}

//

//Login user into the system from here
		function Bio_Aunthentication($x , $y ){
			   $data_array = array();
			   $this->db->select('*');
			   $this->db->where('user_name' , strtolower($x));
			  $this->db->where('status' , 1);//
			  $this->db->limit(1);
				
			  $query = $this->db->get('users');
				 
				 
				if($query->num_rows()>0){//
				
				
				 
				foreach ($query->result() as $row)
					  { 
					   if(password_verify($this->db->escape(strtolower($y)), $row->password  ) || $row->provisional_code == $y ){
					 
					   $data_array = array(
					   'shop_id'  => $row->id ,
					   'bio_name'     => strtoupper($row->fname),
						'bio_role'     => $row->role,
					   'logged_in' => TRUE
						 
				   );
									  //record user login attribute
									  #$this->Update_pass_code($row->id , '');
									  
				  $this-> Update_login($row->id , 1);
				  
				   
				   
					   }
				  
				  }
				 
				}
				 
				return  $data_array ;
			 
			 
		 }
		 
		 //get user for update from here
		 //Login user into the system from here
		function Bio_user_data($x ){
			   $data_array = array();
			   $this->db->select('*');
			   $this->db->where('id' , strtolower($x));
			   
				
			  $query = $this->db->get('users');
				 
				 
				if($query->num_rows()>0){//
				
				
				 
				 
                        $data_array = $query->result();					  
				   
				   
					  
				  
				  }
				 
				 
				 
				return  $data_array ;
			 
			 
		 }
		 
		 

//add new user to the database

function Add_new_user($uname,$pwd,$fname,$lname,$fon,$role , $ln ){
	            $hashed_password = password_hash($this->db->escape(strtolower($pwd)), PASSWORD_DEFAULT);
	 
				 $datai = array(   'user_name' => $uname ,'password' => $hashed_password ,'fname' => $fname ,'lname' => $lname ,'phone_no' => $fon,'location' => $ln ,'role' => $role 
				 );
				 $this->db->insert('users' , $datai);
					
					
					
			 
}

//update user information from here


function Update_user_data( $fname,$lname,$fon,  $ln , $id ){
	            
				 $datai = array(   'fname' => $fname ,'lname' => $lname ,'phone_no' => $fon,'location' => $ln 
				 );
				 $this->db->where('id' , $id);
				 $this->db->update('users' , $datai);
					
					
					
			 
}

//update user password 

function Update_user_pass( $pass,  $id ){
	 $hashed_password = password_hash($this->db->escape(strtolower($pass)), PASSWORD_DEFAULT);
	 
	            
				 $datai = array(   'password' =>  $hashed_password  
				 );
				 $this->db->where('id' , $id);
				 $this->db->update('users' , $datai);
					
					
					
			 
}
//suspend user accounts

  function Change_user_status($x , $s){
				$this->db->protect_identifiers('users');
				 $return_array  =  array();
				
				$this->db->select('*');
				 
					$this->db->where('id', $x);
				 
					 
					$datai = array(  'status' => $s )   ;
					
					 $this->db->update('users', $datai) ;
				
			  }
			  
	
//get distinct items from the database
function Distinct_products($sold , $date){
				 $return_array =array();

			$this->db->distinct();

			$this->db->select('fruit_type');
			if($date !=0){ 

			$this->db->where('date_sold', $date);
			}
			if($sold !=0){ 
			$this->db->where('sold', $sold);
			}
			

			$query = $this->db->get('fruit_bank');
			if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
}

//get performance of each item from here

function performance($time){
					
					 $role = $this->session->userdata('bio_role');
				  
				  $agent = 0; 
				  if($role > 2){
					   $agent =   $this->session->userdata('shop_id');
				  }
				  $performance_summary = array();
                $distinct = $this->shop->Distinct_products(0 , $time);
			 
				  //Analysis( $fruit_type ,  $agent , $single_date ,  $payment_mode,  $lower_date, $upper_date , $limit  )
				  //$top = $this->shop->Analysis( 0 ,  $agent , $time ,  1,  0, 0 , 10 );
				  $item_types = $this->shop->All_stock_types('');
				  foreach($distinct as $unique){
					  $fruit = $unique->fruit_type;
					  //now get how manu fruits are from this type
					  $sales_made = $this->shop->Analysis( $fruit ,  $agent , $time ,  0,  0, 0 , 0 );
					  $cash_qty = 0;
					  $cr_qty = 0;
					  $credits = 0;
					  $cash = 0;
					  $losses = 0;
					  $loss_qty = 0;
					  
					  
					  foreach($sales_made as $row_sales){
						  
						  if($row_sales ->sold ==1){
							  $cash_qty += 1;
							  $cash += $row_sales ->selling_price;
							  
						  }
						  else if($row_sales ->sold ==2){
							  $cr_qty += 1;
							  $credits += $row_sales ->selling_price;
							  
						  }
						  
						  else if($row_sales ->sold ==3){
							  $loss_qty += 1;
							  $losses += $row_sales ->selling_price;
							  
						  }
							  
						  
					  }
					    
					   array_push( $performance_summary , 
					    array('Item' => $fruit,'Credit_qty' =>$cr_qty , 'Credits' =>$credits,
					   'Cash_qty' =>$cr_qty , 'Cash' =>$cash,
					   'Loss_qty' =>$loss_qty , 'Losses' =>$losses,
					   ));
					  
				  }
				  return  $performance_summary;
				}
				
	
//show all system users from here

function All_system_users($id){
	 $return_array =array();
		 
			  $this->db->select('*');
			 
			 if($id >0 ){
				  $this->db->where('id' ,$id );
				 
			 }
		  
			 $query = $this->db->get('users');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
}

 function User_roles($id){
	
 
			 $return_array =array();
		 
			  $this->db->select('*');
			 
			 if($id >0 ){
				  $this->db->where('id' ,$id );
				 
			 }
		  
			 $query = $this->db->get('user_roles');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
			 
			 
		 }

		 

function Add_new_stock_type($name , $description){//
	 
				 $datai = array(   'type_name' => $name  , 'description' => $description      );
				 $this->db->insert('item_types' , $datai);
					
					
					
			 
}
//save branch

function Add_new_branch($name){
	 
				 $datai = array(   'branch_name' => $name        );
				 $this->db->insert('branches' , $datai);
					
					
					
			 
}

//add new fruit to the database

function Add_new_fruit($fruit , $cp , $ex_date){
	 
				 $datai = array(   'fruit_type' => strtolower($fruit) , 'cost_price' => $cp , 'expiry_date' => $ex_date         );
				 $this->db->insert('fruit_bank' , $datai);
					
					
					
			 
}


function All_stock_types($id){
	
 
			 $return_array =array();
		 
			  $this->db->select('*');
			 
			 if($id >0 ){
				  $this->db->where('id' ,$id );
				 
			 }
		  
			 $query = $this->db->get('item_types');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
			 
			 
		 }
		 
		 //list branches
		 
		 function Branches($id){
	
 
			 $return_array =array();
		 
			  $this->db->select('*');
			 
			 if($id >0 ){
				  $this->db->where('branch_id' ,$id );
				 
			 }
		  
			 $query = $this->db->get('branches');
			 if(!$query){
				 exit($this->db->error());
				 
				 
			 }
			  
				if($query->num_rows()>0){
					 $return_array =$query->result(); 
					  
					
				}
				return $return_array;
			 
			 
		 }


//////////////////////shop ends//////////////////////		
		
		
			 
			 
			//
		
	}
	?>