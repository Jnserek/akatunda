 
<?php

 
				
				 $data1 = $_SESSION['Katunda_items'];
				  $data  = $data1[0];
				  $customer  = $data1[1];
?>
    <!-- Main content -->
    <section class="content" >
      <!-- Info boxes -->
      <div class="row" id="content_loaderj">
	  <form  onsubmit ="return Approve_cat();" method ="post">
	  
<div class="box">
            <div class="box-header">
              <h3 class="box-title"> Ordered Items(Fruits)</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			
			<!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          From
          <address>
            <strong>Katunda App</strong><br>
            
            <br>
            Phone: (+256)77794949<br>
            Email: jnserek@gmail.com
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          To
          <address>
            <strong><?php echo $customer[0]; ?></strong><br>
             
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          <b>Invoice #</b><br>
          <br>
          <b>Payment Method:</b> <?php  
		  
				  
				  $modes  = $this->shop->Katunda_payments($customer[1]);
		 
			 
			           foreach($modes as $row){//
					    echo  $row->pay_name ;
					   
					   }
				  
		  ?> <br>
         
        </div>
        <!-- /.col -->
      </div>
			
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				<th>#</th>
                  <th>Item</th>
				  <th>Item Desciption</th>
                   <th>Quantity</th>
                  <th>Unit Price</th>
				  <th>Total Price</th>
				  
                </tr>
                </thead>
                <tbody>
				
				
				<?php 
				
				 $data1 = $_SESSION['Katunda_items'];
				  $data  = $data1[0];
				 $grand_total  =0;
				 $count  =0;
						   foreach($data as $item){
							   $grand_total +=$item['Price']*$item['Qty'];
							   echo '<tr> <td>'.($count  +=1).' </td><td>'. $item['Item'].'</td><td>'. $item['Desc'].'</td><td>'. $item['Qty'].'</td>
							   <td>'.  $item['Price'].'</td><td>'.($item['Price']*$item['Qty']).'</td></tr>'; 
							  
							 
						 }
			 
					   
			?>
                
                </tbody>
                <tfoot>
                 <tr>
				   <th>#</th>
				   <th> </th>
                   <th>Grand Total</th>
                   <th> </th>
                   <th> </th>
				   <th><?php echo $grand_total; ?></th>
				  
                </tr>
                </tfoot>
              </table>
			   
             
            </div>
			 <div class="box-footer">
                <button type="button"   class="mybtn btn btn-warning col-md-4 btn-sm  " data-target="<?php echo base_url();?>">Cancel</button>
                <button type="submit" class="btn btn-info col-md-4 btn-sm pull-right">Submit</button>
              </div>
            <!-- /.box-body -->
          </div>
		  </form>
		  
        
         
        <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	
	 <script>
		   $('.mybtn').on('click', function(event) {
            event.preventDefault(); 
              var url = $(this).data('target');
               location.replace(url);
             });
  
</script>  
	 
      
	 
	 
	