 
          <?php
		   $expired  =   $this->shop->About_to_expire(AddDates(timeCurrent2() , 5));
			  //now auto expire those expired dates
			  // $this->shop->Remove_expired( timeCurrent2() );
		  ?>
		  
		    
		   <?php
		   $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  , 
		   'onSubmit'=>'return Summary_reports();' );

                             //echo form_open('home/Multiple_service_info', $attributes);
							 		
							  
		   ?>
		   <form method  ="post"  onSubmit ="return Summary_reports();" role ="form" > 
              <div class="box-body">
			  
          <div class="box box-danger"> 
            <div class="box-header with-border">
              <h3 class="box-title">Sales report generation form</h3>
            </div>
            <div class="box-body">
              <div class="row">
                <div class="form-group col-xs-2">
				<label> Item Type </label>
                  
                  <select class="form-control" name="item_type">
				  <option value ="0"> Item Type </option>
				  <?php
                    
               
				  $fruits = $this->shop->All_stock_types('');
				  $agents = $this->shop->All_system_users('');
				  
						 
						
					
						foreach($fruits as $fruit){
							echo '<option value ="'.$fruit->type_id.'" >'.$fruit->type_name.'('.$fruit->description.') </option>';
							 
						}
				  ?>
				  
				  </select>
                </div>
				<?php  $role = $this->session->userdata('bio_role');
				 if($role > 2){
					    
				   
				  ?>
				  <input type ="hidden"  name ="agent" value ="<?php echo $this->session->userdata('shop_id'); ?>" />
				  <?php
				  }
				  else {
				  ?>
				
				<div class="form-group col-xs-2">
				<label> Agent Name </label>
				 
                  <select class="form-control" name="agent">
				  <option value ="0"> Agent </option>
				  <?php 
				  $agents = $this->shop->All_system_users('');
				  foreach($agents as $agent_data){
							 
							echo '<option value ="'.$agent_data->id.'" >'.$agent_data->fname.'('.$agent_data->location.') </option>';
						
								
						 
							
						}
				  ?>
				  
				  </select>
                </div>
				  <?php  } ?>
				
				<div class="form-group col-xs-2">
				<label> Sale Type </label>
				
				<?php $payments  = $this->shop-> Katunda_payments('');
				 
				?>
				 
                  <select class="form-control" name="sale_type">
				  <option value ="0"> Sale Type </option>
				  <option value ="3"> Expired </option>
				  <?php 
				  //$agents = $this->shop->All_system_users('');
				  foreach($payments as $agent_data){
							 
							echo '<option value ="'.$agent_data->pay_id.'" >'.$agent_data->pay_name.' </option>';
						
								
						 
							
						}
				  ?>
				  
				  </select>
                </div>
				
                <div class="col-xs-2">
				<label> Date (yyyy-mm-dd)</label>
                  <input  name="d1" type="date" class="form-control" placeholder=".col-xs-2">
                </div>
                <div class="col-xs-2">
				<label> To date (yyyy-mm-dd)</label>
                  <input  name="d2"type="date" class="form-control" placeholder=".col-xs-2">
                </div>
				<div class="col-xs-2"><br />
                   <button type="submit" class="btn btn-info ">Submit</button>
                </div>
				 
              </div>
            </div>
			<div class="row" id="data_loader">
			</div>
            <!-- /.box-body -->
          </div>
		  </div>
		  </form>
 