

  <!-- Left side column. contains the logo and sidebar -->
 <?php 
 $this->view('shop/header');
$this->view('shop/left_slide_bar'); 
 
 ?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
	  
	  
	  
 <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Hover Data Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Description</th>
				  <th>Edit</th>
				  <th>Delete</th>
                </tr>
                </thead>
                <tbody>
				<?php 
			$stock   = $this->shop->All_stock_types('');
			foreach($stock as $row){
				echo '<tr ><td>'.$row->type_name.'  </td><td>'.$row->description.'  </td>
				<td>'.$row->type_id.'
				<div class="form-group">
                  <div class="radio">
                    <label>
                      <input type="radio" name="edit" id="optionsRadios1" value =  "'.$row->type_id.'"  checked>
                      Edit
                    </label>
                  </div>
				
				 
				</td>
				<td>'.$row->type_id.'
				<div class="form-group">
                  <div class="radio">
                    <label>
                      <input type="radio" name="delete" id="optionsRadios1" value =  "'.$row->type_id.'"  checked>
                      Delete
                    </label>
                  </div>
				
				 
				</td>
				
				</tr>';
				//print_r($row);
			}
			?>
                 
                 </tbody>
                <tfoot>
                <tr>
                  <th>Name</th>
                  <th>Description</th>
				  <th>Edit</th>
				  <th>Delete</th>
                   
                </tr>
                </tfoot>
              </table>
			   </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
				
		
		<!---- conent xxxxxxxxx -->
		   <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>
 

		
		 <?php $this->view('shop/footer');?>
		 
		 <script>
		 
		
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>