 <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
	     
       <?php   $role = $this->session->userdata('bio_role');
	   if($role < 3){
	   ?>
        <li class="treeview">
          <a href="<?php echo base_url();?>#">
            <i class="fa fa-pencil"></i>
            <span>Add New</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url();?>index.php/Home/New_butunda_type"><i class="fa fa-circle-o text-aqua"></i>   stock / Katunda type</a></li>
            <li><a href="<?php echo base_url();?>index.php/Home/Add_stock"><i class="fa fa-circle-o text-aqua"></i> Stock item(s)</a></li> 
			<?php if($role < 2){
	         ?>
			
            <li><a href="<?php echo base_url();?>index.php/Home/Add_user"><i class="fa fa-circle-o text-aqua"></i> User</a></li> 
			<?php } ?>
          </ul>
        </li>
	   <?php } ?>
      <?php if($role < 2){
	         ?>
       
        <li class="treeview">
          <a href="<?php echo base_url();?>#">
            <i class="fa fa-wrench"></i>
            <span>Manage</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
             
			<li><a href="<?php echo base_url();?>index.php/Home/All_users"><i class="fa fa-circle-o text-aqua"></i> Users</a></li>
             
          </ul>
        </li>
	  <?php } ?>
	   <?php if($role < 3){
	         ?>
		
		 <li class="treeview">
          <a href="<?php echo base_url();?>#">
            <i class="fa fa-pie-chart"></i>
            <span>Reports</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a  onclick  ="return Reports();" href=""><i class="fa fa-circle-o text-aqua"></i> Sales</a></li> 
           
		        </ul>
        </li>
	   <?php } ?>
		 <li>
		  
		 <a  href = "#"  onclick= "return Sales_form();"><i class="fa fa-dollar  "></i> <span>Sales</span></a></li>
       
		
        <li><a href="<?php echo base_url();?> "><i class="fa fa-book"></i> <span>Documentation</span></a></li>
           </ul>
    </section>
    <!-- /.sidebar -->
	
	
	
	
  </aside>