
  
  <div class="control-sidebar-bg"></div>
 
 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2017<a href="<?php echo base_url();?>">Nsereko Jackson</a>.</strong> All rights
    reserved.
  </footer>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="<?php echo base_url();?>plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?php echo base_url();?>dist/js/shop.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url();?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>dist/js/app.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?php echo base_url();?>plugins/slimScroll/jquery.slimscroll.min.js"></script>

<script src="<?php echo base_url();?>plugins/chartjs/Chart.min.js"></script>
<script src="<?php echo base_url();?>dist/js/pages/dashboard2.js"></script>
 
 
<!-- DataTables -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datepicker/bootstrap-datepicker.js"></script> 

 <input type ="hidden" id ='shop_url' value ="<?php echo base_url(); ?>" />
 <?php $return_string  ='';
		        $time = timeCurrent2();
				 
				  
				$performance   =  $this->shop->performance($time );
			 
				  $fruits = $this->shop->All_stock_types('');
				  foreach($performance as $perf){
					 
					  $fruit_name  = '';
					  foreach($fruits as $fruit){
							
						 
							
							if($fruit->type_id == $perf['Item']){
								$fruit_name  =  $fruit->type_name;
							}
						}
						 

$return_string  .= '{  
                    label: "'.$fruit_name.'",
                    value: '.$perf['Cash'].',
					  },
				  
				';
						
						 
					  
				  }
			 			 
				
	  ?> 
	    
<!-- page script -->
<script>


     //-------------
  //- PIE CHART -
  //-------------
  // Get context with jQuery - using jQuery's .get() method.
  var pieChartCanvas = $("#pieChart").get(0).getContext("2d");
  var pieChart = new Chart(pieChartCanvas);
  var PieData = [
  <?php  echo $return_string; ?>
     
  ];
  var pieOptions = {
    //Boolean - Whether we should show a stroke on each segment
    segmentShowStroke: true,
    //String - The colour of each segment stroke
    segmentStrokeColor: "#fff",
    //Number - The width of each segment stroke
    segmentStrokeWidth: 1,
    //Number - The percentage of the chart that we cut out of the middle
    percentageInnerCutout: 50, // This is 0 for Pie charts
    //Number - Amount of animation steps
    animationSteps: 100,
    //String - Animation easing effect
    animationEasing: "easeOutBounce",
    //Boolean - Whether we animate the rotation of the Doughnut
    animateRotate: true,
    //Boolean - Whether we animate scaling the Doughnut from the centre
    animateScale: false,
    //Boolean - whether to make the chart responsive to window resizing
    responsive: true,
    // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
    maintainAspectRatio: false,
    //String - A legend template
    legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<segments.length; i++){%><li><span style=\"background-color:<%=segments[i].fillColor%>\"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>",
    //String - A tooltip template
    tooltipTemplate: "<%=value %> /= <%=label%> "
  };
  //Create pie or douhnut chart
  // You can switch between pie and douhnut using the method below.
  pieChart.Doughnut(PieData, pieOptions);
  //-----------------
  //- END PIE CHART -
  //-----------------
  
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
  
    $('.suspend').click(function() {
            var item = $(this).attr("value");
			 
			 BioCustom2( 'Home' , 'Suspend' ,    item , item  )
			 
        });
		
		  $('.activate').click(function() {
            var item = $(this).attr("value");
		 
			 BioCustom2( 'Home' , 'Activate' ,    item , item  )
			 
        });
		  $('.alt_user').click(function() {
            var item = $(this).attr("value");
			 
			 BioCustom2( 'Home' , 'Edit_user' ,    item , item  )
			 
        });
		//
		
		 $('.pass_update').click(function() {
            var item = $(this).attr("value");
			 
			 BioCustom2( 'Home' , 'Delete_user' ,    item , item  )
			 
        });
		
		
	 
</script>


<script>
  $(function () {
    //Initialize Select2 Elements
	 //$("#datepicker").inputmask("yyyy/mm/dd", {"placeholder": "yyyy/mm/dd"});
   
    
    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    });

     

     
 
  });
</script>
 

</body>
</html>