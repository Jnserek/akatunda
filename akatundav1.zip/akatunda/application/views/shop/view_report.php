<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Report Results </h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                 <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Item</th>
					<th>Agent</th>
                    <th>Cost Price</th>
                    <th>Selling Price</th>
					
                  </tr>
                  </thead>
                  <tbody>
				  <?php
				      $role = $this->session->userdata('bio_role');
				   
				  $agent = 0; 
				  if($role > 2){
					   $agent = $this->session->userdata('shop_id');
				  }
				  //Analysis( $fruit_type ,  $agent , $single_date ,  $payment_mode,  $lower_date, $upper_date , $limit  )
				  $top = $this->shop->Analysis( $info[0] ,  $agent , $info[2] ,  $info[3],  $info[4], $info[5] , 0 );
					 $count  =0;
					 $cost_price  = 0;
					 $selling_price  = 0;
					foreach($top as $sales){ 
						$fruits = $this->shop->All_stock_types('');
						$item_name  = '';
						$fruit_name  = '';
						$agent_name  = '';
						
						$agents = $this->shop->All_system_users('');
					
						foreach($fruits as $fruit){
							
						 
							
							if($fruit->type_id == $sales->fruit_type){
								$fruit_name  =  $fruit->type_name;
							}
						}
						 
						foreach($agents as $agent_data){
							//$sales->agent_id
							if($agent_data->id == $sales->agent_id){
								$agent_name  = $agent_data->fname;
							}
								
						 
							
						}//$count  =0
						 
						 $cost_price  += $sales->cost_price;
					     $selling_price  += $sales->selling_price;
						echo '<tr> 
						<td>'.($count  +=1).' </td>
						<td> <a href="">'.$fruit_name.' </a> </td>
						<td>'.$agent_name.' </td>
						
						<td> <span class="label label-info">'.$sales->cost_price.' </span></td>
						 
						<td> <span class="label label-success">'.$sales->selling_price.' </span></td>
						</tr>';
					}
				  
				  ?>
				  <tr>
                     <td colspan =3 > Total </td>
					  
                    <td><?php echo $selling_price; ?></td>
                    <td>
                      <?php echo $cost_price; ?>
                    </td>
                  </tr>
                   
                   
                  </tbody>
                </table>
				 
				
				
				
              </div>
              <!-- /.table-responsive -->
            </div>
            
          </div>