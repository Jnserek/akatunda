


  <!-- Left side column. contains the logo and sidebar -->
 <?php 
  #$user = $this->session->userdata('shop_id');
 //get user bio data like name from here
  // $user = $this->session->userdata('bio_name');
  //get users roles
   //// $role = $this->session->userdata('bio_role');
  //
 
  $this->view('shop/header');
 $this->view('shop/left_slide_bar'); 


//$
 
 ?>
   <!-- DataTables -->
 

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboar
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content" >
      <!-- Info boxes -->
      <div class="row" id="content_loaderx">
	  
<div class="box">
            <div class="box-header">
              <h3 class="box-title"> All System Users</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Phone Number</th>
                  <th>User Name</th>
                  <th>Status</th>
				  <th><span class="badge bg-yellow">Suspend </span></th>
				  <th><span class="badge bg-blue">Edit </span></th>
				  <th><span class="badge bg-red">Delete</span></th>
                </tr>
                </thead>
                <tbody>
				<?php 
			$stock   = $this->shop->All_system_users('');
			 
			           foreach($stock as $row){//
					   $state  = 'Active';
					   $Action  = 'Suspend';
					   if($row->status  ==0){
						   $state  = 'Not Active';
					   }
					   
					   
						   
						   
						   echo '<tr><td>'.$row->fname.' </td> <td>'.$row->lname.' </td> <td>'.$row->phone_no.' </td> <td>'.$row->user_name.' </td> <td>'.$state.' </td>
						   <td>';
						   if($row->status  ==1){//
						   
						   echo '<button  class  ="suspend  btn btn-warning "  value ="'.$row->id.'" >  Suspend</button>';
						   }
						   else echo '<button  class  ="activate  btn btn-info btn-sm "  value ="'.$row->id.'" >  Activate</button>';

						   echo ' </td> 
						   <td>   <button  class  ="alt_user  btn btn-info btn-sm "  value ="'.$row->id.'" >  Edit</button> </td>
						   <td>   <button  class  ="pass_update  btn btn-info btn-sm "  value ="'.$row->id.'" >  Delete</button> </td> 
						   
						    
						   </tr>';
			           }
			?>
                
                </tbody>
                <tfoot>
                <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Phone Number</th>
                  <th>User Name</th>
                  <th>Status</th>
				  <th>Suspend</th>
				  <th>Edit</th>
				  <th>Delete</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        
         
        <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>
     
 
      
     <?php $this->view('shop/footer');?>
	 
	 
	