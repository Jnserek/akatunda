

  <!-- Left side column. contains the logo and sidebar -->
 <?php 
  #$user = $this->session->userdata('shop_id');
 //get user bio data like name from here
   $user = $this->session->userdata('bio_name');
  //get users roles
    $role = $this->session->userdata('bio_role');
  //
 
 $this->view('shop/header');
$this->view('shop/left_slide_bar'); 


//$
 
 ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row"   id="content_loaderx">
	  <?php if($role < 3){ ?>
        <div class="col-md-4 col-sm-6 col-xs-12">
		<?php 
		   $losses  =   $this->shop->Stock_sales(timeCurrent2()  , 3);
			   
			    $sales  =   $this->shop->Stock_sales(timeCurrent2()  , 1);
				 $tloss  = $tsales  = 0;
				foreach($sales as $sale){
					  $tsales  = $sale->cost_price;
				}
				 
				foreach($losses as $los){
					  $tloss  = $los->cost_price;
				}
			   
		?>
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-warning"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">  Expire in 5 days<?php   
			  
			  $expired  =   $this->shop->About_to_expire(AddDates(timeCurrent2() , 5));
			  //now auto expire those expired dates
			   $this->shop->Remove_expired( timeCurrent2() );
			   
			 
			  ?></span>
              <span class="info-box-number"><?php echo sizeof($expired);?><small> Items</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-times"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Losses</span>
              <span class="info-box-number"><?php echo $tloss ; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
	  

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-4 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-cart-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Sales</span>
              <span class="info-box-number"><?php echo $tsales; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
		<?php } ?>
        
        <!-- /.col -->
     
	   <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <div class="col-md-8">
		
	  
	  
			
			<div class="box box-info">
            <div class="box-header with-border">
              
			   <h3 class="box-title">
			   <?php if($role < 3){ ?>
			  Latest 10 Sales
			   <?php } else { ?>
			   My Latest 10 Sales
			   <?php }?>
			  </h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th>Item</th>
					<th>Agent</th>
                    <th>Cost Price</th>
                    <th>Selling Price</th>
					
                  </tr>
                  </thead>
                  <tbody>
				  <?php
				  $time = timeCurrent2();
				  echo $role;
				  $agent = 0; 
				  if($role > 2){
					  echo  $agent = $this->session->userdata('shop_id');
				  }
				  //Analysis( $fruit_type ,  $agent , $single_date ,  $payment_mode,  $lower_date, $upper_date , $limit  )
				  $top = $this->shop->Analysis( 0 ,  $agent , $time ,  1,  0, 0 , 10 );
					 $count  =0;
					 $cost_price  = 0;
					 $selling_price  = 0;
					foreach($top as $sales){ 
						$fruits = $this->shop->All_stock_types('');
						$item_name  = '';
						$fruit_name  = '';
						$agent_name  = '';
						
						$agents = $this->shop->All_system_users('');
					
						foreach($fruits as $fruit){
							
						 
							
							if($fruit->type_id == $sales->fruit_type){
								$fruit_name  =  $fruit->type_name;
							}
						}
						 
						foreach($agents as $agent_data){
							//$sales->agent_id
							if($agent_data->id == $sales->agent_id){
								$agent_name  = $agent_data->fname;
							}
								
						 
							
						}//$count  =0
						 
						 $cost_price  += $sales->cost_price;
					     $selling_price  += $sales->selling_price;
						echo '<tr> 
						<td>'.($count  +=1).' </td>
						<td> <a href="">'.$fruit_name.' </a> </td>
						<td>'.$agent_name.' </td>
						
						<td> <span class="label label-info">'.$sales->cost_price.' </span></td>
						 
						<td> <span class="label label-success">'.$sales->selling_price.' </span></td>
						</tr>';
					}
				  
				  ?>
				  <tr>
                     <td colspan =3 > Total </td>
					  
                    <td><?php echo $selling_price; ?></td>
                    <td>
                      <?php echo $cost_price; ?>
                    </td>
                  </tr>
                   
                   
                  </tbody>
                </table>
				 
				
				
				
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
			  <?php if($role < 3){ ?>
              <a href="javascript:void(0)" onclick= "return Reports();" class="btn btn-sm btn-info btn-flat pull-left">View More</a>
			<?php }  ?>
              
            </div>
            <!-- /.box-footer -->
          </div>
		  
		
		<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">
			   <?php if($role < 3){ ?>
			  Sales Performance
			   <?php } else { ?>
			   My performance
			   <?php }?>
			  </h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                 
				<table class="table no-margin">
                  <thead>
                  <tr>
                    <th>#</th>
                    <th   >Item</th>
					<th colspan =3 >Quantities</th>
					<th colspan =3 >Revenue</th>
					 
					
                  </tr>
				  <tr>
                    <th>#</th>
                    <th>Item</th>
					<th>Credit</th>
					 <th>Expired</th>
					<th>Cash</th>
					
					<th>Credit</th>
					 <th>Expired</th>
					<th>Cash</th>
					
                    
					
                  </tr>
                  </thead>
                  <tbody>
				
				  <?php
		        $time = timeCurrent2();
				$total_cash   =$total_credit   =$total_loss   =$count   =0;
				  
				$performance   =  $this->shop->performance($time );
			 
				  $fruits = $this->shop->All_stock_types('');
				  foreach($performance as $perf){
					 
					  $fruit_name  = '';
					  foreach($fruits as $fruit){
							
						 
							
							if($fruit->type_id == $perf['Item']){
								$fruit_name  =  $fruit->type_name;
							}
						}
						 
$return_string  ='';
$return_string  .= '{  
                    label: "'.$fruit_name.'",
                    value: '.$perf['Cash'].',
					
                     
                },
				  
				';
						
						//
						$total_cash   +=$perf['Cash'];
						$total_credit   +=$perf['Credits'];
						$total_loss   +=$perf['Losses'];
					  echo '<tr> <td> '.($count   +=1).'</td><td>'.$fruit_name.' </td>
					  <td>'.$perf['Credit_qty'].' </td>
					   <td>'.$perf['Loss_qty'].' </td>
					   <td>'.$perf['Cash_qty'].' </td>
					  
					  <td>'.$perf['Credits'].' </td>
					    <td>'.$perf['Losses'].' </td>
					  <td>'.$perf['Cash'].' </td>
					 </tr>';
					  
				  }
			 			 
				
	  ?> 
	    
				 
	                <tr>
                    <th>#</th>
                    <th>Item</th>
					<th>Credit</th>
					 <th>Expired</th>
					<th>Cash</th>
					
					<th><?php  echo $total_cash;  ?></th>
					 
					<th><?php  echo $total_loss; ?></th>
					<th><?php  echo $total_credit; ?></th>
					
                    
					
                  </tr>
                   
                   
                  </tbody>
                </table>
				
				
				
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
			 <?php if($role < 3){ ?>
              <a href="javascript:void(0)" onclick= "return Reports();" class="btn btn-sm btn-info btn-flat pull-left">View More</a>
			<?php }  ?>
                </div>
            <!-- /.box-footer -->
          </div>
		  
		  
          
		  </div>
	  
	  <div class="col-md-4">
           
		  
		  <div class="box box-default">
            <div class="box-header with-border">
               <h3 class="box-title">
			   <?php if($role < 3){ ?>
			  Sales Performance
			   <?php } else { ?>
			   My performance
			   <?php }?>
			  </h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-10">
                  <div class="chart-responsive"> 
                    <canvas id="pieChart" height="250"></canvas> 
                  </div>
                  <!-- ./chart-responsive -->
                </div>
                <!-- /.col -->
                 
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
			</div>
			
			
		  </div>
		  </div>
		  </div>
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>
  
 

      
     <?php $this->view('shop/footer');?>
