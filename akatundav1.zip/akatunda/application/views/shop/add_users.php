

  <!-- Left side column. contains the logo and sidebar -->
 <?php 
 $this->view('shop/header');
$this->view('shop/left_slide_bar'); 
 
 ?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
	  
	  
	  
 <div class="col-md-10"> 
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">New User</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
			<?php 
	 
	//echo validation_errors(); 
  
     $attributes = array('class' => 'form-horizontal', 'id' => 'login'   );

      echo form_open('Home/Save_user', $attributes);
?> 
              <div class="box-body">
                 
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">First Name</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="name"  value ="<?php echo set_value('name'); ?>"  required id="inputPassword3" placeholder="Type name">
					
                  </div>
				  <?php echo form_error('name'); ?>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Last Name</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="lname"  value ="<?php echo set_value('lname'); ?>"  required id="inputPassword3" placeholder="Type name">
					
                  </div>
				  <?php echo form_error('lname'); ?>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Phone Number</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="fon"  value ="<?php echo set_value('fon'); ?>"  required id="inputPassword3" placeholder="Phone number">
					
                  </div>
				  <?php echo form_error('fon'); ?>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Location</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="location"  value ="<?php echo set_value('location'); ?>"  required id="inputPassword3" placeholder="Type Location">
					
                  </div>
				  <?php echo form_error('location'); ?>
                </div>
				 
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">User Role</label>

                  <div class="col-sm-6">
				  <select class="form-control" name="branch" >
				 
					  <option value="3" >Agent</option>';
					<?php
					$stock   = $this->shop->User_roles('');
			           foreach($stock as $row){
						   
						   
						   echo ' <option value="'.$row->id.'">'.$row->role_name.'</option>';
			           }
					?>
                    
                  </select>
				   
                  </div>
				  <?php echo form_error('branch'); ?>
                </div>
				
				
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">User name</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control"  <?php echo set_value('Unsername'); ?> name ="Unsername"  required id="inputPassword3" placeholder="Unsername">
                  </div>
				  <?php echo form_error('Unsername'); ?>
                </div>
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Password</label>

                  <div class="col-sm-6">
                    <input type="password" class="form-control" name ="pass"   <?php //echo set_value('pass'); ?> required id="inputPassword3" placeholder="Password">
					 
                  </div>
				  <?php echo form_error('pass'); ?>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Confirm password</label>

                  <div class="col-sm-6">
                    <input type="password" class="form-control" name ="pass2"     required id="inputPassword3" placeholder="confirm password">
					<br />
					<button type="submit" class="mybtn btn btn-success col-md-4 btn-sm " data-target="<?php echo base_url();?>">Submit</button>
             
					
                  </div>
				   
                </div>
               
              
			   </div>
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
         
          <!-- /.box -->
        </div>
		
		<!---- conent xxxxxxxxx -->
		   <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>
 

		
		 <?php $this->view('shop/footer');?>