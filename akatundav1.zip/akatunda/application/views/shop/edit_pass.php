

  <!-- Left side column. contains the logo and sidebar -->
 <?php 
 $this->view('shop/header');
$this->view('shop/left_slide_bar'); 
 
 ?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
	  
	  	  
 <div class="col-md-12"> 
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Update User Password</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
			<?php 
	 
	//echo validation_errors(); 
	 
					$stock   = $this->shop->Bio_user_data($info);
					
					 
  
     $attributes = array('class' => 'form-horizontal', 'id' => 'login'   );
	// print_r($stock );
			           
						   
						  

      echo form_open('Home/Update_user_profile', $attributes);
?> 
              <div class="box-body">
                 
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Old Password</label>

                  <div class="col-sm-6">
                    <input type="password" class="form-control" name ="pass"   <?php echo set_value('pass'); ?> required id="inputPassword3" placeholder="Enter Old Password">
					 
                  </div>
				  <?php echo form_error('pass'); ?>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">New Password</label>

                  <div class="col-sm-6">
                    <input type="password" class="form-control" name ="pass2"     required id="inputPassword3" placeholder="confirm password">
					<br />
					<button type="submit" class="mybtn btn btn-success col-md-4 btn-sm " data-target="<?php echo base_url();?>">Submit</button>
             
					
                  </div>
				   
                </div>
				 
				 
				
				 
               
             
             
			   </div>
              <!-- /.box-footer -->
            </form>
					    
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
         
          <!-- /.box -->
        </div>
		 
	  
	  
	  
  
		<!---- conent xxxxxxxxx -->
		   <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>
 

		
		 <?php $this->view('shop/footer');?>

  
 
	  


		
	 