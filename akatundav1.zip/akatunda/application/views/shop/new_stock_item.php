

  <!-- Left side column. contains the logo and sidebar -->
 <?php 
 $this->view('shop/header');
$this->view('shop/left_slide_bar'); 
 
 ?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
	  
	  
	  
 <div class="col-md-10"> 
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">New stock item</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
			<?php 
	 
	echo validation_errors(); 
  
     $attributes = array('class' => 'form-horizontal', 'id' => 'login'   );

      echo form_open('Home/Save_item', $attributes);
?> 
              <div class="box-body">
                 
                 
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Type description  </label>

                  <div class="col-sm-6">
				   
				  <select class="form-control" name="item" >
				 
					   
					<?php
					$stock   = $this->shop->All_stock_types('');
					print_r($stock );
			           foreach($stock as $row){
						   
						   
						   echo ' <option value="'.$row->type_id.'">'.$row->type_name.' >>'.$row->description.'</option>';
			           }
					?>
                    
                  </select>
				  <?php echo form_error('item'); ?>
                    
                  </div>
                </div>
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Quantity</label>

                  <div class="col-sm-6">
                    <input type="number" class="form-control"  value ="<?php echo set_value('Quantity'); ?>" name ="Quantity"  required id="inputPassword3" placeholder="Quantity">
                  </div>
				  <?php echo form_error('Quantity'); ?>
                </div>
				
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Expiry Date</label>

                  <div class="col-sm-6">
                     
              
               

                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" class="form-control pull-right" value ="<?php echo set_value('exp_date'); ?>" id="datepicker" name="exp_date">
                </div>
                
				  
				  </div>
				  
				  <?php echo form_error('exp_date'); ?>
                </div>
				
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Cost Price</label>

                  <div class="col-sm-6">
                    <input type="number" class="form-control" name ="costp"   <?php echo set_value('costp'); ?> required id="inputPassword3" placeholder="Cost price">
					 <?php echo form_error('costp'); ?>
					 <br />
					<button type="submit" class="mybtn btn btn-success col-md-4 btn-sm " data-target="<?php echo base_url();?>">Submit</button>
             
                  </div>
                </div>
				
			
			 
               
              </div>
             
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
         
          <!-- /.box -->
        </div>
		
		<!---- conent xxxxxxxxx -->
		   <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>
 

		
		 <?php $this->view('shop/footer');?>