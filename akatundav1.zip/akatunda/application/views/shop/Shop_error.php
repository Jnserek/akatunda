 <!-- Left side column. contains the logo and sidebar -->
 <?php 
 $this->view('shop/header');
$this->view('shop/left_slide_bar'); 
 
 ?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Akatunda
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
	  
	  
	  
<div class="col-md-12">
      <div class="box box-solid box-warning">
        <div class="box-header">
          <h3 class="box-title">Success </h3>
        </div><!-- /.box-header -->
        <div class="box-body">
          <?php echo $info; ?>
        </div><!-- /.box-body -->
		 
		  <div class="box-footer">
		  <form  id  ="submit" >
                
               <button type="submit" class="mybtn btn btn-warning col-md-2 btn-sm pull-right" data-target="<?php echo base_url();?>">OK</button>
              
				</form>
				</div>
      </div><!-- /.box -->
    </div>
	
	<!---- conent xxxxxxxxx -->
		   <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>

  

		
		 <?php $this->view('shop/footer');?>
		   <script>
		   $('.mybtn').on('click', function(event) {
            event.preventDefault(); 
              var url = $(this).data('target');
               location.replace(url);
             });
  
</script>  