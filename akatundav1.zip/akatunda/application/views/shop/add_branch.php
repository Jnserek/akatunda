

  <!-- Left side column. contains the logo and sidebar -->
 <?php 
 $this->view('shop/header');
$this->view('shop/left_slide_bar'); 
 
 ?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
	  
	  
	  
 <div class="col-md-10"> 
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Add stock category</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
			<?php 
	 
	echo validation_errors(); 
  
     $attributes = array('class' => 'form-horizontal', 'id' => 'login'   );

      echo form_open('Home/Save_branch', $attributes);
?> 
              <div class="box-body">
                 
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Branch name  </label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="name"   required id="inputPassword3" placeholder="type name">
                  </div>
                </div>
				 
               
              </div>
              <!-- /.box-body -->
              <div class="box-footer"><div class="col-sm-4"> </div>
			   <div class="col-sm-6">
                
                <button type="submit" class="btn btn-success btn-xm    ">Submit</button>
              </div>
			  </div>
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
         
          <!-- /.box -->
        </div>
		
		<!---- conent xxxxxxxxx -->
		   <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>
 

		
		 <?php $this->view('shop/footer');?>