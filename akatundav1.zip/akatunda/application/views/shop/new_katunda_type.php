

  <!-- Left side column. contains the logo and sidebar -->
 <?php 
 $this->view('shop/header');
$this->view('shop/left_slide_bar'); 
 
 ?>
 
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 1.0 </small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
	  
	  
	  
 <div class="col-md-10"> 
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Add stock category</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
			<?php 
	 
	echo validation_errors(); 
  
     $attributes = array('class' => 'form-horizontal', 'id' => 'login'   );

      echo form_open('Home/Add_new_stock', $attributes);
?> 
              <div class="box-body">
                 
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Add New Stock type / Stock</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="name"   required id="inputPassword3" placeholder="Type name">
					
                  </div>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Fruit description (12 pack, 6 pack)</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="description"  required id="inputPassword3" placeholder="Description">
					
					<br />
					<button type="submit" class="mybtn btn btn-success col-md-4 btn-sm " data-target="<?php echo base_url();?>">Submit</button>
             
                  </div>
                </div>
				 
               
              </div>
               
              <!-- /.box-footer -->
            </form>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
         
          <!-- /.box -->
        </div>
		
		<!---- conent xxxxxxxxx -->
		   <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	 <!-- /.content -->
  </div>
 

		
		 <?php $this->view('shop/footer');?>