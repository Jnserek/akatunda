 
	  
	  
<div class="col-md-12">
      <div class="box box-solid box-success">
        <div class="box-header">
          <h3 class="box-title">Success </h3>
        </div><!-- /.box-header -->
        <div class="box-body">
          <?php echo $info; ?>
        </div><!-- /.box-body -->
		 
		  <div class="box-footer">
		  <form  id  ="submit" >
                
               <button type="submit" class="mybtn btn btn-success col-md-2 btn-sm pull-right" data-target="<?php echo base_url();?>">OK</button>
              
				</form>
				</div>
      </div><!-- /.box -->
    </div>
	 
  

		
		 
		   <script>
		   $('.mybtn').on('click', function(event) {
            event.preventDefault(); 
              var url = $(this).data('target');
               location.replace(url);
             });
  
</script>  