

  
 
	  
	  
 <div class="col-md-12"> 
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Profile information</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
			<?php 
	 
	//echo validation_errors(); 
	 
					$stock   = $this->shop->Bio_user_data($info);
					
					 
  
     $attributes = array('class' => 'form-horizontal', 'id' => 'login'   );
	// print_r($stock );
			           foreach($stock as $row){
						   
						   
						  // echo ' <option value="'.$row->id.'">'.$row->role_name.'</option>';
			           

      echo form_open('Home/Edit_user_profile', $attributes);
?> 
              <div class="box-body">
                 
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">First Name</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="name"  value ="<?php echo $row->fname; ?>"  required id="inputPassword3" placeholder="Type name">
					
                  </div>
				  <?php echo form_error('name'); ?>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Last Name</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="lname"  value ="<?php echo $row->lname; ?>"  required id="inputPassword3" placeholder="Type name">
					
                  </div>
				  <?php echo form_error('lname'); ?>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Phone Number</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="fon"  value ="<?php echo $row->phone_no; ?>"  required id="inputPassword3" placeholder="Phone number">
					
                  </div>
				  <?php echo form_error('fon'); ?>
                </div>
				
				<div class="form-group">
                  <label for="inputPassword3" class="col-sm-4 control-label">Location</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name ="location"  value ="<?php  echo $row->location; ?>"  required id="inputPassword3" placeholder="Type Location">
					 <?php echo form_error('location'); ?>
					<br />
					<button type="submit" class="mybtn btn btn-success col-md-4 btn-sm " data-target="<?php echo base_url();?>">Submit</button>
             
                  </div>
				  
				  <input type="hidden" class="form-control" name ="id"  value ="<?php  echo $row->id; ?>"  >
					
				 
                </div>
				 
				 
				
				 
               
             
             
			   </div>
              <!-- /.box-footer -->
            </form>
					   <?php  } ?>
          </div>
          <!-- /.box -->
          <!-- general form elements disabled -->
         
          <!-- /.box -->
        </div>
		 

		
	 