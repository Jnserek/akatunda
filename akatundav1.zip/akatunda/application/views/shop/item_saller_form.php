 

    <!-- Main content -->
    <section class="content" >
      <!-- Info boxes -->
      <div class="row" id="content_loaderj">
	  <form  onsubmit ="return Continue_to_cat();" method ="post">
	  
<div class="box">
            <div class="box-header">
              <h3 class="box-title"> Sale Items</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			 <div class="form-group has-error">
                  <label>Method of payment</label>
				  
				  <select required class  ="form-control" id="payment">
                   			  
				  <?php 
				  
				  $modes  = $this->shop->Katunda_payments('');
		 
			 
			           foreach($modes as $row){//
					    echo '<option value ="'.$row->pay_id.'" > '.$row->pay_name.'</option>';
					   
					   }
				  ?>
				  
				  </select>
                   
                </div>
				<br />
				<h4>  Item Details</h4>
			
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Item</th>
                  <th>Info</th>
                  <th>  Available (Qty)</th>
                  <th>Order (Qty)</th>
                  <th>Unit Price</th>
				  
                </tr>
                </thead>
                <tbody>
				<?php 
			$stock   = $this->shop->All_stock_types('');
		 
			 
			           foreach($stock as $row){//
					   
					   $available = $this->shop->Stock_count($row->type_id , 0 , 0);
					   if( $available > 0){
					    
					   
					   
						   
						   
						   echo '<tr><td>
						   <input type ="hidden" value ="'.$row->type_name.'" class ="item_desc" />
						   <input type ="hidden" value ="'.$row->type_id.'" class ="item" />'.$row->type_name.' </td> 
						   <td>'.$row->description.' </td> 
						   <td class =" col-xs-2" >'.$available.' </td>
						   <td class =" col-xs-2" ><select  class ="qty form-control input-sm" >
						   <option value ="0">Select </option>
						   '
						   
						   ;
						   for ($i=1; $i <=  $available; $i++){
							   echo '<option value ="'.$i.'">'.$i.' </option>';
						   }
							   
						   
						  echo  '</select> </td> 
						   <td class =" col-xs-2" ><input type ="number"   name ="price" class ="price form-control input-sm col-xs-4" /> </td> 
						   
						   <td> 
						   </tr>';
					   }
			           }
			?>
                
                </tbody>
                <tfoot>
                <tr>
                    <th>Item</th>
                  <th>Info</th>
                  <th>  Available (Qty)</th>
                  <th>Order (Qty)</th>
                  <th>Unit Price</th>
				  
                   
                </tr>
                </tfoot>
              </table>
			   
             
            </div>
			 <div class="box-footer">
			 <div class="form-group has-error">
                  <label>Customer Details</label>
                  <textarea class="form-control " rows="3" id ="Customer"  placeholder="Enter ..."> N/A</textarea>
                </div>
                <button type="button"   class="mybtn btn btn-warning col-md-4 btn-sm  " data-target="<?php echo base_url();?>">Cancel</button>
                <button type="submit" class="btn btn-info col-md-4 btn-sm pull-right">Submit</button>
              </div>
            <!-- /.box-body -->
          </div>
		  </form>
		  
        
         
        <!-- /.col -->
      </div>
      <!-- /.row -->
	   <!-- /.row -->
    </section>
	
	 <script>
		   $('.mybtn').on('click', function(event) {
            event.preventDefault(); 
              var url = $(this).data('target');
               location.replace(url);
             });
  
</script>  
	 
      
	 
	 
	