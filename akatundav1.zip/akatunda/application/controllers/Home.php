<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 public function __construct()

        {
                parent::__construct();
				//$this->load->library('session');

               
        }
	public function index()
	{
		 $log_id = $this->session->userdata();
		 
		 if(LoadValid() ){
			
		$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 
		 
		     $this->load->view('shop/Home_page');//
			  
		 
		}
		else{
			$this->LogoutUser();
			
		}
		 }else redirect('Error', 'refresh');
	}
	
		
		function LogoutUser(){
			 $user = $this->session->userdata('bio_id');
			     
			     $this->shop-> Update_login($user , 0); 
			     
			          
					 
				 $this->session->sess_destroy();
				 
				  redirect('Login', 'refresh');
			
		}
		//add new katunda type
		function New_butunda_type(){
			$this->check_user();
			$this->load->view('shop/new_katunda_type');
			
			
		}
		//get report generation form
		function Report_form(){
			$this->check_user();
			$this->load->view('shop/Report_generator');
		}
		function Process_report(){
			$this->check_user();
			//$this->form_validation->set_rules('item_type', 'Item Type', 'trim|xss_clean');
			 $item= $this->input->post('item_type');
			
			 $agent = $this->input->post('agent');
			 $sale_type = $this->input->post('sale_type');//
			  $d1 = $this->input->post('d1');//
			   $d2 = $this->input->post('d2');//
			   $date_lower  =  $date_upper  =  $date_single  = 0;
			    
			  if($d1 !=''){ 
			     $date_lower  = $d1;//FormatTime2($d1);
			  }
			  if($d2 !=''){ 
			      $date_upper  = $d2;// FormatTime2($d2);
			  }
			   if($d1 !='' and $d2 ==''){ 
			   $date_single  = $date_lower; 
			   }
			   
			   
			$current = timeCurrent2();
			//view_report.php
			 $data['info']  =  array($item ,  $agent , $date_single ,  $sale_type,  $date_lower, $date_upper );
			 $this->load->view('shop/view_report' , $data);
			 
				 
			
		}
		
		function New_stock_type(){
			$this->check_user();
			$this->load->view('shop/Add_stock_type');
			
			
		}
		function Add_new_stock(){
			$this->check_user();
			  $this->form_validation->set_rules('name', 'name', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha_numeric_spaces');
				$this->form_validation->set_rules('description', 'Fruit Category', 'trim|min_length[1]|max_length[55]|xss_clean');
				 
				 
				 if ($this->form_validation->run() == FALSE)
					{
						 
						 $this->load->view('shop/new_katunda_type');
						 
							
					}
					else
					{
						  $name = $this->input->post('name');
						  $description = $this->input->post('description');
						  $this->shop->Add_new_stock_type($name , $description);
						  $this->Success('Cat item type  successfully added');
						  
						   
						   
						   
						  
					
				   }
									  

				}
				//List stock types
				function All_stock_types(){
					$this->check_user();
					$this->load->view('shop/List_stock_types'); 
					
				}
				
				///////stock items///////////
				
				function Add_stock(){ //load add stock form
					$this->check_user();
					$this->load->view('shop/new_stock_item'); 
					
				}
				//add depatments to shops
				
				function Add_branch(){ //load add stock form
					$this->check_user();
					$this->load->view('shop/add_branch'); 
					
				}
				
				function Add_user(){ //load add stock form
					$this->check_user();
					$this->load->view('shop/add_users'); 
					
				}
				//add new branch save
				
				function Save_branch(){
			     $this->check_user();
			     $this->form_validation->set_rules('name', 'name', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha_numeric_spaces');
				  
				 
				 if ($this->form_validation->run() == FALSE)
					{
						  $this->load->view('shop/Add_stock_type');
					 }
					else
					{
						  $name = $this->input->post('name'); 
						  $this->shop->Add_new_branch($name  );
						  $data['info']  = 'New branch  successfully added';
						  $this->load->view('shop/sucees' , $data); 
					 
				   }
									  

				}
				//add new cat items///////////
				function Save_item(){
			     $this->check_user();
			     $this->form_validation->set_rules('costp', 'Cost price', 'trim|required|integer|xss_clean');
				 $this->form_validation->set_rules('Quantity', 'Quantity', 'trim|required|integer|xss_clean');
				 $this->form_validation->set_rules('item', 'Item type', 'trim|required|xss_clean');
				  $this->form_validation->set_rules('exp_date', 'Expiry Date', 'trim|required|xss_clean');
				 
				   
				 
				 if ($this->form_validation->run() == FALSE)
					{
						  $this->load->view('shop/new_stock_item');
					 }
					else
					{
						  
						  
						  $costp = $this->input->post('costp');
						  $qty = $this->input->post('Quantity');
						  $item = $this->input->post('item');//
						   $exp_date = FormatTime2($this->input->post('exp_date'));
						   $current = timeCurrent2();
						   if( dateDiff(timeCurrent2(), $exp_date) >0){
						   
						  
						  for($i =0; $i<$qty; $i++){ 
						     $this->shop->Add_new_fruit($item , $costp , $exp_date);
						   
						  }
						  
						   $this->Success('New Fruit Drink(s) has been added successfully');
						   }else{
							    
							    $this->Warning('Your expiry dates seem to be invalid');
						  
						   }
						   
					 
				   }
									  

				}
				
				 
				//add new user
				function Save_user(){
			     $this->check_user();
			     $this->form_validation->set_rules('name', 'name', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha_numeric_spaces');
				 $this->form_validation->set_rules('branch', 'User Role', 'trim|required|integer|xss_clean');
				 
				 $this->form_validation->set_rules('Unsername', 'Unsername', 'required|xss_clean|min_length[5]|max_length[12]|is_unique[users.user_name]');
				 //
				 $this->form_validation->set_rules('lname', 'Last Name', 'xss_clean|min_length[2]|max_length[30]|trim|required|xss_clean');
				 $this->form_validation->set_rules('location', 'location', 'min_length[2]|max_length[30]|trim|xss_clean');
				 
				 $this->form_validation->set_rules('fon', 'Phone Number', 'xss_clean|min_length[2]|max_length[15]|trim|required|xss_clean|is_unique[users.phone_no]');
				 $this->form_validation->set_rules('pass', 'Password', 'min_length[2]|max_length[15]|trim|required|xss_clean');
				
				
				 
				 $this->form_validation->set_rules('pass2', 'Password Confirmation', 'required|matches[pass]');
				   
				 
				 if ($this->form_validation->run() == FALSE)
					{
						  $this->load->view('shop/add_users');
					 }
					else
					{
						
						  $fname = $this->input->post('name');
						  $lname = $this->input->post('lname');
						  $fon = $this->input->post('fon');
						  $role = $this->input->post('branch');
						  $user = $this->input->post('Unsername');
						  $pwd = $this->input->post('pass');
						  $p2 = $this->input->post('pass2');
						  $ln = $this->input->post('location');
						  //
//						  
						 
							   
						 //save this data to the database	  
						$this->shop->Add_new_user($user,$pwd,$fname,$lname,$fon,$role , $ln ) ; 
						$this->Success('New user has been added sucessfully');
				        
						 
						  
					 
				   }
									  

				}
				//update user information 
				
				function Edit_user_profile(){
			     $this->check_user();
			     $this->form_validation->set_rules('name', 'name', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha_numeric_spaces'); 
				 
				 $this->form_validation->set_rules('lname', 'Last Name', 'xss_clean|min_length[2]|max_length[30]|trim|required|xss_clean');
				 $this->form_validation->set_rules('location', 'location', 'min_length[2]|max_length[30]|trim|xss_clean');
				 
				 $this->form_validation->set_rules('fon', 'Phone Number', 'xss_clean|min_length[2]|max_length[15]|trim|required|xss_clean');
				 
				 
				 if ($this->form_validation->run() == FALSE)
					{
						  $this->load->view('shop/add_users');
					 }
					else
					{
						
						  $fname = $this->input->post('name');
						  $lname = $this->input->post('lname');
						  $fon = $this->input->post('fon'); 
						  $ln = $this->input->post('location');
						  $id = $this->input->post('id');
						  //
//						  
						 
							   
						 //save this data to the database	  
						$this->shop->Update_user_data( $fname,$lname,$fon,  $ln , $id ) ; 
						$this->Success('New user has been added sucessfully');
				        
						 
						  
					 
				   }
									  

				}
				//update user password from here 
				
				function Update_user_profile(){
			     $this->check_user();
			     $this->form_validation->set_rules('pass', 'Password', 'min_length[2]|max_length[15]|trim|required|xss_clean');
				 $this->form_validation->set_rules('pass2', 'Password Confirmation', 'required|matches[pass]');
				  $data['info']    = $_SESSION['info'] ;
				 if ($this->form_validation->run() == FALSE)
					{
						  $this->load->view('shop/edit_pass' , $data);
					 }
					else
					{
						
						  $pass = $this->input->post('pass'); 
						  $id = $this->input->post('id');
						  //
//						  
						 
							   
						 //save this data to the database	  
						$this->shop->Update_user_pass( $pass , $id ) ; 
						$this->Success('Password Has been changed sucessfully');
				        
						 
						  
					 
				   }
									  

				}
				//suSpend system users
				
				function Suspend(){//Activate
					 $this->check_user();
					if(isset($_POST['Bio1'])){
						 $user  = (int)  trim($_POST['Bio1']);
						 $this->shop->Change_user_status($user , 0);
						  $this->Success_mini('Operation was successful');
						 
						 
						
					 
					}
				}
				//now we can receive cat items to be processed
				 
				
				function Process_cat(){
					 $this->check_user();
					if(isset($_POST['Bio1'])){
						 $_SESSION['Katunda_items'] =    array( $_POST['Bio1']['scores'] ,$_POST['Bio2']) ;
						   
						 
					     $this->load->view('shop/cat_summary');
						 
						 
						
					 
					}
					
				}
				//approve items on the catelogue from here
				
				function Approve_cat(){
					 $this->check_user();
					//if(isset($_POST['Bio1'])){
						   $data1  =  $_SESSION['Katunda_items'] ;
						    $data  =  $data1[0];
							$client    = $data1[1]; 
							$client_name    = $client[0];
							$payment    = $client[1];
							$agent = $this->session->userdata('shop_id');
							 
							$this->shop->Add_new_order_line($payment  , $client_name );
							$order_line =$this->shop->Order_no();
							$order  = false;
							foreach($order_line as $order){
								  $order  = $order->sales_id;
								
							}
							 
							if($order){
						   foreach($data as $item){
							   
							   $fruit  = $item['Item'];
							    $qty  =  $item['Qty']; 
							    $sp  =  $item['Price']; 
							    
							  $fruits  =  $this->shop->Stock_select($fruit , 0 , 0 , $qty);
							 
							  
							  foreach($fruits as $row){
								  $id = $row->fruit_id;
								 
									  
								  $fruits  =  $this->shop->Mark_as_bought($id,$sp , $order , $agent, $payment );
							  }
							 
							}
							 $this->Success_mini('Operation was sucessfull');
							}
						 else{
						 }
					     
						
					 
					//}
				}
				//get all the sales info from here
				function Sales_form(){
					 $this->check_user();
					if(isset($_POST['Bio1'])){
						   $user  = (int)  trim($_POST['Bio1']); 
						   $data['info']  = $user;
					     $this->load->view('shop/item_saller_form' , $data);
						 
						 
						
					 
					}
				}
				//delete this user from the database from here
				function Delete_user(){
					 $this->check_user();
					if(isset($_POST['Bio1'])){
						 $user  = (int)  trim($_POST['Bio1']); 
						  $this->Success_mini('User deleted');
						 
						 
						
					 
					}
				}
				//activate user
				
				function Activate(){//
					 $this->check_user();
					if(isset($_POST['Bio1'])){
						 $user  = (int)  trim($_POST['Bio1']);
						 $this->shop->Change_user_status($user , 1);
						  $this->Success_mini('Operation was successful');
						 
						 
						
					 
					}
				}
				//update user nformation
				
				function Edit_user(){
					 $this->check_user();
					if(isset($_POST['Bio1'])){
						  $user  = (int)  trim($_POST['Bio1']);
						  
						 $data['info']  = $user;
					     $this->load->view('shop/edit_user' , $data);
						 
						
					 
					}
					
				}
				
				//update user password
				
				function Update_pass(){
					 $this->check_user();
					 $user = $this->session->userdata('shop_id');
					if($user > 0){
						   $data['info']    = (int)  $user;
						 
						 //echo 
					     $this->load->view('shop/edit_pass' , $data);
						 
						
					 
					}
					
				}
				
				//update my profile
				
				function Update_my_profile(){
					 $this->check_user();
					 $user = $this->session->userdata('shop_id');
					if($user > 0){
						    $data['info']    = (int)  $user;
						  
						 $data['info']  =  $this->session->userdata('shop_id');
					     $this->load->view('shop/edit_user' , $data);
						 
						
					 
					}
					
				}
				function All_users(){
					$data['info']  = 22;
					 $this->load->view('shop/All_users' , $data);
				}
				//list all ranches
				function Success($info){ 
				$data['info']  = $info;
					 $this->load->view('shop/success' , $data);
					
				}
				
				//error message from here
				
				function Warning($info){ 
				$data['info']  = $info;
					 $this->load->view('shop/Shop_error' , $data);
					
				}
				function Success_mini($info){ 
				$data['info']  = $info;
					 $this->load->view('shop/success_mini' , $data);
					
				}
				function Success2(){ 
				$data['info']  = 'mmmmmmm';
					 $this->load->view('shop/success' , $data);
					
				}
				
				function Branches(){
					 $this->check_user();
					 $this->load->view('shop/List_branches'); 
				}
				
					function check_user(){
					$log_id = $this->session->userdata('logged_in');
					if($log_id and $this->session->has_userdata('bio_name'))
					{
						   
					   }
							  else{
									 $this->LogoutUser();
				
								 }
						}
		
		 
}
