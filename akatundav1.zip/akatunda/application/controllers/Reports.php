<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

/**
 * Index Page for this controller.
 *
 * Maps to the following URL
 * 		http://example.com/index.php/welcome
 *	- or -
 * 		http://example.com/index.php/welcome/index
 *	- or -
 * Since this controller is set as the default controller in
 * config/routes.php, it's displayed at http://example.com/
 *
 * So any other public methods not prefixed with an underscore will
 * map to /index.php/welcome/<method_name>
 * @see http://codeigniter.com/user_guide/general/urls.html
 */
 
 /**
 * Index Page for this controller.
 *
 * Maps to the following URL
 * 		http://example.com/index.php/welcome
 *	- or -
 * 		http://example.com/index.php/welcome/index
 *	- or -
 * Since this controller is set as the default controller in
 * config/routes.php, it's displayed at http://example.com/
 *
 * So any other public methods not prefixed with an underscore will
 * map to /index.php/welcome/<method_name>
 * @see https://codeigniter.com/user_guide/general/urls.html
 
 
 */
 
 public function __construct()

	{
			parent::__construct();
			 $this->load->library('session');
		   
	}
	 public function index()
{
		if(isset($_SESSION['machines'])){
		$machines = $data['machines'] = $_SESSION['machines'] ;
			$data['search'] =$_SESSION['Reports'];
			//print_r($machines);
	 $this->load->view('pdf/General_report' , $data);//Search_pdf
		}
		else {
			 redirect('Home', 'refresh');
		}
	 
}

function search_report(){
			if(isset($_SESSION['search_data_results'])){
			 $data['action'] = 1;
			 
			   $search_results =   $_SESSION['search_data_results'];
			   
	 // print_r($search_results);
	 
	  $this->load->view('pdf/Search_pdf' , $data);//
			}
			else {
			 redirect('Home', 'refresh');
		}
	
}

//print instalation reports

	function Instllation_report(){
			if(isset($_SESSION['installations_results'])){
			 $data['action'] = 1;
			 
			   $search_results =   	$_SESSION['search_installations'];
			   
	 // print_r($search_results);
	 
	  $this->load->view('pdf/all_installations' , $data);//
			}
			else {
			 redirect('Home', 'refresh');
		}
	
}
//single instalation report from here


function Instllation_report_single(){
			if(isset($_SESSION['installations_results_single'])){
			 $data['action'] = 1;
			 
			   $search_results =   	$_SESSION['installations_results_single'];
			   
	 
	 
	  $this->load->view('pdf/single_installation_report' , $data);//
			}
			else {
			 redirect('Home', 'refresh');
		}
	
}
//combined reports
function Order_report(){
 
	if(isset($_SESSION['mcn_order_id'])){
			 $data['action'] = 1;
		      $this->load->view('pdf/Order' , $data);//
			}
			else {
			 redirect('Home', 'refresh');
		}
}

function combined_report(){
			if(isset($_SESSION['search_data_results'])){
			 $data['action'] = 1;
			 
			   $search_results =   $_SESSION['search_data_results'];
	 // print_r($search_results);
	 
	  $this->load->view('pdf/Custom_reports' , $data);//
			}
			else {
			 redirect('Home', 'refresh');
		}
	
}

function single_report_pdf(){
			if(isset($_SESSION['machine_report_id'])){
			 $data['action'] = 1;
			 
			  // $search_results =   $_SESSION['single_machine_report'];
	 // print_r($search_results);
	 $mac_data = $data['mac_data'] =  $this->bio->get_my_machines($_SESSION['machine_report_id']);
	 
	  $this->load->view('pdf/single_machine_report' , $data);//
			}
			else {
			 redirect('Home', 'refresh');
		}
	
}

function machine_life_report_pdf(){
			if(isset($_SESSION['machine_life_id'])){
			 $data['action'] = 1;
			 
			  // $search_results =   $_SESSION['single_machine_report'];
	 // print_r($search_results);
	// $mac_data = $data['mac_data'] =  $this->bio->get_my_machines($_SESSION['machine_life_id']);
	 
	  $this->load->view('pdf/machine_life_report' , $data);//
			}
			else {
			 redirect('Home', 'refresh');
		}
	
}

		function sendmail()
{
//exit('hello');
$this->load->library('email'); // load email library
$this->email->from('jack@testing.com', 'sender name');
/// $this->email->to('test1@gmail.com');
//$this->email->cc('test2@gmail.com'); 
$this->email->subject('Your Subject');
$this->email->message('Your Message'); 
if ($this->email->send())
	echo "Mail Sent!";
else
	echo "There is error in sending mail!";
}
function Mailx(){
	$config = Array(
'protocol' => 'smtp',
        'smtp_host' => 'ssl://smtp.googlemail.com',
        'smtp_port' => 465,
        'smtp_user' => 'jnserek@gmail.com',
        'smtp_pass' => '210009424',
        'mailtype'  => 'html', 
        'charset' => 'utf-8',
        'wordwrap' => TRUE

    );
    $this->load->library('email', $config);
    $this->email->set_newline("\r\n");
    $email_body ="<div>hello world</div>";
    $this->email->from('jnserek@gmail.com', 'ddd');

    $list = array('jnserek@gmail.com');
    $this->email->to($list);
    $this->email->subject('Testing Email');
	$this->email->set_mailtype("html");
    $this->email->message($email_body);
	 

    $this->email->send();
    echo $this->email->print_debugger();
}	
	 


}

