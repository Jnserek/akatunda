<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Eshop extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 
	 
	 */
	 
	 public function __construct()

        {
                parent::__construct();
				//$this->load->library('session');
				//$_SESSION['cat_items'] = array();
				if(!isset($_SESSION['cat_items'] )){ $_SESSION['cat_items']= array(); } 
               
        }
		
		
	public function index()
	{
		
		  $this->load->view('shop/home');
		 
	}
	function chat_items(){
		if(isset($_POST['comand'])){
			
			   $my_post = $_POST['comand'];
			   
			 
			  
				 $dept = $this->encrypt->decode($my_post);
				 if ( !in_array($dept, $_SESSION['cat_items'])) {
					 
                            array_push($_SESSION['cat_items'] ,$this->encrypt->decode($my_post ));
							bio_succes( 'Item added successfully');
}
				
				 
				else bio_succes(  'Item already exist on a chat');
				
			 
			
			
		}
		
		//echo '3';
	}
	
	function refresh_cat(){
		$_SESSION['cat_items'] = array(); 
		echo 'Cart refreshed';
		 
	}
	
	function remove_cat_item(){
		if(isset($_POST['comand'])){
			
			       $my_post =  $_POST['comand'];
			   
			 
			  
				   $dept = $this->encrypt->decode($my_post);
				 
				 if ( in_array($dept, $_SESSION['cat_items'])) {
					 $key = array_search($dept, $_SESSION['cat_items']); 
					 array_splice($_SESSION['cat_items'], $dept);
					 unset($_SESSION['cat_items'][$key]);
					// array_unique($_SESSION['cat_items']);
                           
							bio_succes( 'Item removed successfully');
}
				
				 
				else bio_succes( 'Item does not exist on a chat');
				
			 
			
			
		}
		
		
	}
	
	function check_out(){
		if(isset($_POST['comand'])){
			
			      $mks =  $_POST['comand'];
			  
		
		 if(sizeof($mks['scores']) > 0){
			  $data['search']    =  $mks; 
								  
								  /*$mks_iterator   =   $mks['scores'];
								  for($i =1; $i<(sizeof($mks_iterator) +1); $i++ ){
									      $std  =  $mks_iterator[$i];
										  if(sizeof($std) > 0){
											     $m_name = trim($std['Name']); 
												 if($m_name != ""){
													 
													 
													 
												   $clean  = $this->pi_store->Get_analysis_hf($hf);
												   if(sizeof($clean)){
													 $successu  +=   1;
												     $this->pi_store->Add_machine_to_db( $std , $dp , $hf);
												   }
												  
												 }//end validation check
										  }//end check 1
								  
								  }//end for loop */
								  
								   $this->load->view('shop/check_out' , $data);
							  }
		}
	}
	function chat(){
		
		 $data['string']    =  '';
		  $this->load->view('shop/chat_items' , $data);
	}
	
	
	function testing(){
		
		$config = $this->bio->scheduler(0 );//(4);
		//print_r($config );
		$jobs_to_shift = $this->bio->scheduler(1);
		 print_r($jobs_to_shift );
		print_r($this->bio->check_shifts());
	}
	
	 
	
	function send_mails(){
	 		 
  $this->load->helper('url');
 
  $emailx = 'beas@kamdevpartners.com';
  $namex = 'BEAS';
  $msg = 'TESTING 123';
  $this->load->library('email');
  $config['protocol'] = "smtp";
  $config['smtp_host'] = "ssl://smtp.gmail.com";
 // $config['smtp_host'] = "ssl://smtp.kamdevpartners.com";//name of the server sending
  $config['smtp_port'] = "465";//get the port number
  
  $config['smtp_user'] = "beasoftware.2016@gmail.com";//user on the server
  $config['smtp_pass'] = "$?php.2016?>";//password of the sending mail adress
  $config['charset'] = "utf-8";
  $config['mailtype'] = "html";
  $config['newline'] = "\r\n";
  
    $this->load->library('email',$config);
    $this->email->from( $emailx, $namex);
   // $this->email->reply_to( $emailx, $namex);
    $this->email->to('jnserek@gmail.com');
	//$this->email->cc('stfrancis@stfrancisss.net');
	
	//$this->email->bcc('st.francisss@yahoo.com');
	 
 
    $this->email->subject('BEAS NOTIFICATION');
    $this->email->message($msg);
   
	if ($this->email->send()) {
             echo "You message has been sent sucessfully ";
        } 
		else {
     
	         echo 'Your message was not sent please try again latter';
			} 

		 
	}
	
	function Search_item(){
		$search_string =   strtolower(trim($this->input->post('id_search')));
		if($search_string){
		 $string = $this->bio->Online_search($search_string  );
		 if(sizeof($string) > 0){
			 $data['search']    =  $string;
			 //search_results.php
			  $this->load->view('shop/search_results' , $data);
			 
					//print_r($string);
					
		 }
		 else {
			 
			bio_error('No item found ');
		 }
		}
			 
	}
	  
		
		 
	
	
}
