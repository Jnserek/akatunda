	<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	class System_controls extends CI_Controller {

			/**
		 
		 *developed by nsereko jackson
		 *jnserek@gmail.com
		 *077794949 
		 */
		 
		 
		public function index()
		{
			 $log_id = $this->session->userdata();
			 
			 if(LoadValid() ){
				
			$log_id = $this->session->userdata('logged_in');
			if($log_id and $this->session->has_userdata('bio_name')){
			 
					redirect('Home', 'refresh');
				  
			 
			}
			else{
				$this->LogoutUser();
				
			}
			 }else redirect('Error', 'refresh');
		}
		
		
		///////////////////////////////////////////////shop will begin from here
		
		function Add_stock_type(){
			
		}
		
		
		
		
		
		
		//////////////////shop ends here
		
			
			function LogoutUser(){
				 $user = $this->session->userdata('bio_id');
					 
					 $this->bio-> Update_login($user , 0); 
					 
						  
						 
					 $this->session->sess_destroy();
					 
					  redirect('Login', 'refresh');
				
			}
			
			//create hospital account from here 
			
		 
			
			//add new problem to the database from here after validation 
			
			
			function machine_problem(){
				$this->check_user();
				$this->form_validation->set_rules('f-name', 'problem  ', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha_numeric_spaces');
				$this->form_validation->set_rules('state', 'Device  state', 'trim|required|min_length[1]|max_length[55]|xss_clean');
				$this->form_validation->set_rules('notify_jms', 'Notification ', 'trim|required|xss_clean');
				
				 
				 if ($this->form_validation->run() == FALSE)
					{
						 $this->load->view('bio/machine_problems');
						 
							
					}
					else
					{
						  $problem = $this->input->post('f-name');
						  $state = $this->input->post('state');
						  $machine = $this->encrypt->decode($_SESSION['mcn_problem_id']);
						  $notification_receiver = $this->input->post('notify_jms');
						 
						  
						  $entray_ar  = array(trim($problem) ,$state ,  $machine  , $notification_receiver  );
						  
							$this->bio->Add_machine_problem($entray_ar);
							success('Device  problem  has been added successfully');
						   
						   
						   
						  
					
				   }
									  

				}
				
				//delete machine problem
				function Delete_machine_problem(){
				$this->check_user();
						  $machine = $this->encrypt->decode($_SESSION['mcn_field_id']);
						   
							$this->bio->delete_machine_problem($machine );
							success('Device  problem  has been updated successfully');
						   
						   
				 
									  

				}
				
				//Edit machine problem
				
				function Edit_machine_problem(){
				$this->check_user();
				$this->form_validation->set_rules('f-name', 'Device problem ', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha_numeric_spaces');
				  
				 if ($this->form_validation->run() == FALSE)
					{
						 $data['action'] = 1; 
						 $this->load->view('bio/machine_problems', $data);
						 
							
					}
					else
					{
						  $problem = $this->input->post('f-name');
						  
						  $machine = $this->encrypt->decode($_SESSION['mcn_field_id']);
						   $entray_ar  = array($problem ,   $machine   );
						  
							$this->bio->Edit_machine_problem($entray_ar);
							success('Device  problem  has been updated successfully');
						   
						   
						   
						  
					
				   }
									  

				}
				
				
				// enter field service report into the database after validation 
				
				
				function Service_entry(){
				$this->check_user();
				$this->form_validation->set_rules('comment', 'Comment', 'trim|min_length[2]|max_length[250]|xss_clean');
				$this->form_validation->set_rules('state', 'Device  state', 'trim|required|min_length[1]|max_length[5]|xss_clean');
				$this->form_validation->set_rules('state1', 'New device state', 'trim|required|min_length[1]|max_length[5]|xss_clean');
				
				$this->form_validation->set_rules('way_foward', 'way forward', 'trim|xss_clean');
				
				$this->form_validation->set_rules('comp', 'Company', 'trim|min_length[0]|max_length[5]|xss_clean');
				$this->form_validation->set_rules('technician_name', 'Technician Name', 'trim|required|min_length[0]|max_length[5]|xss_clean');
				
				 
				 if ($this->form_validation->run() == FALSE)
					{
						$this->load->view('bio/field_service');
						 
							
					}
					else
					{
						  $com = $this->input->post('comment');
						  $state = $this->input->post('state');
						   $state2 = $this->input->post('state1');
							$wf = $this->input->post('way_foward');
							
							 $comp = $this->input->post('comp');
							$tn = $this->input->post('technician_name');
							 
							
							  if(isset($_SESSION['mcn_field_id']) ){
							$machine = $this->encrypt->decode($_SESSION['mcn_field_id']);
							 
							$entray_ar  = array($com ,$state ,$state2 ,$wf ,  $machine , $comp , $tn   );
							 
							
							$id = $this->session->userdata('bio_id');
							 
							if ($id  > 0){
								  $this->bio->Add_field_report($entray_ar);
								 
								 
							success('Device  service report has been added successfully');
							}else login();
							  }else login();
						   
						   
						   
						  
					
				   }
									  

				}
				//alocate machine 
				
				function Allocation(){
				$this->check_user();
				 
				 $this->form_validation->set_rules('state', 'Device ', 'trim|required|min_length[1]|max_length[5]|xss_clean');
				 
				 
				 if ($this->form_validation->run() == FALSE)
					{
						 $this->load->view('bio/Allocate');
						 
							
					}
					else
					{
						  $com = $this->input->post('state');
						  
							
							  if(isset($_SESSION['mcn_field_id']) ){
							$machine = $this->encrypt->decode($_SESSION['mcn_field_id']);
							 
							$entray_ar  = array($machine , 0 , $com   );
						 
							$id = $this->session->userdata('bio_id');
							 
							if ($id  > 0){ 
							$this->bio->Machine_Alocation($entray_ar);
								 
								 
							success('Allocation was successful');
							}else login();
							  }else login();
						   
						   
						   
						  
					
				   }
									  

				}
				
				
				//edit field report here
				
				function Field_report_edit(){
				$this->check_user();
				$this->form_validation->set_rules('comment', 'Comment', 'trim|min_length[2]|max_length[250]|xss_clean');
				$this->form_validation->set_rules('state', 'Device  state', 'trim|min_length[1]|max_length[5]|xss_clean');
				$this->form_validation->set_rules('state1', 'New device state', 'trim|min_length[1]|max_length[5]|xss_clean');
				
				$this->form_validation->set_rules('way_foward', 'way forward', 'trim|xss_clean');
				$this->form_validation->set_rules('comp', 'Company', 'trim|max_length[10]|xss_clean');
				$this->form_validation->set_rules('technician_name', 'Technician Name', 'trim|max_length[10]|xss_clean');
				 
				 if ($this->form_validation->run() == FALSE)
					{
								  echo  $data['action'] = 1;
								  $this->load->view('bio/edit_field_service' , $data);
						 
							
					}
					else

					{
							$com = ucfirst(strtolower(trim($this->input->post('comment'))));
							$state = $this->input->post('state');
							$state2 = $this->input->post('state1');
							$wf = ucfirst(strtolower(trim($this->input->post('way_foward'))));
							$comp = $this->input->post('comp');
							$tn = $this->input->post('technician_name');
							 // print_r($entray_ar);
							  if(isset($_SESSION['mcn_field_id']) ){
							  $machine = $this->encrypt->decode($_SESSION['mcn_field_id']);
							  $entray_ar  = array($com ,$state2 ,$state ,$wf , $machine  ,$comp , $tn   ); 
							   $machine_report  =$this->bio->  Specific_service_info($machine);
							   $id   = '';
							   if(sizeof($machine_report) > 0){
								   $id  = $machine_report[0]['mid'];
								   
							   
							  
							  $this->bio->  Edit_field_report($entray_ar , $id);
							   
								success('Device  service report has been added successfully');
							   }
							   else {
								   
								   bio_error('Update as been failed Machine does not exist');
							   }
							 
							  }else login();
						   
						   
						   
						  
					
				   }
									  

				}
				
				//delete field report
				
				
				function Delete_Field_report(){
							  $this->check_user();
							  if(isset($_SESSION['mcn_field_id']) ){
							   $machine = $this->encrypt->decode($_SESSION['mcn_field_id']);
							   $this->bio->Delete_field_report( $machine);
								success('Device  service report has been deleted successfully');
							  }
										  

				}
				
				
				
				
				function service_report(){
					
				$this->check_user();
				 
				$this->form_validation->set_rules('c-name', 'Company Name  ', 'trim|required|min_length[2]|max_length[50]|xss_clean');
				$this->form_validation->set_rules('job', 'Job number ', 'trim|xss_clean');
				$this->form_validation->set_rules('Diagnosis', 'Diagnosis', 'trim|xss_clean');
				$this->form_validation->set_rules('remedy', 'Remedy', 'trim|min_length[2]|max_length[50]|xss_clean');
				 $this->form_validation->set_rules('Spare', 'Spare Charges', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('tech', 'Technician comment', 'trim|xss_clean');
				$this->form_validation->set_rules('user', 'User comment', 'trim|xss_clean');
				
				$this->form_validation->set_rules('state', 'New state', 'trim|required|xss_clean');
				
				$this->form_validation->set_rules('charge', 'Repair Charges', 'trim|required|xss_clean');
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						  $this->load->view('bio/service_report');
						 
							
					}
					else
					{         // rules have been passed 
						  $cname =  strtoupper(trim($this->input->post('c-name')));
						  $job=  trim($this->input->post('job'));
						  $Diagnosis = strtolower(trim($this->input->post('Diagnosis')));
						  $remedy = strtolower(trim($this->input->post('remedy')) );
						  $Spare =  strtolower($this->input->post('Spare'));
						  
						  //
						  $tech=  trim($this->input->post('tech'));
						  $user = strtolower(trim($this->input->post('user')));
						  $state =  trim($this->input->post('state') );
						  $charge =  $this->input->post('charge');
						 
						  if(isset($_SESSION['mcn_service_id']) ){
						  $machine =  $this->encrypt->decode($_SESSION['mcn_service_id']);
						  
						  $entray_ar  = array($cname , $job, $Diagnosis , $remedy , $Spare , $tech , $user , $state , $charge ,$machine );
						 
						   
							$id = $this->session->userdata('bio_id');
							 
							//if ($id  > 0){
								
								  
							   $this->bio->Add_machine_repair_info($entray_ar);
								  success('Repair information has been  added successfully');
								
						 // }else login();
						  }
							else login();
							 
						   
							  
							 
						  
					
				   }
						
					
					
				}
				
				//delete repair information from the database
				
				function Delete_repair_report(){
					
				$this->check_user();
				 
						  
						  if(isset($_SESSION['mcn_field_id']) ){
						  $machine =  $this->encrypt->decode($_SESSION['mcn_field_id']); 
						 $this->bio->Delete_machine_repair_info($machine); 
						 success('Operation was  successfully');
								
						  
						  }
							else login();
					
				}
				
				
				//Edit repair information
				
				
				function Edit_repair_report(){
					
				$this->check_user();
				 
				$this->form_validation->set_rules('c-name', 'Company Name  ', 'trim|required|min_length[2]|max_length[50]|xss_clean');
				$this->form_validation->set_rules('job', 'Job number ', 'trim|xss_clean');
				$this->form_validation->set_rules('Diagnosis', 'Diagnosis', 'trim|xss_clean');
				$this->form_validation->set_rules('remedy', 'Remedy', 'trim|min_length[2]|max_length[50]|xss_clean');
				 $this->form_validation->set_rules('Spare', 'Spare Charges', 'trim|required|xss_clean');
				 $this->form_validation->set_rules('tech', 'Technician comment', 'trim|xss_clean');
				$this->form_validation->set_rules('user', 'User comment', 'trim|xss_clean');
				
				$this->form_validation->set_rules('state', 'New state', 'trim|required|xss_clean');
				
				$this->form_validation->set_rules('charge', 'Repair Charges', 'trim|required|xss_clean');
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						echo  $data['action'] = 1; 
						  $this->load->view('bio/service_report' , $data);
						 
							
					}
					else
					{         // rules have been passed 
						  $cname =  strtoupper(trim($this->input->post('c-name')));
						  $job=  trim($this->input->post('job'));
						  $Diagnosis = strtolower(trim($this->input->post('Diagnosis')));
						  $remedy = strtolower(trim($this->input->post('remedy')) );
						  $Spare =  strtolower($this->input->post('Spare'));
						  
						  //
						  $tech=  trim($this->input->post('tech'));
						  $user = strtolower(trim($this->input->post('user')));
						  $state =  trim($this->input->post('state') );
						  $charge =  $this->input->post('charge');
						  if(isset($_SESSION['mcn_field_id']) ){
						  $machine =  $this->encrypt->decode($_SESSION['mcn_field_id']);
						  
						  $entray_ar  = array($cname , $job, $Diagnosis , $remedy , $Spare , $tech , $user , $state , $charge   );
						 
						 $this->bio->Update_machine_repair_info($entray_ar , $machine); 
						 success('Repair information has been  updated successfully');
								
						  
						  }
							else login();
					 
				   }
					
				}
			
			function create_hospital(){
				 $this->check_user();
				
				 
				$this->form_validation->set_rules('name', 'customer name  ', 'trim|required|min_length[2]|max_length[50]|xss_clean');
				$this->form_validation->set_rules('locn', 'Location ', 'trim|xss_clean');
				$this->form_validation->set_rules('email', 'email', 'trim|xss_clean|valid_email');
				$this->form_validation->set_rules('fon', 'phone number', 'trim|min_length[2]|max_length[50]|xss_clean|is_natural');//
				
				$this->form_validation->set_rules('type', 'Customer', 'trim|required|xss_clean');
				$this->form_validation->set_rules('person', 'Contact Person  ', 'trim|required|min_length[2]|max_length[50]|xss_clean');
				 //check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						 $this->load->view('bio/addhealthfacility');
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  ucfirst(strtoupper(trim($this->input->post('name'))));
						  $type = strtolower(trim($this->input->post('type')));
						  $email = strtolower(trim($this->input->post('email')));
						  $fon = trim($this->input->post('fon'));
						  $locn =  strtolower($this->input->post('locn')); //
						  
						   $person =  ucfirst(strtolower($this->input->post('person')));
						  
						  $entray_ar  = array($fname , $locn , $fon , $email , $type , $person);
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								
							   $this->bio->Add_hospitals($entray_ar);
								 success('New client has been added successfully');
								
							}
							else login();
							 
						   
							  
							 
						  
					
				   }
									  

				}
				
				function Delete_supplier(){ //delete this supplier from the database
					
					//Update_suppliers
					   if($this->session->bio_role  < 1) {  
					
					 $this->check_user();
				 
					  $alt_data =  $this->encrypt->decode( $_SESSION['dept_edit']);
							 $info =  $this->bio-> Specific_machine_supplier($alt_data); //check from this suppllier	
							$id = $this->session->userdata('bio_id'); //chek if the user if logged in
							
							if (isset( $_SESSION['dept_edit'] ) and sizeof($info) > 0){
									//Edit_hospitals
								
							   $this->bio->Delete_supplier($alt_data  );
								
							   bio_error('Supplier has been  deleted successfully');
							   
								} 
								else {
									
									bio_error('operation failed: Supplier does not exist');
									
									
								}
					   }
					   else bio_error('Operation has failed , You need to administrator to perform this action');
				}
				
				function Delete_client(){
				 $this->check_user();
				 
				  $alt_data =  $this->encrypt->decode( $_SESSION['dept_edit']);
							 $info =  $this->bio-> specific_hospital($alt_data);	
							$id = $this->session->userdata('bio_id');
							
							if ($id  > 0 and isset( $_SESSION['dept_edit'] ) and sizeof($info) > 0){
									//Edit_hospitals
								
							   $this->bio->Delete_hospital($alt_data  );
								
							   bio_error('Hospital has been  deleted successfully');
							   
								} 
								else {
									
									bio_error('operation failed: Health facility does not exist');
									
									
								}
				
				}
				//edit clients information
				
				function edit_client(){
				 $this->check_user();
				
				
				$this->form_validation->set_rules('name', 'customer name  ', 'trim|required|min_length[2]|max_length[50]|xss_clean');
				$this->form_validation->set_rules('locn', 'Location ', 'trim|xss_clean');
				$this->form_validation->set_rules('email', 'email', 'trim|xss_clean|valid_email');
				$this->form_validation->set_rules('fon', 'phone number', 'trim|min_length[2]|max_length[50]|xss_clean|is_natural');
				
				$this->form_validation->set_rules('type', 'Customer', 'trim|required|xss_clean');
				
				$this->form_validation->set_rules('person', 'Contact Person  ', 'trim|required|min_length[2]|max_length[50]|xss_clean');
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 $data['action'] = 1; 
						 $this->load->view('bio/edit_client' , $data);
						 
							
					}
					else
					{         // rules have been passed      
						  
						   $fname =  ucfirst(strtoupper(trim($this->input->post('name'))));
						  $type = strtolower(trim($this->input->post('type')));
						  $email = strtolower(trim($this->input->post('email')));
						  $fon = trim($this->input->post('fon'));
						  $locn =  strtolower($this->input->post('locn')); //
						  
						   $person =  ucfirst(strtolower($this->input->post('person')));
						  
						  $entray_ar  = array($fname , $locn , $fon , $email , $type , $person);
						   
						   $alt_data =  $this->encrypt->decode( $_SESSION['dept_edit']);
							 $info =  $this->bio-> specific_hospital($alt_data);	
							$id = $this->session->userdata('bio_id');
							
							if ($id  > 0 and isset( $_SESSION['dept_edit'] ) and sizeof($info) > 0){
									//Edit_hospitals
								
							   $this->bio->Edit_hospitals($entray_ar ,$alt_data  );
								
							   success('Hospital has been  updated successfully');
							   
								} 
								else {
									
									bio_error('operation failed: Health facility does not exist');
									
									
								}
								
							 
							 
					   
				   }
									  

				}
				
				
				
				// NOW CAPTURE NEW MACHINE STATE INTO THE DATABASE FROM HERE 
				
				
				function create_new_states(){
				 $this->check_user();
				
				 
				$this->form_validation->set_rules('name', 'customer name  ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				 
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						$this->load->view('bio/add_new_states');
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  strtoupper(trim($this->input->post('name')));
						  
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								
							  $id2 =  $this->bio->   validate_new_state( $fname);
							  if( $id2 < 1){
							   
								$this->bio-> Add_machine_states($fname);
								 success('Device  state has been added successfully');
							  }
							  else bio_error('operation failed: This state all ready exist in the database');
								
							}
							else login();
							 
					   
				   }
									  

				}
				
				
											// add new devise supplier  
				
				
				function Add_new_supplier(){ 
				 $this->check_user();
				
										//set validation riles and check them
				$this->form_validation->set_rules('name', 'Device  supplier ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('contact', 'Phone Number ', 'trim|is_natural|min_length[8]|max_length[14]|xss_clean');
				$this->form_validation->set_rules('contactp', 'Contact Person ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('email', 'Email Address ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('loc', 'Location ', 'trim|min_length[2]|max_length[60]|xss_clean');
				
				
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						 $this->load->view('bio/add_new_suplier');
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  strtolower(trim($this->input->post('name')));
						  $fon =   $this->input->post('contact');
						  $contact_person=   $this->input->post('contactp');
						  
						   $email=   $this->input->post('email');
							 $loc=   $this->input->post('loc');
						   $supplier =  array($fname ,$fon , $contact_person , $email , $loc );
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								
								 $this->bio-> Add_suplier_from_contloller($supplier);
							   
								 success('New supplier has been added successfully');
							  
							}
							else login();
							 
					   
				   }
									  

				}
				//add new devise servicing conpany from here
				function Add_new_service_company(){ 
				 $this->check_user();
				
										//set validation riles and check them
				$this->form_validation->set_rules('name', 'Device  supplier ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('contact', 'Phone Number ', 'trim|is_natural|min_length[8]|max_length[14]|xss_clean');
				$this->form_validation->set_rules('contactp', 'Contact Person ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('email', 'Email Address ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('loc', 'Location ', 'trim|min_length[2]|max_length[60]|xss_clean');
				
				
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						 $this->load->view('bio/service_company');
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  strtolower(trim($this->input->post('name')));
						  $fon =   $this->input->post('contact');
						  $contact_person=  strtolower(trim( $this->input->post('contactp')));
						  
						   $email=   $this->input->post('email');
							 $loc=   strtolower(trim($this->input->post('loc')));
						   $service_comp =  array($fname ,$fon , $contact_person , $email , $loc );
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
							 
								 echo $this->bio-> Add_servicing_company($service_comp);
							   
								 success('New service company has been added successfully');
							  
							}
							else login();
							 
					   
				   }
									  

				}
				//edit service company from here
				
				function Edit_service_company(){ 
				 $this->check_user();
				 if(isset($_SESSION['service_company_id'])){
				
										//set validation riles and check them
				$this->form_validation->set_rules('name', 'Service Company Name ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('contact', 'Phone Number ', 'trim|is_natural|min_length[8]|max_length[14]|xss_clean');
				$this->form_validation->set_rules('contactp', 'Contact Person ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('email', 'Email Address ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('loc', 'Location ', 'trim|min_length[2]|max_length[60]|xss_clean');
				
				 
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						  $data['action'] = 1;
						  $this->load->view('bio/edit_service_company' , $data);
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  strtolower(trim($this->input->post('name')));
						  $fon =   $this->input->post('contact');
						  $contact_person=   strtolower(trim($this->input->post('contactp')));
						  
						   $email=   $this->input->post('email');
							 $loc=   strtolower(trim($this->input->post('loc')));
						   $service_comp =  array($fname ,$fon , $contact_person , $email , $loc );
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								 
								 $this->bio-> Update_servicing_company($service_comp , $_SESSION['service_company_id']);
							   
								 success('Update was successfully');
							  
							}
							else login();
							 
					   
				   }
				 }else bio_error('Error Has occurred Please try again');
									  

				}
				
				
				function Get_Reports(){ 
				 $this->check_user(); 
				 
				
										//set validation riles and check them
				$this->form_validation->set_rules('client', 'Client Name ', 'trim|integer|xss_clean');
				
				$this->form_validation->set_rules('department', 'Select Department ', 'trim|xss_clean');
				 
				$this->form_validation->set_rules('type', 'Report Type ', 'trim|integer|xss_clean');
				$this->form_validation->set_rules('p1', 'From ', 'trim|xss_clean');
				$this->form_validation->set_rules('p2', 'To  ', 'trim|xss_clean');
				$this->form_validation->set_rules('machine', ' Machine Name', 'integer|trim|xss_clean');
				
				 
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{    
						  $data['action'] = 1;
						   $this->load->view('bio/Get_reports' , $data);
						  
						 
							
					}
					else
					{  
				 
			  
						   $client =   $this->input->post('client');//Pitickets2020//
						  $dpt =     $this->input->post('department');
						 
						  $type=   $this->input->post('type'); 
							 $p1=    $this->input->post('p1'); 
							 $p2=    $this->input->post('p2');
							 $machine =   $this->input->post('machine');
				
							 $d1 =  $d2 = 0; 
						 
						   if(  $client  < 0 and $dpt < 0 and $type < 0 and $p1 =="" and $p2 ==""  and   $machine < 1 ){
							   
							   bio_error("Select at least one field to continue");
							   
						   }
						   if( $p1 !=""){
							   $p1 = FormatTime($p1);
							   $d1 = dateDiff( $p1 , timeCurrent2() );
							   
						   }
							if( $p2 !=""){
								$p2 = FormatTime($p2);
								   $d2 = dateDiff( $p2 , timeCurrent2() );
							   
						   }
						  
							 if(   ($d1 < 0 and $d2 < 0) || ($d1 < 0 and $d2 > 0) ){
								 bio_error('Error, Please check your dates');
							 }
							 if($d1 > 0 and $d2 > 0){
								 if($d2 > $d1){
									  bio_error('Error, Please check your date interval');
									 
								 }
								 
								 
							 }
						  
						   
						   $_SESSION['Reports'] =   $data['search'] = $search =  array( $client   , $dpt , $type ,   $p1 , $p2 , $machine );
						 
						 
						
							
						  
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								$_SESSION['machines'] = $return_data = $data['machines'] =  $this->bio->Machine_Reports(  $client   , $dpt , 0 ,$p1 , $p2 , $machine);
								 
								 
								$data['action'] =1;
								  $this->load->view('bio/Report_results' , $data);
								 
								 //$this->bio-> Update_servicing_company($service_comp , $_SESSION['service_company_id']);
							   
								 //success('Update was successfully');
							  
							}
							else login();
							 
					   
				   }
				 
									  

				}
				
				
				function Search_data(){ 
				 $this->check_user(); 
				 
				
										//set validation riles and check them
				$this->form_validation->set_rules('client', 'Client Name ', 'trim|integer|xss_clean');
				
				$this->form_validation->set_rules('manuf', 'Device Manufacturer ', 'trim|xss_clean');
				$this->form_validation->set_rules('sup', 'Device Supplier ', 'trim|xss_clean');
				
				$this->form_validation->set_rules('state', 'State ', 'trim|integer|xss_clean');
				$this->form_validation->set_rules('machinex', 'Machine ', 'trim|xss_clean');
				
				$this->form_validation->set_rules('y1', 'Year 1 ', 'trim|integer|xss_clean');
				$this->form_validation->set_rules('y2', 'Year2 ', 'trim|integer|xss_clean');
				$this->form_validation->set_rules('dtype', 'Department type ', 'trim|xss_clean');//
				
				 
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{    
						  $data['action'] = 1;
						   $this->load->view('bio/search' , $data);
						  
						 
							
					}
					else
					{  
				 
			 
						 $client =   $this->input->post('client');//Pitickets2020//
																   //get machine data from here
							$machine =     $this->input->post('machines');
							 $dtype =     $this->input->post('departments');
							
							  $man=array();                               //get data for machine manufacturere
						  $man1=   $this->input->post('manuf');
						  if($man1 >-1){
							  $man=array($man1);
							  
						  }
						   
							 
						 
							$sup=  $this->encrypt->decode( $this->input->post('sup'));
							 $state=    $this->input->post('state');
							 
							 $y1=   $this->input->post('y1');
							  $y2=    $this->input->post('y2');
							 
							  
						   $search =  array($machine , $client   , $man , $sup , $state , $y1 , $y2 , $dtype );
						 
						   if(sizeof($machine) < 1 and $client  < 0 and sizeof($man) < 1 and $sup < 0 and $state < 0 and $y1 < 5 and $y2 < 5 and sizeof($dtype) < 1  ){
							   
							   bio_error("Select at least one field to continue");
							   
						   }
							
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
							 
								$_SESSION['search_data_options'] =$search; 
								   $_SESSION['search_data_results'] = $return_data = $data['machines'] =  $this->bio->Filter_machines_search($machine , $client   , $man , $sup , $state , $y1 , $y2  , $dtype);
								//print_r( $return_data);//search_results.php
								$data['action'] =1;
								  $this->load->view('bio/search_results' , $data);
								 
								 //$this->bio-> Update_servicing_company($service_comp , $_SESSION['service_company_id']);
							   
								 //success('Update was successfully');
							  
							}
							else login();
							 
					   
				   }
				 
									  

				}
				
				//get installations data
				
				function select_instalation($id  ){
					 $this->check_user(); 
					 echo 'Here we are';
					
				}
				
				function Search_installations(){ 
				 $this->check_user(); 
				 
				
										//set validation riles and check them
				$this->form_validation->set_rules('client', 'Client Name ', 'trim|integer|xss_clean');
				
				$this->form_validation->set_rules('machines', 'Machine name ', 'trim|xss_clean');
				$this->form_validation->set_rules('sup', 'Device Supplier ', 'trim|xss_clean');
				 $this->form_validation->set_rules('y1', 'Year 1 ', 'trim|xss_clean');
				$this->form_validation->set_rules('y2', 'Year2 ', 'trim|xss_clean'); 
				
				 
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{    
						  $data['action']  = 0;
						  $this->load->view('bio/select_installations' , $data);
						  
						 
							
					}
					else
					{  
				 
			 
						 $client =   $this->input->post('client');//Pitickets2020//
																   //get machine data from here
							$machine =     $this->input->post('machines');
							 
							$sup=  $this->encrypt->decode( $this->input->post('sup'));
							 $y1=   $this->input->post('y1');
							  $y2=    $this->input->post('y2');
							 
							  
						   $search =  array($machine , $client   ,  $sup ,  $y1 , $y2   );
						 
						   if( $machine =='' and $client  ==''   and $sup =='' and   $y1 ==''  and $y2  ==''    ){
							   
							   bio_error("Select at least one field to continue");
							   
						   }
							
						 
							 
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
							 
								$_SESSION['search_installations'] =$search; 
								  $_SESSION['installations_results'] = $return_data = $data['machines'] =  $this->bio->Filter_installations($machine , $client   ,   $sup ,   $y1 , $y2   );
								 
								$data['action'] =1;
								
								  $this->load->view('bio/installation_results' , $data);
								 
							 
							  
							}
							else login();
							 
					   
				   }
				 
									  

				}
				
				//search per orderline from here
				
				function Search_Order_line(){ 
				 $this->check_user(); 
					   //set validation riles and check them
				 $this->form_validation->set_rules('client', 'Client Name ', 'trim|xss_clean');
				  $this->form_validation->set_rules('state', 'State ', 'trim|integer|xss_clean');
				  $this->form_validation->set_rules('y1', 'Year 1 ', 'trim|xss_clean');
				 $this->form_validation->set_rules('y2', 'Year2 ', 'trim|xss_clean'); 
											 //check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{    
						  $data['action'] = 1;
						   $this->load->view('bio/search_order_line' , $data);
						
					}
					else
					{  
				 
			 
						 $client =   $this->encrypt->decode($this->input->post('client'));//Pitickets2020//
							  $state=    $this->input->post('state');
							  $y1=   $this->input->post('y1');
							  $y2=    $this->input->post('y2');
							 
							  
						   $search =  array($client ,  $state , $y1 , $y2   );
						 
						   if ($client  < 0   and $state < 0 and $y1 == '' and $y2  == ''    ){
							   
							   bio_error("Select at least one field to continue");
							   
						   }
							
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
							 
								//$_SESSION['search_data_options'] =$search; 
								
									$data['machines'] =$data['orders'] =  $this->bio-> Search_order_line('' , $client,  $y1, $y2, $state);
									
					$data['decision'] =  7; 
				   $this->load->view('bio/cat/my_cat' , $data);
							  
							}
							else login();
							 
					   
				   }
				 
									  

				}
				
				function Search_custom_data(){ 
				 $this->check_user();  
				$this->form_validation->set_rules('client', 'Client Name ', 'trim|xss_clean');
				
				$this->form_validation->set_rules('reports', 'Report Type ', 'trim|xss_clean');
				$this->form_validation->set_rules('sup', 'Device Supplier ', 'trim|xss_clean'); 
				$this->form_validation->set_rules('machinex', 'Machine ', 'trim|xss_clean');
				
				$this->form_validation->set_rules('y1', 'Year 1 ', 'trim|xss_clean');
				$this->form_validation->set_rules('y2', 'Year2 ', 'trim|xss_clean');
				$this->form_validation->set_rules('dtype', 'Department type ', 'trim|xss_clean');//
				
				 
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{    
						  $data['action'] = 1;
						   $this->load->view('bio/custom_reports' , $data);
						  
						 
							
					}
					else
					{  
				 
			 
						  $client =   $this->encrypt->decode($this->input->post('client'));//Pitickets2020//
																   //get machine data from here
							 $machine =     $this->input->post('machines');
							  $dtype =     $this->input->post('departments');
							
														   //get data for machine manufacturere
							$report=   $_SESSION['action_search'];
						   
							 
						 
							$sup=  $this->encrypt->decode( $this->input->post('sup'));
							
							 
							 $y1=   $this->input->post('y1');
							  $y2=    $this->input->post('y2');
							  $action=   $this->input->post('action');
							 
							  
						   $search =  array($machine , $client   , $report ,     $y1 , $y2 , $dtype );
						 
						   if(sizeof($machine) < 1 and $client  < 0 and  $report < 0   and $y1 ==  '' and $y2 ==  '' and sizeof($dtype) < 1  ){
							   
							   bio_error("Select at least one field to continue");
							   
						   }
							
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								 
							 
								$_SESSION['search_data_options'] =$search;
								 $data['action'] =$action;
								 $_SESSION['search_report'] =$report;
								
								//print_r($search);
								//exit($report);//Filter_machines_search_custom($machine , $client   ,  $sup , $state , $y1 , $y2 , $dtype)
								if($report ==1 ){
								   $_SESSION['search_data_results'] = $return_data = $data['machines'] =  $this->bio->Filter_machines_search_custom($machine , $client   ,   $sup ,   $y1 , $y2  , $dtype);
								//print_r( $return_data);//search_results.php
								
								  $this->load->view('bio/problem_search_results' , $data);
								}
								else if($report ==2 ){
									 
									
									 $_SESSION['search_data_results'] = $return_data = $data['machines'] =  $this->bio->Filter_machines_services($machine , $client   ,   $sup ,   $y1 , $y2  , $dtype);
								 
								  $this->load->view('bio/device_servicing' , $data);
									
								}
								else  {
								 
									
									 $_SESSION['search_data_results'] = $return_data = $data['machines'] =  $this->bio->Filter_machines_Repair($machine , $client   ,   $sup ,   $y1 , $y2  , $dtype);
								//print_r( $return_data);//search_results.php
								$data['action'] =1;
								  $this->load->view('bio/all_repairs_done' , $data);
								}
								 
								 //$this->bio-> Update_servicing_company($service_comp , $_SESSION['service_company_id']);
							   
								 //success('Update was successfully');
							  
							}
							else login();
							 
					   
				   }
				 
									  

				}
				
				function Installation(){
					 $this->check_user();  
				$this->form_validation->set_rules('client_id', 'Hospital Name ', 'required|trim|xss_clean');
				 
				$this->form_validation->set_rules('device', 'Machine Name ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('mod', 'Device Model ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('sn', 'Serial No ', 'required|trim|xss_clean');  
				$this->form_validation->set_rules('country', 'countryof origin ', 'required|trim|xss_clean');  
				$this->form_validation->set_rules('sup', 'Supplier ', 'required|trim|xss_clean');  
				$this->form_validation->set_rules('man', 'Manufacturer ', 'required|trim|xss_clean');  	
				$this->form_validation->set_rules('code', 'Code ', 'trim|xss_clean');  
				$this->form_validation->set_rules('price', 'Cost price ', 'trim|xss_clean');  
				$this->form_validation->set_rules('yr', 'Year of manufacture ', 'required|trim|xss_clean');  	
				$this->form_validation->set_rules('instalation', 'installation date ', 'required|trim|xss_clean');  	
				$this->form_validation->set_rules('test1', 'Test No 1 ', 'trim|xss_clean');  	
				$this->form_validation->set_rules('result1', 'Test result 1 ', 'trim|xss_clean');  	
				
				
				//$this->form_validation->set_rules('departments', 'Machine ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('training', 'User training ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('trained', 'User trained ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('warranty', 'Machine warranty period ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('comment', 'Use comment ', 'trim|xss_clean');
				$this->form_validation->set_rules('customer', 'Customer Name ', 'required|trim|xss_clean');
				
				 
				
				 $data['action'] = 1;
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{    
						  
						   $this->load->view('bio/New_instalation' , $data);
						  
						  
						 
							
					}
					else
					{ 
	 
	 $client =    $this->input->post('client_id'); 
	  $dep =    $this->input->post('dep'); 
	 $device =    $this->input->post('device');
	 $model =    $this->input->post('mod');
	 $sn =    $this->input->post('sn');
	 $country =    $this->input->post('country');
	 $sup =    $this->input->post('sup');
	 $man =    $this->input->post('man');
	 $code =    $this->input->post('code');
	 $price =    $this->input->post('price');
	 $yr =    $this->input->post('yr');
	 
	 $i_date =    $this->input->post('instalation');
	 $date_send  = array($device ,  $model , $sn ,$dep ,  $country , $yr , $sup, $man , $i_date , $price  , $code );

	 
	  //installations
	 $t1 =    $this->input->post('test1');
	 $r1 =    $this->input->post('result1');
	 //set 2
	 $t2 =    $this->input->post('test2');
	 $r2 =    $this->input->post('result2');
	 //set 2
	 $t3 =    $this->input->post('test3');
	 $r3 =    $this->input->post('result3');
	 //set 2
	 $t4 =    $this->input->post('test4');
	 $r4=    $this->input->post('result4');
	 //set 2
	  $t5 =    $this->input->post('test5');
	 $r5 =    $this->input->post('result5');
	 //set 2
	 //other data 
	 
	 $training =  $this->input->post('training');
	 $trained =    $this->input->post('trained');
	 $waranty =    $this->input->post('warranty'); 
	 $customer =    $this->input->post('customer');
	 $comment =    $this->input->post('comment');
	 if( $training > 0 and  $trained < 1){
		  bio_warning('Please indicate number of users trained');
		   $this->load->view('bio/New_instalation' , $data);
		 
	 }else
	 
	  if( strlen($t1) < 2 and strlen($t2) < 2 and strlen($t3) < 2 and strlen($t4) < 2 and strlen($t5) < 2 ){
		   bio_warning('Please fill atleast one test to continue');
		   $this->load->view('bio/New_instalation' , $data);
		   
		   
	   }
	   else {
			$machine_id =  $this->bio->Installations( $date_send ,   $client);
	 
	 $instalation_data = array($machine_id ,  $training , $waranty ,$trained ,  $comment , $customer  );
	 

	 
	   $instalation_id =  $this->bio->Installation_data( $instalation_data ,   $client);
	  
	 
	  if(strlen($t1) >1 ){
	 $this->bio->Installations_test_data( $t1  , $r1, $instalation_id);
	 }
	  if(strlen($t2) >1 ){
	 $this->bio->Installations_test_data( $t2  , $r2, $instalation_id);
	 }
	  if(strlen($t3) >1 ){
	 $this->bio->Installations_test_data( $t3  , $r3, $instalation_id);
	 }
	 if(strlen($t4) >1 ){
	 $this->bio->Installations_test_data( $t4  , $r4, $instalation_id);
	 }
	  if(strlen($t5) >1 ){
	 $this->bio->Installations_test_data( $t5  , $r5, $instalation_id);
	 }  
	   } 
	 
	 
	 //$this->load->view('bio/New_instalation' , $data);
	 success('Operation was successful');
							  

	 
	 
					}
					
				}
				//edit test value from here//delete_tests
				function Edit_tests(){
					 $this->check_user();   
			   if(isset($_SESSION['test_field_id'])){
				$this->form_validation->set_rules('result1', 'Test Result ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('test1', 'Test ', 'required|trim|xss_clean');
				$data['action'] = 1;
				if ($this->form_validation->run() == FALSE) 
					{    
						  
				   $this->load->view('bio/edit_installation_tests' , $data);
						  
						  
						 
							
					}
					else
					{  
         				//installations
						 $t1 =    $this->input->post('test1');
						 $r1 =    $this->input->post('result1');
					  
						  if(strlen($t1) >1 ){
						 $this->bio->update_test_data(   $t1  , $r1,   $_SESSION['test_field_id']);
						 }
						  
							
						 success('Operation was successful');
												  

						 
						 
					}
					 }else{bio_error('Invalid data supplied');}
					
				}
				//delete test data from here
				function Delete_tests(){
					 $this->check_user();   
			   if(isset($_SESSION['test_field_id'])){
				   //$_SESSION['test_field_id']
				   $this->bio->delete_test_data($_SESSION['test_field_id']);
				   success('Action was successful');
			 
					 }else{bio_error('Invalid data supplied');}
					
				}
				//delete installation data from here
				function Delete_installation(){
					 $this->check_user();   
			   if(isset($_SESSION['instalations_id'])){
				  
				   $this->bio->delete_instllation_data($_SESSION['instalations_id']);
				   success('Action was successful');
			 
					 }else{bio_error('Invalid data supplied');}
					
				}
				
				//edit installations from here
				
				function Installation_updates(){
					 $this->check_user();  
				$this->form_validation->set_rules('client_id', 'Hospital Name ', 'required|trim|xss_clean');
				 
				$this->form_validation->set_rules('device', 'Machine Name ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('mod', 'Device Model ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('sn', 'Serial No ', 'required|trim|xss_clean');  
				$this->form_validation->set_rules('country', 'countryof origin ', 'required|trim|xss_clean');  
				$this->form_validation->set_rules('sup', 'Supplier ', 'required|trim|xss_clean');  
				$this->form_validation->set_rules('man', 'Manufacturer ', 'required|trim|xss_clean');  	
				$this->form_validation->set_rules('code', 'Code ', 'trim|xss_clean');  
				$this->form_validation->set_rules('price', 'Cost price ', 'trim|xss_clean');  
				$this->form_validation->set_rules('yr', 'Year of manufacture ', 'required|trim|xss_clean');  	
				$this->form_validation->set_rules('instalation', 'installation date ', 'required|trim|xss_clean');  	
				$this->form_validation->set_rules('test1', 'Test No 1 ', 'trim|xss_clean');  	
				$this->form_validation->set_rules('result1', 'Test result 1 ', 'trim|xss_clean');  	
				 
				$this->form_validation->set_rules('training', 'User training ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('trained', 'User trained ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('warranty', 'Machine warranty period ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('comment', 'Use comment ', 'trim|xss_clean');
				$this->form_validation->set_rules('customer', 'Customer Name ', 'required|trim|xss_clean');
				
				 
				
				 $data['action'] = 1;
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{    
						  
							 $this->load->view('bio/edit_instalation_data' , $data);
							
					}
					else
					{ 
			  $client =    $this->input->post('client_id'); 
			  $dep =    $this->input->post('dep'); 
			 $device =    $this->input->post('device');
			 $model =    $this->input->post('mod');
			 $sn =    $this->input->post('sn');
			 $country =    $this->input->post('country');
			 $sup =    $this->input->post('sup');
			 $man =    $this->input->post('man');
			 $code =    $this->input->post('code');
			 $price =    $this->input->post('price');
			 $yr =    $this->input->post('yr');
			 
			 $i_date =    $this->input->post('instalation');
			 $date_send  = array($device ,  $model , $sn ,$dep ,  $country , $yr , $sup, $man , $i_date , $price  , $code );
             $training =  $this->input->post('training');
			 $trained =    $this->input->post('trained');
			 $waranty =    $this->input->post('warranty'); 
			 $customer =    $this->input->post('customer');
			 $comment =    $this->input->post('comment');
	 if( $training > 0 and  $trained < 1){//   =  
		  bio_warning('Please indicate number of users trained');
			$this->load->view('bio/edit_instalation_data' , $data);
							
		 
	 } 
	   else {
			 $instalation_id = 0;
			 $machine_id = 0;
			 $machines =   $_SESSION['installations_results_single'];
			 foreach($machines as $mac){ 
			 $instalation_id  = $mac->installation_id;
			 $machine_id =$mac->machine_id ;		 
			 }
			 if(  $machine_id >0 and $instalation_id > 0 ){
			 $this->bio->Installation_machine_update( $date_send ,   $client , $machine_id); 
	 
			$instalation_data = array($machine_id ,  $training , $waranty ,$trained ,  $comment , $customer  );
	 
			$this->bio->Installation_update( $instalation_data ,   $client ,$instalation_id); 
	  
			success('Operation was successful');
			 }else{
				 bio_warning('Error has occured please try again');
			 }
					 
	 
					}
					
				}
				}
				//multiple service report
				
				function Service_report_form(){ 
				 $this->check_user();  
				$this->form_validation->set_rules('client', 'Hospital Name ', 'required|trim|xss_clean');
				 
				$this->form_validation->set_rules('company', 'Company ', 'required|trim|xss_clean');
				$this->form_validation->set_rules('technician', 'Technician Company ', 'required|trim|xss_clean'); 			
				$this->form_validation->set_rules('departments', 'Machine ', 'required|trim|xss_clean');
				 
				
				 
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{    
						  $data['action'] = 1;
						   $this->load->view('bio/Select_service_report_for_machines' , $data);
						  
						 
							
					}
					else
					{  
				 
			 
						  $client =   $this->encrypt->decode($this->input->post('client'));//Pitickets2020//
																   //get machine data from here
						  $company =   $this->encrypt->decode($this->input->post('company'));
						  $tech =   $this->encrypt->decode($this->input->post('technician'));
						  $department =   $this->encrypt->decode($this->input->post('departments')); 
							 
							  
						   $search =  array(  $client   , $company ,    $tech ,  $department  );
						 
						   if(  $client  < 0   ){
							   
							   bio_error("Select at least one field to continue");
							   
						   }
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								 $_SESSION['service_updates'] =  $search ;//session to store machine updates
								
								$data['machines'] =$this->bio->get_departmental_machines($department , $client);
							 
							   // print_r($return_data);
								 
								 
								 $data['action'] =1;
								  $this->load->view('bio/add_service_reports' , $data);
								 
								 
								 //$this->bio-> Update_servicing_company($service_comp , $_SESSION['service_company_id']);
							   
								 //success('Update was successfully');
							  
							}
							else login();
							 
					   
				   }
				 
									  

				}
				//add new technician into the dataase from here
				
				
				function Add_new_service_technician(){ 
				 $this->check_user();
				
										//set validation riles and check them
				$this->form_validation->set_rules('name', 'Technician ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('contact', 'Phone Number ', 'trim|is_natural|min_length[8]|max_length[14]|xss_clean');
				 
				$this->form_validation->set_rules('email', 'Email Address ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('tech_comp', 'Technician company ', 'trim|max_length[10]|xss_clean');
				
				
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						 $this->load->view('bio/add_new_service_tech');
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  strtolower(trim($this->input->post('name')));
						  $fon =   $this->input->post('contact');
						   
						   $email=   $this->input->post('email');
						   $tech_comp=   $this->input->post('tech_comp');
						   $service_comp =  array($fname ,$fon ,   $email , $tech_comp);
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								  $this->bio-> Add_servicing_tech($service_comp);
							   
								 success('New  Servicing Technician has been added successfully');
							  
							}
							else login();
							 
					   
				   }
									  

				}
				//delete user events
				
				
				function delete_system_events(){ 
				 $this->check_user(); 
					 
						 $data['action'] = 1; 
						 // $this->load->view('bio/edit_events' , $data);
						 
							
						 $event  =   $this->encrypt->decode( $_SESSION['edit_event']); 
						  
						 
								  $this->bio-> Delete_event( $event);
							   
								 warning('Event successfuly deleted');
						 
				 
				}
				//add new service event
				function edit_system_events(){ 
				 $this->check_user();
				$this->form_validation->set_rules('name', 'Device  supplier ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('sdate', 'Start Date ', 'trim|min_length[2]|max_length[12]|xss_clean');
				 
				$this->form_validation->set_rules('edate', 'End Date ', 'trim|min_length[2]|max_length[12]|xss_clean');
				
				$this->form_validation->set_rules('stime', 'Start Time ', 'trim|max_length[12]|xss_clean');
				$this->form_validation->set_rules('end_time', 'End Time ', 'trim|max_length[12]|xss_clean');
				$this->form_validation->set_rules('type', 'Event Type ', 'trim|greater_than_equal_to[0]|xss_clean');
				
				
				  $data['action'] = 2; 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						
							 
						 $this->load->view('bio/edit_events' , $data);
						 
							
					}
					else
					{  
						  $fname =  strtolower(trim($this->input->post('name')));
						  $sdate =   $this->input->post('sdate');
							$edate=   $this->input->post('edate');
						   $start_time=   $this->input->post('start_time');
							$end_time=   $this->input->post('end_time');
							$type=   $this->input->post('type');
							 $id = $this->session->userdata('bio_id');
						   $service_comp =  array($fname ,$sdate ,   $edate , $start_time , $end_time , $type , $id);
						  $event  =   $this->encrypt->decode( $_SESSION['edit_event']);   
							 
								 
								 
						  $diff  = dateDiff( $edate , $sdate);
							
						   if($diff > 0 and $edate !=''){
							   warning('Your dates seem to be invalid');
								$this->load->view('bio/edit_events' , $data);
							   
						   }
						   else {
						   
						  
							if ($id  > 0){
								  $this->bio-> Update_user_events($service_comp , $event);
							   
								 success('Event succesfully edited');
							  
							}else login();
						   }
							
							 
					   
				   }
									  

				}
				//new tech
				
				
				
				function system_events(){ 
				 $this->check_user();
				$this->form_validation->set_rules('name', 'Device  supplier ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('sdate', 'Start Date ', 'trim|min_length[2]|max_length[12]|xss_clean');
				 
				$this->form_validation->set_rules('edate', 'End Date ', 'trim|min_length[2]|max_length[12]|xss_clean');
				
				$this->form_validation->set_rules('stime', 'Start Time ', 'trim|max_length[12]|xss_clean');
				$this->form_validation->set_rules('end_time', 'End Time ', 'trim|max_length[12]|xss_clean');
				$this->form_validation->set_rules('type', 'Event Type ', 'trim|greater_than_equal_to[0]|xss_clean');
				
				
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						 $this->load->view('bio/new_event');
						 
							
					}
					else
					{  
						  $fname =  strtolower(trim($this->input->post('name')));
						  $sdate =   $this->input->post('sdate');
							$edate=   $this->input->post('edate');
						   $start_time=   $this->input->post('start_time');
							$end_time=   $this->input->post('end_time');
							$type=   $this->input->post('type');
							 $id = $this->session->userdata('bio_id');
						   $service_comp =  array($fname ,$sdate ,   $edate , $start_time , $end_time , $type , $id);
						  $diff  = dateDiff( $edate , $sdate);
							
						   if($diff > 0 and $edate !=''){
							   warning('Your dates seem to be invalid');
							   $this->load->view('bio/new_event');
							   
						   }
						   else {
						   
						  
							if ($id  > 0){
								  $this->bio-> Add_user_event($service_comp);
							   
								 success('Event  addition was successful');
							  
							}else login();
						   }
							
							 
					   
				   }
									  

				}
				//new tech
				
				function Search_Inventories(){ 
				 $this->check_user();
				
								 //set validation riles and check them
				$this->form_validation->set_rules('search_inventory', 'Device  supplier ', 'max_length[30]|xss_clean');
				 
				
				 
												//check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						 //$this->load->view('bio/add_new_service_tech');
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  strtolower(trim($this->input->post('search_inventory')));
						  
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								  $this->bio-> Add_servicing_tech($service_comp);
							   
								 success('New  Servicing Technician has been added successfully');
							  
							}
							else login();
							 
					   
				   }
									  

				}
				
				
				
				//NEW Device manufacturerE IN THE DATABASE
				
				function Add_new_manufacturer(){
				 $this->check_user();
				
				 
				$this->form_validation->set_rules('name', 'Device manufacturer ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				$this->form_validation->set_rules('contact', 'Phone Number ', 'trim|is_natural|min_length[8]|max_length[14]|xss_clean');
				$this->form_validation->set_rules('contactp', 'Contact Person ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('email', 'Email Address ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('loc', 'Location ', 'trim|min_length[2]|max_length[60]|xss_clean');
				 
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						$this->load->view('bio/add_new_manufacturer');
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  strtolower(trim($this->input->post('name')));
						  
						   $fon =   $this->input->post('contact');
						  $contact_person=   $this->input->post('contactp');
						  
						   $email=   $this->input->post('email');
							 $loc=   $this->input->post('loc');
						   $supplier =  array($fname ,$fon , $contact_person , $email , $loc );
						  
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								 $this->bio-> Add_manufacturer_bank($fname);
							   
								 success('New manufacturer has been added successfully');
							  
							}
							else login();
							 
					   
				   }
									  

				}
				
				//function to update new departments 
				
				
				function Update_departments(){
				 $this->check_user();
				 
			 
				if(isset($_SESSION['dept_edit'] ) ){
				
				 
				$this->form_validation->set_rules('name', 'Department name  ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				$this->form_validation->set_rules('dtype', 'Department type  ', 'trim|required|max_length[3]|xss_clean');
				 
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						  $data['action'] = 1;
						 $this->load->view('bio/edit_departments', $data );
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =   ucfirst(strtoupper(trim($this->input->post('name'))));
						  $dtype =    $this->input->post('dtype');
						  
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								
							   $dept = $this->encrypt->decode($_SESSION['dept_edit'] );
							   
								$this->bio-> Update_depatment_names($fname , $dept ,  $dtype);
								 success('Department has been updated');
								 
						  //
						  $this->bio->  Update_machine_depatment_types($dept , $dtype);
					 
	 
							  
							   
								
							}
							else login();
							 
					   
				   }
				} else   login();
									  

				}
				
										 //update machine suppliers 
				
				
				function Update_suppliers(){
				 $this->check_user();
				 
				if(isset($_SESSION['dept_edit'] ) ){            //check if session has been set that stores the supplier id
																//validate user in puts
				$this->form_validation->set_rules('name', 'Device  supplier ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('contact', 'Phone Number ', 'trim|is_natural|min_length[8]|max_length[14]|xss_clean');
				$this->form_validation->set_rules('contactp', 'Contact Person ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('email', 'Email Address ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('loc', 'Location ', 'trim|min_length[2]|max_length[60]|xss_clean');
				
				
											   //check validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 $data['action'] = 1; 
						$this->load->view('bio/edit_machine_supplier' , $data );
						 
							
					}
					else
					{       
						   $fname =  strtolower(trim($this->input->post('name')));
						   $fon =   $this->input->post('contact');
						   $contact_person=   $this->input->post('contactp');
						  
						   $email=   $this->input->post('email');
						   $loc=   $this->input->post('loc');
						   $supplier =  array($fname ,$fon , $contact_person , $email , $loc );
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								
								$dept = $this->encrypt->decode($_SESSION['dept_edit'] );
							   
								$this->bio-> update_suplier_from_contloller($supplier , $dept);
								 success('Supplier has been updated');
							  
							   
								
							}
							else login();
							 
					   
				   }
				} else   login();
									  

				}
				
				//update Device manufactureres
				
				function Update_manufactureres(){
				 $this->check_user();
				 
				if(isset($_SESSION['dept_edit'] ) ){
				
				 
				 
				$this->form_validation->set_rules('name', 'Device manufacturer ', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				$this->form_validation->set_rules('contact', 'Phone Number ', 'trim|is_natural|min_length[8]|max_length[14]|xss_clean');
				$this->form_validation->set_rules('contactp', 'Contact Person ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('email', 'Email Address ', 'trim|min_length[2]|max_length[30]|xss_clean');
				
				$this->form_validation->set_rules('loc', 'Location ', 'trim|min_length[2]|max_length[60]|xss_clean');
				  
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 $data['action'] = 1;
						 $this->load->view('bio/edit_manufacturere_info' , $data );
						 
							
					}
					else
					{         
						   $fname =  ucfirst(strtolower(trim($this->input->post('name'))));
						  
						   $fon =   $this->input->post('contact');
						  $contact_person=   $this->input->post('contactp');
						  
						   $email=   $this->input->post('email');
							 $loc=   $this->input->post('loc');
						   $manf_data=  array($fname ,$fon , $contact_person , $email , $loc );
						  
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								
								$dept = $this->encrypt->decode($_SESSION['dept_edit'] );
							   
								$this->bio->Update_manufacturer_from_controller( $manf_data , $dept);
								 success('Manufacturer has been updated');
							  
							   
								
							}
							else login();
							 
					   
				   }
				} else   login();
									  

				}
				
				//delete this manufacturer from the database 
				
				
				function Delete_manufacturere(){
				 $this->check_user();
				 
				if(isset($_SESSION['dept_edit'] ) ){
				
				 $fname =    strtolower(trim($this->input->post('name')));
						  
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								
								 $dept = $this->encrypt->decode($_SESSION['dept_edit'] );
							   
								$this->bio->Delete_manufacturere( $dept);
								 success('Supplier has been deleted');
							  
							   
								
							}
							else login();
				} else   login();
									  

				}
				
				//update machine states
				function Update_machine_states_info(){
				 $this->check_user();
				 
				if(isset($_SESSION['dept_edit'] ) ){
				
				 
				$this->form_validation->set_rules('name', 'Manufacturers name', 'trim|required|min_length[2]|max_length[30]|xss_clean');
				 
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 $data['action'] = 1; 
						  $this->load->view('bio/edit_states' , $data );
						 
							
					}
					else
					{         
						  echo  $fname =    strtolower(trim($this->input->post('name')));
						  
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								
								  $dept = $this->encrypt->decode($_SESSION['dept_edit'] );
								$this->bio->Update_machine_states($fname , $dept);
								  success('Supplier has been updated');
							  
							   
								
							}
							else login();
							 
					   
				   }
				} else   login();
									  

				}
				
				//edit setting ststes from the database
				
				function Update_system_settinngs(){
				 $this->check_user();
				 
				if(isset($_SESSION['edit_settings'] ) ){
				
				 
				$this->form_validation->set_rules('name', 'Setting ', 'trim|required|min_length[1]|max_length[2]|xss_clean|is_natural');
				 
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 $data['action'] = 4; 
						  $this->load->view('bio/edit_setting' , $data);
						 
							
					}
					else
					{         
						  $state  =     $this->input->post('name');
						  
						   
						   
								
								  $stn =  $_SESSION['edit_settings'];
								 
								   $this->bio->Update_setting_state($stn , $state);
								 echo  success('Supplier has been updated');
							   
							 
					   
				   }
				} else   login();
									  

				}
				
				
				
				
				
				
				//function to capture number of departments to be entered fo this user into the dba_close
				function get_department_numbers(){
				 $this->check_user();
				
				 
				$this->form_validation->set_rules('dpts', 'Number of departments', 'trim|required|greater_than_equal_to[1]|numeric|less_than_equal_to[100]|xss_clean|is_natural_no_zero');
				 
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						$this->load->view('bio/department_nos');
						 
							
					}
					else
					{         // rules have been passed 
						  $dpts =  trim($this->input->post('dpts'));
						  
						   
						   
							$id = $this->session->userdata('bio_id');
							if ($id  > 0){
								$_SESSION['no_of_departments'] = $dpts ;
								 
								$this->session->set_tempdata('no_of_departments', $dpts, 300); 
								$this->load->view('bio/create_departments');
								
							   
								
							}
							else login();
							 
					   
				   }
									  

				}
				
				function hellox(){
					echo 'hello';
					$entray_ar  = array('mmdmdmmdmd' , 'mmdmdmd' , '' , '' , 1);
					
					echo $this->bio->Add_hospitals($entray_ar);
					
					
				}
			
			
			function new_user(){
				$this->check_user();
				$this->form_validation->set_rules('f-name', 'first name ', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha');
				$this->form_validation->set_rules('l-name', 'last name', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha');
				//$this->form_validation->set_rules('f-name', 'f-name', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha');
				$this->form_validation->set_rules('email', 'email', 'trim|xss_clean|valid_email');
				$this->form_validation->set_rules('mobile', 'phone number', 'trim|min_length[2]|max_length[50]|xss_clean|is_natural');
				$this->form_validation->set_rules('username', 'user name', 'trim|required|min_length[4]|max_length[16]|xss_clean|alpha');
				$this->form_validation->set_rules('password', 'password', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha_dash');
				$this->form_validation->set_rules('pass1', 'Passwords provided', 'trim|required|matches[password]'  );
				$this->form_validation->set_rules('hosp', 'Hospital', 'trim|xss_clean'  );
				 if ($this->form_validation->run() == FALSE)
					{
						//echo validation_errors();
						//$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
						
						$this->load->view('bio/add_new_user');
						 
							
					}
					else
					{
						 $_SESSION['error'] = '';
						  $fname = $this->input->post('f-name');
						  $lname = $this->input->post('l-name');
						  $email = $this->input->post('email');
						  $fon = $this->input->post('mobile');
						  $hosp = $this->input->post('hosp');
						  $uname =  strtolower($this->input->post('username'));
						  $pass = strtolower($this->input->post('password')); 
						 
						  
						  $entray_ar  = array($fname , $lname , $email , $fon , $uname , $pass , $hosp);
						  if( $uname  == $pass){
							   warning('You password should be different from your user name');
							 
							  $this->load->view('bio/add_new_user');
							  
							 // exit('');
						  }
						 ELSE if($this->bio->validate_user_name($uname)  > 0 ){
								 //$this->load->view('bio/add_new_user');
									warning('Please choose a different user name');
								  $this->load->view('bio/add_new_user');
								 
								 // exit();
						  }
						  else{ $_SESSION['error'] = '';
							 $id = $this->session->userdata('bio_id');
						   $profile  =   $this->bio->Get_user_profile_info($id);
							 if(sizeof($profile) > 0){ 
							  
							  $this->bio->Add_user_to_db($entray_ar);
							  success('operation was successful');
							   
							 }
						  }
					
				   }
									  

				}
				
				//Update machine
				function Update_machine(){
				$this->check_user();
				//$this->form_validation->set_rules('name', 'Device Name ', 'trim|required|min_length[2]|max_length[50]|xss_clean');
				$this->form_validation->set_rules('mod', 'Model', 'trim|min_length[2]|max_length[50]|xss_clean');
					$this->form_validation->set_rules('sn', 'Serial Number', 'trim|max_length[20]|xss_clean');
					$this->form_validation->set_rules('man', 'Manufacturer', 'trim|max_length[10]|xss_clean|is_natural');
					$this->form_validation->set_rules('yr', 'Year of Manufacture', 'trim|min_length[3]|max_length[5]|xss_clean|is_natural');
					$this->form_validation->set_rules('yri', 'Year of Installation', 'trim|min_length[2]|max_length[4]|xss_clean|is_natural');
					$this->form_validation->set_rules('dep', 'Department', 'trim|min_length[1]|max_length[10]|xss_clean|is_natural');
					$this->form_validation->set_rules('state', 'Device State', 'trim|required|min_length[1]|max_length[10]|xss_clean|is_natural');
					$this->form_validation->set_rules('country', 'Country of origin', 'trim|max_length[60]|xss_clean');
					$this->form_validation->set_rules('sup', 'Supplier', 'trim|max_length[10]|xss_clean|is_natural');
					
					
					$this->form_validation->set_rules('code', 'Device Code', 'trim|max_length[15]|xss_clean');
					
					$this->form_validation->set_rules('price', 'Device Price', 'trim|min_length[0]|max_length[10]|xss_clean|is_natural');
					 
				  if ($this->form_validation->run() == FALSE)
					{
						 
						 
						 $data['action'] = 1; 
						  
						$this->load->view('bio/edit_device' , $data);
						 
							
					}
					else
					{ 
						  $idm=   $this->encrypt->decode($_SESSION['mcn_field_id']) ;
						 
					
						  $fname =  strtolower( $this->input->post('name'));
						  $mod = ucfirst(strtolower( $this->input->post('mod')));
						  $sn = ucfirst(strtolower( $this->input->post('sn')));
						  $man = $this->input->post('man');
						  $sup = $this->input->post('sup');
						  
						  $dep = $this->input->post('dep');
						  $state = $this->input->post('state');
						  $country = ucfirst(strtolower( $this->input->post('country')));
						  
						  
						  $yr = $this->input->post('yr');
						  $yri = $this->input->post('yri'); 
						  
						   $code = ucfirst(strtolower( $this->input->post('code')));
							$price = $this->input->post('price');
						   
						   
						
							$entray_ar  =  $this->bio->Add_manufacturer_bank($fname );
						  
						   $id_machine  =  $this->bio-> Get_Next_machine_id($fname);
							$entray_ar  = array($id_machine , $sup , $man , $dep , $mod, $state, $sn , $country  , $yr , $yri , $code , $price);
						 
						   
						  
						   $id = $this->session->userdata('bio_id');
							
							  
							   $this->bio->Update_device_info($entray_ar , $idm);
							  success('operation was successful');
							 $_SESSION['mcn_field_id'] =  $_SESSION['error'] = '';
							   
							 
				   }
									  

				}
				
				//delete this machine from the database
				
				function Delete_device(){
				$this->check_user();
				 
						  $idm=   $this->encrypt->decode($_SESSION['mcn_field_id']) ;
						 
					
						  $this->bio-> Delete_device_data($idm);
							  success('operation was successful');
							 $_SESSION['mcn_field_id'] =  $_SESSION['error'] = '';
			 
				}
				
				function Change_order_status(){
				   $this->check_user();
				 
						  $idm=   $this->encrypt->decode($_SESSION['mcn_order_id'][0]) ;
						  
						 
					
						  $this->bio-> Change_device_order_states($idm , $_SESSION['mcn_order_id'][1]);
							  success('operation was successful');
							 $_SESSION['mcn_order_id'][0] =  $_SESSION['error'] = '';
			 
				}
				
				
				
		
				
				//create new item from the database
				
				function new_price_item(){
				$this->check_user();
				$this->form_validation->set_rules('m_name', 'Device  name ', 'trim|required|min_length[2]|max_length[60]|xss_clean');
				$this->form_validation->set_rules('scie_name', 'Name', 'trim|min_length[2]|max_length[60]|xss_clean');
				 
				$this->form_validation->set_rules('category', 'Category', 'trim|xss_clean');
				$this->form_validation->set_rules('spec', 'Specification', 'trim|min_length[1]|max_length[950]|xss_clean'); 
				
				$this->form_validation->set_rules('desc', 'Device  Description', 'trim|min_length[1]|max_length[950]|xss_clean'); 
				
				$this->form_validation->set_rules('featured', 'Featured', 'trim|xss_clean'  );
				$this->form_validation->set_rules('price', 'Price', 'trim|min_length[3]|max_length[9]|xss_clean');

			  $this->form_validation->set_rules('discount', 'Discount', 'trim|max_length[6]|xss_clean'); 
			   $this->form_validation->set_rules('new_arrival', 'New Arrival', 'trim|xss_clean'); 			
				
				
				 if ($this->form_validation->run() == FALSE)
					{
						//echo validation_errors();
						//$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
						
						//$this->load->view('bio/add_new_user');
						$this->load->view('bio/add_new_catelogue');
						 
						 
							
					}
					else
					{
						//exit('hello boss');
						
						$this->form_validation->set_rules('m_name', 'Device  name ', 'trim|required|min_length[2]|max_length[60]|xss_clean');
				$this->form_validation->set_rules('scie_name', 'Name', 'trim|min_length[2]|max_length[60]|xss_clean');
				 
				$this->form_validation->set_rules('category', 'Category', 'trim|xss_clean');
				$this->form_validation->set_rules('spec', 'Specification', 'trim|min_length[1]|max_length[950]|xss_clean'); 
				
				$this->form_validation->set_rules('descption', 'Device  Description', 'trim|min_length[1]|max_length[950]|xss_clean'); 
				
				$this->form_validation->set_rules('featured', 'Featured', 'trim|xss_clean'  );
				$this->form_validation->set_rules('price', 'Price', 'trim|min_length[3]|max_length[9]|xss_clean');

	$this->form_validation->set_rules('discount', 'Discount', 'trim|max_length[6]|xss_clean'); 
	$this->form_validation->set_rules('new_arrival', 'New Arrival', 'trim|xss_clean'); 			
				

						 
						  $fname = $this->input->post('m_name');
						  $lname = $this->input->post('scie_name');
						  $cat = $this->input->post('category');
						  $spec = $this->input->post('spec');
						  $desc = $this->input->post('descption');
						  $ft =  $this->input->post('featured');
						  $prc = $this->input->post('price'); 
						  
						   $ds =  $this->input->post('discount');
						  $na = $this->input->post('new_arrival');
						 
						  
						  $entray_ar  = array($fname , $lname , $cat , $spec , $desc , $ft , $prc , $ds , $na);
						   
							 $id = $this->session->userdata('bio_id');
						   $profile  =   $this->bio->Get_user_profile_info($id);
							 if(sizeof($profile) > 0){ 
							  
							  $this->bio->Add_new_cat_item_to_db($entray_ar);
							  success('operation was successful');
							   
							 }
						  }
					
				   
									  

				}
				
				//Edit cat item 
				
				function Edit_cat_item(){
				$this->check_user();
				if( !isset($_SESSION['cat_item_alt'])){ danger('Item was not found'); exit();}
				$this->form_validation->set_rules('m_name', 'Device  name ', 'trim|required|min_length[2]|max_length[60]|xss_clean');
				$this->form_validation->set_rules('scie_name', 'Name', 'trim|min_length[2]|max_length[60]|xss_clean');
				 
				$this->form_validation->set_rules('category', 'Category', 'trim|xss_clean');
				$this->form_validation->set_rules('spec', 'Specification', 'trim|min_length[1]|max_length[950]|xss_clean'); 
				
				$this->form_validation->set_rules('desc', 'Device  Description', 'trim|min_length[1]|max_length[950]|xss_clean'); 
				
				$this->form_validation->set_rules('featured', 'Featured', 'trim|xss_clean'  );
				$this->form_validation->set_rules('price', 'Price', 'trim|min_length[3]|max_length[9]|xss_clean');

			  $this->form_validation->set_rules('discount', 'Discount', 'trim|max_length[6]|xss_clean'); 
			   $this->form_validation->set_rules('new_arrival', 'New Arrival', 'trim|xss_clean'); 			
				
				
				 if ($this->form_validation->run() == FALSE)
					{
						$data['action'] =1;
						$this->load->view('bio/edit_cat_item' , $data);
						 
						 
							
					}
					else
					{
						//exit('hello boss');
						
						$this->form_validation->set_rules('m_name', 'Device  name ', 'trim|required|min_length[2]|max_length[60]|xss_clean');
						  $this->form_validation->set_rules('scie_name', 'Name', 'trim|min_length[2]|max_length[60]|xss_clean');
				 
						 $this->form_validation->set_rules('category', 'Category', 'trim|xss_clean');
						  $this->form_validation->set_rules('spec', 'Specification', 'trim|min_length[1]|max_length[950]|xss_clean'); 
				
						$this->form_validation->set_rules('descption', 'Device  Description', 'trim|min_length[1]|max_length[950]|xss_clean'); 
				
						$this->form_validation->set_rules('featured', 'Featured', 'trim|xss_clean'  );
						$this->form_validation->set_rules('price', 'Price', 'trim|min_length[3]|max_length[9]|xss_clean');

						 $this->form_validation->set_rules('discount', 'Discount', 'trim|max_length[6]|xss_clean'); 
						 $this->form_validation->set_rules('new_arrival', 'New Arrival', 'trim|xss_clean'); 			
				

						 
						  $fname = $this->input->post('m_name');
						  $lname = $this->input->post('scie_name');
						  $cat = $this->input->post('category');
						  $spec = $this->input->post('spec');
						  $desc = $this->input->post('descption');
						  $ft =  $this->input->post('featured');
						  $prc = $this->input->post('price'); 
						  
						   $ds =  $this->input->post('discount');
						  $na = $this->input->post('new_arrival');
						 
						 $id1  = $_SESSION['cat_item_alt']['id'];
						  $entray_ar  = array($fname , $lname , $cat , $spec , $desc , $ft , $prc , $ds , $na);
						  
						   
							 $id = $this->session->userdata('bio_id');
						   $profile  =   $this->bio->Get_user_profile_info($id);
							 if(sizeof($profile) > 0){ 
							  
							  $this->bio->Update_cat_item($entray_ar , $id1);
							  success('operation was successful');
							   
							 }
						  }
					 
				}
				
				//delete cat item from the database from here
				
				function Delete_catlog_item(){
					if(isset( $_SESSION['cat_item_alt'])){
					   $id1  = $_SESSION['cat_item_alt']['id'];
					   $this->bio->Delete_cat_item($id1 , 0);
					   success('Operation was successful');
					 
					 
					}
					else {
						
						bio_error('No data was set');
					}
					
					
				}
				
				
				//add new chat
				
				function new_chat_item(){
				$this->check_user(); 
				  
				$this->form_validation->set_rules('chat_message', 'Message', 'trim|min_length[1]|max_length[950]|xss_clean');  			
				
				
				 if ($this->form_validation->run() == FALSE)
					{
						 $this->load->view('bio/chats/read_chat_items');
						 
						 
							
					}
					else
					{
						 
						 
						  $message  = $this->input->post('chat_message'); 
						  $receiver  =   $this->encrypt->decode($_SESSION['chat_receiver']);
						  
						 
						   
							 $id = $this->session->userdata('bio_id');
						   $profile  =   $this->bio->Get_user_profile_info($id);
							 if(sizeof($profile) > 0){ 
							  //$entray_ar  = array($id , $receiver , $message );
							 // print_r( $entray_ar);
							  $this->bio->add_notification( $id , $receiver , $message , 0 ,'' );
							  
							  //$this->bio->Add_new_cat_item_to_db($entray_ar);
							  //success('operation was successful');
								 $tempdata = array(  'message' => 'Message sent!');

								$this->session->set_tempdata($tempdata, NULL, 4);
							  $this->load->view('bio/chats/read_chat_items');
							   
							 }
							 else {
								 bio_error('Operation is failed Invalid user data');
							 }
						  }
					
				   
									  

				}
				
				
											   //update profile information for this user loged in
				function acc_update_profile(){
				$this->check_user();
				$this->form_validation->set_rules('f-name', 'first name ', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha');
				$this->form_validation->set_rules('l-name', 'last name', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha');
				$this->form_validation->set_rules('email', 'email', 'trim|xss_clean|valid_email');
				$this->form_validation->set_rules('mobile', 'phone number', 'trim|min_length[2]|max_length[50]|xss_clean|is_natural');
				 //heck validation rules
				 if ($this->form_validation->run() == FALSE) 
					{  
						 
						 $_SESSION['profile'] =1;            //set profile page highlight the pofile edit tab
						 $this->load->view('bio/profile');  //load the profile alt page
						 
							
					}
					else
					{         // rules have been passed 
						  $fname =  strtolower(trim($this->input->post('f-name')));
						  $lname = strtolower(trim($this->input->post('l-name')));
						  $email = strtolower(trim($this->input->post('email')));
						  $fon = trim($this->input->post('mobile'));
						  $uname =  strtolower($this->input->post('username'));
						  $pass = strtolower($this->input->post('password')); 
						 
						  
						  $entray_ar  = array($fname , $lname , $email , $fon);
						   
							$id = $this->session->userdata('bio_id');
						   $profile  =   $this->bio->Get_user_profile_info($id);
							 if(sizeof($profile) > 0){
							 $this->bio-> update_user_biodata($entray_ar , $id);
							   success('operation was successful');
							 }
						  
					
				   }
									  

				}
				
				//update user name and password from here 
				
				function acc_alt_profile(){
				$this->check_user();
				 
				 $this->form_validation->set_rules('password', 'password', 'trim|required|min_length[2]|max_length[50]|xss_clean|alpha_dash');
				$this->form_validation->set_rules('pass1', 'Passwords provided', 'trim|required|matches[password]'  );
				//$this->form_validation->set_rules('passo', 'Passwords provided', 'trim|required]'  );
				 if ($this->form_validation->run() == FALSE)
					{
						 
						  
						 $this->load->view('bio/update_password');
						 
							
					}
					else
					{
						 $id = $this->session->userdata('bio_id');
						   $profile  =   $this->bio->Get_user_profile_info($id);
							 if(sizeof($profile) > 0){
						  //get password information from here
								 $pass = strtolower($this->input->post('password'));
								  //echo  $pass0 = strtolower($this->input->post('passo')); 							 
						 
								 
						   
								 $this->bio->update_user_password($pass  , $id); 
								  $user_data  = $this->bio-> Bio_Verificaion_Update($id);
								  $this->session->set_userdata($user_data);
								   success('operation was successful');
								 
								  
							 }else {
								 bio_error('Error unknown user profile data');
							 }
						  
					
				   }
									  

				}
				
				
				
			 
			
			
			  function username_check($str)
			{
					if ($str == 'test')
					{
							$this->form_validation->set_message('username_check', 'Your user name is already taken');
							return FALSE;
					}
					else
					{
							return TRUE;
					}
			}
			
			
			 function pass_check($str , $str2)
			{
					if ($str != $str2)
					{
							$this->form_validation->set_message('pass_check', 'The {field} your passwords do not match');
							return FALSE;
					}
					else
					{
							return TRUE;
					}
			}
			
			
			function check_user(){
					$log_id = $this->session->userdata('logged_in');
					if($log_id and $this->session->has_userdata('bio_name'))
					{
						   
					   }
							  else{
									 $this->LogoutUser();
				
								 }
						}
			
	}
			
			 
			
			 
