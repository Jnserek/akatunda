<?php

class Upload extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
        }

        public function index()
        {
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			$data['base']       = $this->config->item('base_url');
			$data['error']       =  array('error' => '');
                $this->load->view('upload_form',   $data);
				 }else redirect('Error', 'refresh');
        }
		function Upload_images(){
			 
		 $log_id = $this->session->userdata('logged_in');
		 if(isset($_SESSION['cat_item'] )){
			 
			  $id_data = $this->encrypt->decode( $_SESSION['cat_item']); 
		if($log_id){
		  $photoname =   $id_data;
			 
		 $this->load->library('image_lib');
		$this->load->helper('file');
		$config['upload_path'] = './cat_items/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']	= '10000';
		$config['max_width']  = '10024';
		$config['max_height']  = '10768';
		$config['overwrite'] = TRUE;
		$config['file_name'] = $photoname;
		$this->load->library('upload', $config);
		$this->load->library('SimpleImage');
		$img_id = $photoname.'.jpg'; 
		 
	
		if(isset( $_FILES["userfile"])    ) {  
			
		if(isset( $_FILES["userfile"])) {
			 
		
		if ($_FILES["userfile"]["error"] > 0) {
        			$error = $_FILES["userfile"]["error"];
    		}
			else if (($_FILES["userfile"]["type"] == "image/gif") || 
			($_FILES["userfile"]["type"] == "image/jpeg") || 
			($_FILES["userfile"]["type"] == "image/png") || 
			($_FILES["userfile"]["type"] == "image/jpeg")) {


             $image = new SimpleImage();

            $image->load($_FILES['userfile']['tmp_name']);
           $image->resizeToWidth(500); 
            $image->resizeToHeight(500);
            $image->save('./cat_items/'.$img_id);
			  $image->resizeToWidth(150); 
            $image->resizeToHeight(100);
			 
            $image->save('./cat_items/thumbs/'.$img_id);
		
			 
	
	     }
		}  

		// $this->events->Update_Adverts_in_db($datai , $id_data['EId']);
		 echo 1;
		
		} 
		
		
		}else exit('Invalid data supplied');
		}else exit('Invalid data supplied');
		
 	
		
}

	 

        public function do_upload()
        {
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			IF(ISSET($_POST['cat'])){
			    $cat  = $_POST['cat'];
			    $this->load->library('csvimport'); 
               $data['base']       = $this->config->item('base_url');
			    $config['upload_path']          = './machines/';
                $config['allowed_types']        = 'csv';
                $config['max_size']             = 4000; 

                $this->load->library('upload', $config);
					$data['base']       = $this->config->item('base_url');
			         $data['error']         =  array('error' => '');
               

                if ( ! $this->upload->do_upload('userfile'))
                {
                       $data['error']       =  array('error' => $this->upload->display_errors());

                        $this->load->view('upload_form',   $data);
                }
                else
                {
				 
				$this->load->library('upload');
				 $file_data = $this->upload->data();
                $file_path =  './machines/'.$file_data['file_name'];
				$csv_array = $this->csvimport->get_array($file_path)	; 
           		$succes = 0;
                $fail = 0;				
            if ($this->csvimport->get_array($file_path)) {
				
                $csv_array = $this->csvimport->get_array($file_path);
                foreach ($csv_array as $row) {
					 
                   $insert_data = array(//database>>field name
                        'machine_name'=>$row['MachineName'],
                        'scie_name'=>$row['ScientificName'],
						'specifications'=>$row['Specifications'],
                        'descriptions'=> $row['Description'],
                        'price'=>  (int)$row['Price'],
						'machine_cat'=> (int) $cat,
						'discount'=> (int) $row['Discount'] 
                    );
					
					 
                     $this->bio->Add_new_cat_excell($insert_data);
					 $succes += 1; 
					 
                }
              
             
                 
            }

                	 

                 $upload_status = 'success uploads  >>'.$succes . ' failed uploads >>'  .$fail;
                 $this->session->set_flashdata('success', $upload_status );
                          redirect('Upload/');
                }
		} else redirect('Error', 'refresh');
		}else redirect('Error', 'refresh');
        }
}
?>