<?php class Biomedical extends CI_Model {
    
    function __construct() {
        parent::__construct();
		$this->load->database();
        
    }
	
	function Data_cleabing_supliers(){//analysis_suplier_bank2
		$this->db->select('*'); 
		
		 $query = $this->db->get('analysis_manufacturere_bank2');
		
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  { 
                  
				 
					 
					// $this->db->where('id' ,$row->id );
					 				  
				   $client  = array(  'name' => strtolower($row->name )  );
				    $this->db->insert('analysis_manufacturere_bank', $client);
//				   
				   }
				 
				
			}
		  
		   
		 
	 }
	 //cleaning supliers
	 
	 function Data_cleaning_supliers(){//analysis_suplier_bank2
		$this->db->select('*'); 
		
		 $query = $this->db->get('analysis_suplier_bank2');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  { 
                  
				 
					 
					// $this->db->where('id' ,$row->id );
					 				  
				   $client  = array(  'name' => strtolower($row->name )  );
				    $this->db->insert('analysis_suplier_bank', $client);
//				   
				   }
				 
				
			}
		  
		   
		 
	 }
	 
	 
	 //import machine types
	 function Data_cleaning_machine_types(){//analysis_suplier_bank2
		$this->db->select('*'); 
		
		 $query = $this->db->get('analysis_machine_bank2');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  { 
                  
				 
					 
					// $this->db->where('id' ,$row->id );
					 				  
				   $client  = array(  'name' => strtolower($row->name )  );
				    $this->db->insert('analysis_machine_bank', $client);
//				   
				   }
				 
				
			}
		  
		   
		 
	 }
	 
	 //impost depermrnt types
	 
	 	function Data_cleaning_departmentTypes(){//analysis_suplier_bank2
		$this->db->select('*'); 
		
		 $query = $this->db->get('analysis_departments_s');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  { 
                  
				 
					 
					// $this->db->where('id' ,$row->id );
					 				  
				   $client  = array(  'name' => strtolower($row->name )  );
				    $this->db->insert('department_types', $client);
//				   
				   }
				 
				
			}
		  
		   
		 
	 }
	
	function Update_department_types(){
				 $return_array = array(); 
		 $this->db->select('*');
		 $this->db->where('department_type <', 1  );
		  $query = $this->db->get('analysis_machines');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row2)
				  {  
				  $department  = $this-> get_my_department( $row2->department);
				 
				  if(sizeof($department) > 0){
				  
				  if($department['dtype'] > 0){
					 
					  $this-> Update_dep_types($row2->id , $department['dtype']);
				  
					
				 }
				 else {
					 $client  = array('id' =>$row2->id   , 'department' =>  $row2->department        ); 
					  
				  array_push($return_array , $client);
				 }
				 
				  }
				 
				   }
				
				
				
			}
			return $return_array;
		
	}
	
	//udate department rtype for machines
	
	  //$this->db->where('id', $id);
	             // $this->db->update('analysis_machines', $datai);
	//get depatyment types//department_type
	
	function Update_dep_types($id , $dep){
		$datai =  array('department_type' => $dep ); 
		
		  $this->db->where('id', $id);
	              $this->db->update('analysis_machines', $datai);
	}
	
	function department_types(){
		 $return_array = array(); 
		 $this->db->select('*');
		  $query = $this->db->get('department_types');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row2)
				  {  
				  
				   $client  = array('id' =>$row2->id   , 'name' => ucfirst(strtolower($row2->name ))       ); 
				 array_push($return_array , $client); 
				  
				  //$return_array  .=  '"'.strtolower($row->name).'" , ';// $row->id  ,  $row->name)    ; 
				   
				 
				   }
				
				
				
			}
			return $return_array;
		 
		 
	 }
	 
	 
	function Load_New($rec , $sys , $Rs){
		 $return_array =array();
		 
		 $this->db->select('*');
		 $this->db->where('receiver' ,$rec );
		 if($Rs==1 ){
			  $this->db->or_where('sender' ,$Rs );
			 
		 }
		 if($sys >= 0 ){
		 $this->db->where('type' ,$sys );
		 }
		 $this->db->where('read_notification' ,0 );
		 //read_notification
		 $this->db->protect_identifiers('system_notifications_logs');
		 $this->db->order_by('date_loged DESC');//date_loged
		 
		 
		 
		 $query = $this->db->get('system_notifications_logs');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  { 
				  $client  = array('id' =>$row->id ,'sender' => $row->sender  ,'rec' => $row->receiver ,'msg' => $row->message ,'info' => $row->other_info ,'type' => $row->type,'read' => $row->read_notification  ); 
				  array_push($return_array , $client); 
				  
				   }
				
				return $return_array;
				
			}
		 
		 
	 }
	 
	 
	 //load chat messages 
	 
	 function Load_Chats($sen , $sys , $rec , $no){
		 $return_array =array();
		 
		 $this->db->select('*');
		 $this->db->where('sender' ,$sen );
		  $this->db->where('receiver' ,$rec );
		   $this->db->where('type' ,$sys );
		 //if($Rs==1 ){
			  $this->db->or_where('sender' ,$rec );
			 
		// }
		 
		  $this->db->where('receiver' ,$sen );
		// if($sys >= 0 ){
		 $this->db->where('type' ,$sys );
		// }
		// $this->db->where('read_notification' ,0 );
		 //read_notification
		 $this->db->protect_identifiers('system_notifications_logs');
		 $this->db->order_by('date_loged DESC');//date_loged
		 if($no >0){
		 //$this->db->limit($no);
		 }
		 
		 
		 
		 $query = $this->db->get('system_notifications_logs');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  { 
				  $client  = array('id' =>$row->id ,'sender' => $row->sender ,'log' => $row->date_loged  ,'rec' => $row->receiver ,'msg' => $row->message ,'info' => $row->other_info ,'type' => $row->type,'read' => $row->read_notification  ); 
				  array_push($return_array , $client); 
				  
				   }
				
				
				
			}
		 return $return_array;
		 
	 }
	 
	 //just reaad notifications
	 
	 function Load_Notifucations($rec , $sys  ){
		 $return_array =array();
		 
		 $this->db->select('*');
		 
		  $this->db->where('receiver' ,$rec );
		   $this->db->where('type' ,$sys );
		   // $this->db->order_by('id DESC');
		     
		 //read_notification
		 $this->db->protect_identifiers('system_notifications_logs');
		//date_loged
		 
		 
		 
		 
		 $query = $this->db->get('system_notifications_logs');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  { 
				  $client  = array('id' =>$row->id ,'sender' => $row->sender ,'log' => $row->date_loged  ,'rec' => $row->receiver ,'msg' => $row->message ,'info' => $row->other_info ,'type' => $row->type,'read' => $row->read_notification  ); 
				  array_push($return_array , $client); 
				  
				   }
				
				
				
			}
		 return $return_array;
		 
	 }
	 
	 
	 //new chats 
	 
	 function New_Chats($sen , $sys , $rec , $no){
		 $return_array =array();
		 
		 $this->db->select('*');
		 $this->db->where('sender' ,$sen );
		  $this->db->where('receiver' ,$rec );
		   $this->db->where('type' ,$sys );
		 //if($Rs==1 ){
			  $this->db->or_where('sender' ,$rec );
			 
		// }
		 
		  $this->db->where('receiver' ,$sen );
		// if($sys >= 0 ){
		 $this->db->where('type' ,$sys );
		// }
		  $this->db->where('read_notification' ,0 );
		 //read_notification
		 $this->db->protect_identifiers('system_notifications_logs');
		 $this->db->order_by('date_loged DESC');//date_loged
		 if($no >0){
		 //$this->db->limit($no);
		 }
		 
		 
		 
		 $query = $this->db->get('system_notifications_logs');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			  
		 return $query->num_rows();
		 
	 }
	 
	 
	 //mark as read notifications
	 
	 function Mark_as_read($sen , $sys , $rec , $no){
		 $return_array =array();
		 
		  $this->db->select('*');
		 //$this->db->where('sender' ,$sen );
		  //$this->db->where('receiver' ,$rec );
		  // $this->db->where('type' ,$sys );
		 
			 // $this->db->or_where('sender' ,$rec );
			 
		 
		 
		  $this->db->where('receiver' ,$sen );
		// if($sys >= 0 ){
		// $this->db->where('type' ,$sys );
		// }
		 $this->db->where('read_notification' ,0 );
		 //read_notification
		 $this->db->protect_identifiers('system_notifications_logs');
		 $this->db->order_by('date_loged DESC');//date_loged
		 
		 
		 
		 $query = $this->db->get('system_notifications_logs');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			if($query->num_rows()>0){
				  $datai = array(   'read_notification'  => 1)   ;
	             
				 $this->db->update('system_notifications_logs', $datai) ;
				
				
				
			}
		 //return $return_array;
		 
	 }
	 //mark as read notifications
	 
	 function Mark_as_read_notification($rec , $sys) {
		 $return_array =array(); 
		  $this->db->where('receiver' ,$rec ); 
		 $this->db->where('type' ,$sys );
		 
		 $this->db->protect_identifiers('system_notifications_logs');
		 $this->db->order_by('date_loged DESC');//date_loged
		 
		 
		 
		 $query = $this->db->get('system_notifications_logs');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			if($query->num_rows()>0){
				  $datai = array(   'read_notification'  => 1)   ;
	             
				 $this->db->update('system_notifications_logs', $datai) ;
				
				
				
			}
		 //return $return_array;
		 
	 }
	
	 
	
	
	function Load_notifications($rec , $sys){
		 $return_array =array();
		 
		 $this->db->select('*');
		 $this->db->where('receiver' ,$rec );
		// $this->db->or_where('sender' ,$rec );
		 $this->db->protect_identifiers('system_notifications_logs');
		 
		 
		 
		 $query = $this->db->get('system_notifications_logs');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  { 
				  $client  = array('id' =>$row->id ,'sender' => $row->sender  ,'rec' => $row->receiver ,'msg' => $row->message ,'info' => $row->other_info ,'type' => $row->type,'read' => $row->read_notification  ); 
				  array_push($return_array , $client); 
				  
				   }
				
				return $return_array;
				
			}
		 
		 
	 }
	
	//get the machine lyf
	function check_shifts(){
		
		
		 
		$jobs_to_shift = $this->bio->scheduler(1);
		if(sizeof($jobs_to_shift) > 0){
			$techs = $this->bio->scheduler(0 );//(4);
			
			//foreach($jobs_to_shift as $job){
				$job  = $jobs_to_shift[0]['job']; //job number
				$diff  = $jobs_to_shift[0]['diff']; //period spent
				$date_dif =3;
				$date_diffs = $this-> check_days_to_shift(3);
				if(sizeof($date_diffs) >0){
					$date_dif =  $date_diffs['state']; //actual days to con cider
				}
				if($diff > $date_dif){
					if(sizeof($techs) > 0){
						$tech  =  $techs[0]['id']; //technicians
						$fon  =  $techs[0]['fon'];
						  
						 $receivers = $fon;
						 $recv ='';
						 $message_body  = 'An old job has been shifted to your account';
						
						  $this->Shift_jobs($job , $tech );
						 
						 //////////
						 $this->  Shift_jobs($job , $tech  );
						 $this->add_notification( 0 , $tech , $message_body , 2 ,$recv );
						 
					$send_sms = $this->check_settings(1);
				 if(sizeof($send_sms) > 0 and  strlen($message_body) > 0){
					 
					  
					   
					  if(strlen($recv) ==10   ){
								$checker=  substr($recv , 0 , 3);
								if( strstr($checker , '07')){
									$recv .= '256'.substr($receivers , 0 , -1);
				      
					        $this-> Sms_sender($recv ,$message_body );
					  }
					  }
					 
					 
				 }
						 
						 
						 /////////
						
					}
					
				}
				
				
				
			 
		}
		
		  
	}
	
	
		function compute_machine_lyfe($machines){
				//general   
				$gen_desc = '';
				 $green= 0; 
				 $yellow= 0; 
				  $orange= 0; 
				   $red = 0; 
				   $machine_data  =  array();
				   //number counters
				   
				   $green_n= 0; 
				   $yellow_n= 0; 
				  $orange_n= 0; 
				   $red_n = 0;
				   
				   //labels 
				   
				    $green_l   = 'GREEN'; 
				   $yellow_l   = 'YELLOW'; 
				   $orange_l   = 'ORANGE'; 
				   $red_l      = 'RED';
				   //code meaning 
				   
				   $green_m   = 'OK'; 
				   $yellow_m   = 'WORKING WELL'; 
				   $orange_m   = 'ABSOLUTE'; 
				   $red_m      = 'OUTDATED';
				   //
				   
				   
				  $Downt =0;
				 $Time_worked =0;
				
				 //exit();
				 foreach ($machines as $rowx){ 
				   $id =  $this->encrypt->decode($rowx['mid']);
				 $machinesx =$this->Get_machine_problems($id);
				 $D =$this->Machine_dep_rate($id);//depreciation rate
				 $Downt =0;
				 $Time_worked =0;
				 
				 
				 
				 if(sizeof($machinesx) > 0){
					  
					 foreach ($machinesx as $rowc){ 
					 $date_i=  strtotime($rowc['d_in']); //
					 $date_o=  strtotime($rowc['d_out']);
					 
					 //real dates
					 
					 $date_in=  $rowc['d_in'];
					 $date_out=   $rowc['d_out'];
					  if($date_o < 1){
							$date_out =  timeCurrent2();
							 
						 }
					 if($date_i > 0){
						 //depreciation rate for this machine
						 
						$Downt =  $down_time =  dateDiff( $date_in , $date_out);
					 // echo 'in..'.$rowc['d_in'].'out...'.$rowc['d_out'].'....down time in days..'.$down_time.'... depreciation rate...'.$D.'.....';
					 }
					 
				 //time it has worked in days  
				
			 }   
		 }
				
				 
				  $today =  timeCurrent2();
				 
				 $installed_date  =  strtotime($rowx['installed']);
				 if( $installed_date > 0){
					 $Time_worked = dateDiff( $rowx['installed'] , $today);
					 
				 }
				 
				
				  $Residual_initial =  1-($D *7) ;
				 $Residual_current =  1-($D *(($Time_worked -$Downt)/365 )) ;
				  $value_diff = $Residual_current - $Residual_initial;
				 
				
				  $Machine_rating  =  ($value_diff)*100;//
					$colors =  '';
				$colors_code =  0;
				if($Machine_rating > 10 ){ $green += 1;   $green_n += 1; 
				$colors =  '#4da74d';
				$colors_code =  4;
				$gen_desc =$green_m;
				}
				else if($Machine_rating >= 0 and $Machine_rating <= 10){ $yellow += 1; $yellow_n += 1; 
				$colors =  '#FFFF00';
				$colors_code =  1;
				$gen_desc =$yellow_m;
				}
				
				else if($Machine_rating >= -15 and $Machine_rating <=0 ){ $orange += 1; $orange_n += 1;
				$colors =  '#FF5000';
				$colors_code =  2;
				$gen_desc =$orange_m;
				}
				else if($Machine_rating < -15   ){ $red += 1;$red_n += 1;
				$colors =  '#FF0000';
				$colors_code =  3;
				$gen_desc =$red_m;
				}
				
				
			//$this->	Machine_name_bank($x);
			
			$sno = $this-> match_machine($id);
			$serial ='N/A';
			if(sizeof($sno) >0){
				 
				
				IF($sno['sno'] != "" ){
					$serial = $sno['sno'];
					
				}
			}
		 
			 
				
				$client = array('id' =>$id , 'name' =>$this->	Machine_name_bank($rowx['name']), 'sno' =>$serial,  'color'=>$colors , 'colors_code'=> $colors_code, 'Machine_rating'=> $Machine_rating  ,'state_name'=> $gen_desc   );//from here
 
 //////////////////
                  array_push ($machine_data , $client);
 
  
				 }
				 
				   $list_pie  = '{ label: "'.$yellow_l.'" ,  data: '. ($yellow).'} ,{ label: "'.$orange_l.'" ,  data: '. ($orange).'} ,{ label: "'.$red_l.'" ,  data: '. ($red).'} ,{ label: "'.$green_l.'" ,  data: '. ($green).'}';
			//precentages recorded in each
			
			 //exit('no data for u boss'); 
				$list_datax  =  array(); 
				  array_push($list_datax ,array($yellow_l ,    $yellow  ,'#FFFF00' , $yellow_m ));
				  array_push($list_datax ,array( $orange_l  ,$orange , '#FF5000' , $orange_m  ));
				   array_push($list_datax , array($red_l    ,$red , '#FF0000' , $red_m ) );
				     array_push($list_datax ,array($green_l    ,$green , '#4da74d' , $green_m));
					 
					 //
					 $list_dataxm  =  array(); 
				  array_push($list_dataxm ,array($yellow_m ,    $yellow  ,'#FFFF00' ));
				  array_push($list_dataxm ,array( $orange_m  ,$orange , '#FF5000'));
				   array_push($list_dataxm , array($red_m    ,$red , '#FF0000') );
				     array_push($list_dataxm ,array($green_m    ,$green , '#4da74d'));
				 
				 
				 
				 //how many in in each category
				 $list_count  =  array(
				  $yellow_l   =>$yellow_n ,
				   $orange_l   =>$orange_n ,
				    $red_l   =>$red_n ,
				     $green_l    =>$green_n ,
				 
				 );
				 
				 return array('pie_chart_data' => $list_pie , 'list_data' => $list_datax, 'details' => $machine_data,  'details_meaning' => $machine_data  );
			
			
		
	}
	function machine_life_two($machines){
			
			$machine_data = array();
				 $green= 0; 
				 $yellow= 0; 
				  $orange= 0; 
				   $red = 0; 
				   
				   //number counters
				   
				   $green_n= 0; 
				   $yellow_n= 0; 
				  $orange_n= 0; 
				   $red_n = 0;
				   
				   //labbels 
				   
				    $green_l   = 'GREEN'; 
				   $yellow_l   = 'YELLOW'; 
				   $orange_l   = 'ORANGE'; 
				   $red_l      = 'RED';
				   
				   
				  $Downt =0;
				 $Time_worked =0;
				
				 //exit();
				 foreach ($machines as $rowx){ 
				   $id =  $this->encrypt->decode($rowx['mid']);
				 $machinesx =$this->Get_machine_problems($id);
				 $D =$this->Machine_dep_rate($id);//depreciation rate
				 $Downt =0;
				 $Time_worked =0;
				 
				 
				 
				 if(sizeof($machinesx) > 0){
					  
					 foreach ($machinesx as $rowc){ 
					 $date_i=  strtotime($rowc['d_in']); //
					 $date_o=  strtotime($rowc['d_out']);
					 
					 //real dates
					 
					 $date_in=  $rowc['d_in'];
					 $date_out=   $rowc['d_out'];
					  if($date_o < 1){
							$date_out =  timeCurrent2();
							 
						 }
					 if($date_i > 0){
						 //depreciation rate for this machine
						 
						$Downt =  $down_time =  dateDiff( $date_in , $date_out);
					 // echo 'in..'.$rowc['d_in'].'out...'.$rowc['d_out'].'....down time in days..'.$down_time.'... depreciation rate...'.$D.'.....';
					 }
					 
				 //time it has worked in days  
				
			 }   
		 }
				
				 
				  $today =  timeCurrent2();
				 
				 $installed_date  =  strtotime($rowx['installed']);
				 if( $installed_date > 0){
					 $Time_worked = dateDiff( $rowx['installed'] , $today);
					 
				 }
				 
				
				  $Residual_end =  1-($D *7) ; //when the machine will expire this will be the predicted value
				 $Residual_current =  1-($D *(($Time_worked -$Downt)/365 )) ;
				  $value_diff = $Residual_current - $Residual_end;
				 
				
				  $Machine_rating  =  ($value_diff)*100;//
				 
				$colors =  '';
				$colors_code =  0;
				if($Machine_rating > 10 ){ $green += 1;   $green_n += 1; 
				$colors =  '4da74d';
				$colors_code =  4;
				}
				else if($Machine_rating >= 0 and $Machine_rating <= 10){ $yellow += 1; $yellow_n += 1; 
				$colors =  '#FFFF00';
				$colors_code =  1;
				}
				
				else if($Machine_rating >= -15 and $Machine_rating <=0 ){ $orange += 1; $orange_n += 1;
				$colors =  '#FF5000';
				$colors_code =  2;
				}
				else if($Machine_rating < -15   ){ $red += 1;$red_n += 1;
				$colors =  '#FF0000';
				$colors_code =  3;
				}
				
				
				$client = array('id' =>$id , 'color'=>$colors , 'colors_code'=> $colors_code, 'Machine_rating'=> $Machine_rating  ,'Machine_rating'=> $Machine_rating   );//from here
 
 //////////////////
                  array_push ($machine_data , $client);
 
 
 
 
				 }
				//colors: ["#FFFF00", "#FF5000", "#FF0000", "#4da74d", "#9440ed" ,"#afd8f8"], 
				//$machine_data = array('id' =>$id , 'color'=>$colors , 'colors_code'=> $colors_code );
				 
				   $list_pie  = '{ label: "'.$yellow_l.'" ,  data: '. ($yellow).'} ,{ label: "'.$orange_l.'" ,  data: '. ($orange).'} ,{ label: "'.$red_l.'" ,  data: '. ($red).'} ,{ label: "'.$green_l.'" ,  data: '. ($green).'}';
			//precentages recorded in each
			
			 //exit('no data for u boss'); 
				$list_datax  =  array(
				  $yellow_l   =>$yellow ,
				   $orange_l   =>$orange ,
				    $red_l    =>$red ,
				     $green_l    =>$green ,
				 
				 );
				 
				 //how many in in each category
				 $list_count  =  array(
				  $yellow_l   =>$yellow_n ,
				   $orange_l   =>$orange_n ,
				    $red_l   =>$red_n ,
				     $green_l    =>$green_n ,
				 
				 );
				 
				 return array('pie_chart_data' => $list_pie , 'list_data' => $list_datax, 'list_data_numbers' => $list_count  , 'summay_data' =>   $machine_data  );
			
	}
	//device problems 
	
	function Problem_details($mcn , $typ , $lower , $upper ){//machine//
		$this->db->select('*');
		$this->db->distinct('date_reported');
		$this->db->where('m_id' , $mcn);
		if($typ > 0 and $lower !='' and    $upper !='' ){
			$array = array( 'date_reported >=' => $lower , 'date_reported <=' => $upper);
            $this->db->where($array);
			 
		}
		else if($typ > 0 and $lower !=''){
			echo $lower;
			$this->db->where('date_reported' , $lower);
			
		}
		
		$query  = $this->db->get('machine_problems');
		 $return_array  = array();
		 
		
		 if($query->num_rows()>0){
				   foreach ($query->result() as $row)
				  { 
				   $client  = array();
				    
				  $client  =  array('id' =>  $row->id  ,'dates' =>  $row->date_reported  , 'problem' =>$row->problem , 'sorted' =>$row->worked_on , 'date_worked_on' =>$row->date_worked_on, 'tech' =>$row->receiver_tech ,'state' =>$row->new_state          ) ;
				  
				  if(sizeof($client) >0){
				  array_push($return_array , $client);
				  }
				   }
				   
				 }
				 
				 if($typ < 1){
					 return  $this->unique_multidim_array( $return_array , 'dates');
					 
				 }
				 else {
					 
				    return $return_array;
				 }					
		
		
		
	}
		
		//repair information
		function Repair_details($mcn , $typ , $lower , $upper ){//machine//
		$this->db->select('*');
		$this->db->distinct('date_loged');
		$this->db->where('machine' , $mcn);
		if($typ > 0 and $lower !='' and    $upper !='' ){
			$array = array( 'date_loged >=' => $lower , 'date_loged <=' => $upper);
            $this->db->where($array);
			 
		}
		else if($typ > 0 and $lower !=''){
			echo $lower;
			$this->db->where('date_loged' , $lower);
			
		}
		
		$query  = $this->db->get('repair_info');
		 $return_array  = array();
		 
		
		 if($query->num_rows()>0){
				   foreach ($query->result() as $row)
				  { 
				   $client  = array();
				    
				  $client  =  array('id' =>  $row->id  ,'dates' =>  $row->date_loged  , 'comp' =>$row->repairing_company , 'invoice' =>$row->job_no , 'diag' =>$row->diag, 'remedy' =>$row->remedy , 'spare' =>$row->spares , 'tech_comm' =>$row->tech_comm , 'cost' =>$row->total_charges , 'state' =>$row->new_state          ) ;
				  
				  if(sizeof($client) >0){
				  array_push($return_array , $client);
				  }
				   }
				   
				 }
				 
				 if($typ < 1){
					 return  $this->unique_multidim_array( $return_array , 'dates');
					 
				 }
				 else {
					 
				    return $return_array;
				 }					
		
		
		
	}
	
	//service details
	
	function Service_details($mcn , $typ , $lower , $upper ){//machine//
		$this->db->select('*');
		$this->db->distinct('period_done');
		$this->db->where('machine' , $mcn);
		if($typ > 0 and $lower !='' and    $upper !='' ){
			$array = array( 'period_done >=' => $lower , 'period_done <=' => $upper);
            $this->db->where($array);
			 
		}
		else if($typ > 0 and $lower !=''){
			echo $lower;
			$this->db->where('period_done' , $lower);
			
		}
		
		$query  = $this->db->get('service_report');
		 $return_array  = array();
		 
		
		 if($query->num_rows()>0){
				   foreach ($query->result() as $row)
				  { 
				   $client  = array();
				   
				 
  
				  
				  $client  =  array('id' =>  $row->id  ,'dates' =>  $row->period_done  , 'wf' =>$row->way_forward , 'com' =>$row->comment , 'tech' =>$row->technician, 'tech_comp' =>$row->tech_company , 'new' =>$row->new_state , 'old' =>$row->current_state        ) ;
				  
				  if(sizeof($client) >0){
				  array_push($return_array , $client);
				  }
				   }
				   
				 }
				 
				 if($typ < 1){
					 return  $this->unique_multidim_array( $return_array , 'dates');
					 
				 }
				 else {
					 
				    return $return_array;
				 }					
		
		
		
	}
	
	
	//get the last service dayas from the databse
	
	//service_report//SELECT DISTINCT YEAR(date_posted), MONTH(date_posted) FROM table
	
	//format the dates

	
	
	
	function service_dates($xf , $dp){
		$this->db->select('*');
		$this->db->distinct('period_done');
		$query  = $this->db->get('service_report');
		 $return_array  = array();
		 
		
		 if($query->num_rows()>0){
				   foreach ($query->result() as $row)
				  { 
				   $client  = array();
				  $machines  = $this->match_machine($row->machine );
				  
				  
				 $hfd =  $dpd =0;

				  if(sizeof($machines) > 0 ){ 
				  
				  
				    $hfd =  $machines['hf'] ;
				  $dpd =  $machines['dep'] ;
				  
				  
				   if(($xf > 0 or $dp  > 0)){ 
				
				   
				  if($xf > 0){
					  if($xf == $hfd  ){
						  	  $client  =  array('id' =>  $row->id  ,'dates' =>  $row->period_done , 'hf'  => $this->specific_hospital($hfd)    ) ;
						  
					  }
					  
				  }
				   else if($dp > 0){
					   if($dp == $dpd  ){
						  	  $client  =  array('id' =>  $row->id  ,'dates' =>  $row->period_done , 'hf'  => $this->specific_hospital($hfd)    ) ;
						  
					  }
					   
					  
				  }
				  }
				  else{
				 
				  
				  $client  =  array('id' =>  $row->id  ,'dates' =>  $row->period_done  , 'hf'  => $this->specific_hospital($hfd)      ) ;
				  }
				  }
				  //
				  if(sizeof($client) >0){
				  array_push($return_array , $client);
				  }
				  
				   }
				   
				 }
				   if(sizeof($return_array) > 0){ return  $this->unique_multidim_array( $return_array , 'dates'); } else return $return_array; 
		
		
		
	}
	
	
	
	
	
	
	function unique_multidim_array($array, $key) {  //remove duplicates from array
    $temp_array = array(); 
    $i = 0; 
    $key_array = array(); 
    
    foreach($array as $val) { 
        if (!in_array($val[$key], $key_array)) { 
            $key_array[$i] = $val[$key]; 
            $temp_array[$i] = $val; 
        } 
        $i++; 
    } 
    return $temp_array; 
}    





   //get this boss
   
   function match_machine($mcn){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	          $this->db->protect_identifiers('analysis_machines');
			   
			    $this->db->select('*');
				   $this->db->where('id' ,  $mcn);//
					$this->db->where('mstate' , 1);//
					 
					
		 // $query = $this->db->get('analysis_machines'); 
		  
				 
		    $query = $this->db->get('analysis_machines'); 
		  
		  if($query->num_rows()>0){
				   foreach ($query->result() as $row)
				  {  
				   
				  $return_array   =  array('id' =>  $row->id  ,'hf' =>  $row->health_facility  ,'dep' =>  $row-> department , 'name'=>  $row->  name, 'sno'=>  $row->  sno , 'price'	 => $row->device_price , 'code'	 => $row->device_code  ) ;
				  //
				  //array_push($return_array , $client);
				   }
				   
				 }
				 return    $return_array ;
		
		        
			
			
			
		}
	
	function RealDate(){
			 date_default_timezone_set('Africa/Nairobi');
			   
			$pymen_dat=date('Y-m-d');
			return $pymen_dat;
			
		}
	
	/// add machines to database from here
	
	
	
	function Add_machine_to_db( $std , $dp , $hf){ //
                                               $m_name = trim($std['Name']); 
											   
											   if($m_name ==""){}
											 
											   
											    $m_mod = trim($std['Model']); 
												
												if($m_mod ==""){
													$m_mod ="unknown";
												}
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_mod ) ){
													$m_mod ="unknown";
													
												 }
											    $m_sn = trim($std['Sno']); 
												
												if($m_sn ==""){
													$m_sn ="unknown";
												}
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_sn ) ){
													$m_sn ="unknown";
													
													
												 }
												 $m_yr = trim($std['Yr']);
												
												if($m_yr ==""){ $m_yr =0000;}
												else
												if( !preg_match('/[0-9]+$/',$m_yr ) ){
													$m_yr =0000;
													
												 }
												
												 $m_c = trim($std['Cou']); 
												if($m_c ==""){
													$m_c ="unknown";
													
												}
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_c ) ){
													$m_c ="unknown";
													
												 }
												
												
											    $m_sup = trim($std['Sup']);
												
												if($m_sup ==""){
													$m_sup ="unknown";
												}
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_sup ) ){
													$m_sup ="unknown";
													
												 	
												}
												 
												
												
                                                $m_state = trim($std['St']);
												
												if($m_state ==""){
													$m_state =1;
													
												}
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_state ) ){
													$m_state =1;
												 	
													
												}
												$m_comm = trim($std['comment']);
												if($m_comm ==""){
													$m_comm ="unknown";
													
												}
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_comm ) ){
													$m_comm ="unknown";
												 	
												}

												
                                                $m_manf = trim($std['Manuf']);
												
												if($m_manf ==""){
													$m_manf ="unknown";
												}
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_manf ) ){
													$m_manf ="unknown";
												 }
												 
												 $m_count= $std['noz'];
												 
												 $yr_i = trim($std['yri']);
												 if($yr_i ==""){ $yr_i ='0000-00-00';}
												else
												if( preg_match('/[0-9]+$/',$yr_i ) ){
													$yr_i = $yr_i."-00-00";
												 }
												 
												 //clean way foward and action
												 
												 
												 $m_acn= trim($std['m_action']); 
											   
											   if($m_acn ==""){
												   $m_acn ="unknown";
												   
											   }
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_acn ) ){
													 $m_acn ="unknown";
												 	
												}
												
												//action clean
												
												 $m_wf = trim($std['way_foward']); 
											   
											   if($m_wf ==""){
												    $m_wf ="unknown";
											   }
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$m_wf ) ){
													 $m_wf ="unknown";
												 	
												}
												
												$code = trim($std['d_code']); 
											   
											   if($code ==""){
												   $code ="unknown";
												   
											   }
												else
												if( !preg_match('/[a-zA-Z0-9.,-]+$/',$code ) ){
													$code ="unknown";
												 	
												}
												
												
												 $price = trim($std['d_price']); 
											   
											   if($price ==""){}
												else
												if( !preg_match('/[0-9]+$/',$price ) ){
													$price ="";
												 	
												}
												if( $m_name < 1){
													$this->Add_machine_bank(strtolower($m_name));
													$m_name = $this->	Get_Next_machine_id(strtolower($m_name));
													
												}
												IF($m_sup < 1){
													$this->Add_suplier_bank(strtolower($m_sup));//
													$m_sup= $this-> Get_Next_supplier_id(strtolower($m_sup));
													
													
												}
												IF($m_manf < 1){
													$this->Add_manufacturer_bank(strtolower($m_manf));
													$m_manf= $this-> Get_Next_manufacturer_id(strtolower($m_manf));
													
													
												}
 									  
								
			 
			  $datai = array(  'action_performed' => $m_acn  ,'way_foward' => $m_wf  ,'name' => $m_name  ,'model' => $m_mod   ,'sno' => $m_sn 
                             ,'country' => $m_c   ,'mstate' => $m_state ,'myr' => $m_yr 
                             ,'suplier' => $m_sup   ,'department' => $dp ,'health_facility' => $hf  , 'maufacturer'	 => $m_manf ,  
							 'period_done'	 => $this->RealDate(),  'date_installed'	 => $yr_i ,'department_type'	 => $yr_i , 'comment'	 => trim($m_comm ) ,'device_price'	 => trim($price ) , 'device_code' => trim($code)						 
			  );  
			   



			 // $this->Add_machine_bank(strtolower($m_name));
			   //  $this->Add_suplier_bank(strtolower($m_sup));//
			  //$this->Add_manufacturer_bank(strtolower($m_manf));
			   
				  for($i = 0; $i< $m_count; $i++){
	
				  $this->db->insert('analysis_machines', $datai);
				  }
				 
			
		}
		
		//edit device details
		
		function Update_device_info( $x , $id  ){ // $entray_ar  = array($fname , $sup , $man , $dep , $mod, $state, $sn , $country  , $yr , $yri);
					  
								
			 
			  $datai = array(   'name' => $x[0]  ,'model' => $x[4]   ,'sno' => $x[6]  ,'country' => $x[7]   ,'mstate' => $x[5] ,'myr' => $x[8] 
                             ,'suplier' => $x[1]   ,'department' => $x[3]   , 'maufacturer'	 => $x[2] , 'date_installed'	 => $x[9].'-00-00'  , 'device_code'	 => $x[10] , 'device_price'	 => $x[11]  						 
			  );  
			   

                   $this->db->where('id', $id);
	              $this->db->update('analysis_machines', $datai);
				  
				 
			
		}
		///
		
		function new_departmental_machines( $hf){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machines');
			   
			    $this->db->select('*');
				 
		        $this->db->where('department' , 0); 
				 
				  if($hf > 0){
					 $this->db->where('health_facility' , $hf);//
				}
				 $this->db->where('mstate < ' , 2);
				 
		       $this->db->order_by('mstate DESC, name ASC');
		   
		   
		    
		  $query = $this->db->get('analysis_machines'); 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
				 
	 		     $client = array(  
			   'mid' => $this->encrypt->encode($row2-> id)  ,'name' => $row2-> name  ,'mod' =>  $row2-> model   ,'sn' => $row2-> sno 
                             ,'cou' => $row2-> country  ,'ms' => $row2-> mstate ,'yr' => $row2-> myr 
                             ,'sup' => $row2->suplier   ,'dep' => $row2->department ,'hf' => $row2->health_facility  , 'man'	 => $row2->maufacturer ,  'period'	 => $row2->period_done , 'comment'	 => $row2->comment
			 , 'installed' => $row2-> date_installed  , 'price'	 => $row2->device_price , 'code'	 => $row2->device_code);
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
			
			
			
		}
		
		
		function get_departmental_machines($dpt , $hf){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machines');
			   
			    $this->db->select('*');
				if($dpt > 0){
		    $this->db->where('department' , $dpt);//
				}
				else  if($hf > 0){
					 $this->db->where('health_facility' , $hf);//
				}
				$this->db->where('mstate >' , 0);
				 
		       $this->db->order_by('mstate DESC, name ASC');
		   
		   
		    
		  $query = $this->db->get('analysis_machines'); 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
				 
	 		     $client = array(  
			   'mid' => $this->encrypt->encode($row2-> id)  ,'name' => $row2-> name  ,'mod' =>  $row2-> model   ,'sn' => $row2-> sno 
                             ,'cou' => $row2-> country  ,'ms' => $row2-> mstate ,'yr' => $row2-> myr 
                             ,'sup' => $row2->suplier   ,'dep' => $row2->department ,'hf' => $row2->health_facility  , 'man'	 => $row2->maufacturer ,  'period'	 => $row2->period_done , 'comment'	 => $row2->comment
			 , 'installed' => $row2-> date_installed  , 'price'	 => $row2->device_price , 'code'	 => $row2->device_code);
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
			
			
			
		}
		
		// get machine counts from health facility and departments
		function get_departmental_machines_count($dpt , $hf){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machines');
			   
			    $this->db->select('*');
				if($dpt > 0){
		    $this->db->where('department' , $dpt);//
				}
				else {
					 $this->db->where('health_facility' , $hf);//
				}
				$this->db->where('mstate >' , 0);
		   $this->db->order_by('mstate DESC, name ASC');
		   
		    
		  $query = $this->db->get('analysis_machines'); 
			 
			return  $query->num_rows(); 
			 
			
			
			
		}
		
		//departmental machines with ststes in conciderations here
		
		function machone_count($dpt , $hf , $st){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machines');
			   
			    $this->db->select('*');
				if($dpt >= 0){
		    $this->db->where('department' , $dpt);//
				}
				if($hf >0) {
					 $this->db->where('health_facility' , $hf);//
				}
				
				if($st  > 0){
					 $this->db->where('mstate' , $st);
					
				}
		   $this->db->order_by('mstate DESC, name ASC');
		   
		    
		  $query = $this->db->get('analysis_machines'); 
			 
			return  $query->num_rows(); 
			 
			
			
			
		}
		
		function Count_machines($hf , $st){
			
			 $machines =0;
              $queryv = $this->db->query('select count(id) as machines from analysis_machines where health_facility ='.$hf.' and mstate ='.$st.' ');
			  if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				    $machines =$row->machines;
					  
					 
				 
				   }
			  }
			  return  $machines;
	
		}
		
		
		//machines missing depreciation rates
		
		
		function Missing_depreciation_rates($x){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machine_bank');
			   
			    $this->db->select('*');
				if($x  <  1){
				 
		       $this->db->where('depreciation_rate' , 0);//
				}
				 
		       $this->db->order_by('name DESC');
		   
		    
		      $query = $this->db->get('analysis_machine_bank'); 
			 
			 if($query->num_rows()>0){//cl_status
			       foreach ($query->result() as $row2)
				  {
  					  
				 
	 		     $client  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'m_name' => $row2-> name  ,'dep_rate' =>  $row2-> depreciation_rate    );
			   array_push($return_array , $client);
	
				 
				  }
			 
			
			
			
		   }
		   return $return_array;
		}
		
		
		// all machine suppliers
		
		function All_machine_suppliers(){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_suplier_bank');
			   
			    $this->db->select('*');
				 
				 
		       $this->db->order_by('name');
		   
		    
		      $query = $this->db->get('analysis_suplier_bank'); 
			 
			 if($query->num_rows()>0){//cl_status
			       foreach ($query->result() as $row2)
				  {
  					  
				 
	 		     $client  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'m_name' => $row2-> name ,'agent' => $row2-> contact_person ,'email' => $row2-> email_address  ,'phone_number' => $row2-> phone_number,'location' => $row2-> location      );
			   array_push($return_array , $client);
	
				 
				  }
			 
			
			
			
		   }
		   return $return_array;
		}
		
		
		//update machine depreciation rates
		
		function Missing_depreciation_rates_updates(){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machine_bank');
			   
			    $this->db->select('*');
				 
		       $this->db->where('depreciation_rate' , 0);//
				 
		       $this->db->order_by('name DESC');
		   
		    
		      $query = $this->db->get('analysis_machine_bank'); 
			 
			 if($query->num_rows()>0){//cl_status
			       foreach ($query->result() as $row2)
				  {
  					  
				 
	 		     $client  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'m_name' => $row2-> name  ,'dep_rate' =>  $row2-> depreciation_rate    );
			   array_push($return_array , $client);
	
				 
				  }
			 
			
			
			
		   }
		   return $return_array;
		}
		
		
		
		// count hospitalmachines with states
		
		function get_departmental_machines_count_states($dpt , $hf , $st){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machines');
			   
			    $this->db->select('*');
				 $this->db->where('mstate' , $st);//
				if($dpt > 0){
		    $this->db->where('department' , $dpt);//
				}
				else  if($hf > 0){
					 $this->db->where('health_facility' , $hf);//
				}
				$this->db->where('mstate >' , 0);
		   $this->db->order_by('mstate DESC, name ASC');
		   
		   
		    
		  $query = $this->db->get('analysis_machines'); 
			 
			return  $query->num_rows(); 
			 
			
			
			
		}
		
		/// get specific machine from the database 
		
		
		function get_my_machines($id){
			
			 $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machines');
			   
			    $this->db->select('*');
				 
		    $this->db->where('id' , $id);//
			 $query = $this->db->get('analysis_machines'); 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
				 
	 		     $return_array  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'name' => $row2-> name  ,'mod' =>  $row2-> model   ,'sn' => $row2-> sno 
                             ,'cou' => $row2-> country  ,'ms' => $row2-> mstate ,'yr' => $row2-> myr 
                             ,'sup' => $row2->suplier   ,'dep' => $row2->department ,'hf' => $row2->health_facility  , 'man'	 => $row2->maufacturer ,  'period'	 => $row2->period_done ,  'installed'	 => $row2->date_installed , 'comment'	 => $row2->comment , 'price'	 => $row2->device_price , 'code'	 => $row2->device_code
			  );
			   
	
				 
				  }
			}
			return $return_array;
			
			
			
		}
		
		//machine problems with ststes
		
		function Get_machine_problems_states($state){ 
		
		 	
	//PROTECT TABLE FIELDS
	   $queryv = $this->db->query('select  receiver_tech , problem ,m_id,  a.id as id , b.name as mname,  c.name  as machine , date_reported , date_shifted ,  datediff(NOW() , date_shifted)  as shifted  , datediff(NOW() , date_reported)  as dif  from analysis_machine_bank c, analysis_machines b, machine_problems a where c.id = b.name and m_id=b.id and worked_on='.$state.'');
	
	        
     $return_array  = array();
			 
			 
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				   
					  $temp_array  = array( 'm_id' => $row->m_id ,'receiver' => $row->receiver_tech ,'diff' => $row->dif,'shift' => $row->shifted,'m_name' => $row->mname ,'machine' => $row->machine ,'prob' => $row->problem ,'machine' => $row->machine,'reported' => $row->date_reported ,'date_shifted' => $row->date_shifted , 'tech' => $this->All_techs($row->receiver_tech )    );
					  array_push($return_array , $temp_array);
					 
					 
				 
				   }
			  }
			  
			  return  $return_array;
			 	 
			}
			
			//
			
			function Get_machine_prob_by_hospital($hf , $state){
				 //select all machine problems with states
				 if($hf > 0){
	   $queryv = $this->db->query('
	   select  health_facility , department ,  d.name as client , d.location as location , d.email as email , d.phone_number as phone, contact_person , receiver_tech , problem ,m_id,  a.id as id , b.name as mname,  c.name  as machine , date_reported , date_shifted , datediff(NOW() , date_shifted)  as shifted  , datediff(NOW() , date_reported)  as dif  from hospitals d , analysis_machine_bank c, analysis_machines b, machine_problems a where c.id = b.name and m_id=b.id  and d.id = health_facility and health_facility ='.$hf.' and  worked_on='.$state.'
		  
	  ' );
				 }
				 else {
	  
	  $queryv = $this->db->query('
	   select  health_facility , department ,  d.name as client , d.location as location , d.email as email , d.phone_number as phone, contact_person , receiver_tech , problem ,m_id,  a.id as id , b.name as mname,  c.name  as machine , date_reported , date_shifted , datediff(NOW() , date_shifted)  as shifted  , datediff(NOW() , date_reported)  as dif  from hospitals d , analysis_machine_bank c, analysis_machines b, machine_problems a where c.id = b.name and m_id=b.id  and d.id = health_facility and  worked_on='.$state.'
		  
	  ' );
				 }
	
	        
     $return_array  = array();
			 
			 
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				   
					  $temp_array  = array( 'm_id' => $row->m_id ,'hf' => $row->health_facility,'dpt' => $row->department,'client' => $row->client,'person' => $row->contact_person,'location' => $row->location,'phone' => $row->phone ,'receiver' => $row->receiver_tech ,'email' => $row->email ,'diff' => $row->dif,'shift' => $row->shifted,'m_name' => $row->mname ,'machine' => $row->machine ,'prob' => $row->problem ,'machine' => $row->machine,'reported' => $row->date_reported ,'date_shifted' => $row->date_shifted     );
					  array_push($return_array , $temp_array);
					 
					 
				 
				   }
			  }
			  
			  return  $return_array;
			
			}
			
			//machine problem view by admin aor tech
			
			function Get_machine_prob_by_tech($state){
				 //select all machine problems with states
	   $queryv = $this->db->query('
	   select  health_facility , department ,  d.name as client , d.location as location , d.email as email , d.phone_number as phone, contact_person , receiver_tech , problem ,m_id,  a.id as id , b.name as mname,  c.name  as machine , date_reported , date_shifted , datediff(NOW() , date_shifted)  as shifted  , datediff(NOW() , date_reported)  as dif  from hospitals d , analysis_machine_bank c, analysis_machines b, machine_problems a where c.id = b.name and m_id=b.id  and d.id = health_facility and  worked_on='.$state.'
		  
	  ' );
	
	        
     $return_array  = array();
			 
			 
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				   
					  $temp_array  = array( 'm_id' => $row->m_id ,'hf' => $row->health_facility,'dpt' => $row->department,'client' => $row->client,'person' => $row->contact_person,'location' => $row->location,'phone' => $row->phone ,'receiver' => $row->receiver_tech ,'email' => $row->email ,'diff' => $row->dif,'shift' => $row->shifted,'m_name' => $row->mname ,'machine' => $row->machine ,'prob' => $row->problem ,'machine' => $row->machine,'reported' => $row->date_reported ,'date_shifted' => $row->date_shifted     );
					  array_push($return_array , $temp_array);
					 
					 
				 
				   }
			  }
			  
			  return  $return_array;
			
			}
			//get tech pending jobs
			function Get_tech_prob_status($tech , $state ){ 
		
		 	
	//PROTECT TABLE FIELDS
	   $queryv = $this->db->query('select  receiver_tech , problem ,m_id,  a.id as id , b.name as mname,  c.name  as machine , date_reported , date_shifted ,  datediff(NOW() , date_shifted)  as shifted  , datediff(NOW() , date_reported)  as dif  from analysis_machine_bank c, analysis_machines b, machine_problems a where c.id = b.name and m_id=b.id  and receiver_tech ='.$tech.' and worked_on='.$state.'');
	
	        
     $return_array  = array();
			 
			 
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				   
					  $temp_array  = array( 'm_id' => $row->m_id ,'receiver' => $row->receiver_tech ,'diff' => $row->dif,'shift' => $row->shifted,'m_name' => $row->mname ,'machine' => $row->machine ,'prob' => $row->problem ,'machine' => $row->machine,'reported' => $row->date_reported ,'date_shifted' => $row->date_shifted , 'tech' => $this->All_techs($row->receiver_tech )    );
					  array_push($return_array , $temp_array);
					 
					 
				 
				   }
			  }
			  
			  return  $return_array;
			 	 
			}
		
		
		
		
		function Get_machine_status($id , $tech , $st , $return){ 
		
		
		$return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	
	
	            $this->db->protect_identifiers('machine_problems');
			   
			    $this->db->select('*');
				 if($id > 0){
		        $this->db->where('m_id' , $id);//
				 }
				  if($tech > 0){
				 $this->db->where('receiver_tech' , $tech);//
				  }
				   
				   $this->db->where('worked_on' , $st);
				   
				 
				 
				 
				 
		        $this->db->order_by('date_reported DESC');
		        $query = $this->db->get('machine_problems'); 
			  
			      if($query->num_rows()>0){//cl_status
				  if($return >0){
				 
			       foreach ($query->result() as $row2)
				  {
  					  
				 
	 		     $client  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'prob' => $row2-> problem  ,'new_state' =>  $row2-> new_state   ,'dt' => $row2->date_reported 
                             ,'worked_on' => $row2-> worked_on ,'d_in' => $row2-> date_reported  ,'machine' => $row2-> m_id  ,'tech' => $row2-> receiver_tech,'d_out' => $row2-> date_worked_on   
                             	 
			  );
			   array_push($return_array , $client);
				  }
				  
	
				 
				  }
				  else  $return_array = $query->num_rows();  
			}
			return $return_array;
                
				 
			}
			
			
			
			function Specific_machine_problems($id){ 
		
		
		       $return_array = array(); //will take on the data about a given agent 	
	            $this->db->protect_identifiers('machine_problems');
			     $this->db->select('*');
				 if($id > 0){
		        $this->db->where('id' , $id);//
				 }
				 
		        $this->db->order_by('date_reported DESC');
		        $query = $this->db->get('machine_problems'); 
			 
			      if($query->num_rows()>0){//cl_status
			       foreach ($query->result() as $row2)
				  {
  					  
				 
	 		     $client  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'prob' => $row2-> problem  ,'new_state' =>  $row2-> new_state   ,'dt' => $row2->date_reported 
                             ,'worked_on' => $row2-> worked_on ,'d_in' => $row2-> date_reported  ,'machine' => $row2-> m_id  ,'tech' => $row2-> receiver_tech,'d_out' => $row2-> date_worked_on   
                             	 
			  );
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
                
				 
			}
		
		
		//user complain about this machine

		
		function Get_machine_problems($id){ 
		
		
		       $return_array = array(); //will take on the data about a given agent 	
	            $this->db->protect_identifiers('machine_problems');
			   
			    $this->db->select('*');
				 if($id > 0){
		        $this->db->where('m_id' , $id);//
				 }
				 
		        $this->db->order_by('date_reported DESC');
		        $query = $this->db->get('machine_problems'); 
			 
			      if($query->num_rows()>0){//cl_status
			       foreach ($query->result() as $row2)
				  {
  					  
				 
	 		     $client  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'prob' => $row2-> problem  ,'new_state' =>  $row2-> new_state   ,'dt' => $row2->date_reported 
                             ,'worked_on' => $row2-> worked_on ,'d_in' => $row2-> date_reported  ,'machine' => $row2-> m_id  ,'tech' => $row2-> receiver_tech,'d_out' => $row2-> date_worked_on   
                             	 
			  );
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
                
				 
			}
		
		
		// get all the information about this machine from the dtbase as far as servicing is concerned
		
		
		
		
		function Get_service_info($id){ 
		
		
		$return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	
	
	            $this->db->protect_identifiers('service_report');
			   
			    $this->db->select('*');
				 
		        $this->db->where('machine' , $id);//
				 
		        $this->db->order_by('period_done DESC');
		        $query = $this->db->get('service_report'); 
			 
			      if($query->num_rows()>0){//cl_status
			       foreach ($query->result() as $row2)
				  { 
				 
	 		    $client  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'state' => $row2-> current_state  ,'com' =>  $row2-> comment   ,'wf' => $row2->way_forward 
                             ,'new_st' => $row2-> new_state  ,'m_id' => $row2-> machine ,'period' => $row2-> period_done
                             	 
			  );
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
                
				 
			}
			
			               //get the service report 
			
			function Specific_service_info($id){ 
		
		
		$return_array = array(); //will take on the data about a given agent 	
	                          //PROTECT TABLE FIELDS
	            $this->db->protect_identifiers('service_report');
			   
			    $this->db->select('*');
				 
		        $this->db->where('id' , $id); 
		        $query = $this->db->get('service_report'); 
			 
			      if($query->num_rows()>0){//cl_status
			       foreach ($query->result() as $row2)
				  { 
				 
	 		    $client  = array( 
			   'mid' => $this->encrypt->encode($row2-> id)  ,'state' => $row2-> current_state  ,'com' =>  $row2-> comment   ,'wf' => $row2->way_forward 
                             ,'new_st' => $row2-> new_state  ,'m_id' => $row2-> machine ,'period' => $row2-> period_done , 'technician' => $row2->technician , 'tech_company' => $row2->tech_company
                             	 
			  );
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
                
				 
			}
			
			                     //specific repair information
			function Get_specific_repair_info($id){ 
		
		
		             $return_array = array();  	
	                                 //PROTECT TABLE FIELDS
	                 $this->db->protect_identifiers('repair_info');
			   
			         $this->db->select('*');
				 
		             $this->db->where('id' , $id); 
		    
		             $query = $this->db->get('repair_info'); 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
				 
	 		     $client  = array( 
			   'id' => $this->encrypt->encode($row2-> id)  ,'comp' => $row2-> repairing_company  ,'no' =>  $row2-> job_no   ,'diag' => $row2->diag 
                             ,'remedy' => $row2-> remedy  ,'spares' => $row2-> spares ,'tech' => $row2-> tech_comm, 'user_com' => $row2-> user_comm,'new_s' => $row2-> new_state,'charge' => $row2-> total_charges
                             	 
			  );
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
                
				
				 
			}
			
			
			                // get  machine repair information
			
			
			function Get_machine_repair_info($id){ 
		
		
		$return_array = array(); //will take on the data about a given agent 	
	                    //PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('repair_info');
			   
			    $this->db->select('*');
				 
		    $this->db->where('machine' , $id);//repairing_company
				 
		   $this->db->order_by('machine DESC');
		   
		    
		  $query = $this->db->get('repair_info'); 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
				 
	 		     $client  = array( 
			   'id' => $this->encrypt->encode($row2-> id)  ,'comp' => $row2-> repairing_company  ,'no' =>  $row2-> job_no   ,'diag' => $row2->diag 
                             ,'remedy' => $row2-> remedy  ,'spares' => $row2-> spares ,'tech' => $row2-> tech_comm, 'user_com' => $row2-> user_comm,'new_s' => $row2-> new_state,'charge' => $row2-> total_charges
                             	 
			  );
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
                
				
				 
			}
			
			                       //edit this report
			
			function Edit_field_report($x , $id){ // 
                
				
				 $datai = array( 'comment' => ucfirst(strtolower($x[0])) , 'current_state' => $x[1] ,   'new_state'	 => $x[2] , 'way_forward' => ucfirst(strtolower($x[3]))   , 'technician' => $x[5] , 'tech_company' => $x[6]   );
				 $this->db->where('id' , $x[4]);
	
				 $this->db->update('service_report' , $datai ); //effects should not affect the current state of the machine
				 //$this-> Machine_state_updates($id , $x[2]);
				 //$this->update_device_Service_report($x[4] , $x[3] , $x[0]);
				 
			}
			
			//delete   field report 
			
			function Delete_field_report($id){ // 
                
				
				  $this->db->where('id' , $id);
	
				 $this->db->delete('service_report' );
				 
			}
			
			
			//enter new service report
			function Add_field_report($x){ // 
                
				
				 $datai = array(       'comment' => ucfirst(strtolower($x[0])) , 'current_state' => $x[1] ,   'new_state'	 => $x[2] , 'way_forward' => ucfirst(strtolower($x[3]))  , 'period_done'	 => $this->RealDate()    , 'machine' => $x[4] , 'technician' => $x[5] , 'tech_company' => $x[6]);
				 
	
				 $this->db->insert('service_report', $datai);
				$this-> Machine_state_updates($x[4] , $x[2]);
				$this->update_device_Service_report($x[4] , $x[3] , $x[0]);
			}
			
			function Machine_Alocation($x){
				 $datai = array( 'device' => $x[0] , 'date_comissioned' => $this->RealDateTime() , 'giver' => $x[1] ,  'receiver'=> $x[2] );
				$this->db->insert('device_transfers' , $datai);
				
				 $this->change_department($x[0] , $x[2]);
				
				
				
			}
			
			function change_department($x , $t){
				$this->db->where('id' , $x);
				 $datai = array( 'department' => $t);
				$this->db->update('analysis_machines' , $datai);
				
				
			}
			
			//update device information from the databse from here 
			
			function update_device_Service_report($id , $wf , $com){
				$this->db->where('id' , $id);
				$datai = array('way_foward' => $wf ,'comment' => $com  );
				$this->db->update( 'analysis_machines', $datai);
				
				
			}
		
		
		// need these functions for now
		
		function Add_machine_bank($x){ 
                $this->db->select('name');
			   $this->db->where('name' , $x);
		       $query = $this->db->get('analysis_machine_bank');
			   if($query->num_rows()>0){
				   
				 }
			else {//add new machine
				
				 $datai = array(  'name' => $x     );
				 
	
				 $this->db->insert('analysis_machine_bank', $datai);
			}
				 
			
		}
		
		
		
		// chek the machine name and if does not exist return the mnew id to be used
		
		
		function Get_Next_machine_id($x){ 
		        $return_array  =0;
                $this->db->select('id');
			   $this->db->where('name' , strtolower($x));
			   $this->db->limit(1);
		       $query = $this->db->get('analysis_machine_bank');
			   if($query->num_rows()>0){
				   foreach ($query->result() as $row)
				  {  
				  
				  $return_array  = $row->id ;
				   }
				   
				 }
			else {//add new machine
				
				 $return_array  =  $this->Maxid_of_machine_type(); //get the next machine id
			}
				 
			return $return_array;
		}
		
		
		function Get_Next_manufacturer_id($x){ 
		        $return_array  =0;
                $this->db->select('id');
			   $this->db->where('name' , strtolower($x));
			   $this->db->limit(1);
		       $query = $this->db->get('analysis_manufacturere_bank');
			   if($query->num_rows()>0){
				   foreach ($query->result() as $row)
				  {  
				  
				  $return_array  = $row->id ;
				   }
				   
				 }
			else {//add new machine
				
				 $return_array  =  $this->Maxid_of_manufacturer(); //get the next machine id
			}
				 
			return $return_array;
		}
		
		
		//get next supplier id
		function Get_Next_supplier_id($x){ 
		        $return_array  =0;
                $this->db->select('id');
			   $this->db->where('name' , strtolower($x));
			   $this->db->limit(1);
		       $query = $this->db->get('analysis_suplier_bank');
			   if($query->num_rows()>0){
				   foreach ($query->result() as $row)
				  {  
				  
				  $return_array  = $row->id ;
				   }
				   
				 }
			else {//add new machine
				
				 $return_array  =  $this->Maxid_of_supplier(); //get the next machine id
			}
				 
			return $return_array;
		}
		
		//get the maximum machine id from the database
		
		function Maxid_of_machine_type(){
			$this->db->protect_identifiers('analysis_machine_bank');
			 $return_array  =  0;
			$this->db->select_max('id', 'maxid');
             $query = $this->db->get('analysis_machine_bank'); // Produces: SELECT MAX(age) as member_age FROM members

			 
			
			 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $return_array  = ( $row->maxid +1);
				   				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
		
		//next manufacturer
		function Maxid_of_supplier(){
			$this->db->protect_identifiers('analysis_suplier_bank');
			 $return_array  =  0;
			$this->db->select_max('id', 'maxid');
             $query = $this->db->get('analysis_suplier_bank'); // Produces: SELECT MAX(age) as member_age FROM members
  
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $return_array  = ( $row->maxid +1);
				   				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
		//next manufacturer id number_format
		
		function Maxid_of_manufacturer(){
			$this->db->protect_identifiers('analysis_manufacturere_bank');
			 $return_array  =  0;
			$this->db->select_max('id', 'maxid');
             $query = $this->db->get('analysis_manufacturere_bank'); // Produces: SELECT MAX(age) as member_age FROM members

			 
			
			 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $return_array  = ( $row->maxid +1);
				   				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
	
	
		
		
		function pending_requests($x){
			
			 $this->db->select('*');//2	m_id
			   $this->db->where('m_id' , $x);
			    $this->db->where('worked_on' , 0);
		       $query = $this->db->get('machine_problems');
			  return $query->num_rows();
				 
			
		}
		
		
		                           //edit machine problem fro here
		function Edit_machine_problem($x){ 
		  
		 
                 $datai = array(   'problem' => $x[0]          );
				 
	              $this->db->where('id' , $x[1]);
				  $this->db->update('machine_problems', $datai); 
			}
			//delete machine problem
			
			function delete_machine_problem($x){ 
		   
				 
	              $this->db->where('id' , $x);
				  $this->db->delete('machine_problems'); 
			}
		
		
		// add new machine problem to the database
		
		function Add_machine_problem($x){ 
		 $tech_receiver = $this->bio->scheduler(0);
		 $tech =0;
		 
		 $notify_jms =  $x[3];
		 if($notify_jms > 0){
		 
		 if(sizeof($tech_receiver) > 0){
			 
			$tech =  $tech_receiver[0]['id'];
			 
			 
		 }
		 
                 $datai = array(   'problem' => $x[0]  , 'new_state' => $x[1] , 'm_id' => $x[2]  , 'date_reported'	 => $this->RealDate()  , 'worked_on'	 => 0 ,   'receiver_tech'	 =>$tech  );
				 
	
				  $this->db->insert('machine_problems', $datai);//send notification from here
				 
				    $recv =  $message_body  = '';
					  $body_info  = $this-> Message_body($x[2]);
					  if(sizeof($body_info) > 0){
						  
						  //system sms v
					 $message_body  =  $body_info['machine'] . ' , of '.$body_info['hosp'].' under '. $body_info['dpt'].' Dept  reported '.$x[0].'  on '. $this->RealDate();  
					  }
					  
					  
					  $send_sms = $this->check_settings(1);
				 if(sizeof($send_sms) > 0 and  strlen($message_body) > 0){
					  $receivers = '';
					 for($r =0; $r<sizeof($send_sms); $r++ ){
						  $receivers .= $send_sms[$r].',';
						 
					 }
					 $recv .= substr($receivers , 0 , -1);
					 
					 $datai = array(   'sender' => 0  , 'receiver' => $tech , 'message' => $message_body  , 'other_info'	 => $this->RealDate()  , 'type'	 => 1    );
				      $this->add_notification( 0 , $tech , $message_body , 1 ,$recv );
					 $this-> Sms_sender($recv ,$message_body );
				 	 
				 }
		 }
		 else {
			 //just add my notification from here
			  $datai = array(   'problem' => $x[0]  , 'new_state' => $x[1] , 'm_id' => $x[2]  , 'date_reported'	 => $this->RealDate()  , 'worked_on'	 => 0 ,   'receiver_tech'	 =>0  );
				 
	
				  $this->db->insert('machine_problems', $datai);//send notification from here
			 
		 }
				 //
			}
			
			function add_notification( $sender , $receiver , $msg , $typ ,$info ){ 
			 $datai = array(   'sender' => $sender  , 'receiver' => $receiver , 'message' => $msg  , 'other_info'	 => $info    , 'type'	 => $typ    );
			 $this->db->insert('system_notifications_logs' , $datai);
				
				
				
			}
			function is_connected()
{
	$is_conn  =  false;
    $fp = fsockopen("www.php.net", 80, $errno, $errstr, 30);
if (!$fp) {
    $is_conn  =  false;
} else {
   $is_conn  =  true;
    }
    fclose($fp);
	return $is_conn;
	
	
	


}

function send_mail($msg , $header){
	$this->load->library('email');

$this->email->from('beas@kamdevpartners.com', 'BEAS ALERTS');
$this->email->to('jnserek@gmail.com');

 
 $this->email->cc('jnserek@gmail.com'); 
//$this->email->bcc('them@their-example.com'); 

$this->email->subject(''.$header.'');
$this->email->message(''.$msg.'');	

$this->email->send();

  $this->email->print_debugger();
	
	
}
			
			
			function  Sms_sender($rec ,$code ){
					
			 
			$receiver = urlencode(''.$rec.''); 
			$message = urlencode(''.$code.' BEAS');
			
			 
			$encoded = 'http://lambda.smsmedia.ug/api/capi/send.php?sender='.$receiver.'&dest=8198&user=kamdevpartners&pass=devkam&code=devkam&content='.$message.'';
			 echo  $xml = file_get_contents($encoded);
			 
			  if($xml){
				  return 1;
			  }
			  else return 0;
				 
			 
}
			
			
			function check_settings($id){
				$return_array = array();
				 $this->db->select('*');//2	m_id
			     $this->db->where('id' , $id);
			    $this->db->where('state' , 1);
		        $query = $this->db->get('system_settings');
				if($query->num_rows() > 0){
					
					$tech_receiver =  $this->All_techs('' );
					if(sizeof($tech_receiver) > 0){
						
						foreach($tech_receiver as $tech){
							if(strlen($tech['fon']) ==10   ){
								$checker=  substr($tech['fon'] , 0 , 3);
								if( strstr($checker , '07')){
							    $fon   ='256'. substr($tech['fon'] , 1);
							
							    array_push($return_array ,$fon );
								
								}
							 
							}
							 
							
						}
						 
						
						
					}
					
				}
				 
				
			  return $return_array;
				
				
			}
			
			function check_any_settings($id){
				$return_array = array();
				 $this->db->select('*');//2	m_id
			     $this->db->where('id' , $id);
			    $this->db->where('state' , 1);
		        $query = $this->db->get('system_settings');
				if($query->num_rows() > 0){
					
				$return_array = array(1);	 
					
				}
				 
				
			  return $return_array;
				
				
			}
			
			function check_days_to_shift($id){
				$return_array = array();
				 $this->db->select('*');//2	m_id
			     $this->db->where('id' , $id);
			    
		        $query = $this->db->get('system_settings');
				  if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {  
				  
				  $return_array  = array('id' =>$row->id   , 'state' =>$row->name     ); 
				   }
				 
			}
				
			}
			
			//prepare notification for 
			
			function Message_body($x ){//
				 //$recv = $this->check_settings(1);
				$return_array = array(); 
				
				 $hf  = $hospital = 'N/A'; 
				$Department = 'N/A'; 
				 $mcn_info  = $this-> match_machine($x);
				 if(sizeof($mcn_info) > 0){
					 $hf  = $mcn_info['hf']; 
                     $dp  = $mcn_info['dep'];
                     $mcn = $mcn_info['name']; 
					 $machine = $this-> Machine_name_bank($mcn);
					 
					 
					  $hosp = $this->specific_hospital($hf);
					 
					 if( sizeof($hosp ) >0 and strlen($machine) > 3 ){
						 
						$hospital =   ucfirst(strtolower($hosp['name'])) .' , '. ucfirst(strtolower($hosp['ln']));
					 
					 
					 $department  = $this->get_my_department( $dp);
					 if(sizeof($department) > 0){
						 
						$Department =  ucfirst(strtolower($department['dname']));
					 }
					 
					 
					  $return_array = array( 'machine' => $machine , 'hosp' =>$hospital , 'dpt' => $Department ,'hosp_id' =>$hf,'fon' =>$hosp['fon'] );
					
					 
					 
					 }
					 
					
					 
					 
				 }
				 return $return_array;
				   
}
			
			//enter new service report
			function Add_field_reportx($x){ // 
                
				
				 $datai = array(       'comment' => $x[0] , 'current_state' => $x[1] ,   'new_state'	 => $x[2] , 'way_forward' => $x[3]  , 'period_done'	 => $this->RealDate()    , 'machine' => $x[4]);
				 
	
				 $this->db->insert('service_report', $datai);
				$this-> Machine_state_updates($x[4] , $x[2]);
			}
			
			//update achine state n the machines table from here 
			
			
			function Machine_state_updates($x , $s){
			 
			   $this->db->where('id' , $x);
			    
		       
			  $datai = array(   'mstate'  => $s)   ;
	             
				 $this->db->update('analysis_machines', $datai) ;
				 
			
		}
		 
		
		
		// add new suppliers //
		
		function Add_suplier_bank($x){ 
                $this->db->select('name');
			   $this->db->where('name' , $x); 
		       $query = $this->db->get('analysis_suplier_bank');
			   if($query->num_rows()>0){
				   
				   
				 }
			else {//add new machine
			 	
				 $datai = array(  'name' => $x         );
				 //analysis_machine_bank
	
				 $this->db->insert('analysis_suplier_bank', $datai) ;
			}
				 
			
		}
		
		
		//add new supplier
		
		function Add_suplier_from_contloller($x){ //add new suuplier to the database 
                $this->db->select('name');
			   $this->db->where('name' , $x[0]);
			   $this->db->where('email_address' , $x[3]);
		       $query = $this->db->get('analysis_suplier_bank');
			   if($query->num_rows()>0){
				   
				   
				 }
			else { $datai = array(  'name' => $x[0]  ,  'phone_number' => $x[1]  ,  'contact_person' => $x[2]  ,  'email_address' => $x[3]  ,  'location' => $x[4]      );
				 
	
				 $this->db->insert('analysis_suplier_bank', $datai) ;
			}
				 
			
		}
		//add new servicing company from here
		
		function Add_servicing_company($x){ //add new suuplier to the database 
                $this->db->select('name');
			   $this->db->where('name' , $x[0]);
			   $this->db->where('email_address' , $x[3]);
		       $query = $this->db->get('service_companies');
			   if($query->num_rows()>0){
				   
				   
				 }
			else { $datai = array(  'name' => $x[0]  ,  'phone_number' => $x[1]  ,  'contact_person' => $x[2]  ,  'email_address' => $x[3]  ,  'location' => $x[4]      );
				 
	
				 $this->db->insert('service_companies', $datai) ;
			}
				 
			
		}
		//update service compnay
		
		function Update_servicing_company($x , $id){ //add new suuplier to the database 
                $this->db->where('id' , $id);
			    
			$datai = array(  'name' => $x[0]  ,  'phone_number' => $x[1]  ,  'contact_person' => $x[2]  ,  'email_address' => $x[3]  ,  'location' => $x[4]      );
				 
	
				 $this->db->update('service_companies', $datai) ;
			 
				 
			
		}
		
		//add a new technician from here who will be servicing the machines 
		
		
		function Add_servicing_tech($x){ //add new suuplier to the database 
                $this->db->select('name');
			   $this->db->where('name' , $x[0]);
			   $this->db->where('email_address' , $x[3]);
		       $query = $this->db->get('servicing_technician');
			   if($query->num_rows()>0){
				   // $service_comp =  array($fname ,$fon ,   $email , $tech_comp);
				   
				 }
			else { $datai = array(  'name' => $x[0]  ,  'phone_number' => $x[1]  ,     'email_address' => $x[2]  ,  'tech_company' => $x[3]      );
				 
	
				 $this->db->insert('servicing_technician', $datai) ;
			}
				 
			
		}
		
		
		//get all the servicing companies
		
		function Servicing_company($x){  //select a specific supplier from the database 
		 $return_array  =  array();
                $this->db->select('*');
				if($x > 0){
					$this->db->where('id' , $x);
				}
		       $query = $this->db->get('service_companies');//
			   
			   if($query->num_rows()>0){
				  foreach ($query->result() as $row2)
				  {  
				  $client  = array( 
			   'id' =>  $row2-> id  ,'name' => $row2-> name ,'agent' => $row2-> contact_person ,'email' => $row2-> email_address  ,'phone_number' => $row2-> phone_number,'location' => $row2-> location      );
			   array_push($return_array , $client);
				   }
			 }
			return $return_array;
		 	
		}
		
		//All available servicing techs
		
		function Servicing_techs($x){  //select a specific supplier from the database 
		 $return_array  =  array();
                $this->db->select('*');
				if($x > 0){
					$this->db->where('id' , $x);
				}
		       $query = $this->db->get('servicing_technician');//
			   
			   if($query->num_rows()>0){
				  foreach ($query->result() as $row2)
				  {  
				  $client  = array( 
			   'id' =>  $row2-> id  ,'name' => $row2-> name   ,'email' => $row2-> email_address  ,'phone_number' => $row2-> phone_number,'tech' => $row2-> tech_company      );
			   array_push($return_array , $client);
				   }
			 }
			return $return_array;
		 	
		}
		
		
		                                            //update device manufacturer
		
		
		function update_suplier_from_contloller($x , $id){  
                 $datai = array(  'name' => $x[0]  ,  'phone_number' => $x[1]  ,  'contact_person' => $x[2]  ,  'email_address' => $x[3]  ,  'location' => $x[4]      );
				 
	              $this->db->where('id' , $id);
				 $this->db->insert('analysis_suplier_bank', $datai) ;
			 	 
			
		}
		
		                                    //get a  given supplier from the database
		
		function Specific_machine_supplier($x){  //select a specific supplier from the database 
		 $return_array  =  array();
                $this->db->select('*');
			   $this->db->where('id' , $x);
		       $query = $this->db->get('analysis_suplier_bank');//
			   
			   if($query->num_rows()>0){
				  foreach ($query->result() as $row2)
				  {  
				  $return_array  = array( 
			   'id' => $this->encrypt->encode($row2-> id)  ,'name' => $row2-> name ,'agent' => $row2-> contact_person ,'email' => $row2-> email_address  ,'phone_number' => $row2-> phone_number,'location' => $row2-> location      );
			   
				   }
			 }
			return $return_array;
		 	
		}
		
		function Specific_machine_manufacturer($x){ //select a specific manufacturer from the database
		 $return_array  =  array();
                $this->db->select('*');
			   $this->db->where('id' , $x);
		       $query = $this->db->get('analysis_manufacturere_bank');
			   
			   if($query->num_rows()>0){
				  foreach ($query->result() as $row2)
				  { 
				  //push results to an array
                    $return_array  =  array('id' =>$row2->id   , 'name' =>$row2->name ,'agent' => $row2-> contact_person ,'email' => $row2-> email_address  ,'phone_number' => $row2-> phone_number,'location' => $row2-> location         ); 
					   }
				 
			}
			return $return_array;
		 	
		}
		
		
		
		//add new manufacturer to the database
		
		
		function Add_manufacturer_bank($x ){ 
                $this->db->select('name');
			   $this->db->where('name' , $x);
		       $query = $this->db->get('analysis_manufacturere_bank');
			   if($query->num_rows()>0){
				   
				 }
			else {//add new machine
				
				 $datai = array(  'name' => $x     );
				 //analysis_machine_bank
	
				 $this->db->insert('analysis_manufacturere_bank', $datai) ;
			}
				 
			
		}
		                             //add new manufacturer from controller
		
		function Add_manufacturer_from_controller($x ){ 
                $this->db->select('name');
			   $this->db->where('name' , $x[0]);
			   $this->db->where('email_address' , $x[3]);
		       $query = $this->db->get('analysis_manufacturere_bank');
			   if($query->num_rows()>0){
				   
				 }
			else {//add new machine
				
				 $datai = array(  'name' => $x[0]  ,  'phone_number' => $x[1]  ,  'contact_person' => $x[2]  ,  'email_address' => $x[3]  ,  'location' => $x[4]      );
				 
	
				 $this->db->insert('analysis_manufacturere_bank', $datai) ;
			}
			
			 
				 
			
		}
		
		        //update device manufacturers in the database from here
		
		function Update_manufacturer_from_controller($x , $id ){ 
                $query = $this->db->get('analysis_manufacturere_bank');
			      $datai = array(  'name' => $x[0]  ,  'phone_number' => $x[1]  ,  'contact_person' => $x[2]  ,  'email_address' => $x[3]  ,  'location' => $x[4]      );
				 
	             $this->db->where('id' , $id); 
				 $this->db->update('analysis_manufacturere_bank', $datai) ;
		 	
		}
		
		
		
	
	  
	 //all the machines
	 
	 function Machines_search(){
		 $return_array ='[ '; 
		 $this->db->select('*');
		  $query = $this->db->get('analysis_machine_bank');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {  
				  
				  $return_array  .=  '"'.strtolower($row->name).'" , ';// $row->id  ,  $row->name)    ; 
				   
				 
				   }
				
				
				
			}
			return $return_array.'"x"]';
		 
		 
	 }
	 
	 //get all my suppliers available for the searching purpose
	 
	 function Supplier_search(){
		 $return_array ='[ '; 
		 $this->db->select('*');
		  $query = $this->db->get('analysis_suplier_bank');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {  
				  
				  $return_array  .=  '"'.strtolower($row->name).'" , ';// $row->id  ,  $row->name)    ; 
				   
				 
				   }
				
				
				
			}
			return $return_array.'"x"]';
		 
		 
	 }
	 
	 //get all the supliers 
	 
	 
	 function Suppliers_All (){
		 $return_array = array(); 
		 $this->db->select('*');
		  $query = $this->db->get('analysis_suplier_bank');
		   $this->db->order_by(' name ASC');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {  
				  
				   $client  = array('id' =>$row->id   , 'name' =>$row->name     ); 
				  array_push($return_array , $client); 
				  
				  
				   }
				
				
				
			}
			return $return_array;
		 
		 
	 }
	 //all machines from the bank
	 
	 //get dereciation rate for this machine
	 function Machine_dep_rate($x){
		 $return_array = array(); 
		  $client  = 0;
		 $this->db->select('*');
		  $this->db->where('id' , $x);
		  $query = $this->db->get('analysis_machine_bank');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {  
				  
				   $client  =  $row->depreciation_rate ; 
			 
				  
				  
				   }
				
				
				
			}
			
			if($client < 1 || $client > 100){
				$client = 10;
			}
			return $client*0.01;
		 
		 
	 }
	 
	  function Machine_name_bank($x){
		 $return_array = array(); 
		  $client  = '';
		 $this->db->select('*');
		  $this->db->where('id' , $x);
		  $query = $this->db->get('analysis_machine_bank');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {  
				  
				   $client  =  $row->name ; 
			 
				  
				  
				   }
				
				
				
			}
			
			if(  $client == ''){
				$client = 'N/A';
			}
			return $client;
		 
		 
	 }
	 
	 
	 function Machines_bank_All(){
		 $return_array = array(); 
		 $this->db->select('*');
		  $this->db->order_by('name');
		  $query = $this->db->get('analysis_machine_bank');
		  
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {  
				  
				   $client  = array('id' =>$row->id   , 'name' =>$row->name     ); 
				  array_push($return_array , $client); 
				  
				  
				   }
				
				
				
			}
			return $return_array;
		 
		 
	 }
	 //get all my machone manufactureres from the database
	 
	 function Manufacturers_All(){
		 $return_array = array(); 
		 $this->db->select('*');
		  $query = $this->db->get('analysis_manufacturere_bank');
		   $this->db->order_by(' name ASC');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row2)
				  {  
				  
				   $client  = array('id' =>$row2->id   , 'name' =>$row2->name ,'agent' => $row2-> contact_person ,'email' => $row2-> email_address  ,'phone_number' => $row2-> phone_number,'location' => $row2-> location         ); 
				  array_push($return_array , $client); 
				  
				  //$return_array  .=  '"'.strtolower($row->name).'" , ';// $row->id  ,  $row->name)    ; 
				   
				 
				   }
				
				
				
			}
			return $return_array;
		 
		 
	 }
	 
	 
	 //get all manufacturere's search
	 
	  
	 
	 
	 //SELECT ALL THE MANUFACTURERES FROM TTHE DATABASE BANK
	 
	 
	  
	 
	 //search all my manufacturers
	 
	 function Manufacturer_search(){
		 $return_array ='[ '; 
		 $this->db->select('*');
		  $query = $this->db->get('analysis_manufacturere_bank');
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {  
				  
				  $return_array  .=  '"'.strtolower($row->name).'" , ';// $row->id  ,  $row->name)    ; 
				   
				 
				   }
				
				
				
			}
			return $return_array.'"x"]';
		 
		 
	 }
	 
	
	
	//add repair infor to the database from here 
	
	 function Add_machine_repair_info($x){ //  //
	//PROTECT TABLE FIELDS
	 
	            $this->db->protect_identifiers('repair_info');//phone_number
			   $datai = array(  'repairing_company' => $x[0] ,  'job_no' => $x[1] ,  'diag' => $x[2] ,  'remedy' => $x[3] ,  'spares'  => $x[4],  'tech_comm' => $x[5] ,  'user_comm'  => $x[6],  'new_state' => $x[7] ,  'machine'  => $x[9] ,  'total_charges'  => $x[8] ,  'date_loged'  => $this->RealDate()  )   ;
	         
			 $this->db->insert('repair_info', $datai) ;
			 
			 
			 $this-> pending_requests_updates($x[9]);
			 
		 	
		} 
		//delete repair information fromthe database
		
		function Delete_machine_repair_info($id){ //  //
	                   //PROTECT TABLE FIELDS
	 
	           $this->db->protect_identifiers('repair_info');//phone_number
			   $this->db->where('id' , $id);
			   $this->db->delete('repair_info') ;
			  
			 
		 	
		} 
		
		//update machine repair information
		
		function Update_machine_repair_info($x , $id){ //  //
	                   //PROTECT TABLE FIELDS
	 
	           $this->db->protect_identifiers('repair_info');//phone_number
			   $datai = array(  'repairing_company' => $x[0] ,  'job_no' => $x[1] ,  'diag' => $x[2] ,  'remedy' => $x[3] ,  'spares'  => $x[4],  'tech_comm' => $x[5] ,  'user_comm'  => $x[6],  'new_state' => $x[7] ,    'total_charges'  => $x[8]  )   ;
	           $this->db->where('id' , $id);
			   $this->db->update('repair_info', $datai) ;
			  
			 
		 	
		} 
		
		function pending_requests_info($x){
			 $return_array  = array();
			 $this->db->select('*');//2	m_id
			   $this->db->where('id' , $x);
			    
		       $query = $this->db->get('machine_problems');
			   
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				   $return_array  = array('id' =>$row->id ,'tech' => $row->receiver_tech    ); 
				 		 
				   }
			   
				 
			}
			 return $return_array; 
				 
			
		}
		
		function update_worked_on($x){
			
		  $this->db->select('*');//2	m_id
			   $this->db->where('id' , $x);
			    $this->db->where('worked_on' , 0);
		       
			  $datai = array(   'worked_on'  => 1 , 'date_worked_on'  => $this->RealDate())   ;
	             
				 $this->db->update('machine_problems', $datai) ;
				 
		}
		
		//shift the jobs
		
		function Shift_jobs($x , $receiver ){
			
		 
			   $this->db->where('id' , $x);
			   
		       
			  $datai = array(   'date_shifted'  => $this->RealDate() , 'receiver_tech'  => $receiver)   ;
	             
				 $this->db->update('machine_problems', $datai) ;
				 
		}
		
		function pending_requests_updates($x){
			
			
				 
				 	     $recv =  $message_body  = '' ;
						  $hosp_id =0;
					  $body_info  = $this-> Message_body($x); 
 					  
					  if(sizeof($body_info) > 0){ 
						   
						   $receivers  = $body_info['fon'];
						   $hosp_id = $body_info['hosp_id'];
					      $message_body  =  'Hello '.$body_info['hosp'].'  Your  ' .$body_info['machine'] . ' is ready come and pick It '. $this->RealDate();  
					  }
					  
					  
					  $send_sms = $this->check_settings(1);
					   $owner_info =  $this->  pending_requests_info($x);
					 
					   
				 if(sizeof($send_sms) > 0 and  strlen($message_body) > 0 and sizeof($owner_info) >0 ){
					
					 if(strlen($receivers) ==10   ){
								$checker=  substr($receivers , 0 , 3);
								if( strstr($checker , '07')){
							    $recv    ='256'. substr($receivers , 1);
							
							    
								
								}
							 
							}
							if( strlen($recv)  ==12){
					 
					 
					 
					 $datai = array(   'sender' => $owner_info['tech']  , 'receiver' => $hosp_id , 'message' => $message_body  , 'other_info'	 => $this->RealDate()  , 'type'	 => 1    );
				      $this->add_notification( 0 , $hosp_id , $message_body , 1 ,$recv );
					 $this-> Sms_sender($recv ,$message_body );
							}
					 
					 
				 }
				 $this->update_worked_on($x);
				 
				 
				 
			
		}
		
		
	
	//add new hospital to the databse dsection
	
	
	 function Add_hospitals($x){ //$entray_ar  = array($fname , $locn , $fon , $email , $type);
	//PROTECT TABLE FIELDS
	 
	            $this->db->protect_identifiers('hospitals');//phone_number
			   $datai = array(  'name' => $x[0] ,  'location' => $x[1] ,  'phone_number' => $x[2] ,  'email' => $x[3] ,  'hosp_type'  => $x[4] , 'contact_person'  => $x[5]   )   ;
	         
			 $this->db->insert('hospitals', $datai) ;
			 
		 	
		} 
		
		//edit this health facility
		function Edit_hospitals($x , $y){ //$entray_ar  = array($fname , $locn , $fon , $email , $type);
	//PROTECT TABLE FIELDS
	 
	            $this->db->protect_identifiers('hospitals');//phone_number
			   $datai = array(  'name' => $x[0] ,  'location' => $x[1] ,  'phone_number' => $x[2] ,  'email' => $x[3] ,  'hosp_type'  => $x[4] ,  'contact_person'  => $x[5] )   ;
	        
			 $this->db->where('id' , $y);
			  $this->db->update('hospitals', $datai) ;
			  
			 
		 	
		}
		
		//delete all hospital / client data from the databse
		
		function Delete_departments(){
			
		}
		
		//delete this supplier from the database
		
		function Delete_supplier($x){ 
			  
			  $this->db->where('id' , $x);
			  $this->db->delete('analysis_suplier_bank') ;
			  
			
			
			
		}
		
		
		function Delete_hospital($x){
			
			 $this->db->where('id' , $x);
			  $this->db->delete('hospitals') ;
			  
			  $this->db->where('hosp_id' , $x);
			  $this->db->delete('bio_department') ;
			  
			 // $this->db->where('customer' , $x);
			  //$this->db->delete('bio_orders') ;
			  //health_facility
			  
			  $this->db->where('health_facility' , $x);
			  $this->db->delete('analysis_machines') ;
			  
			
			
			
		}
		
		//delete this machine from the databse
		
		function Delete_device_data($x){
			
			  
			  $datai = array(  'mstate' => 0 )   ;
			  $this->db->where('id' , $x);
	           $this->db->update('analysis_machines', $datai) ;
			  
			
			
			
		}
		
		//add new ststes to the database from here
		
		
	 function Add_machine_states($x){ //add new machine states from here
	 
	           $this->db->protect_identifiers('new_states');//phone_number
			   $datai = array(  'name' => $x  )   ;
	           $this->db->insert('new_states', $datai) ;
			 
		 	
		} 
		
		//check for this new state and see if it exists in the database 
		
		
		 
	 function validate_new_state($x){ //from the database 
			$return_array = array();
			 
			  $this->db->select('*');
			  $this->db->where('name' , $x);
			   $query = $this->db->get('new_states');
			 
			 return $query->num_rows();
			  
			  
		}
		
		function validate_new_state_two($x){ //from the database 
			$return_array = array();
			 
			  $this->db->select('*');
			  $this->db->where('id' , $x);
			   $query = $this->db->get('new_states');
			 
			 return $query->num_rows();
			  
			  
		}
		
		//all machine states
		
		
		function Update_machine_states($n , $d){ 
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('new_states');
			     $datai = array(  'name' => $n )   ;
	             $this->db->where('id' , $d);
				 $this->db->update('new_states', $datai) ;
				 
			
		}
		
		
		
	
	
	//GET ALL HOSPITAL TYPES FROM THE DATABASE
	
	
	function All_Hospital_Type(){
			$this->db->protect_identifiers('client_categories');
			 $return_array  =  array();
			
			$this->db->select('*');
			
			 
			
			$query = $this->db->get('client_categories');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				   $client  = array('id' =>$row->id ,'name' => ucfirst(strtolower($row->name ))   ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 //service companies listing
		 
		 function List_Companies($x){
			$this->db->protect_identifiers('service_companies');
			$this->db->select('*');
			 $return_array  =  array();
			 if($x > 0){
				 
				 $this->db->where('id' , $x);
			 }
			 
			$query = $this->db->get('service_companies');
			 
			if($query->num_rows()>0){ 
			foreach ($query->result() as $row)
				  { 
				    $client  = array('id' =>$row->id ,'email' =>$row->email_address ,'location' =>$row->location ,'phone' =>$row->phone_number ,'agent' =>$row->contact_person ,'name' => ucfirst(strtolower($row->name ))   ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 //get servicing technicians
		 
		  function List_service_techs($x){
			$this->db->protect_identifiers('servicing_technician');
			$this->db->select('*');
			 $return_array  =  array();
			 if($x > 0){
				 
				 $this->db->where('id' , $x);
			 }
			 
			$query = $this->db->get('servicing_technician');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				    $client  = array('id' =>$row->id ,'email' =>$row->email_address ,'phone' =>$row->phone_number ,'company' =>$row->tech_company ,'name' => ucfirst(strtolower($row->name ))   ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 //service technician technicians 
		 
		  function Service_techs($x){
			$this->db->protect_identifiers('servicing_technician');
			$this->db->select('*');
			 $return_array  =  array();
			 
				 
				 $this->db->where('tech_company' , $x);
			 
			 
			$query = $this->db->get('servicing_technician');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				    $client  = array('id' =>$row->id ,'email' =>$row->email_address ,'phone' =>$row->phone_number ,'company' =>$row->tech_company ,'name' => ucfirst(strtolower($row->name ))   ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 
		 //get all the system settings from the database
		 
		 function Settings_system($x){
			$this->db->protect_identifiers('system_settings');
			$this->db->select('*');
			 $return_array  =  array();
			 if($x > 0){
				 
				 $this->db->where('id' , $x);
			 }
			 
			$query = $this->db->get('system_settings');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				   $client  = array('id' =>$row->id ,'state' =>$row->state ,'name' => ucfirst(strtolower($row->name ))   ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 
		 //update system setting ststes
		 function Update_setting_state( $id , $st){
			 
			 $this->db->where('id', $id);
			 $datai= array( 'state' =>$st);
			 $this->db->update('system_settings', $datai);
		 }
		 
		 //get all hospital types
		 
		 function All_machine_states(){
			$this->db->protect_identifiers('new_states');
			 $return_array  =  array();
			
			$this->db->select('*');
			$this->db->where('id >' , 0);
			
			 
			
			$query = $this->db->get('new_states');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				   $client  = array('id' =>$row->id ,'name' => ucfirst(strtolower($row->name))    ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 
		 //all system users
		 
		  function Alter_user_state($x , $s){
			$this->db->protect_identifiers('system_users');
			 $return_array  =  array();
			
			$this->db->select('*');
			 
				$this->db->where('id', $x);
			 
			    $this->db->where('hospital_no!=', '**');
				$datai = array(  'state' => $s )   ;
	            
				 $this->db->update('system_users', $datai) ;
			
		  }
		  function All_users($x){ //get all system users apart from super user 
			$this->db->protect_identifiers('system_users');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
				$this->db->where('id', $x);
			}
			$this->db->where('hospital_no!=', '**');
			
			 
			
			$query = $this->db->get('system_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				   $client  = array('id' =>$row->id ,'role' =>$row->hospital_no , 'loged_in' =>$row->logged_in ,'state' =>$row->state ,'mail' =>$row->email ,'fon' =>$row->phone_no ,'name' => ucfirst(strtolower($row->uname)),'fname' => ucfirst(strtolower($row->full_name)),'lname' => ucfirst(strtolower($row->last_name))    ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 
		  function All_users_by_states($x){ //get all system users apart from super user  basing on user ststes
			$this->db->protect_identifiers('system_users');
			 $return_array  =  array();
			
			$this->db->select('*');
			 
				$this->db->where('logged_in', $x);
			 
			$this->db->where('hospital_no!=', '**');
			
			 
			
			$query = $this->db->get('system_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				   $client  = array('id' =>$row->id ,'role' =>$row->hospital_no , 'loged_in' =>$row->logged_in ,'state' =>$row->state ,'mail' =>$row->email ,'fon' =>$row->phone_no ,'name' => ucfirst(strtolower($row->uname)),'fname' => ucfirst(strtolower($row->full_name)),'lname' => ucfirst(strtolower($row->last_name))    ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 
		 
		 function All_system_users(){
			$this->db->protect_identifiers('system_users');
			 $return_array  =  array();
			
			$this->db->select('*');
			
			 
			
			$query = $this->db->get('system_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				   $client  = array('id' =>$row->id ,'name' => ucfirst(strtolower($row->name))  ,  'loged_in' =>$row->logged_in   ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 
		 
		 //get all hospitals
		 
		 
		 function All_Hospitals(){
			$this->db->protect_identifiers('hospitals');
			 $return_array  =  array();
			
			$this->db->select('*');
			 $query = $this->db->get('hospitals');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				   $client  = array('id' =>$row->id ,'name' => $row->name ,'ln' => $row->location ,'fon' => $row->phone_number  ,'mail' => $row->email ,'type' => $row->hosp_type  ,'person' => $row->contact_person    ); 
				  array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
		 
		 //functon to get a partcular hospital from the database
		 
		 function specific_hospital($x){
			$this->db->protect_identifiers('hospitals');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			$this->db->where('id' , $x);
			}
			 $query = $this->db->get('hospitals');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				 $client = array('id' =>$row->id ,'name' => $row->name ,'ln' => $row->location ,'fon' => $row->phone_number  ,'mail' => $row->email ,'type' => $row->hosp_type  ,'person' => $row->contact_person    ); 
				 array_push($return_array , $client); 			 
				   }
			   
				 
			}
			 return $return_array;
		 }
	
	
	
	
	
	
	function Random_code(){
			 
			 //check which is the ticket type
			 
			     $bytes = openssl_random_pseudo_bytes(3 ); // get a 6  digit nuber
                 return $pwd =  bin2hex($bytes) ;
			 
			 
		 }
	function Bio_Aunthentication($x , $y ){
		   $data_array = array();
		   $this->db->select('*');
		   $this->db->where('uname' , strtolower($x));
		  $this->db->where('state' , 1);//
		  $this->db->limit(1);
		    
		  $query = $this->db->get('system_users');
			 
			 
			if($query->num_rows()>0){//cl_status
			
			
			 
			foreach ($query->result() as $row)
				  { 
				   if(password_verify($this->db->escape(strtolower($y)), $row->password  ) || $row->provisional_code == $y ){
				 
				   $data_array = array(
                   'bio_id'  => $row->id ,
                   'bio_name'     => strtoupper($row->full_name),
				    'bio_role'     => $row->hospital_no,
				   'logged_in' => TRUE
				     
               );
			                      //record user login attribute
								  $this->Update_pass_code($row->id , '');
								  
			  $this-> Update_login($row->id , 1);
			  
			   
			   
				   }
			  
			  }
		 	 
			}
			 
			return  $data_array ;
		 
		 
	 }
	 
	 
	 //password recoverly option
	 
	 
	 function Pass_recoverly($x , $y ){
		   $data_array = array();
		   $this->db->select('*');
		   $this->db->where('uname' , strtolower($x));
		   $this->db->where('phone_no' ,  $y);
		  $this->db->where('state' , 1);//
		  $this->db->limit(1);
		    
		  $query = $this->db->get('system_users');
			 
			 
			if($query->num_rows()>0){//cl_status
			
			
			 
			foreach ($query->result() as $row)
				  { 
				   
					$this->  Update_code($row->id  , $y);
					  
				       $data_array= array( $row->id);
				  
			  }
		 	 
			}
			 
			return  $data_array ;
		 
		 
	 }
	 
	  function Update_code($id  , $receivers){
		   $code  = $this-> Random_code();
		    $this->Update_pass_code($id , $code);
		
		 $message_body = $code.' is your pass code from BEAS'; 
		  $this->add_notification( 0 , $id , $message_body , 5 , $receivers );//
		 $send_sms = $this->check_settings(1);
		 
		  if(sizeof($send_sms) > 0   ){
					
					 if(strlen($receivers) ==10   ){
								$checker=  substr($receivers , 0 , 3);
								if( strstr($checker , '07')){
							    $recv    ='256'. substr($receivers , 1);
							
							    
								
								}
							 
							}
							if( strlen($recv)  ==12){
					   // $datai = array(   'sender' => 0  , 'receiver' => $id , 'message' => $message_body  , 'other_info'	 => $this->RealDate()  , 'type'	 => 0    );
				     
					 $this-> Sms_sender($recv ,$message_body );
							}
		  }
		 
		 
	 }
	 
	 function Update_pass_code($id , $code){
		  $this->db->where('id' , $id);
		
		 $datai  = array(  'provisional_code' => $code );
		 $this->db->update('system_users', $datai);
		 
		 
		 
	 }
	 
	 function Update_login($id , $st){
		 $this->db->where('id' , $id);
		 $datai  = array(  'logged_in' => $st );
		 $this->db->update('system_users', $datai);
		 
		 
	 }
	 
	 
	 function Add_user_to_db($x){ 
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('system_users');
			      $hashed_password = password_hash($this->db->escape(strtolower($x[5])), PASSWORD_DEFAULT);
	 		   
			    $datai = array(  'full_name' => $x[0] ,  'last_name'=> $x[1] ,  'email'=> $x[2],  'phone_no'=> $x[3] ,  'hospital_no'=> $x[6] ,  'password'  => $hashed_password , 'uname'  => strtolower($x[4]),  'state'  => 1)   ;
	
				 $this->db->insert('system_users', $datai) ;
				 
			
		} 
		//add new price item to database from here
		
		function Add_new_cat_item_to_db($x){ 
	//PROTECT TABLE FIELDS
 
	           $this->db->protect_identifiers('bio_catelogue');
			     
	 		   
			    $datai = array(  'machine_name' => $x[0] ,  'scie_name'=> $x[1] ,  'specifications'=> $x[3],  'descriptions'=> $x[4] ,  'price'=> $x[6] , 

				'discount'  => $x[7] , 'featured'  =>  $x[5],  'mark_as_new'  => $x[8], 'run_up_to'  =>  0,  'machine_cat'  => $x[2]  )   ;
	
				 $this->db->insert('bio_catelogue', $datai) ;
				 
			
		}
		
		//edit cat items
		
		function Update_cat_item($x , $id){ 
	//PROTECT TABLE FIELDS
 
	           $this->db->protect_identifiers('bio_catelogue');
			     
	 		   
			    $datai = array(  'machine_name' => $x[0] ,  'scie_name'=> $x[1] ,  'specifications'=> $x[3],  'descriptions'=> $x[4] ,  'price'=> $x[6] , 

				'discount'  => $x[7] , 'featured'  =>  $x[5],  'mark_as_new'  => $x[8], 'run_up_to'  =>  0,  'machine_cat'  => $x[2]  )   ;
	
				 $this->db->where('id' , $id);
				 $this->db->update('bio_catelogue', $datai) ;
				 
			
		}
		
		function Delete_cat_item($id , $st){
			$datai = array(  'state' => $st     )   ;
	
			
			$this->db->where('id', $id);
			$this->db->update('bio_catelogue' , $datai);
		}
		function Add_new_cat_excell($x){ 
	//PROTECT TABLE FIELDS
	// $entray_ar  = array($fname , $lname , $cat , $spec , $desc , $ft , $prc , $ds , $na);
	           $this->db->protect_identifiers('bio_catelogue');
			     
	 		   
			   
				 $this->db->insert('bio_catelogue', $x) ;
				 
			
		} 

		
		
		//add new departments to databse 
		
		
		function Add_department_to_db($x , $y , $d_type){ // add new department to databse
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('bio_department'); 
			    $datai = array(  'name' => $x ,  'hosp_id'=> $y ,  'department_type'=> $d_type )   ;
	
				 $this->db->insert('bio_department', $datai) ;
				 
			
		}

//check if this name does not exist for this hospital in the database

function validate_dpt_name($x , $y){ //from the database 
			$return_array = array();
			 
			  $this->db->select('*');
			  $this->db->where('name' , $x);
			   $this->db->where('hosp_id' , $y);
			   $query = $this->db->get('bio_department');
			 
			 return $query->num_rows();
			  
			  
		}


function get_hospital_departments( $h){ //from the database 
			$return_array = array();
			 
			  $this->db->select('*');
			  //$this->db->where('name' , $x);
			  if($h >0){
			   $this->db->where('hosp_id' , $h);
			  }
			   $query = $this->db->get('bio_department');
			 
			 if($query->num_rows()>0){//cl_status
			 foreach ($query->result() as $row)
				  { 
				  
				  
				  $client  = array('id' =>$row->id ,'dname' => ucfirst(strtolower($row->name)) ,'dtype' => $row->department_type     ); 
				  array_push($return_array , $client);
				   
			  
			  }
		 	 
			}
			
			 
			return  $return_array ;
			  
			  
		}

//get department by id
function get_my_department( $h){ //from the database 
			$return_array = array();
			 
			  $this->db->select('*');
			  //$this->db->where('name' , $x);
			   $this->db->where('id' , $h);
			   $query = $this->db->get('bio_department');
			 
			 if($query->num_rows()>0){//cl_status
			 foreach ($query->result() as $row)
				  { 
				  
				  
				  $return_array  = array('id' =>$row->id ,'dname' => $row->name ,'dtype' => $row->department_type     ); 
				  //array_push($return_array , $client);
				   
			  
			  }
		 	 
			}
			 
			return  $return_array ;
			  
			  
		}

//update usert department

 function Update_depatment_names($n , $d , $dp){ 
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('bio_department');
			     $datai = array(  'name' => $n , 'department_type' => $dp )   ;
	            $this->db->where('id' , $d);
				 $this->db->update('bio_department', $datai) ;
				 //print_r($datai );
				 //exit();
				 
			
		}
		
		//update machine departments from here
		
		function Update_machine_depatment_types($old , $new){ 
	//PROTECT TABLE FIELDS
	          
			     $datai = array(  'department_type' => $new  )   ;
	             $this->db->where('department' , $old);
				 $this->db->update('analysis_machines', $datai) ;
				 
			
		}
		

 function Update_supplier_names($n , $d){ 
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_suplier_bank');
			     $datai = array(  'name' => $n )   ;
	             $this->db->where('id' , $d);
				 $this->db->update('analysis_suplier_bank', $datai) ;
				 
			
		}
		
		function Update_manufacturer_names($n , $d){ 
	                                            //PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_manufacturere_bank');
			     $datai = array(  'name' => $n )   ;
	             $this->db->where('id' , $d);
				 $this->db->update('analysis_manufacturere_bank', $datai) ;
				 
			
		}
		
		//delete this manufacturer from the databse
		
		function Delete_manufacturere($m){  
	                                            //PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_manufacturere_bank');
			     
	             $this->db->where('id' , $m);
				 $this->db->delete('analysis_manufacturere_bank') ;
				 
			
		}

		
//update departmental names

function Update_depreciation_rates($id , $n , $r){  
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('analysis_machine_bank');
			     $datai = array(   'depreciation_rate' => $r )   ;
	             $this->db->where('id' , $id);
				 $this->db->update('analysis_machine_bank', $datai) ;
				 
			
		}		
					
					
				
		
		
		
		//update basic bio data in the databse from here 
		
		 function update_user_biodata($x , $y){ 
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('system_users');
			      //$hashed_password = password_hash($this->db->escape(strtolower($x[5])), PASSWORD_DEFAULT);
	 		   
			    $datai = array(  'full_name' => $x[0] ,  'last_name'=> $x[1] ,  'email'=> $x[2],  'phone_no'=> $x[3] , 'state'  => 1)   ;
	             $this->db->where('id' , $y);
				 $this->db->update('system_users', $datai) ;
				 
			
		}
		
		//very fy pasword before
		
		//check validate user
		
		function Bio_Verificaion_Update($x  ){
		   $data_array = array();
		   $this->db->select('*');
		   $this->db->where('id' , $x);
		 
		  $this->db->limit(1);
		    
		  $query = $this->db->get('system_users');
			 
			 
			if($query->num_rows()>0){//cl_status
			
			
			 
			foreach ($query->result() as $row)
				  { 
				   
				   $data_array = array(
                   'bio_id'  => $row->id ,
                   'bio_name'     => strtoupper($row->full_name),
				    'bio_role'     => $row->hospital_no,
				   'logged_in' => TRUE
				     
               );
			                      
								  $this->Update_pass_code($row->id , '');
				 
			  
			   
			   
				   
			  
			  }
		 	 
			}
			 
			return  $data_array ;
		 
		 
	 }
		
		function Bio_Verificaion($x , $y ){
		   $data_array = array();
		   $this->db->select('*');
		   $this->db->where('id' , $x);
		 
		  $this->db->limit(1);
		    
		  $query = $this->db->get('system_users');
			 
			 
			if($query->num_rows()>0){//cl_status
			
			
			 
			foreach ($query->result() as $row)
				  { 
				   if(password_verify($this->db->escape(strtolower($y)), $row->password  ) ){
				 
				   $data_array = array(
                   'bio_id'  => $row->id ,
                   'bio_name'     => strtoupper($row->full_name),
				    'bio_role'     => $row->hospital_no,
				   'logged_in' => TRUE
				     
               );
			                      
								  $this->Update_pass_code($row->id , '');
				 
			  
			   
			   
				   }
			  
			  }
		 	 
			}
			 
			return  $data_array ;
		 
		 
	 }
		
		function update_user_password($x , $y){ 
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('system_users');
			      $hashed_password = password_hash($this->db->escape(strtolower($x)), PASSWORD_DEFAULT);//
	 		   
			    $datai = array(  'password' => $hashed_password , 'state'  => 1)   ;
				$this->db->where('id' , $y);
	
				 $this->db->update('system_users', $datai) ;
				 
			
		}
		
		function scheduler($type ){
			 $my_results_data1  =  	$this->All_techs(0 );
			if($type ==0 ){
			
			$my_results_data  = $this->columnSort($this->All_techs(0 ), 'jobs_pending');
			return $my_results_data;//
				
				
			}
			
			else if ($type ==1){ //move this job to another person with ost no of days
			   $date_dif =3;
				$date_diffs = $this-> check_days_to_shift(3);
				if(sizeof($date_diffs) >0){
					$date_dif =  $date_diffs['state']; //actual days to con cider
				}
				
					$pending_rates  = $this->sort_descending($this-> pending_rates( $date_dif , 'D' ,  sizeof($my_results_data1)) , 'diff'); //above 4 days
				return $pending_rates ;
			}
			else return array();
			
			 
			 
			  
		}
		
		function search_machine($string , $user){
			$return_array  = array();
			$queryv = array();
			if($user > 0){
			 $queryv = $this->db->query("select  a.id as id , a.name ,  model , sno , country , mstate , myr, suplier , department , health_facility , maufacturer , comment from analysis_machines a , analysis_machine_bank b  where  (a.name = b.id and b.name like '%".$string."%' and health_facility=  ".$user." ) ");// or(health_facility = e.id or (e.name like '%".$string."%' or e.location like '%".$string."%') )
			}
			else {
							 $queryv = $this->db->query("select  a.id as id , a.name ,  model , sno , country , mstate , myr, suplier , department , health_facility , maufacturer , comment from analysis_machines a , analysis_machine_bank b  where  (a.name = b.id and b.name like '%".$string."%') ");// or(health_facility = e.id or (e.name like '%".$string."%' or e.location like '%".$string."%') )
			
			}
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				    $client  =  array('mid' =>  $row->id  ,'hf' =>  $row->health_facility,'cou' =>  $row->country,'ms' =>  $row->mstate  ,'yr' =>  $row->myr  ,'dep' =>  $row-> department , 'name'=>  $row->  name,  'mod'=>  $row->  model, 'sn'=>  $row->  sno , 'sup'=>  $row->  suplier , 'man'=>  $row->  maufacturer  ) ;
				 
				  array_push($return_array , $client);
				  }
			}
			
			if(sizeof($return_array) > 0){
				return $this->unique_multidim_array($return_array, 'mid');
				  return  $return_array;
			}
			else return  $return_array;
		}
		
		//machine reports
		
		 function Machine_Reports(  $client   , $dp , $sup , $p1 , $p2 , $machine ){
			 
			 //$this->db->select('*');
			 $client_q = '';
			 $period_q ='';
			 if($p1 > 0 and $p2 > 0 ){
				 
			  //$this->db->where('health_facility' , $client);
			 // $client_q = 'and (health_facility )';// between '2017-12-12' and '2018-12-12'
			 $period_q .= " and ( date_installed between '".$p1."' and '". $p2. "' )";//' ;// and ( date_installed  between '.$p1.' and '.$p2.'  )';
			 }
			 else if($p1 > 0 ){
				  $period_q .= '  and (date_installed  = '.$p1.'   )';
				 
			 }
			 else  if( $p2 > 0 ){
				   $period_q .= '  and (date_installed  = '.$p2.'   )';
				 
			 }
			 
			 
			 
			 if($client > 0){
				 
			  //$this->db->where('health_facility' , $client);
			 // $client_q = 'and (health_facility )';
			 $client_q .= '  and (health_facility = '.$client.' )';
			 }
			  $dp_q = '';
			 
			  if($dp > 0){
			 //$this->db->where('department' , $dp);
			 $dp_q .= ' and (department  = '.$dp.' ) ';
			 }
			  $sup_q = ' ';
			 if($sup > 0){
			 //$this->db->where('suplier' , $sup);
			  $sup_q .= ' and ( suplier   = '.$sup.' ) ';
			 }
			 $mcn_q ='';
			  if( $machine > 0){
			 //$this->db->where('name' ,  $machine);
			  $mcn_q .= ' and ( name   = '.$machine.' ) ';
			 }

			   $sql = 'SELECT * FROM analysis_machines WHERE ( mstate > 0 '.$mcn_q. $sup_q .$dp_q. $client_q.$period_q.'   ) ';
			  			 
             // $query =$this->db->query($sql); 
			 
			 
			 //$this->db->where('mstate >' , 0);
				 
		   //$this->db->order_by('mstate DESC, name ASC');
		   
		  $return_array =  array();  
		    
		  //$query = $this->db->get('analysis_machines'); 
		  $query =$this->db->query($sql); 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
				 
	 		     $client = array(  
			   'mid' => $this->encrypt->encode($row2-> id)  ,'name' => $row2-> name  ,'mod' =>  $row2-> model   ,'sn' => $row2-> sno 
                             ,'cou' => $row2-> country  ,'ms' => $row2-> mstate ,'yr' => $row2-> myr 
                             ,'sup' => $row2->suplier   ,'dep' => $row2->department ,'hf' => $row2->health_facility  , 'man'	 => $row2->maufacturer ,  'period'	 => $row2->period_done , 'comment'	 => $row2->comment
			 , 'installed' => $row2-> date_installed , 'price'	 => $row2->device_price , 'code'	 => $row2->device_code);
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
		 }
		
		//search machine by id
		
		//get machine basing on id
		 function Filter_machines_search($machine , $client   , $man , $sup , $state , $y1 , $y2 , $dtype){
			   $client_q  = '';
			 
			  if($client > 0){
				 
			  //$this->db->where('health_facility' , $client);
			    $client_q  .= ' and health_facility = '.$client.'';
			 }
			
			 
			
			$machine_q ='';
			 if(sizeof($machine) > 0){
				 $count  =0; 
				 
				 foreach($machine as $row){
					 if($row > 0){
					 if($count < 1){
					 
						  $machine_q .= ' name = '.$row.''; 
						 
					 }
					 else {
						  $machine_q .= ' or name = '.$row.''; 
						 
					 }
					 }
					 $count  +=1;
					 
				 }
				 
			 
			 } 
			  if( $machine_q != ''){
				 
				 $machine_q = ' and ('.$machine_q.')';
			 }
			 
			 
			 
			 
			 
			$man_q = ''; 
			   if(sizeof($man) > 0){
		       $count  =0;
				 foreach($man as $row){
					 if($row > 0){
					 if($count < 1){
						 $man_q .= '   maufacturer  = '.$row.'';
						 
						 
					 }
					 else {
						  $man_q .= ' or  maufacturer  = '.$row.'';
						 
					 }
					 $count  +=1;
					 
				 }
				 }
				 
			 }
			 
			  if( $man_q != ''){
				  
				 
				 $man_q = ' and ('.$man_q.')';
			 }
			 $sup_q   = '';
			 if($sup > 0){ 
			 $sup_q   =  '   and (suplier  = '.$sup.')';
			 }
			 $state_q  =  '';
			 
			  if($state > 0){ 
			 $state_q  =  '   and (mstate  = '.$state.')';
			 }
			 
			 $dtype_q = '';
			  if(sizeof($dtype )> 0){
			  $count  =0;
			
			 
				  foreach($dtype as $row){
					 if($row > 0){
					 if($count < 1){
						 $dtype_q .= ' department_type = '.$row.'';
					  
					 }
					 else {
						 $dtype_q .= ' or department_type = '.$row.'';
						 
						 
						 
					 }
					 $count  +=1;
					 
				 }
				 } 
			 
			 
			 } 
			 if($dtype_q != ''){
				 
				 $dtype_q = ' and ('.$dtype_q.')';
			 }
			 
			 
		 
		  $sql = 'SELECT * FROM analysis_machines WHERE ( mstate > 0 '.$client_q. $machine_q .$man_q. $sup_q.$state_q.$dtype_q.'   ) ';
              $query =$this->db->query($sql);
		   
		  $return_array =  array();  
		    
		  //$query = $this->db->get('analysis_machines'); 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
				 
	 		     $client = array(  
			   'mid' => $this->encrypt->encode($row2-> id)  ,'name' => $row2-> name  ,'mod' =>  $row2-> model   ,'sn' => $row2-> sno 
                             ,'cou' => $row2-> country  ,'ms' => $row2-> mstate ,'yr' => $row2-> myr 
                             ,'sup' => $row2->suplier   ,'dep' => $row2->department ,'hf' => $row2->health_facility  , 'man'	 => $row2->maufacturer ,  'period'	 => $row2->period_done , 'comment'	 => $row2->comment
			 , 'installed' => $row2-> date_installed , 'price'	 => $row2->device_price , 'code'	 => $row2->device_code , 'dtype'	 => $row2->department_type);
			   array_push($return_array , $client);
	
				 
				  }
			}
			return $return_array;
		 }
		
		
		function search_machine_suplier($string ,  $user){
			$return_array  = array();
			$queryv = array();
			if($user > 0){
			
			$queryv = $this->db->query("select  a.id as id , a.name ,  model , sno , country , mstate , myr, suplier , department , health_facility , maufacturer , comment from analysis_machines a , analysis_suplier_bank b  where  suplier = b.id and b.name like '%".$string."%' and health_facility=  ".$user."");
			 
			}
			else {
				$queryv = $this->db->query("select  a.id as id , a.name ,  model , sno , country , mstate , myr, suplier , department , health_facility , maufacturer , comment from analysis_machines a , analysis_suplier_bank b  where  suplier = b.id and b.name like '%".$string."%'");
			
				
			}
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				     $client  =  array('mid' =>  $row->id  ,'hf' =>  $row->health_facility,'cou' =>  $row->country,'ms' =>  $row->mstate  ,'yr' =>  $row->myr  ,'dep' =>  $row-> department , 'name'=>  $row->  name,  'mod'=>  $row->  model, 'sn'=>  $row->  sno , 'sup'=>  $row->  suplier , 'man'=>  $row->  maufacturer  ) ;
				 
				  array_push($return_array , $client);
				  }
			}
				  if(sizeof($return_array) > 0){
				return $this->unique_multidim_array($return_array, 'mid');
				  
			}
			else return  $return_array;
		}
		
		//search heelth facility from here
		
		function search_facility($string , $user){
			$return_array  = array();
			$return_array  = array();
			$queryv = array();
			if($user > 0){
			
			$queryv = $this->db->query("select  a.id as id , a.name ,  model , sno , country , mstate , myr, suplier , department , health_facility , maufacturer , comment from analysis_machines a , hospitals b  where  health_facility = b.id   and health_facility=  ".$user." and (b.name like '%".$string."%' or b.location like '%".$string."%'  ) ");
			}
			else {
				$queryv = $this->db->query("select  a.id as id , a.name ,  model , sno , country , mstate , myr, suplier , department , health_facility , maufacturer , comment from analysis_machines a , hospitals b  where  health_facility = b.id and (b.name like '%".$string."%' or b.location like '%".$string."%'  ) ");
			
			}
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				   $client  =  array('mid' =>  $row->id  ,'hf' =>  $row->health_facility,'cou' =>  $row->country,'ms' =>  $row->mstate  ,'yr' =>  $row->myr  ,'dep' =>  $row-> department , 'name'=>  $row->  name,  'mod'=>  $row->  model, 'sn'=>  $row->  sno , 'sup'=>  $row->  suplier , 'man'=>  $row->  maufacturer  ) ;
				 
				  array_push($return_array , $client);
				  }
			}
				 if(sizeof($return_array) > 0){
				return $this->unique_multidim_array($return_array, 'mid');
				  
			}
			else return  $return_array;
		}
		//get machine manufacturer
		
		function search_machine_manufacturer($string , $user){
			$return_array  = array();
			$queryv = array();
			if($user > 0){
			
			$queryv = $this->db->query("select  a.id as id , a.name ,  model , sno , country , mstate , myr, suplier , department , health_facility , maufacturer , comment from analysis_machines a , analysis_manufacturere_bank b  where  maufacturer = b.id and b.name like '%".$string."%'  and health_facility=  ".$user."");
			}
			else {
				$queryv = $this->db->query("select  a.id as id , a.name ,  model , sno , country , mstate , myr, suplier , department , health_facility , maufacturer , comment from analysis_machines a , analysis_manufacturere_bank b  where  maufacturer = b.id and b.name like '%".$string."%' ");
			
				
			}
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				   $client  =  array('mid' =>  $row->id  ,'hf' =>  $row->health_facility,'cou' =>  $row->country,'ms' =>  $row->mstate  ,'yr' =>  $row->myr  ,'dep' =>  $row-> department , 'name'=>  $row->  name,  'mod'=>  $row->  model, 'sn'=>  $row->  sno , 'sup'=>  $row->  suplier , 'man'=>  $row->  maufacturer  ) ;
				 
				  array_push($return_array , $client);
				  }
			}
				 if(sizeof($return_array) > 0){
					  
				return $this->unique_multidim_array($return_array, 'mid');
				  
			}
			else return  $return_array;
		}
		
		function pending_rates( $x , $measure , $users){
			$return_array  = array();
			
			$queryv = $this->db->query("select datediff(NOW() , date_shifted)  as shifted  , datediff(NOW() , date_reported)  as dif  , id   from machine_problems where worked_on =0");
            
 
			 
			if($queryv->num_rows()>0){//cl_status
			foreach ($queryv->result() as $row)
				  { 
				 $check_nos = $row->dif; //shifted
				 $shift_interval = $row->shifted;
				 //if ithe interval is exceeded and time ater last shifts are not geate than all active techs  can consider this job 
				  if($check_nos > $x    and ( $x >=  $shift_interval ) and   ($shift_interval <= $x* $users)  ){ 
					  $temp_array  = array( 'job' => $row->id ,'diff' => $row->dif,'shift' => $row->shifted   );
					  array_push($return_array , $temp_array);
					 
					 
				 }
				   }
			  }
			  
			  return  $return_array;
			  
		}
		
		function RealDateTime(){
			 date_default_timezone_set('Africa/Nairobi');
			   
			$pymen_dat=date('Y-m-d-H-i-s');
			return $pymen_dat;
			
		}
		
		function Form_back_up(){
			$this->load->dbutil();
			
			$prefs = array(
        'tables'        => array(),   // Array of tables to backup.
        'ignore'        => array(),                     // List of tables to omit from the backup
        'format'        => 'zip',                       // gzip, zip, txt
        'filename'      => 'database_backup.sql',              // File name - NEEDED ONLY WITH ZIP FILES
        'add_drop'      => TRUE,                        // Whether to add DROP TABLE statements to backup file
        'add_insert'    => TRUE,                        // Whether to add INSERT data to backup file
        'newline'       => "\n"                         // Newline character used in backup file
);

              $backup =   $this->dbutil->backup($prefs);
			  $fname ='Database_backup_'.$this->RealDateTime();
	          $this->load->helper('file');
              $this->load->library('zip'); 
              write_file('./db_back_ups/'.$fname.'.zip', $backup);  
	  
	  
		}
		
		//list file for back ups
		
		function List_file_backups(){
			  
        // Load the file helper and write the file to your server
         $this->load->helper('file');
         $this->load->library('zip');
         $this->load->helper('directory'); 
        return $map = directory_map('./db_back_ups/');
		
  
	  
		}
		
		// download 
		
		function Download_back_up($x){
		 
$this->load->helper('file');
$this->load->library('zip');
$this->load->helper('directory');
$this->load->helper('download'); 

force_download('/db_back_ups/'.$x); 
	  
	  
		}
		
		
		function back_up(){
			$this->load->dbutil();
			
			$prefs = array(
        'tables'        => array(),   // Array of tables to backup.
        'ignore'        => array(),                     // List of tables to omit from the backup
        'format'        => 'zip',                       // gzip, zip, txt
        'filename'      => 'mybackup.sql',              // File name - NEEDED ONLY WITH ZIP FILES
        'add_drop'      => TRUE,                        // Whether to add DROP TABLE statements to backup file
        'add_insert'    => TRUE,                        // Whether to add INSERT data to backup file
        'newline'       => "\n"                         // Newline character used in backup file
);

    $backup =   $this->dbutil->backup($prefs);
	  
	  
	  

// Backup your entire database and assign it to a variable
//$backup = $this->dbutil->backup();

// Load the file helper and write the file to your server
$this->load->helper('file');
$this->load->library('zip');
$this->load->helper('directory');
$this->load->helper('download');
write_file('./db_back_ups/mm.zip', $backup);

// Load the download helper and send the file to your desktop



  $map = directory_map('./db_back_ups/');
print_r($map);
 
exit();

// Alternately you can set preferences by calling the ``initialize()`` method. Useful if you auto-load the class:
$this->upload->initialize($config);

force_download('mybackup.gz', $backup); 
	  
	  
		}
		
		function optimize_db(){
			
			$result = $this->dbutil->optimize_database();

if ($result !== FALSE)
{
         
}
		}
		//upload machines from here
		
		  function All_Machines_in_catelogue($x , $st ){
		 
			$this->db->protect_identifiers('bio_catelogue');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('id' , $x) ; 
			}
		 
			$this->db->where('state' , $st) ;
			  
			$query = $this->db->get('bio_catelogue');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'name' => $row->machine_name  ,'sname' => $row->scie_name  ,'spec' => $row->specifications  ,'desc' => $row->descriptions  ,'price' => $row-> price , 'New' => $row->mark_as_new , 'discount' => $row-> discount, 'fet' => $row-> featured  , 'date' => $row-> date_entered, 'run' => $row-> run_up_to, 'cat' => $row-> machine_cat , 'pic' => $row->  picture  ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		//get item name from cateogue 
		
		function Item_name($x  ){
		 
			$this->db->protect_identifiers('bio_catelogue');
			 $return_array  =  array();
			
			$this->db->select('*');
			 
			  $this->db->where('id' , $x) ;  
			$query = $this->db->get('bio_catelogue');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $return_array  = array('id' =>$row->id ,'name' => ucfirst(strtolower($row->machine_name))  ,'sname' => ucfirst(strtolower($row->scie_name))  ,'spec' => ucfirst(strtolower($row->specifications))  ,'desc' => $row->descriptions  ,'price' => $row-> price , 'New' => $row->mark_as_new , 'discount' => $row-> discount, 'fet' => $row-> featured  , 'date' => $row-> date_entered, 'run' => $row-> run_up_to, 'cat' => $row-> machine_cat , 'pic' => $row->  picture  ); 
			 			 
				 // array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		
		function All_featured($x  ){
		 
			$this->db->protect_identifiers('bio_catelogue');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('id' , $x) ; 
			}
		 
			$this->db->where('featured' , 1) ;
			$this->db->where('state' , 1) ;
			  
			$query = $this->db->get('bio_catelogue');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'name' => $row->machine_name  ,'sname' => $row->scie_name  ,'spec' => $row->specifications  ,'desc' => $row->descriptions  ,'price' => $row-> price , 'New' => $row->mark_as_new , 'discount' => $row-> discount, 'fet' => $row-> featured  , 'date' => $row-> date_entered, 'run' => $row-> run_up_to, 'cat' => $row-> machine_cat , 'pic' => $row->  picture  ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		function All_recomended($x  ){
		 
			$this->db->protect_identifiers('bio_catelogue');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('id' , $x) ; 
			}
		 
			$this->db->where('recomended' , 0) ;
			$this->db->where('state' , 1) ;
			  
			$query = $this->db->get('bio_catelogue');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'name' => $row->machine_name  ,'sname' => $row->scie_name  ,'spec' => $row->specifications  ,'desc' => $row->descriptions  ,'price' => $row-> price , 'New' => $row->mark_as_new , 'discount' => $row-> discount, 'fet' => $row-> featured  , 'date' => $row-> date_entered, 'run' => $row-> run_up_to, 'cat' => $row-> machine_cat , 'pic' => $row->  picture  ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		//machine search
		
		function Online_search($x  ){
		 
			$this->db->protect_identifiers('bio_catelogue');
			 $return_array  =  array();
			
			$this->db->select('*');
			 
			  $this->db->like('machine_name' , $x) ; 
			   $this->db->or_like('scie_name' , $x) ;
			   $this->db->or_like('descriptions' , $x) ;
			 
		 
			$this->db->where('recomended' , 0) ;
			$this->db->where('state' , 1) ;
			  
			$query = $this->db->get('bio_catelogue');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'name' => $row->machine_name  ,'sname' => $row->scie_name  ,'spec' => $row->specifications  ,'desc' => $row->descriptions  ,'price' => $row-> price , 'New' => $row->mark_as_new , 'discount' => $row-> discount, 'fet' => $row-> featured  , 'date' => $row-> date_entered, 'run' => $row-> run_up_to, 'cat' => $row-> machine_cat , 'pic' => $row->  picture  ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			if(sizeof(  $return_array) > 0){
				return $this->unique_multidim_array( $return_array , 'id'); 
				
				
			}
			else return array();
				 
			
		}
		
		
		
		
		//All_Machines_cats($x , $st )
		
		//all machines by category
		function All_machines_by_cat($x ){
		 
			$this->db->protect_identifiers('bio_catelogue');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('machine_cat' , $x) ;
			}
		 
			
			$this->db->where('state' , 1) ;
			  
			$query = $this->db->get('bio_catelogue');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'name' => $row->machine_name  ,'sname' => $row->scie_name  ,'spec' => $row->specifications  ,'desc' => $row->descriptions  ,'price' => $row-> price , 'New' => $row->mark_as_new , 'discount' => $row-> discount, 'fet' => $row-> featured  , 'date' => $row-> date_entered, 'run' => $row-> run_up_to, 'cat' => $row-> machine_cat , 'pic' => $row->  picture  ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		function get_machine_in_cart($x ){
		 
			$this->db->protect_identifiers('bio_catelogue');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('id' , $x) ;
			}
		 
			
			//$this->db->where('state' , 1) ;
			  
			$query = $this->db->get('bio_catelogue');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'name' => $row->machine_name  ,'sname' => $row->scie_name  ,'spec' => $row->specifications  ,'desc' => $row->descriptions  ,'price' => $row-> price , 'New' => $row->mark_as_new , 'discount' => $row-> discount, 'fet' => $row-> featured  , 'date' => $row-> date_entered, 'run' => $row-> run_up_to, 'cat' => $row-> machine_cat , 'pic' => $row->  picture  ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		function All_Machines_cats($x , $st ){
		 
			$this->db->protect_identifiers('machine_types');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('id' , $x) ; 
			}
		 
			$this->db->where('state' , $st) ;
			  
			$query = $this->db->get('machine_types');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'name' =>  ucfirst($row->name)          ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		//sort the array //this will give u a user with  least no of jobs as a firt in arrasy
function columnSort($unsorted, $column) {
     
    $sorted = $unsorted;
    for ($i=0; $i < sizeof($sorted)-1; $i++) {
      for ($j=0; $j<sizeof($sorted)-1-$i; $j++)
        if ($sorted[$j][$column] > $sorted[$j+1][$column]) {
          $tmp = $sorted[$j];
          $sorted[$j] = $sorted[$j+1];
          $sorted[$j+1] = $tmp;
      }
    }
    return $sorted;
} 


	function sort_descending($unsorted, $column) {
    $sorted = $unsorted;
    for ($i=0; $i < sizeof($sorted)-1; $i++) {
      for ($j=0; $j<sizeof($sorted)-1-$i; $j++)
        if ($sorted[$j][$column] < $sorted[$j+1][$column]) {
          $tmp = $sorted[$j];
          $sorted[$j] = $sorted[$j+1];
          $sorted[$j+1] = $tmp;
      }
    }
    return $sorted;
}
		
		
		//sot in decsending order_by
		
		
		//all active jobs should be obtained from here boss
		
		  function No_pending_jobs($x , $y){
		 
			$this->db->protect_identifiers('machine_problems');
			 $return_array  =  array();
			
			$this->db->select('*');
			 
			$this->db->where('receiver_tech' , $x) ; 
			$this->db->where('worked_on' , $y) ;
			  
			$query = $this->db->get('machine_problems');
			 
			return $query->num_rows();
				 
			
		}
		  function All_techs($x ){
		 
			$this->db->protect_identifiers('system_users');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('id' , $x) ; 
			}
			$this->db->where('hospital_no' , '*') ; 
			$this->db->where('state' , 1) ;
			  
			$query = $this->db->get('system_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'fname' => $row->full_name  ,'lname' => $row->last_name  ,'email' => $row->email  ,'fon' => $row->phone_no  , 'jobs_pending' => $this-> No_pending_jobs($row->id , 0)    ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		function All_Normal_users($x ){
		 
			$this->db->protect_identifiers('system_users');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('id' , $x) ; 
			}
			$this->db->where('hospital_no !=' , '*') ; 
			$this->db->where('state' , 1) ;
			  
			$query = $this->db->get('system_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'fname' => $row->full_name  ,'lname' => $row->last_name  ,'email' => $row->email  ,'fon' => $row->phone_no  , 'jobs_pending' => $this-> No_pending_jobs($row->id , 0)    ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		
		function Tech_name($x ){
		 
			$this->db->protect_identifiers('system_users');
			 $return_array  =  array();
			
			$this->db->select('*');
			if($x > 0){
			  $this->db->where('id' , $x) ; 
			}
			  
			$query = $this->db->get('system_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $temp_array  = array('id' =>$row->id ,'fname' => $row->full_name  ,'lname' => $row->last_name  ,'email' => $row->email  ,'fon' => $row->phone_no      ); 
			 			 
				  array_push($return_array , $temp_array);
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
		
		//sum of acive
		 
		
		
	 function Get_user_profile_info($x ){
		 
			$this->db->protect_identifiers('system_users');
			 $return_array  =  array();
			
			$this->db->select('*');
			  
			  $this->db->where('id' , trim($x)) ; 
			  $this->db->limit(1);
			 
			
			$query = $this->db->get('system_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  //$datai = array(  'full_name' => $x[0] ,  'last_name'=> $x[1] ,  'email'=> $x[2],  'phone_no'=> $x[3] ,  'password'  => $hashed_password , '	uname'  => strtolower($x[4]),  'state'  => 2)   ;
	
				  
				  
				  $return_array  = array('id' =>$row->id ,'fname' => $row->full_name  ,'lname' => $row->last_name  ,'email' => $row->email  ,'fon' => $row->phone_no  ,'hosp' =>$row-> hospital_no   ); 
				 // array_push($return_array , $client); 			 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
				 
			
		}
	 
	 
	 //chek for validity of the user name
	 
	 
	 function validate_user_name($x){ //from the database 
			$return_array = array();
			 
			  $this->db->select('*');
			  $this->db->where('uname' , $x);
			   $query = $this->db->get('system_users');
			 
			 return $query->num_rows();
			  
			  
		}
		
	
	
	
	//////////////////////////////////////////////////////////////
	
	
	//update my manager's  accout from here 
	
	function update_manager_account($x , $id){
		$datai  = array( 'state' => $x   ); 
		  
	 $this->db->where('id' , $id);
	 $this->db->update('pi_event_managers' , $datai);
		 
		 
	 }
	//update mny event type from the database 
	
	function updateEventType($x){
		$datai  = array( 'name' => $x[0]  ,'description' => $x[1]    ); 
		  
	 $this->db->where('id' , $x[2]);
	 $this->db->update('pi_event_types' , $datai);
		 
		 
	 }
	//load all the eent types
	function All_Event_Type(){
			$this->db->protect_identifiers('pi_event_types');
			 $return_array  =  array();
			
			$this->db->select('*');
			
			 
			
			$query = $this->db->get('pi_event_types');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
				  $client  = array('id' =>$row->id ,'name' => $row->name  ,'descripn' => $row->description   ); 
				  array_push($return_array , $client); 			 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
	//check on the event type from the database
	function check_Event_Type($x){
			$this->db->protect_identifiers('pi_event_types');
			 $return_array  =  array();
			
			$this->db->select('id , name');
			$this->db->where('name' , trim($x[0]) ) ; 
			 
			
			$query = $this->db->get('pi_event_types');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $return_array  = array('id' =>$row->id ,'name' => $row->name  ,'descripn' => $row->description   );				 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
		
		//specific event
		
		function check_S_Event_Type($x){
			$this->db->protect_identifiers('pi_event_types');
			 $return_array  =  array();
			
			$this->db->select('*');
			$this->db->where('id' , trim($x[0]) ) ; 
			 
			
			$query = $this->db->get('pi_event_types');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $client  =  array('id' =>$row->id ,'name' => $row->name  ,'descripn' => $row->description   );
 
				  array_push($return_array , $client);				
				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
		//add event type to the database 
		
		function Add_Ticket_Type_to_db($x){ // adds a manager to the databse
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_event_types');
	 		  
			 
			  $datai = array(  'name' => trim($x[0]) ,  'description' => trim($x[1])   );
	
				 $this->db->insert('pi_event_types', $datai) ;
				 
			
		}
		
		
	//load events tichets
	
	function My_pi_events_tickets($id){
			$this->db->protect_identifiers('event_tickets`');
			 $return_array  =  array();
			
			$this->db->select('*');
			$this->db->where('event_id' , $id);

			 
			
			$query = $this->db->get('event_tickets`');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('TId'  => $row->id ,'name'  =>  $row->psudo_name,'nos'  =>  $row->no_available ,'price'  =>  $row->price ,'type'  =>  $row->type  );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
	}
	
	//load my events from the database
			function My_pi_events($id){
			$this->db->protect_identifiers('pi_events');
			 $return_array  =  array();
			
			$this->db->select('*');
			$this->db->where('organizer' , $id);

			 
			
			$query = $this->db->get('pi_events');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('EId'  => $row->id ,'name'  =>  $row->name,'locn'  =>  $row->location ,'poster'  =>  $row->poster ,'start'  =>  $row->start_time,'end'  =>  $row->end_time ,'type'  =>  $row->Type  );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
	}
	
	//events should be loaded from the database
	function My_pi_events_all(){
			$this->db->protect_identifiers('pi_events');
			 $return_array  =  array();
			
			$this->db->select('*');
			//$this->db->where('organizer' , $id);

			 
			
			$query = $this->db->get('pi_events');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('EId'  => $row->id ,'name'  =>  $row->name,'locn'  =>  $row->location ,'poster'  =>  $row->poster ,'start'  =>  $row->start_time,'end'  =>  $row->end_time ,'type'  =>  $row->Type , 'orgn' =>  $row->organizer  );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
	}
	
	
	
	function My_pi_events_specific($id){
			$this->db->protect_identifiers('pi_events');
			 $return_array  =  array();
			
			$this->db->select('*');
			 $this->db->where('id' , $id);
			 $this->db->limit(1);

			 
			
			$query = $this->db->get('pi_events');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('EId'  => $row->id ,'name'  =>  $row->name,'locn'  =>  $row->location ,'poster'  =>  $row->poster ,'period'  =>  $row->period,'long'  =>  $row->langtude,'lat'  =>  $row->latitude ,'start'  =>  $row->start_time,'end'  =>  $row->end_time ,'type'  =>  $row->Type , 'orgn' =>  $row->organizer  );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
	}
	
	
	function My_pi_events_pending(){
			$this->db->protect_identifiers('pi_events');
			 $return_array  =  array();
			
			$this->db->select('*');
			 $this->db->where('state' , 0);
			 // $this->db->where('state' , 1);
			  //$this->db->where('state' , 2);

			 
			
			$query = $this->db->get('pi_events');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('EId'  => $row->id ,'name'  =>  $row->name,'locn'  =>  $row->location ,'poster'  =>  $row->poster ,'start'  =>  $row->start_time,'end'  =>  $row->end_time ,'type'  =>  $row->Type , 'orgn' =>  $row->organizer  );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
	}
	
	//pospone an event 
	
	function My_pi_events_pospone(){
			$this->db->protect_identifiers('pi_events');
			 $return_array  =  array();
			
			$this->db->select('*');
			 $this->db->where('state' , 1);
			 // $this->db->where('state' , 1);
			  //$this->db->where('state' , 2);

			 
			
			$query = $this->db->get('pi_events');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('EId'  => $row->id ,'name'  =>  $row->name,'locn'  =>  $row->location ,'poster'  =>  $row->poster ,'start'  =>  $row->start_time,'end'  =>  $row->end_time ,'type'  =>  $row->Type , 'orgn' =>  $row->organizer  );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
	}
	
	
	
	function updatePoster($p , $id){
		 $datai  = array(  'poster'  =>$p  );
	 $this->db->where('id' , $id);
	 $this->db->update('pi_events' , $datai);
		 
		 
	 }
	 
	 function update_comp_logo($p , $id){
		 $datai  = array(  'logo_id'  =>$p  );
	 $this->db->where('id' , $id);
	 $this->db->update('pi_event_managers' , $datai);
		 
		 
	 }
	 
	 
	 function Activate_events($p , $id){ //st 
		 $datai  = array(  'state'  =>$p  );
	 $this->db->where('id' , $id);
	 $this->db->update('pi_events' , $datai);
		 
		 
	 }
	 
	 function Update_events_detailz($p , $d){ //st 
	  
		 $datai  = array(  'name'  =>$d[0] , 'location'  =>$d[1] , 'langtude'  =>$d[2] , 'latitude'  =>$d[3] , 'period'  =>$d[4] , 'start_time'  =>$d[5] , 'end_time'  =>$d[6] , 'Type'  =>$d[7] , 'organizer'  =>$d[8]   );
	 $this->db->where('id' , $p);
	 $this->db->update('pi_events' , $datai);
		 
		 
	 }
	 
	 
	
	//add events to the system
		function Add_new_event($x , $y){ // adds a manager to the databse
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_events');
	 		  //	 
	//pi_1.push(evn , ven , evt , prd , t1 , t2 , vip , vipa , gtano  ,  vvipa , vvipano ,  cop , copa , copano);
	//pi_1.push(evn , ven , evt , prd , t1 , t2 , gt, gta , gtano , vip , vipa , vipati  ,  vvip ,  vvipa , vvipano ,  cop , copa , copano);
			 
			  $datai = array(  'name' => trim($x[0]) ,  'location' => trim($x[1]),  'Type' => trim($x[2]),  'period' => trim($x[3]),  'start_time' => trim($x[4]),  'end_time' => trim($x[5])  , 'organizer' => $y   );
	
				 $this->db->insert('pi_events', $datai) ;
				 
				  $data_id =  $this->Maxid();
				 //echo 'max id from the databse'.$data_id;
				
				 $datai = array(  'type' => trim($x[0]) ,  'price' => trim($x[1]),  'no_available' => trim($x[2]),  'psudo_name' => trim($x[2]) );
				 if($x[8] > 0){
					 $datai = array(  'type' => 1 ,  'price' => trim($x[7]),  'no_available' => trim($x[8]),  'psudo_name' => trim($x[6]) , 'event_id' => $data_id  );
					 $this->db->insert('event_tickets', $datai) ;
					 
					 
				 }
				 if($x[11] > 0){
					 
					 $datai = array(  'type' => 2 ,  'price' => trim($x[9]),  'no_available' => trim($x[11]),  'psudo_name' => trim($x[10]) , 'event_id' => $data_id  );
					 $this->db->insert('event_tickets', $datai) ;
					 
					 
				 }
				 if($x[14] > 0){
					 $datai = array(  'type' => 3 ,  'price' => trim($x[12]),  'no_available' => trim($x[14]),  'psudo_name' => trim($x[13]) , 'event_id' => $data_id  );
					 $this->db->insert('event_tickets', $datai) ;
					 
					 
				 }
				 
				  if($x[17] > 0){
					  $datai = array(  'type' => 4 ,  'price' => trim($x[15]),  'no_available' => trim($x[17]),  'psudo_name' => trim($x[16]) , 'event_id' => $data_id  );
					 $this->db->insert('event_tickets', $datai) ;
					 
					 
				 }
				 
				 
			
		}
		//load events for photo entry
		
		function E_missing_photos(){
			$this->db->protect_identifiers('pi_events');
			 $return_array  =  array();
			
			$this->db->select('*');
			$this->db->where('poster' , '');

			 
			
			$query = $this->db->get('pi_events');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('EId'  => $row->id ,'name'  =>  $row->name,'locn'  =>  $row->location  );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
	}
	//load all the event types from the database
	
	function Load_Event_types(){
			$this->db->protect_identifiers('pi_event_types');
			 $return_array  =  array();
			
			$this->db->select('*');

			 
			
			$query = $this->db->get('pi_event_types');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('EId'  => $row->id ,'name'  =>  $row->name  );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
	}
			
			
		
	//loa all thitickets available
	
	function Load_tickets(){
			$this->db->protect_identifiers('ticket_types');
			 $return_array  =  array();
			
			$this->db->select('*');

			 
			
			$query = $this->db->get('ticket_types');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $pushdata  =  array('tId'  => $row->id ,'tname'  =>  $row->ticket_name ,'tdsc'  =>  $row->description );
                array_push($return_array , $pushdata);				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
		
		//determine the event id in the database
		function Max_venue_id(){
			$this->db->protect_identifiers('pi_events_venues');
			 $return_array  =  0;
			$this->db->select_max('e_id', 'maxid');
             $query = $this->db->get('pi_events_venues'); //  
			 
			 if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $return_array  =  $row->maxid;
				   				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
		}
		
		//validate the events before being added to the database
		
		
		function Check_my_venue($name, $desc){
			$this->db->protect_identifiers('pi_events_venues');
			 $return_array  =  0;
			$this->db->select('e_id');
			$this->db->where('e_name' , $name);
			$this->db->where('e_venue_desc' , $desc);
             $query = $this->db->get('pi_events_venues'); //  
			 
			  
			 return $query->num_rows();
		}
		//event id load from the database
		
		function Maxid(){
			$this->db->protect_identifiers('pi_events');
			 $return_array  =  0;
			$this->db->select_max('id', 'maxid');
             $query = $this->db->get('pi_events'); // Produces: SELECT MAX(age) as member_age FROM members

			 
			
			 
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $return_array  =  $row->maxid;
				   				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
	
	
	//add a new tickrt to the databse
	
		function Add_Ticket_to_db($x){ // adds a manager to the databse
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('Ticket_types');
	 		  
			 
			  $datai = array(  'ticket_name' => trim($x[0]) ,  'description' => trim($x[1])   );
	
				 $this->db->insert('Ticket_types', $datai) ;
				 
			
		} 
		
		//insert data in the venues
		
		function Add_Venue_to_db($x){ // adds a manager to the databse
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_events_venues');
	 		  
			 
			  $datai = array(  'e_name' => $x[0] ,  'e_venue_desc' => $x[1] ,    'v_contact' => $x[2] ,  'v_email' => $x[3] , 'v_physical_address' => $x[4] ,     'v_longtude' => $x[5] ,  'v_latitude' => $x[6] ,     'state' => 1  , 'e_poster' => $x[7]      );
			  //$array_venue = array($event_name , $event_desc , $event_fon , $event_email , $event_physical , $event_long , $event_lat , $fname );
			 
	
				 $this->db->insert('pi_events_venues', $datai) ;
				 
			
		} 
	
	//get information availabel about a given events manager 
	
	function Load_manager($x){ 
         $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_event_managers');
			   
			    $this->db->select('*');
		   
		  
		   $this->db->where('id' , $x);//
		   
		    
		  $query = $this->db->get('pi_event_managers');
		 // $query = $this->db->get('pi_companies');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
	 		  
			 
			  $return_array = array(  'fname' => $row2-> fname ,  'lname'=> $row2-> lname ,  'em'=>  $row2-> email,  'sex'=> $row2-> gender , 'code'  =>  $row2-> country  , 'fon'  => $row2->Phone_number    ,   'comp'  =>  $row2-> company  ,   'compd'  =>  $row2-> company_description ,   'poster'  =>  $row2-> logo_id   );
	
				// $this->db->insert('pi_event_managers', $datai) ;
				  }
			}
			return $return_array;
				 
			
		}
	
	//now let us add a new copany and its details to the databse
	
	function Add_company_to_db($x){  
	//PROTECT THE IDENTIFIRES
	
	     $this->db->protect_identifiers('pi_companies');
			 
			  $datai = array(  'name' => $this->db->escape($x[0]) ,  'description'=> $this->db->escape($x[1]) ,  'logo'=> $this->db->escape_str($x[2]),  'website'=> $this->db->escape_str($x[3]) , 'mob_money'  => $x[4]   );
	
				 $this->db->insert('pi_companies', $datai) ;
				 
			
		} 
		//select the maximum id no to give a diff no to the databse selected
		
		//$this->db->select_max('age');
		//avoid double entry
		
		function get_existing_company($name , $mob){
			$this->db->protect_identifiers('pi_companies');
			$return_array = 0;
			 
			  $this->db->select('id');
			   $this->db->where( 'mob_money' , $mob);//name
			   $this->db->or_where( 'name' , $name);
			    
			   
			  
			$query = $this->db->get('pi_companies');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $return_array  =  $row->id ;				 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			  
			  
		}
		
		//checck for te validity of the names put in the database
		function check_ticket($x){
			$this->db->protect_identifiers('ticket_types');
			 $return_array  =  array();
			
			$this->db->select('id');
			$this->db->where('ticket_name' , trim($x[0]) ) ; 
			 
			
			$query = $this->db->get('ticket_types');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $return_array  =  array(1);				 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			
			
			
		}
		//chekk admin from the datase
		
		function get_adminc($x){ //from the database
			$return_array = array();
			 
			  $this->db->select('*');
			  $this->db->where('id' , $x);
			    
			   
			  
			$query = $this->db->get('pi_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $return_array  =  array('fnam'=> $row->fname ,'snam'=> $row->sname ,'unam'=> $row->user_name  );				 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			  
			  
		}function get_admin($x){ //from the database
			$return_array = array();
			 
			  $this->db->select('*');
			  $this->db->where('id' , $x);
			    
			   
			  
			$query = $this->db->get('pi_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $return_array  =  array('fnam'=> $row->fname ,'snam'=> $row->sname ,'unam'=> $row->user_name  );				 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			  
			  
		}
		
		
		//please update the admin profile information from here 
		
		function Update_admin( $id , $x){ //from the database
			$return_array = array();
			 
			  $this->db->select('*');
			  $this->db->where('id' , $id);
			   $this->db->limit(1);
			    
			   
			  
			$query = $this->db->get('pi_users');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $hashed_password = password_hash($this->db->escape(strtolower($x[2])), PASSWORD_DEFAULT);
				  
				  $return_array  =  array('fname'=> $x[0] ,'sname'=> $x[1] ,'password'=>  $hashed_password)  ;	
				  $this->db->where('id' , $id);
				  $this->db->update('pi_users' , $return_array);
				  
				  
                //$return_array  =  array('fnam'=> $row->fname ,'snam'=> $row->sname ,'unam'=> $row->user_name  );				 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			  
			  
		}
		
		//update manager's password information from here 
		
		
		function Update_manager_password( $id , $x){ //from the database
			$return_array = array();
			 
			  $this->db->select('*');
			  $this->db->where('id' , $id);
			   $this->db->limit(1);
			    
			   
			  
			$query = $this->db->get('pi_event_managers');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $hashed_password = password_hash($this->db->escape(strtolower($x)), PASSWORD_DEFAULT);
				  
				  $return_array  =  array( 'password'=>  $hashed_password)  ;	
				  $this->db->where('id' , $id);
				  $this->db->update('pi_event_managers' , $return_array);
				  $return_array = array(1);
				  
				   }
			   
				 
			}
			 return $return_array;
			  
			  
		}
		
		function get_max_age(){
			$return_array = 1;
			 
			  $this->db->select_max('id' , 'maxid');
			    
			   
			  
			$query = $this->db->get('pi_companies');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  
				  
                $return_array  =  $row->maxid + 1;				 
				  
				  
				   }
			   
				 
			}
			 return $return_array;
			  
			  
		}
		
		//now get maximum id from the event at hand
		
		
		function Max_manager_id(){
			$this->db->protect_identifiers('pi_event_managers');
			 $return_array  =  0;
			$this->db->select_max('id', 'maxid');
             $query = $this->db->get('pi_event_managers'); //  
			 
			 if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $return_array  =  $row->maxid;
				   				
				  
				  
				   }
			   
				 
			}
			 return $return_array;
		}
		
		//update my events from the database
		function Agent_update_db($x , $id){ // adds a manager to the databse
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_event_managers');
			   //pi_1.push(fn , sn , em ,  code , fon  ,  comp ,  compd  );
			    
	 		  
			 //add //company_description//logo_id
			  $datai = array(  'fname' => $x[0] ,  'lname'=> $x[1] ,  'email'=> $x[2],    'country'  => $x[3]  , 'Phone_number'  => $x[4] , 'company'  => trim($x[5]), 'company_description'  => trim($x[6]))   ;
	
				 $this->db->where('id' , $id);
				 $this->db->update('pi_event_managers', $datai) ;
				 
			
		} 
		
	 
	function Add_agent_to_db($x){ // adds a manager to the databse
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_event_managers');
			   
			    $hashed_password = password_hash($this->db->escape(strtolower($x[6])), PASSWORD_DEFAULT);
	 		  
			 //add //company_description//logo_id
			  $datai = array(  'fname' => $x[0] ,  'lname'=> $x[1] ,  'email'=> $x[2],  'gender'=> $x[3] , 'country'  => $x[4]  , 'Phone_number'  => $x[5]  , 'password'  => $hashed_password , 'username'  => strtolower($x[7]), 'company'  => trim($x[8]), 'company_description'  => trim($x[9]))   ;
	
				 $this->db->insert('pi_event_managers', $datai) ;
				 
			
		} 
		
		//get event companies
		
		function Load_manager_comp_data(){ 
         $return_array = array(); //will take on the data about a given agent 	
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_event_managers');
			   
			    $this->db->select('*');
		   
		  
		   //$this->db->where('id' , $x);//
		   
		    
		  $query = $this->db->get('pi_event_managers');
		 // $query = $this->db->get('pi_companies');
			 
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row2)
				  { 
				  //echo $row2-> company;
				  
				   $this->db->select('*');
		           $this->db->where('id' , $row2-> company); 
		           $queryc = $this->db->get('pi_companies'); 
				    
				     
					  
					  if($queryc->num_rows()>0){//cl_status
			foreach ($queryc->result() as $rowc)
				  { 
				  $client = array(  'name' => $rowc-> name ,  'description'=> $rowc-> description ,  'log'=>  $rowc-> logo  ,  'comp'=>  $row2-> company ,  'manager'=>  $row2-> id   );
				  
				  array_push($return_array , $client);
				 
				 }
	 		   
				 }
			}
			return $return_array;
				 
			
		}
		}	

//load all my event cwnues from the dataase


function Load_venues(){ // adds a manager to the databse
$return_array = array( );
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_events_venues');
			   $this->db->select('*');
			   
			    $queryc = $this->db->get('pi_events_venues'); 
				    
				     
					  
					  if($queryc->num_rows()>0){//cl_status
			foreach ($queryc->result() as $rowc)
				  { 
				  $client = array(  'id' => $rowc-> e_id ,'e_name' => $rowc-> e_name ,  'e_venued'=> $rowc-> e_venue_desc ,  'fon'=>  $rowc-> v_contact  ,  'email'=>  $rowc-> v_email ,  'physical'=>  $rowc-> v_physical_address ,  'long'=>  $rowc-> v_longtude ,  'lat'=>  $rowc-> v_latitude ,  'estate'=>  $rowc-> state ,  'poster'=>  $rowc-> e_poster   );
				  
				  array_push($return_array , $client);
				 
				 }
	 		   
				 }
				 
				 return  $return_array; 
			   
	 		  
			   	 
			
		}
//load allmy event managers from the databse

function Load_managers(){ // adds a manager to the databse
$return_array = array( );
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_event_managers');
			   $this->db->select('*');
			   
			    $queryc = $this->db->get('pi_event_managers'); 
				    
				     
					  
					  if($queryc->num_rows()>0){//cl_status
			foreach ($queryc->result() as $rowc)
				  { 
				  //load may data from here
				   
				  $client = array(  'id' => $rowc-> id ,'f_name' => $rowc-> fname ,'l_name' => $rowc-> lname ,'c_name' => $rowc-> company ,  'comp_desc'=> $rowc-> company_description ,  'fon'=>  $rowc-> Phone_number  ,  'email'=>  $rowc-> email ,  'code'=>  $rowc-> country ,   'poster'=>  $rowc-> logo_id ,   'state'=>  $rowc-> state   );
				  
				  array_push($return_array , $client);
				 
				 }
	 		   
				 }
				 
				 return  $return_array; 
			   
	 		  
			   	 
			
		}			
//get the missing photos from the databse

function Load_managers_missing_logos(){ // adds a manager to the databse
$return_array = array( );
	//PROTECT TABLE FIELDS
	           $this->db->protect_identifiers('pi_events_venues');
			   $this->db->select('*');
			   $this->db->where('logo_id' , '');
			   
			    $queryc = $this->db->get('pi_events_venues'); 
				    
				     
					  
					  if($queryc->num_rows()>0){//cl_status
			foreach ($queryc->result() as $rowc)
				  { 
				  //load may data from here
				   //$return_array = array(  'fname' => $row2-> fname ,  'lname'=> $row2-> lname ,  'em'=>  $row2-> email,  'sex'=> $row2-> gender , 'code'  =>  $row2-> country  , 'fon'  => $row2->Phone_number    ,   'comp'  =>  $row2-> company   );
	
			
				  $client = array(  'id' => $rowc-> e_id ,'c_name' => $rowc-> company ,  'comp_desc'=> $rowc-> company_description ,  'fon'=>  $rowc-> Phone_number  ,  'email'=>  $rowc-> email ,  'code'=>  $rowc-> country ,   'poster'=>  $rowc-> logo_id   );
				  
				  array_push($return_array , $client);
				 
				 }
	 		   
				 }
				 
				 return  $return_array; 
			   
	 		  
			   	 
			
		}			

function Load_Admin_alerts_active(){  
$return_array = array( );
	 
	           $this->db->protect_identifiers('pi_events_venues');
			   $this->db->select('*');
			    $this->db->where('state' , 1);
			   
			    $queryc = $this->db->get('pi_events'); 
				
				return  $queryc->num_rows(); 
			   
	     }

function Load_Admin_alerts_pending(){  
$return_array = array( );
	 
	           $this->db->protect_identifiers('pi_events_venues');
			   $this->db->select('*');
			    $this->db->where('state' , 0);
			   
			    $queryc = $this->db->get('pi_events'); 
				
				return  $queryc->num_rows(); 
			   
	     }

function Load_Admin_alerts_done(){  
$return_array = array( );
	 
	           $this->db->protect_identifiers('pi_events_venues');
			   $this->db->select('*');
			    $this->db->where('state' , 3);
				 $this->db->or_where('state' , 2);
			   
			    $queryc = $this->db->get('pi_events'); 
				
				return  $queryc->num_rows(); 
			   
	     }			 
				
		
		
		
		
	
	function LoadCompanies(){
		 $return_array =array();
		 
		 $this->db->select('*');
		 $this->db->protect_identifiers('pi_companies');
		 
		 
		 
		 $query = $this->db->get('pi_companies');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {   
				  
				  $client  = array('id' =>$row->id ,'c_name' => $row->name  ,'descripn' => $row->description ,'logo' => $row->logo ,'web' => $row->website ,'mob' => $row->mob_money,'state' => $row->status  ); 
				  array_push($return_array , $client); 
				  
				   }
				
				return $return_array;
				
			}
		 
		 
	 }
	 //get specific comapy
	 
	 function specific_Companies($x){
		 $return_array =array();
		 
		 $this->db->select('*');
		 $this->db->protect_identifiers('pi_companies');
		 $this->db->where( 'id' , $x);
		 $this->db->limit( 1);
		 
		 
		 
		 $query = $this->db->get('pi_companies');
		 if(!$query){
			 exit($this->db->error());
			 
			 
		 }
		 
			 
			if($query->num_rows()>0){
				  foreach ($query->result() as $row)
				  {   
				  
				  $return_array = array('id' =>$row->id ,'c_name' => $row->name  ,'descripn' => $row->description ,'logo' => $row->logo ,'web' => $row->website ,'mob' => $row->mob_money,'state' => $row->status  ); 
				  //array_push($return_array , $client); 
				  
				   }
				
				return $return_array;
				
			}
		 
		 
	 }
	 
	 //catelogue maximun rows
	 
	 function Add_order_line($x){ // 
                
				
				 $datai = array(         'customer'	 => $x[0] ,   'additional_info' => $x[1] , 'state' => $x[2]  , 'order_type' => $x[3] , 'order_date'	 => bio_time()  );
				 
	
				 $this->db->insert('bio_orders', $datai);
				 
			}
			
			 function Add_order_items($x){ // 
                
				
				 $datai = array( 'order_id'	 => $x[0] ,   'item_id' => $x[1] , 'unit_price' => $x[2]  , 'discount' => $x[3]  , 'quantity'=> $x[4]   );
				 
	
				 $this->db->insert('order_items', $datai);
				 
			}
	 
	 function Maxid_order(){
			$this->db->protect_identifiers('bio_orders');
			 $return_array  =  0;
			$this->db->select_max('id', 'maxid');
             $query = $this->db->get('bio_orders'); // Produces: SELECT MAX(age) as member_age FROM members

			  
			if($query->num_rows()>0){//cl_status
			foreach ($query->result() as $row)
				  { 
				  $return_array  =  $row->maxid;
				   }
			     
			}
			 return $return_array;
			
			
			
		}
		
		 function Orders( $s , $t){
			$this->db->protect_identifiers('bio_orders');
			 $return_array  =  0;
			  
			  if($s > 0){
			$this->db->where('state', $s);
			 }
			  if($t > 0){
			$this->db->where('order_type', $t);
			 }
             $query = $this->db->get('bio_orders'); // Produces: SELECT MAX(age) as member_age FROM members

			 return  $query->num_rows(); 
			 
			
			
		}
		
			 function Cat_summaries( $s , $f , $r){
			$this->db->protect_identifiers('bio_orders');
			 $return_array  =  0;
			  
			  if($s > 0){
			$this->db->where('state', $s);
			 }
			  if($f > 0){
			$this->db->where('featured', $f);
			 }
			  if($r > 0){
			$this->db->where('recomended', $r);
			 }
             $query = $this->db->get('bio_catelogue'); // Produces: SELECT MAX(age) as member_age FROM members

			 return  $query->num_rows(); 
			 
			
			
		}
		
		//get order ites from the dtabase
		function Load_orders($id , $cus,  $s){
		 $return_array =array();
		 
		 $this->db->select('*'); 
		 if($id > 0 ){
			  $this->db->where('id' ,$id );
			 
		 }//customer
		 if($cus > 0 ){
		 $this->db->where('customer' ,$cus );
		 }
		 
		 if($s >=0){
		 
		 $this->db->where('state' ,$s ); 
		 }		 
		 $this->db->order_by('order_date DESC');//date_loged
		  $queryc = $this->db->get('bio_orders'); 
				    
				     
					  
					  if($queryc->num_rows()>0){//cl_status
			foreach ($queryc->result() as $rowc)
				  { 
				  //load may data from here
				   
				  $client = array(  'id' => $rowc-> id ,'cust' => $rowc-> customer ,'dt' => $rowc-> order_date ,'info' => $rowc-> additional_info ,  'type'=> $rowc-> order_type ,  'state'=>  $rowc->state         );
				  
				  array_push($return_array , $client);
				 
				 }
	 		   
				 }
				 
				 return  $return_array; 
		}
		//get orser items 
		
		function Load_orders_items($id , $or,  $it){
		 $return_array =array();
		 
		 $this->db->select('*'); 
		 if($id > 0 ){
			  $this->db->where('id' ,$id );
			 
		 }//customer
		 if($or > 0 ){
		 $this->db->where('order_id' ,$or );
		 }
		 
		 if($it >0){
		 
		 $this->db->where('item_id' ,$it ); 
		 }		 
		 $this->db->order_by('id DESC');//date_loged
		  $queryc = $this->db->get('order_items'); 
				    
				     
					  
					  if($queryc->num_rows()>0){//cl_status
			foreach ($queryc->result() as $rowc)
				  { 
				  //load may data from here
				   
				  $client = array(  'id' => $rowc-> id ,'order' => $rowc->order_id ,'item' => $rowc->item_id ,'price' => $rowc-> unit_price ,'disc' => $rowc-> discount ,  'qty'=> $rowc-> quantity ,  'state'=>  $rowc->state         );
				  
				  array_push($return_array , $client);
				 
				 }
	 		   
				 }
				 
				 return  $return_array; 
		}
		 
		 
		//
	
}
?>