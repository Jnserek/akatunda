<?php

class Upload extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
        }

        public function index()
        {
			 if(LoadValid() ){
			$data['base']       = $this->config->item('base_url');
			$data['error']       =  array('error' => '');
                $this->load->view('upload_form',   $data);
				 }else redirect('Error', 'refresh');
        }

        public function do_upload()
        {
			IF(ISSET($_POST['cat'])){
			    $cat  = $_POST['cat'];
			    $this->load->library('csvimport'); 
               $data['base']       = $this->config->item('base_url');
			    $config['upload_path']          = './machines/';
                $config['allowed_types']        = 'csv';
                $config['max_size']             = 4000; 

                $this->load->library('upload', $config);
					$data['base']       = $this->config->item('base_url');
			         $data['error']         =  array('error' => '');
               

                if ( ! $this->upload->do_upload('userfile'))
                {
                       $data['error']       =  array('error' => $this->upload->display_errors());

                        $this->load->view('upload_form',   $data);
                }
                else
                {
				 
				$this->load->library('upload');
				 $file_data = $this->upload->data();
                $file_path =  './machines/'.$file_data['file_name'];
				$csv_array = $this->csvimport->get_array($file_path)	; 
           		$succes = 0;
                $fail = 0;				
            if ($this->csvimport->get_array($file_path)) {
				
                $csv_array = $this->csvimport->get_array($file_path);
                foreach ($csv_array as $row) {
					 
                   $insert_data = array(//database>>field name
                        'machine_name'=>$row['MachineName'],
                        'scie_name'=>$row['ScientificName'],
						'specifications'=>$row['Specifications'],
                        'descriptions'=> $row['Description'],
                        'price'=>  (int)$row['Price'],
						'machine_cat'=> (int) $cat,
						'discount'=> (int) $row['Discount'] 
                    );
					
					 
                     $this->bio->Add_new_cat_excell($insert_data);
					 $succes += 1; 
					 
                }
              
             
                 
            }

                	 

                 $upload_status = 'success uploads  >>'.$succes . ' failed uploads >>'  .$fail;
                 $this->session->set_flashdata('success', $upload_status );
                          redirect('Upload/');
                }
			}
        }
}
?>