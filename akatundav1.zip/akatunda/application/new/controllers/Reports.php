<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 /**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 
	 
	 */
	 
	 public function __construct()

        {
                parent::__construct();
				 $this->load->library('session');
               
        }
		 public function index()
	{
		 	if(isset($_SESSION['machines'])){
			$machines = $data['machines'] = $_SESSION['machines'] ;
			    $data['search'] =$_SESSION['Reports'];
				//print_r($machines);
		 $this->load->view('pdf/General_report' , $data);//Search_pdf
			}
			else {
				 redirect('Home', 'refresh');
			}
		 
	}
	
	function search_report(){
				if(isset($_SESSION['search_data_results'])){
				 $data['action'] = 1;
				 
				   $search_results =   $_SESSION['search_data_results'];
		 // print_r($search_results);
		 
		  $this->load->view('pdf/Search_pdf' , $data);//
				}
				else {
				 redirect('Home', 'refresh');
			}
		
	}
		
		 
	
	
}

