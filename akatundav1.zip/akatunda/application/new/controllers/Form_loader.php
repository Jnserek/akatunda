<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form_loader extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 public function __construct()

        {
                parent::__construct();
				//$this->load->library('session');
				if(!isset($_SESSION['catin_items'] )){ $_SESSION['catin_items']= array(); } 
               
        }
		
		
		//function to calculate the life of machines depending on which user we are dealing with
		
		
	public function index()
	{
		 $log_id = $this->session->userdata();
		 
		 
			
		$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
		 
		        redirect('Home', 'refresh');
			  
		 
		}
		else{
			$this->LogoutUser();
			
		}
	}
	
 	
	function machine_life(){//machine_life_details.php
	
	$log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					 
						   
					 
			     $this->load->view('bio/machine_life_details' );
						  
					 
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		function My_notifications(){//machine_life_details.php
	
	$log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					 
						   
					 
			     $this->load->view('bio/chats/read_notifications' );
						  
					 
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		
		
	 
	
	function Loading(){
					 
					   $log_id = $this->session->userdata();
		 
		 
			
		$log_id = $this->session->userdata('logged_in');
		        if($log_id and $this->session->has_userdata('bio_name')){
		 
		                  echo 2;
			  
		 
		                }
		          else{
			             echo 'Loging out.......';
			
		            }
					  
				  }
	
		
		function LogoutUser(){
			 $user = $this->session->userdata('bio_id');
			     
			     $this->bio-> Update_login($user , 0);   
					 
				 $this->session->sess_destroy();
				 
				  redirect('Login', 'refresh');
			
		}
		
		function New_machine_form(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];
						  
						  
						 
			
			               $_SESSION['my_depat'] = $dept = $this->encrypt->decode($my_post);
						  
						  // $_SESSION['profile'] =0;
			              $this->load->view('bio/add_machines_to_department_in_hospital');
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		//add new machine service report 
		
		function New_service_Report(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];
						   $_SESSION['mcn_service_id'] =   $my_post;
						 $this->load->view('bio/service_report');
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		function Allocate(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];
						     $_SESSION['mcn_field_id'] =   $my_post;
						 $this->load->view('bio/Allocate');
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		function Transfer(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];
						     $_SESSION['mcn_field_id'] =   $my_post;
						 $this->load->view('bio/Allocate');
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		//field service
		
		function Field_service(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];
						     $_SESSION['mcn_field_id'] =   $my_post;
						 $this->load->view('bio/field_service');
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		//  get machine service history
		
		
		function Machine_history(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];
						    echo $machine = $this->encrypt->decode( $my_post);
							
							$mac_data = $data['mac_data'] =  $this->bio->get_my_machines($machine);
							  
							if(sizeof($mac_data) > 0){
							
							$data['action'] = $_POST['Bio2']; 
						 $this->load->view('bio/machne_history' , $data);
							}
							else exit('No data  has been found for this machine');
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		//add get report form
		
		function New_machine_Report(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];
						    $_SESSION['mcn_problem_id'] =   $my_post;
						   $this->load->view('bio/machine_problems');
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		
		function department_info_fo(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					 echo $this->input->post('Bio1');
					  if(isset($_POST['Bio1'])){
						  $my_post = $_POST['Bio1'];
						 
			
			              echo $dept = $this->encrypt->decode($my_post);
						   
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		// receive new machine entry database
		
		function machine_entry_one(){
			
		 
						 
			$role = $this->session->userdata('bio_role');
				 $log_id = $this->session->userdata('logged_in');
		          if(  $this->session->has_userdata('bio_name')){
				 if(isset($_POST['Bio1'])){
						 $_SESSION['s1']  =  $mks = $_POST['Bio1'];
						 $_SESSION['s2']  =  $dp = $_POST['Bio2'];
						   $successu  =   0;
						
					
			if(sizeof($mks['scores']) > 0){
				
								  
								  $mks_iterator   =   $mks['scores'];
								 
								 
								  for($i =1; $i<=(sizeof($mks_iterator) ); $i++ ){
									      $std  =  $mks_iterator[$i];
										  if(sizeof($std) > 0){
								 $m_name = trim($std['Name']); 
											   
												 if($m_name != "" and preg_match('/[a-zA-Z0-9.,-]+$/',$m_name ) ){
													 
													 
								
													 //$successu  +=   1;
													 
													 //print_r($std);
									
												   $this->bio->Add_machine_to_db( $std , $dp , $role);
													 
												   
												 }//end validation check
										  }//end check 1
								  
								  }//end for loop
								  //echo $successu.'mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm';
								  success( 'Your  Machine(s) have been added successfully');
							  }//first checker
			  }//end post test
			  
			   }else  login();
			      
			
			
		}
		
		//add cat items
		
		
		function alt_cat_items(){//remove items from the cat
			 $role = $this->session->userdata('bio_role');
				 $log_id = $this->session->userdata('logged_in');
		          if(  $this->session->has_userdata('bio_name')){
				 if(isset($_POST['Bio1'])){
					  $my_data =    $_POST['Bio1'];
					  $command =    $_POST['Bio2'];
					  $items  = 0;
					  if($command ==1 ){
						 
						
						foreach ($my_data as $cat_items   ){
						 $my_post =  $cat_items ;
						 
					 
				 $dept = $this->encrypt->decode($my_post);
				 if ( in_array($dept, $_SESSION['catin_items'])) {
					 $items  += 1;
                           // array_push($_SESSION['catin_items'] , $dept);
							
							$key = array_search($dept, $_SESSION['catin_items']); 
							 array_splice($_SESSION['catin_items'], $dept);
					 
					           unset($_SESSION['catin_items'][$key]);
					 
							//bio_succes( 'Item added successfully');
                      }
	

	          }
             if( $items  > 0){
	                   bio_succes( $items. 'Item removed successfully');
	
                   }	 else bio_succes(  'Item does not exist on a chat');
				
			  }
					  else if($command ==2 ){
						  //
						 // print_r($my_data);
						$mks = $my_data[0];
						$info = $my_data[1];
						
						$customer = $this->session->userdata('bio_role');
						//'customer'	 => $x[0] ,   'additional_info' => $x[1] , 'state' => $x[2]  , 'order_type' => $x[3]
						$order  = array($customer , $info , 0 , 1);
						  $this->bio->Add_order_line($order);
						$max_id = $this->bio-> Maxid_order();
						 
						  $successu  =   0;
						
					
			if(sizeof($mks['scores']) > 0){
				
								  
								  $mks_iterator   =   $mks['scores'];
								  
								  for($i =0; $i<(sizeof($mks_iterator) ); $i++ ){
									      $std  =  $mks_iterator[$i];
										  if(sizeof($std) > 0){ 
								 $cat_item = $this->encrypt->decode($std['Item']);
 								   $qty = (int) $std['Qty'];
                                        $item_data= $this->bio-> get_machine_in_cart($cat_item );
										if(sizeof($item_data) >0){
											$price = $item_data[0]['price'] ;
											$discount = $item_data[0]['discount'] ;
											$order_items  = array($max_id ,  $cat_item , $price , $discount , $qty);
											 
											  $this->bio->Add_order_items($order_items);
											 $successu  +=   1;
											
										}
										
											    
										  }//end check 1
								  
								  }//end for loop
								  //echo $successu.'mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm';
								   $_SESSION['catin_items']= array();
								 success( ''.$successu .' Items submitted for order');
							  }//first checker
						  
						  
					  }
					  
						 
				 
			  }//end post test
			  
			   }else  login();
			      
			
			
		}
		
		
		
		function Add_cat_items(){
			 $role = $this->session->userdata('bio_role');
				 $log_id = $this->session->userdata('logged_in');
		          if(  $this->session->has_userdata('bio_name')){
				 if(isset($_POST['Bio1'])){
					  $my_data =    $_POST['Bio1'];
						 
						$items  = 0;
						foreach ($my_data as $cat_items   ){
						 $my_post =  $cat_items ;
					 
				 $dept = $this->encrypt->decode($my_post);
				 if ( !in_array($dept, $_SESSION['catin_items'])) {
					 $items  += 1;
                            array_push($_SESSION['catin_items'] , $dept);
							//bio_succes( 'Item added successfully');
}
						}
if( $items  > 0){
	bio_succes( $items. 'Item added successfully');
	
}	 else bio_succes(  'Item already exist on a chat');
				
			 
						 
				 
			  }//end post test
			  
			   }else  login();
			      
			
			
		}
		
		//update machine names and depreciation rates
		
		function Update_depreciation_rates(){
			
		 
						 
			$role = $this->session->userdata('bio_role');
				 $log_id = $this->session->userdata('logged_in');
		          if(  $this->session->has_userdata('bio_name')){
				 if(isset($_POST['Bio1'])){
						  $mks = $_POST['Bio1'];
						  
						   $successu  =   0;
						  
					
			if(sizeof($mks['scores']) > 0){
				
								  
								  $mks_iterator   =   $mks['scores'];
								  //print_r($mks_iterator);
								  				 
								 
								  for($i =0; $i<(sizeof($mks_iterator) ); $i++ ){
									      $std  =  $mks_iterator[$i];
										  if(sizeof($std) > 0){
								           $m_name = trim($std['Name']);
										   $m_rates = trim($std['Drate']);
										   $m_id = $this->encrypt->decode(trim($std['Mcn_id'])); 
										     if($m_name != "" and preg_match('/[a-zA-Z0-9.,-]+$/',$m_name ) and  $m_id > 0 and $m_rates > 0 ){
													  
									//update depreciation rates
												  $this->bio->Update_depreciation_rates(  $m_id  , $m_name  , $m_rates);
													 
												   
												 }//end validation check
										  }//end check 1
								  
								  }//end for loop
								  
								  success( 'Your  Machines has been updated');
							  }//first checker
			  }//end post test
			  
			   }else  login();
			      
			
			
		}
		
		
		
		 
		
		
		
		//edit machine form
		
		function Edit_depart_form(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						  
						 echo $action  =  $_POST['Bio2'];
						 if($action > 0){
						 
						   $_SESSION['dept_edit']  =   $my_post = $_POST['Bio1'];
			               $this->load->view('bio/edit_departments' );
						 }
						 else {
							 echo 'All Information about this ';
						 }
						  
					  }else  login();
			       
			  }else 
		  login();
		}
		
		//edit hospital info
		
		function Edit_client_form(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						  
						  $data['action'] =   $action  =  $_POST['Bio2'];
						 
						
						   $_SESSION['dept_edit']  =   $my_post = $_POST['Bio1'];
			               $this->load->view('bio/edit_client' , $data );
						 
						 
						  
					  }else  login();
			       
			  }else 
		  login();
		}
		
		
		
		//update machines supplier
		
		function Edit_supplier_info_form(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $data['action']  =   $_POST['Bio2'];
						   $_SESSION['dept_edit']  =   $my_post = $_POST['Bio1'];
						   $mcn = $this->encrypt->decode($my_post); 
						   
						  $supplier =  $this->bio-> Specific_machine_supplier($mcn);
						  if( sizeof($supplier > 0) ){
						   $this->load->view('bio/edit_machine_supplier' , $data );
						  }
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		//edit manufacturers information  
		
		function Edit_maufacturer_info_form(){ //
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						  $data['action']  =   $_POST['Bio2'];
						   $_SESSION['dept_edit']  =   $my_post = $_POST['Bio1'];
						   $mcn = $this->encrypt->decode($my_post); 
						   
						  $supplier =  $this->bio-> Specific_machine_manufacturer($mcn);
						  if( sizeof($supplier > 0) ){
						  $this->load->view('bio/edit_manufacturere_info', $data );
						  }
						  
					  }else  login();
			       
			  }else 
		  login();
		}
		
		//machine states
		
		function Edit_system_user_state(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						   $_SESSION['dept_edit']  =   $my_post = $_POST['Bio1']; //read post data
						    $mcn = $this->encrypt->decode($my_post);  //decode post data 
						   
						  $supplier =  $this->bio-> All_users($mcn); //chek if this user exists in the databse
						  if( $supplier > 0){
						 
						  $new_state = 1;
						  $state =  $supplier[0]['state']; //get user state
						  if($state ==1 ){ // if not active
							  $new_state = 0; //deactivate
							  
						  }
						  else if($state ==0 ){ //if was not active then activate 
							  $new_state = 1; //activate
							  
						  }
						  
						  $this->bio-> Alter_user_state($mcn , $new_state); //apply changes to database
						  success(' User state has been changed successfully');
						  }
						  else {
							  
							  bio_error('Sorry, No data was found ');
						  }
						  
					  }else  login();
			       
			  }else 
		  login();
		}
		
		function Edit_machine_states_info_form(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						   $_SESSION['dept_edit']  =   $my_post = $_POST['Bio1'];
						    $mcn = $this->encrypt->decode($my_post); 
						   
						  $supplier =  $this->bio-> validate_new_state_two($mcn);
						  if( $supplier > 0){
						  $this->load->view('bio/edit_states' );
						  }
						  
					  }else  login();
			       
			  }else 
		  login();
		}
		function Edit_device(){  //edit my machine information
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];
						   $data['action'] = $_POST['Bio2'];  
						  
						     $_SESSION['mcn_field_id'] =   $my_post;
						 $this->load->view('bio/edit_device' , $data);
						  
					  }else  login();
			       
			  }else 
		  login();
		 
		}
		
		function Edit_Problem(){  //edit my machine information
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						  $my_post = $_POST['Bio1'];
						  $data['action'] = $_POST['Bio2'];  
						  
						      $_SESSION['mcn_field_id'] =   $my_post;
						      $this->load->view('bio/edit_machine_problems' , $data);
						  
					  }else  login();
			       
			  }else 
		  login();
		 
		}
		
		//edit service report 
		function Edit_Service_Report(){  //edit my machine information
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						  $my_post = $_POST['Bio1'];
						  $data['action'] = $_POST['Bio2'];  
						  
						    $_SESSION['mcn_field_id'] =   $my_post;
						      $this->load->view('bio/edit_field_service' , $data);
						  
					  }else  login();
			       
			  }else 
		  login();
		 
		}
		
		//edit service details from here
		
		function Edit_repair(){  //edit my machine information
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						  $my_post = $_POST['Bio1'];
						  $data['action'] = $_POST['Bio2'];  
						  
						       $_SESSION['mcn_field_id'] =   $my_post;
						      $this->load->view('bio/edit_repair' , $data);
						  
					  }else  login();
			       
			  }else 
		  login();
		 
		}
		
		
		//detaild about this department
		
		function department_info_form(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						  $my_post = $_POST['Bio1'];
					 
			
			                 $dept = $this->encrypt->decode($my_post);
						  
						  $data['mcns'] =   $mcns = $this-> bio-> get_departmental_machines($dept , 0);//hospital_no
						 
						   if(sizeof($mcns) > 0){
							   $data['machines'] =   $mcns;
							    $data['dp'] =    $dept;
							   $data['action'] =    $_POST['Bio2'];
							    $this->load->view('bio/departmental_machines' , $data);
							 
						   }
						   else bio_error('Sorry, No data was found ');//bio_error('Sorry, No data was found ');
						  
					  }else  login();
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		function test(){
			$arry  = array('jack' , 2 , 3 , 4 , 5 , 6);
			
			$this->bio->Add_field_report($arry);
		}
		
		function Search_Inventories(){
			 
			 $log_id = $this->session->userdata();
		    $role = $this->session->userdata('bio_role');
		    if($log_id ){
				$results = array();
			   $fname =   strtolower(trim($this->input->post('search_inventory')));
			   $my_string = explode(' ' ,  $fname );
			if(sizeof($my_string) > 0){
				
				
				foreach($my_string as $search){
				
			 
			 $return_data1 =  $this->bio->search_machine($search , $role);
			 foreach($return_data1 as $return){
				 array_push($results , $return );
				 
			 }
			  
			   $return_data2 =  $this->bio->search_machine_suplier($search , $role);
			    foreach($return_data2 as $return){
				 array_push($results , $return );
				 
			 } 
			   
			   $return_data3 =  $this->bio->search_machine_manufacturer($search , $role);
			    foreach($return_data3 as $return){
				 array_push($results , $return );
				 
			 } 
			    if($role < 1){
				  $return_data4 =  $this->bio->search_facility($search , $role);
				   foreach($return_data4 as $return){
				 array_push($results , $return );
				   }
				 
			 }
				 
				}
			}
			else {
				
				
			 $return_data1 =  $this->bio->search_machine($fname , $role);
			 foreach($return_data1 as $return){
				 array_push($results , $return );
				 
			 }
			  
			   $return_data2 =  $this->bio->search_machine_suplier($fname , $role);
			    foreach($return_data2 as $return){
				 array_push($results , $return );
				 
			 } 
			   
			   $return_data3 =  $this->bio->search_machine_manufacturer($fname , $role);
			    foreach($return_data3 as $return){
				 array_push($results , $return );
				 
			 } 
			   if($role < 1){
				  $return_data4 =  $this->bio->search_facility($fname , $role);
				   foreach($return_data4 as $return){
				 array_push($results , $return );
				 
			 }
			   }
				
				
			}
			
			 if(sizeof($results) > 0){
				$results =  $this->bio->unique_multidim_array($results, 'mid');
				
			 }
 
			  
			 $data['machines'] = $results;   
			 $this->load->view('bio/machinesearch_results' , $data);
			 
			} 
			
			
			
		}
		function search_inventory(){
			 $log_id = $this->session->userdata();
		 
		 
			
		$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $fname =   strtolower(trim($this->input->post('id_search')));
			 $role = $this->session->userdata('bio_role');
			 //$return_data1 =  $this->bio->search_machine($fname , $role);
			// print_r($return_data);
			   $return_data1 =  $this->bio->search_machine_suplier($fname , $role);
			  // print_r($return_data);
			   
			   //$return_data3 =  $this->bio->search_machine_manufacturer($fname , $role);
			   
				//  $return_data4 =  $this->bio->search_facility($fname , $role);
				 print_r($return_data1);
			 if($role  > 0){ //seacrh only for this cat
			 
				 
			 }
			 else {
				 
				 //search eveny crap
			 }
			 
			 
			
		}
		}
		
		function Service_companies(){
			
			 $log_id = $this->session->userdata(); 
		if($log_id  ){
			
			$data['action'] = 0; 
			$this->load->view('bio/list_service_companies' , $data);
		}
		}
		//manage service companies
		
		function Manage_Service_companies(){
			
			 $log_id = $this->session->userdata(); 
		if($log_id  ){
			
			$data['action'] = 1; 
			$this->load->view('bio/list_service_companies' , $data);
		}
		}
		function validate_user_name(){
			
			 $log_id = $this->session->userdata();
		 
		 
			
		$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			$fname =   strtolower(trim($this->input->post('id_search')));
			 if(strlen($fname) < 16 and strlen($fname) > 3  ){
			  
			if($this->bio->validate_user_name($fname)  > 0 || (strlen($fname) > 15  )){
				   echo 'User name is taken';
				
			}
			else {
				
				echo 'Available';
			}
			 }
			 else{
				 echo 'User name is invalid';
				 
			 }
		}
			
			/*if (preg_match('/[a-zA-Z_]+/', $fname)) {
				
				echo $fname;
			}
			else {
				echo 'Invalid user name';
			}
			*/
			
			 
		}
		
		function create_new_profile(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			
		 
			
			$this->load->view('bio/add_new_user');
		}
		}
		
		function create_new_category_item(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			
		 
			
			$this->load->view('bio/add_new_catelogue');
		}
		}
		
		function Load_profile(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			
			//profile.php
			 $_SESSION['profile'] =0;
			$this->load->view('bio/profile');
		}
		}
		
		function create_profile(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 $_SESSION['profile'] =0;
			//profile.php
			$this->load->view('bio/profile');
		}
		} //add_new_states
		
		//now load form for adding new states
		
		function state_additin_form(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 
			 
			$this->load->view('bio/add_new_states');
			 
		  }else 
		  login();
		}
		
		//view all my departments from the database
		
		
		function My_dpts(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 
			 
			$this->load->view('bio/my_departments');
			 
		  }else 
		  login();
		}
		
		//List all clients (hospitals ) under manage action
		
			function My_hosp_machines(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 $data['action']  = 1;
			 
			$this->load->view('bio/admin/my_hospitals', $data);
			 
		  }else 
		  login();
		}
		
		//list clients (hospitals)
		
			function List_clients(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 
			 $data['action']  = 0;
			$this->load->view('bio/admin/my_hospitals' , $data);
			 
		  }else 
		  login();
		}
		
		function My_clients(){ //my clients with edit function
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 
			 $data['action']  = 2;
			$this->load->view('bio/admin/list_clients' , $data);
			 
		  }else 
		  login();
		}
		
		//just list my clients from the database
		
		function List_my_client(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 
			 $data['action']  = 0;
			$this->load->view('bio/admin/list_clients' , $data);
			 
		  }else 
		  login();
		}
		
		
		
		function My_machines(){
			$log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					   
						  
						  $data['mcns'] =   $mcns = $this-> bio-> get_departmental_machines(0 , $role);
						   if(sizeof($mcns) > 0){
							   $data['machines'] =   $mcns;
							    $data['dp'] =    0;
								$data['action'] =    1;
								 
							   
							  $this->load->view('bio/departmental_machines' , $data);
							 
						   }
						   else bio_error('Sorry, No data was found ');
						  
					 
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		//allocate machines
		
		function Allocate_machines(){
			$log_id = $this->session->userdata('logged_in');
			  $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					   
						 
						  $data['mcns'] =   $mcns = $this-> bio-> new_departmental_machines(0 , $role);
						   if(sizeof($mcns) > 0){
							   $data['machines'] =   $mcns;
							   $data['dp'] =    0;
								$data['action'] =    1;
							   
							 $this->load->view('bio/All_new_machines' , $data);
							 
						   }
						   else bio_error('Sorry, No data was found ');
				 
			  }else 
		  login();
		}
		
		//device transfer
		
		function Load_Transfer(){
			$log_id = $this->session->userdata('logged_in');
			  $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					   
						 
						  $data['mcns'] =   $mcns = $this-> bio-> get_departmental_machines(0 , $role);
						   if(sizeof($mcns) > 0){
							   $data['machines'] =   $mcns;
							   $data['dp'] =    0;
								$data['action'] =    0;
							   
							 $this->load->view('bio/All_new_machines' , $data);
							 
						   }
						   else bio_error('Sorry, No data was found ');
						  
					 
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		//list machines
		
		function List_machines(){
			$log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					   
						  
						  $data['mcns'] =   $mcns = $this-> bio-> get_departmental_machines(0 , $role);
						   if(sizeof($mcns) > 0){
							   $data['machines'] =   $mcns;
							    $data['dp'] =    0;
								$data['action'] =    0;
							   
							 $this->load->view('bio/departmental_machines' , $data);
							 
						   }
						   else bio_error('Sorry, No data was found ');
						  
					 
			      
			
			                                                               //add new manufacturer from controller
			 
			  }else 
		  login();
		}
		
		
		//machine reports
		
		function My_Reports(){
			$log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					   if(isset($_POST['Bio1'])){
						   $decision  = $_POST['Bio1']; 
					   
						  
						  $data['mcns'] =   $mcns = $this-> bio-> get_departmental_machines(0 , $role);
						   if(sizeof($mcns) > 0){
							   $data['machines'] =   $mcns;
							    $data['dp'] =    0;
								if($decision  ==1){
							   
							 $this->load->view('bio/reports/machine_reports_states' , $data);
								}
								else if($decision  ==2){
							   
							 $this->load->view('bio/reports/suppliers' , $data);
								}
							 
						   }
						   else bio_error('Sorry, No data was found ');
					 
					   }
					   else  login(); 
			  }else   login();  
		 
		}
		
		//catalogue data
		
		function Catalogue(){
			$log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					   if(isset($_POST['Bio1'])){
						    $data['action'] =0; 
						   $data['decision'] =  $decision  = $_POST['Bio1'];  
						   if($decision ==1 ){ //display only recommended items
							    $data['machines'] =   $mcns = $this-> bio->   All_recomended(''  );
								 if(sizeof($mcns) > 0){
									 $this->load->view('bio/cat/display_machines' , $data);
								 }
								else bio_error('Sorry, No data was found ');
							   
						   }
						   else  if($decision ==2 ){
							    $data['machines'] =   $mcns = $this-> bio->   All_featured(''  );
								 if(sizeof($mcns) > 0){
									 $this->load->view('bio/cat/display_machines' , $data);
								 }
								else bio_error('Sorry, No data was found ');
							   
							   
						   }
						     else if($decision ==0 ){
							    $data['action'] =1; 
							  
							    $data['machines'] =   $mcns = $this-> bio->   All_Machines_in_catelogue('' , 1 );
								 if(sizeof($mcns) > 0){
									 $this->load->view('bio/cat/display_machines' , $data);
								 }
								 
								 
								 
								else bio_error('Sorry, No data was found ');
							   
							   
						   }
						   
						   
						   else if($decision ==3 ){
							    
							  
							    $data['machines'] =   $mcns = $this-> bio->   All_Machines_in_catelogue('' , 1 );
								 if(sizeof($mcns) > 0){
									 $this->load->view('bio/cat/display_machines' , $data);
								 }
								 
								 
								 
								else bio_error('Sorry, No data was found ');
							   
							   
						   }
						    else if($decision ==4 ){
							    $data['machines'] =   $mcns = $this-> bio->   All_Machines_in_catelogue('' , 1 );
								 if(sizeof($mcns) > 0){
									 $this->load->view('bio/cat/display_machines' , $data);
								 }
								 
								 
								 
								else bio_error('Sorry, No data was found ');
							   
							   
						   }
						   
						     else if($decision ==5 ){
								 $data['machines'] =   $mcns = $this-> bio->   All_Machines_in_catelogue('' , 1 );
								 if(sizeof($mcns) > 0){
									 $this->load->view('bio/cat/my_cat' , $data);
								 }
								 
								 
								 
								else bio_error('Sorry, No data was found ');
							   
							   
						   }
					   
						  
						  
						   else  bio_error('Sorry, No data was found ');
					 
					   }
					   else  login(); 
			  }else   login();  
		 
		}
		
		
		//add new department from here 
		
		function Departments_form(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 
			 
			$this->load->view('bio/department_nos');
			 
		  }else 
		  login();
		}
		
		function Departments_entry_form(){
			$log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		if($log_id and $this->session->has_userdata('bio_name')){
			$my_post =$_POST['Bio1'];
			$check_dpts =0;
			 
			$my_post =$my_post['scores'];
			 
			for($i= 1; $i<=sizeof($my_post); $i++ ){
				$hosp = strtolower($my_post[$i]['Name']);
				$dep_type =  $my_post[$i]['Dep_type'];
				/*if(ctype_alnum($my_post[$i])){
					
					echo '<br />>>>'.$my_post[$i];
				}
				else {
					echo '<br /> error'.$my_post[$i];
				} */
				if(preg_match('/[a-zA-Z0-9.,-]+$/',$hosp )){
					//echo '<br />is valid'.$hosp;
					if($this->bio->validate_dpt_name($hosp , $role) < 1){
						$this->bio->Add_department_to_db($hosp , $role , $dep_type);
						$check_dpts +=1;
						
						
					}
					 
				}
			}
			
			if($check_dpts > 0){
				success($check_dpts .' Departments have been added successfully');
				
			}
			else {
				bio_error('Some of your departments contain illegal characters and can not be added ');
			}
			
			
			 
			 
			 
		  }else 
		  login();
		}
		
		function My_chats(){
			//read_chat_items.php 
			$log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $_SESSION['chat_receiver'] = $_POST['Bio1'];
			 
			
			 
			 $this->load->view('bio/chats/read_chat_items');
			  
			
			
			 
			 
			 
		  }else 
		  login();
		}
		
		
		
		
		
		function Client_form_addition(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  //
			$cat = $this->bio-> All_Hospital_Type();
			
			if(sizeof($cat) > 0){
			 
			$this->load->view('bio/addhealthfacility');
			}
			else bio_error('No client category found contact your system administrator for assistance');
		  }else 
		  login();
		}
		
		
		//machine depreciation rates
		
		
		function Machine_depreciation_rates(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  //
			$cat = $this->bio-> All_Hospital_Type();
			
			if(sizeof($cat) > 0){
			 
			$this->load->view('bio/analysis_machines');
			}
			else bio_error('No client category found contact your system administrator for assistance');
		  }else 
		  login();
		}
		
		//machine suppliers
		
		
		function Machine_suppliers(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  //
			  $data['action']  = 1;
			 
			$this->load->view('bio/machine_suppliers' , $data);
		 
			
		  }else 
		  login();
		}
		
		//list all  machine suppliers
		
		function List_suppliers(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  //
			 $data['action']  = 0;
			 
			$this->load->view('bio/machine_suppliers' , $data);
		 
			
		  }else 
		  login();
		}
		/*
		 $data['action'] = 1;//will  display manage option
			$this->load->view('bio/machine_manufactureres' , $data);
		
		*/
		
		
		function Machine_manufactureres(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $data['action'] = 1;
			$this->load->view('bio/machine_manufactureres' , $data);
		  
		  }else 
		  login();
		}
		
		
		//list my manufacturers
		
		function List_manufactureres(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $data['action'] = 0;
			$this->load->view('bio/machine_manufactureres' ,  $data);
		  
		  }else 
		  login();
		}
		//get machine states
		
		function Machine_states(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $data['action'] = 1;
			 $this->load->view('bio/all_machine_states' , $data);
		   }else 
		  login();
		}
		
		//list machine states 
		
		function List_states(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $data['action'] = 0;
			 $this->load->view('bio/all_machine_states' , $data);
		 
			
		  }else 
		  login();
		}
		
		//list system users
		
		function List_users(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $data['action'] = 0;
			 $this->load->view('bio/All_system_users' , $data);
		 
			
		  }else 
		  login();
		}
		
		function List_Acive_users(){ //list active users 
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $data['action'] = 2;
			 $this->load->view('bio/All_system_users' , $data);
		 
			
		  }else 
		  login();
		}
		
		function List_Idle_users(){ //list inactive users 
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $data['action'] = 3;
			 $this->load->view('bio/All_system_users' , $data);
		 
			
		  }else 
		  login();
		}
		
		
		//manage system users
		function Manage_users(){
			 $role = $this->session->userdata('bio_role');
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  $data['action'] = 1;
			  if($role  =="**"){
			 $this->load->view('bio/All_system_users' , $data);
			  }else {
				   bio_error('You do not have rights to perform this function');
		 
			  }
		 
			
		  }else 
		  login();
		}
		
		//add new machine supplier form
		
		function Supplier_entry_form(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  //
			$cat = $this->bio-> All_Hospital_Type();
			
			if(sizeof($cat) > 0){
			 
			 $this->load->view('bio/add_new_suplier');
			}
			else bio_error('No client category found contact your system administrator for assistance');
		  }else 
		  login();
		}
		
		
		//Load service company addition from from the view folder
		//add_new_service_tech.php
		
		function Service_company_entry_form(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  //
			$cat = $this->bio-> All_Hospital_Type();
			
			if(sizeof($cat) > 0){
			 
			 $this->load->view('bio/service_company');
			}
			else bio_error('No client category found contact your system administrator for assistance');
		  }else 
		  login();
		}
		
		//add new technician
		
		function Service_tech_entry_form(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			  //
			 
			 
			 $this->load->view('bio/add_new_service_tech');
			 
		  }else 
		  login();
		}
		
		
		//add new manufacturere to the database
		
		function Manufacturer_entry_form(){
			$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			 
			 
			 $this->load->view('bio/add_new_manufacturer');
			  }else 
		  login();
		}
		
		
		function Device_problems(){
			
			 
			 $data['action'] = 1;
			 $this->load->view('bio/list_problems' , $data);
		}
		 //pending problems
		
		function Tech_pending_probs(){
			
			 
			 $data['action'] = 2;
			 $this->load->view('bio/list_problems' , $data);
		}
		
		function alt_user_credentials(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		if($log_id ){
			 $_SESSION['profile'] =0;
			//profile.php
			$this->load->view('bio/update_password');
		}
		else {
			
			echo bio_error('Cant perform this action');
		}
		}
		
		function System_back_up(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and  $role =="**" ){
			
			 $this->bio->Form_back_up();
				echo bio_succes('Operation was successful');
				  }
				  else {
					  echo bio_succes('Cant perform this action');
					  
					  
				  }
			 
		}
		
		//get susytem settings from database
		
			function System_settings(){// 
			 
				  $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and  $role =="**" ){
				 
				 $this->load->view('bio/list_settings');
				  }else {
					  
					 echo  bio_erro('Cant perform this action');
				  }
				 
				 
			 
			 
		}
		
		//list files for backup
		
		function List_file_backup(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and  $role =="**" ){
			
			 $files = $this->bio->List_file_backups();
			 if(sizeof($files) > 0){
				 
				 $this->load->view('bio/list_databases');
				 
				 
			 }
			 else 
				echo bio_error('Operation was successful');
				  }
				  else {
					  echo bio_error('Cant perform this function');
					  
				  }
			 
		}
		
		//list files from server from bavk ups
		
		function List_file_backup_deletion(){
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and  $role =="**" ){
			 $files = $this->bio->List_file_backups();
			 if(sizeof($files) > 0){
				 
				 $this->load->view('bio/delete_obsolute');
				 
				 
			 }
			 else 
				echo bio_error('Operation was successful');
				  }
				  else   bio_error('Cant perform this action');
			 
		}
		function Edit_service_company(){
			
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $role =='**'){
					  if(isset($_POST['Bio1'])){
						  $data['action'] = $_POST['Bio2'];
						 
						 if($_POST['Bio2'] ==0  ){
							  $_SESSION['service_company_id']= $_POST['Bio1'];
							 //edit_service_company.php
							 $this->load->view('bio/edit_service_company' , $data);
							 
						 }
						 
					  }
				  }
		}
		
		
		function Load_search(){
			
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id  ){
					 
						  $data['action'] = 1;
						  
							 $this->load->view('bio/search' , $data);
							 
					  
				  }
			 	  
		}
		//my reports
		
		function Load_Reports(){
			
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id  ){
					 
						  $data['action'] = 1;
						  
							 $this->load->view('bio/Get_reports' , $data);
							 
					  
				  }
			 	  
		}
		
		//perform action on cat items from here
		
		function Alt_cat_item(){  //edit my machine information
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $role =='**'){
					  if(isset($_POST['Bio1'])){
						 $data['action'] = $_POST['Bio2'];
						  $my_post = $_POST['Bio1'];
						 if($_POST['Bio2'] ==0 ||  $_POST['Bio2'] ==1 ){
							$item =  $this->encrypt->decode($my_post);
							$item_data  = $this->bio->Item_name($item  );
							if(sizeof($item_data) > 0){
								 
								$_SESSION['cat_item_alt'] = $item_data;
							 
							 
							$this->load->view('bio/edit_cat_item' , $data);
							}
							else {
								
								bio_error('No item was found');
							}
							
							  
						 }
						  
						 
						 
						  
						 else echo 'Error';
						 
						  
					  }else  login();
			       
			  }else 
		  login();
		 
		}
		
		//download machine
		function Download_machine(){  //edit my machine information
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $role =='**'){
					  if(isset($_POST['Bio1'])){
						 $data['action'] = $_POST['Bio2'];
						echo  $my_post = $_POST['Bio1'];
						 if($_POST['Bio2'] ==0  ){
							 $files = get_filenames('./db_back_ups/');
							 
							 if(sizeof( $files) > 1 ){
								  //$files =  sort($files);
								  $file_size =  (sizeof($files)-1);
								 if($files[$file_size] != $my_post){
									 
									 
								
								 unlink('./db_back_ups/'.$my_post.'');
								 success('File has been deleted successfully');
							  
							 
								 }
								 else {
									 bio_error('Latest backup file can not be deleted');
									 
								 }
							 
							 // 
							 }
							 else bio_error('File can not be deleted, Create a new back up to continue');
							 
						 }
						 else  if($_POST['Bio2'] ==1  ){  
						      $this->load->helper('download'); 
							force_download('db_back_ups/'.$my_post.'', NULL);
							 
						 }
						 
						  else  if($_POST['Bio2'] ==4  ){
							  $_SESSION['edit_settings'] = $my_post; 
							   $this->load->view('bio/edit_setting' , $data);
							  
						  }
						 else echo 'Error';
						 
						  
					  }else  login();
			       
			  }else 
		  login();
		 
		}
		
		//delete_obsolute.php
		
		function delete_db_files(){  //edit my machine information
			 $log_id = $this->session->userdata('logged_in');
			 $role = $this->session->userdata('bio_role');
		          if($log_id and $this->session->has_userdata('bio_name')){
					  if(isset($_POST['Bio1'])){
						 $my_post = $_POST['Bio1'];  
						      $this->load->helper('download'); 
							 
								  
						  
					  }else  login();
			       
			  }else 
		  login();
		 
		}
		
		
		//list files from the server
		
		function List_files(){
			//echo $string = read_file('/db_back_ups/');
			echo $models_info = get_filenames('/db_back_ups/');
			print_r($models_info);
		}
		
		//back up the database 
		
		function back_up(){
			
			$this->bio->back_up();
		}
}
