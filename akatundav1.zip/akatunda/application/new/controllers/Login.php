<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 
	 
	 */
	 
	 public function __construct()

        {
                parent::__construct();
				$this->load->library('session');
               
        }
		
		
	public function index()
	{
		
		 $log_id = $this->session->userdata();
		 
		if(LoadValid() ){
		 
		$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
			redirect('index.php/Home', 'refresh');
			
		}else {
		 
		 $this->load->view('bio/login');
		}
		}
		else redirect('Error', 'refresh');
	}
	  function validate(){
	  	
		   
		
		$uname  =  $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[2]|max_length[12]|xss_clean|alpha_numeric');
        $pass  =     $this->form_validation->set_rules('password', 'Password', 'required|xss_clean',
                        array('required' => 'You must provide a %s.')
                );
                  if ($this->form_validation->run() == FALSE)
                {
					 
					bio_error('Login failed please check your user name and password');
					
                }
                else
                {   //assign post values to the variables from here
					  $uname = $this->input->post('username');
					  $pass = $this->input->post('password');
					  $rep =   $this->bio-> Bio_Aunthentication($uname , $pass );
					 
					 
					 if(sizeof($rep) < 1){
						 bio_error('Login failed please check your user name and password');
						 
						 
					 }
					 else {
						   $this->session->set_userdata($rep);
						   
						  
						    
					      echo 'Loading........';   ?>
					      <script type="text/javascript">
                           window.location.href = "<?php echo base_url(); ?>index.php/home";
                           </script>
                             <?php
					    }
					  
                }
        }
		
		function Recover_password(){
	  	
		   
		
		$uname  =  $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[2]|max_length[12]|xss_clean|alpha_numeric');
        $pass  =     $this->form_validation->set_rules('password', 'Password', 'required|xss_clean',
                        array('required' => 'You must provide a %s.')
                );
                  if ($this->form_validation->run() == FALSE)
                {
					 
					bio_error('Operation has been failed');
					
                }
                else
                {   //assign post values to the variables from here
					   $uname = $this->input->post('username'); //user name
					   $pass = $this->input->post('password'); //phone number
					 
					  
					 
					  $rep =   $this->bio-> Pass_recoverly($uname , $pass );
					 
					 
					 if(sizeof($rep) < 1){
						 bio_error('Pass_word recovery has been failed');
						 
						 
					 }
					 else { //code has been sent to your code
						  bio_success('Your verification has been sent to your phone <span class="pull-right"> <a href="Login"> Login here?</a></span>');
						  
						      ?>
					       
                             <?php
					    }
					  
                }
        }
		
		 
	
	
}
