<?php  
class Machine_uploads extends CI_Controller {

    function __construct() {
        parent::__construct();
    
          
        $this->load->library('csvimport');
		$this->load->helper(array('form', 'url'));
		$this->load->library('upload');
    }
	
	 function index() {
		  if(LoadValid() ){
		$log_id = $this->session->userdata('logged_in');
		  
	 $data['base']       = $this->config->item('base_url');
       $this->load->view('bio/upload/upload_machines', $data);
		 }else redirect('Error', 'refresh');
    }
	
	function importcsv() {
			  	//$this->BetaLinks();
			  	if(isset($_POST['cat'])){
			  		$t  =  $y  =   $_POST['cat'];
			  		//$t  =   $_POST['trm'];
  
       
                   $data['base']       = $this->config->item('base_url');
                     
         $this->load->library('csvimport');
		$this->load->helper('url');
		$this->load->helper('file');
		
		 
		$vv   ='';
		 $succes = 0; 
		$fail = -3;
		$updats = 0;
        $not_reg = 0; //wrong subjects
        $no_comb = 0; // students with no cominations
        $fai_stds  = '';
		 $bx       =  $data['base']       = $this->config->item('base_url');
       // $data['addressbook'] = $this->csv_model->get_addressbook();
        $data['error'] = '';    //initialize image upload error array to empty

        /* $x  =   $config['upload_path'] = './machines/';
        $config['allowed_types'] = 'csv';
        $config['max_size'] = '4000';

        $this->load->library('upload', $config);
		*/
		echo '<br /><br /><br /><br /><br />';
		

                $config['allowed_types']        = 'csv';
                $config['max_size']             = 4000;
                $x  =  $config['upload_path']          = './uploads/';

                $this->load->library('upload', $config);
         

        // If upload failed, display error
        if (!$this->upload->do_upload()) {
            $data['error'] = $this->upload->display_errors();
            //  $data['ssn_info']       =   $_SESSION['excell_mks_upload_olevel'];
                //$data['addressbook'] =   $mks_data;
                 $this->load->view('bio/upload/upload_machines', $data);// $this->load->view('fees_import_vew', $data);
 
			 
        } else {
            $file_data = $this->upload->data();
            $file_path =  './uploads/'.$file_data['file_name'];
            
            if ($this->csvimport->get_array($file_path)) {
                $csv_array = $this->csvimport->get_array($file_path);
               /* foreach ($csv_array as $row) {
					 
					
					$std  = $row['SID'];
					$cls  = $row['Class'];
					$f  = $row['SchoolFees'];
					$fn  = $row['FunctionalFees'];
					$py  = $row['PaidBy'];
					  
					if($std > 0 and ($cls > 0 || $cls < 8 ) and ($f > 0 || $fn > 0) ){ 

						$fe_info  =array($std , $y , $t , $cls , $f , $fn , $py  ); 
						$this->ctr->FeesEntry($fe_info , $this->user());
						$succes  += 1; 
		  
						   
  

					}
					else {
						if($std > 0 ){
						$fail += 1; 
						$fai_stds  .= $std.' , ';
					}
					 


					}
					
                      
					 
                   
					 
                }*/

                	 

                $upload_status = 'success uploads  >>'.$succes . ' failed uploads >>'  .$fail .' Students with failed uploads >>'.$fai_stds;
               
                $this->session->set_flashdata('success', $upload_status );
               // $data['addressbook'] =    $this->ctr->Terminal_fees_excell_view_selected($y , $t);
                // $this->load->view('fees_import_vew', $data);
				 $this->load->view('bio/upload/upload_machines', $data);
                  redirect($bx.'Machine_uploads/');
				   
                //echo "<pre>"; print_r($insert_data);
            } else 
                $data['error'] = "Error occured";
               //$data['addressbook'] =   $mks_data;
                 $this->load->view('bio/upload/upload_machines', $data);
            }

        }
            
        }

function importcsvb() {
	 
	
		 //$this->load->helper('url');
		 $bx       =  $data['base']       = $this->config->item('base_url');
       // $data['addressbook'] = $this->csv_model->get_addressbook();
        $data['error'] = '';    //initialize image upload error array to empty

        $config['upload_path'] = './machines/';
        $config['allowed_types'] = 'csv';
        $config['max_size'] = '6000';

        $this->load->library('upload', $config);


        // If upload failed, display error
        if (!$this->upload->do_upload()) {
            $data['error'] = $this->upload->display_errors();

            $this->load->view('bio/upload/upload_machines', $data);
        } else {
            $file_data = $this->upload->data();
            $file_path =  './machines/'.$file_data['file_name'];
            
            if ($this->csvimport->get_array($file_path)) {
                $csv_array = $this->csvimport->get_array($file_path);
                foreach ($csv_array as $row) {
					 
					if( isset($row['MachineName'] ) and  isset($row['ScientificName']) and isset($row['Specifications']) and isset($row['Description'])  and isset($row['Price']) and isset($row['Discount']) ){       
					
                   /* $insert_data = array(//database>>field name
                        's_sname'=>$row['MachineName'],
                        's_fname'=>$row['ScientificName'],
						's_oname'=>$row['Specifications'],
                        's_sex'=> $row['Description'],
                        's_class'=>$row['Price'],
						's_secn'=> $row['Discount'] 
                    );
                    $this->csv_model->insert_csv($insert_data); */
                }
                $this->session->set_flashdata('success', 'Csv Data Imported Successfully');
                $this->load->view('bio/upload/upload_machines', $data);
                //echo "<pre>"; print_r($insert_data);
				}
            } else 
                $data['error'] = "Error occurred";
                $this->load->view('bio/upload/upload_machines', $data);
            }
			 
            
        }
}
 