<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Biomedical extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 
	public function index()
	{
		 $log_id = $this->session->userdata();
		 
		 
			
		$log_id = $this->session->userdata('logged_in');
		if($log_id and $this->session->has_userdata('bio_name')){
		 
		        redirect('Home', 'refresh');
			  
		 
		}
		else{
			$this->LogoutUser();
			
		}
	}
	
		
		function LogoutUser(){
			     
			          
					 
				 $this->session->sess_destroy();
				 
				  redirect('Login', 'refresh');
			
		}
		
		function create_user(){
			
			echo 'hello boss ';
		}
}
