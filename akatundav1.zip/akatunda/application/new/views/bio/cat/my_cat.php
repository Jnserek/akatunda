<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			   $cats  =$this->bio->All_Machines_cats('' , 1 );
			     
				
			//	print_r($machines1);
		 

?>     
<div class="panel panel-default">
                        <div class="panel-heading">
                           <h4> 
							
							<?php
							  if($decision ==5 ){
							 echo   'My shopping history';
							   
							   
						   }
					   
							?>
							</h4>
                        </div>
                        
 
						<div class="panel-body">
                            <div class="row">
                                <div class="col-md-12" >
								<div class="panel panel-default">
								<div  id="cat_results" > </div>
						  <?php 
						 //value of machines is determined in the controller
						 
					  
					$orders =$this->bio->  Load_orders('' , $role,  '');
					 
						  if (sizeof( $machines) > 0){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_cat_items();' );

                              echo form_open('Form_loader/Add_cat_items', $attributes);
							  
					                ?>	
									 
						 <div class="panel-body">  
                            <div class="table-responsive">
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th>   <th>  Customer </th> <th> Date</th><th> Order Note</th> <th> States</th> <th> Items</th>      </tr>
                                   </thead>
                                    <tbody>
									<?php  $ids = 0;  foreach($orders as $row) {?>
									
									 <tr> <td>  <?php echo $ids += 1;?></td> 
									 
									 <td><?php
									 if($role  < 1) { 
									 
									$customer = $this->bio-> Get_user_profile_info($row['cust'] );
									if(sizeof($customer)>0){
										
									 
										echo 'Name : '.$customer['fname'].' '.$customer['lname'].'<br />';
										echo 'Phone Number : '.$customer['fon'].'<br />';
										echo 'Email : '.$customer['email'].'<br />';
										//specific_hospital($x)
										$facility = $this->bio->specific_hospital($customer['hosp']);
										if(sizeof($facility ) >0){
											echo 'Hospital : '. $facility ['name'].'<br />';
											echo 'Location : '. $facility ['ln'].'<br />';
											echo 'Phone No : '. $facility ['fon'];
											
										}
										 
										
									}
									 }else echo 'Me';

									 ?></td>


									 <td><?php echo $row['dt'] ?></td> <td> <?php echo $row['info'] ?></td> <td> <?php echo $row['state']; ?></td> <td>
									 <?php   $or_items =  $this->bio->Load_orders_items('' , $row['id'],  '');  ?>
									 <?php if(sizeof($or_items) >0) {?>
									 <table class="table table-striped table-bordered table-hover"  >
                                    <thead>
                                    <tr> <th> #</th>   <th> Item Name</th><th> Unit Price</th> <th> Discount</th> <th> Quantity</th>  <th> Sub Total</th>      </tr>
                                   </thead>
                                    <tbody>
									<?php $total=0;   foreach($or_items as $items){?>
									<tr> <td> <?php  echo $items['id']; ?></td><td> <?php  $item_name = $this->bio->Item_name( $items['id']);  if(sizeof($item_name) >0){ echo $item_name['name'].' , ' .$item_name['sname'].' , ' .$item_name['spec'];}?></td><td> <?php  echo $items['price']; ?></td><td> <?php  echo $items['disc']; ?></td> <td> <?php  echo $items['qty']; ?></td><td> <?php  echo $tot =   $items['qty']*$items['price']*(100 -$items['disc'])*0.01; $total +=$tot;  ?></td></tr>
									<?php } ?>
									
									<tr>  <td colspan = "5" > Total </td> <td> <?php  echo $total; ?></td>  </tr>
								
									</tbody>
									</table>
									 <?php } ?>
									 
									 </td>        </tr>
									<?php  } ?>
                  
                 
                                </tbody>
                                </table>
                            </div>
                            
                        </div>
                  
                   <?php    bio_footer();?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						  //else { ?>
						
						<!--  <h5><strong> Error : No data found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                
                       .
                            </div>
						-->
						  

								
							 <?php  // }
						
						?>
						</DIV>

                                 
    </div>
	 
	</div>
	
	
	</div>
	</DIV>
	
	<script src="<?php echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php echo base_url();?>assets/metro/js/dynamic-table.js"></script
	 
                                