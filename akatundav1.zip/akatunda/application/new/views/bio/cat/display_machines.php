<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			   $cats  =$this->bio->All_Machines_cats('' , 1 );
			     
				
			//	print_r($machines1);
		 

?>     
<div class="panel panel-default">
                        <div class="panel-heading">
                           <h4> 
							
							<?php
							
							if($decision ==1 ){
							    echo 'Recommended Items';
							   
						   }
						   else  if($decision ==2 ){
							    echo 'Featured Items';
						   }
						   
						   else if($decision ==3 ){
							 echo   'Available Items';
							   
							   
						   }
						   else if($decision ==4 ){
							 echo   'Cart Items';
							   
							   
						   }
						    else if($decision ==0 ){
							 echo   'Cart Items';
							   
							   
						   }
					   
							?>
							</h4>
                        </div>
                        
 
						<div class="panel-body"> 
								<div  id="cat_results" > </div>  
						  <?php 
						 //value of machines is determined in the controller
						  $cat_items =  $_SESSION['catin_items'];
					  $total = 0; 

						  if (sizeof( $machines) > 0  ){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_cat_items();' );
if($decision ==4  ){
	if(sizeof($cat_items) <1){
		bio_error('No item found <a  href="" class="" onclick =  "return Load_Cat_All();"  > Add items</a>');
	}
                              echo form_open('Form_loader/alt_cat_items', $attributes);
}
else  echo form_open('Form_loader/Add_cat_items', $attributes);
							  
					                ?>	
									 
						 <div class="panel-body">   
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Specifications</th> <th> Details</th> <th> Price</th> <th> Discount</th> <th> Category</th> <?php if($decision ==4  ){ ?><th> Quantity</th><th> Total</th><?php  } if($role  > 0) {echo '<th>Order</th>';}    if($role  < 1) { if($decision ==0  ){   ?> <th> Edit</th> <?php if($role  =='**') { ?> <th> Delete</th> <?php }   }} ?>  </tr>
                                   </thead>
                                    <tbody>
									<?php 
									if($decision ==4  ){
										
									
									foreach($cat_items as $cart ){
										
									
									
									foreach($machines as $row) {
										if($cart ==$row['id'] ){
											$total += $row['price'];
											$item_id= $this->encrypt->encode( $row['id']);
										
										?>
									
									 <tr> <td class="pnm cart_description"><?php echo $row['name'] ?> <input type= "hidden"   class ="cat_item" value ="<?php echo $item_id;?>"  name ="cat_item"  /> </td> <td> <?php echo $row['sname'] ?></td> <td> <?php echo $row['spec'] ?></td> <td>  <?php echo $row['desc'] ?></td> <td> <input type= "number" readonly value ="<?php echo $row['price'];?>"  name ="price"  />   </td> <td>  <?php echo $row['discount'] ?></td> <td> <?php  foreach($cats as $cat){  if($cat['id'] == $row['id']){echo  $cat['name'];} } ?> </td> <?php if($decision ==4  ){ ?><td> <input type= "number" value = "1" name ="quantity" class ="quantity" /> </td>  <td><input type= "text" value = "<?php echo $row['price'];?>"  readonly  class ="subtot" /> </td><?php  }     if($role  > 0) { ?>  <td><input type = "checkbox" name = "cat_item" value = "<?php    echo $item_id ; ?>" /><?php }  ?>  </td>  </tr>
									<?php 
										}
									} 
									}
									}
									else {
										
									foreach($machines as $row) {
									 
										
										?>
									
									 <tr> <td><?php echo $row['name'] ?></td> <td> <?php echo $row['sname'] ?></td> <td> <?php echo $row['spec'] ?></td> <td>  <?php echo $row['desc'] ?></td> <td>  <?php echo $row['price'] ?></td> <td>  <?php echo $row['discount'] ?></td> <td> <?php  foreach($cats as $cat){  if($cat['id'] == $row['id']){echo  $cat['name'];} } ?> </td>   <?php  if($role  > 0) { ?>  <td><input type = "checkbox" name = "cat_item_cat" value = "<?php    echo $this->encrypt->encode( $row['id']) ; ?>" /><?php }  ?>  </td>  <?php  if($role  < 1) { if($action > 0  ){   ?> <td> <button  type  ="button"    class = "edit_item_cate btn btn-mini btn-warning" value = "<?php    echo $this->encrypt->encode( $row['id']) ; ?>" > Edit </button></td> <?php if($role  =='**') { ?> <td> <button      class = "del_item_cate btn btn-mini btn-danger"  type ="button"  value = "<?php    echo $this->encrypt->encode( $row['id']) ; ?>" > Delete </button></td> <?php }   }}?></tr>
									<?php 
										}
										
										
									} 
									if($decision ==4  ){?>
									
                  
                 					  
    <td colspan="8" >TOTAL PRICE</td>
     
    <td colspan="2"><input type="text" class="grdtot cart_total_price " readonly  value = "<?php echo  $total;?>"   /> <br /><br />
	 Additional Information<textarea id ="order_info" rows ="5"    ></textarea> <br /><br />
	<button  class ="btn btn-info offset10" onclick="return Continue_to_cat();" >  SUBMIT THIS ORDER</button></td>
	 
    </tr>
									<?php }?>
                                </tbody>
                                </table>
								 
                            </div>
                            
                        </div>
                  
                   <?php   // bio_footer();?>
					 
										
										  
                                 
                                        
 
						<?php   
							
							
						}
						 else { ?>
						
						  <h5><strong> Error : No data found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                 No items found on the cart please add some.
								<a  href="" class="" onclick =  "return Load_Cat_All();"  >Add items</a>
                       .
                            </div>
						 
						  

								
							 <?php    }
						
						?>
						</DIV>

                                 
    </div>
	 
	 
	
	<script src="<?php echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php echo base_url();?>assets/metro/js/dynamic-table.js"></script>
   
    <script>
   $('.del_item_cate').click(function() {
            var item = $(this).attr("value");
			 
			BioCustom2( 'Form_loader' , 'Alt_cat_item' ,    item , 0 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
		
		$('.edit_item_cate').click(function() {
            var item = $(this).attr("value");
			 
			BioCustom2( 'Form_loader' , 'Alt_cat_item' ,    item , 1 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
   </script>
  
	 
                                