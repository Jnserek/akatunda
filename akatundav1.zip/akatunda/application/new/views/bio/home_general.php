
<?php
  $user  = $this->session->bio_id; 
 
 
				   
				     $execution  = $this->bio->Get_machine_status('' , $user , 1 , 0);
					   $pending  = $this->bio->Get_machine_status('' , $user , 1 , 0);
					//print_r($execution ); 

 //exit();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="biomedical equipment Inventry management system">
    <meta name="author" content="Pi village Uganda limited">
    <meta name="keyword" content="jms biomedical equipment management software">
    <link rel="shortcut icon" href="<?php  echo base_url();?>assets/img/photonBeta.png">
	<?php 
	echo meta(array('name' => 'robots', 'content' => 'no-cache'));
	//$this->bio->check_shifts();
	
	?>

    <title>HOME || BIOMEDICAL EQIPMENT SOFTWARE V1.0</title>

    <!-- Bootstrap CSS --> <?php  
        echo link_tag('assets/css/bootstrap.min.css');
		// <!--external css-->
        echo link_tag('assets/css/bootstrap-theme.css');
		//
        echo link_tag('assets/css/elegant-icons-style.css');
		//
       echo link_tag('assets/css/font-awesome.min.css');
	   //
        echo link_tag('assets/css/style.css');
		echo link_tag('assets/css/widgets.css'); 
		echo link_tag('assets/css/timeline-component.css'); 
		//
        echo link_tag('assets/css/style-responsive.css');
echo link_tag('assets/css/jquery-ui-1.10.4.min.css');
echo link_tag('assets/css/ionicons.min.css');
$user = $this->session->bio_id;	
 
		
?>

<style type="text/css">
            /* FROM HTTP://WWW.GETBOOTSTRAP.COM
             * Glyphicons
             *
             * Special styles for displaying the icons and their classes in the docs.
             */

            .bs-glyphicons {
                padding-left: 0;
                padding-bottom: 1px;
                margin-bottom: 20px;
                list-style: none;
                overflow: hidden;
            }
            .bs-glyphicons li {
                float: left;
                width: 25%;
                height: 115px;
                padding: 10px;
                margin: 0 -1px -1px 0;
                font-size: 12px;
                line-height: 1.4;
                text-align: center;
                border: 1px solid #ddd;
            }
            .bs-glyphicons .glyphicon {
                margin-top: 5px;
                margin-bottom: 10px;
                font-size: 24px;
            }
            .bs-glyphicons .glyphicon-class {
                display: block;
                text-align: center;
                word-wrap: break-word; /* Help out IE10+ with class names */
            }
            .bs-glyphicons li:hover {
                background-color: rgba(86,61,124,.1);
            }

            @media (min-width: 768px) {
                .bs-glyphicons li {
                    width: 12.5%;
                }
            }
        </style>
     
  </head>
  <body>

  <!-- container section start -->
  <section id="container" class="">
       <header class="header dark-bg"  >
	   <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
            </div>

            <!--logo start-->
            <a href="" class="logo">MEIMS <span class="lite"> SOFTWARE</span></a>
            <!--logo end-->

            <div class="nav search-row" id="top_menu">
                <!--  search form start -->
               <ul class="nav top-menu">                    
                    <li>
					        <?php 
                                $attributes = array('class' => 'navbar-form', 'id' => 'new_search', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return  My_search();' );

                              echo form_open('Form_loader/Search_Inventories', $attributes);
					  
					  

?>			      
                       	 
							 <input class="form-control" name ="search_inventory" placeholder="Search" type="text">
							<button class="btn btn-info btn-sm" type ="submit"   title="Bootstrap 3 themes generator">Search</button>
                        </form> 
                    </li>                    
                </ul>
                <!--  search form end -->                
            </div>
			<?php 
					 
//bio_id					
					$all_nots = $this->bio->Load_New($user , 1 , '');
					$all_shifts = array();
					if($this->session->bio_role  <1) {
					$all_shifts = $this->bio->Load_New($user , 2 , 1);
					}
					//print_r($all_shifts);
					
					
					?>

            <div class="top-nav notification-row">                
                <!-- notificatoin dropdown start-->
                <ul class="nav pull-right top-menu">
                    
                   <?php 
				   if($this->session->bio_role  <1) {
				   
				   $execution  = $this->bio->Get_machine_status('' , $user , 1 , 0);
					  $pending  = $this->bio->Get_machine_status('' , $user , 1 , 0);
					  
				   
				   ?> <!-- task notificatoin start -->
                    <li id="task_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="">
                            <span class="icon-task-l"></i>
                            <span class="label  <?php  if(sizeof($pending) > 0){?>label-warning <?php } else {?> label-info <?php } ?>"> <i class="fa fa-tasks"> <?php echo sizeof($pending); ?> </i></span>
                        </a>
                        <ul class="dropdown-menu extended tasks-bar">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have <?php echo sizeof($pending); ?> pending jobs</p>
                            </li>
                            
                            <li>
                                <a href="">
                                    <div class="task-info">
                                        <div class="desc">
                                            Jobs completed
                                        </div>
                                        <div class="percent"><?php  echo sizeof($execution);?></div>
                                    </div>
                                    
                                </a>
                            </li>
                            
                             
                            <li>
                                <a href="">
                                    <div class="task-info">
                                        <div class="desc">Execution Rate</div>
										<?php 
										$total = sizeof($pending) + sizeof($execution) ;
										if($total <1){$total =1; }
										 
										$rate =   (sizeof($execution) /($total))*100;
										
										?>
                                        <div class="percent"><?php echo $rate;?>%</div>
                                    </div>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar"  role="progressbar" aria-valuenow="<?php echo $rate;?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $rate;?>%">
                                            <span class="sr-only"><?php echo $rate;?>% Complete</span>
                                        </div>
                                    </div>

                                </a>
                            </li>
                            
                        </ul>
                    </li>
				   <?php } ?>
                    <!-- task notificatoin end -->
                    <!-- inbox notificatoin start-->
					
					<?php $chat_techs= $this->bio->All_techs('' ); 
					$chats_sums = $this->bio-> New_Chats($user , 0 ,$user , 6);
					?>
					<li id="mail_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="assets/#">
                            <i class="icon-envelope-l"></i>
                            <span class="label  <?php  if(sizeof($chats_sums) > 0){?>label-danger <?php } else {?> label-info <?php } ?>"> <i class="fa fa-envelope-o"> <?php  echo $chats_sums;
							$chats_sums = $this->bio-> New_Chats($user , 0 ,$user , 6);//New_Chats($sen , $sys , $rec , $no)
							
							
							?></i></span>
                        </a>
                        <ul class="dropdown-menu extended inbox">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">Chat with Techs.</p>
                            </li>
							
							<?php

 						$chat_techs= $this->bio->All_techs('' ); 
							 
							foreach($chat_techs as $row){
								if($user !=$row['id']){

							?>
                            <li>
                                <a href="assets/#">
								<div class="radio">
                                              <label>
                                                  <input type="radio"    name ="chats"  value="<?php echo $this->encrypt->encode($row['id']); ?>" onclick ="return my_chats();" >
									 <span class="photo"><img alt="avatar" src="<?php  echo base_url();?>assets/img/default.png"></span>
                                    <span class="subject">
                                    <span class="from"><?php echo $row['fname'].' '. $row['lname']; ?></span>
                                    <span class="time"><?php  echo  $this->bio-> New_Chats($user , 0 ,$row['id'] , 6)?></span>
                                    </span>
                                     </label>
												  </div>
                                </a>
                            </li>
								<?php } } ?>
                             
                             
                        </ul>
                    </li>
					
					<?php 
					$normal_users =  $this->bio-> All_Normal_users(''); 
					if($this->session->bio_role  <1) {?>
                    <li id="mail_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            
                            <span class="label label-info"> <i class="fa fa-comment-o">  <?php echo sizeof($normal_users);?> </i></span>
                        </a>
                        <ul class="dropdown-menu extended inbox">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue"> <?php //echo sizeof($normal_users);?> Chat with Users</p>
                            </li>
							<?php 
                            foreach($normal_users as $row){
								if($user !=$row['id']){

							?>
                            <li>
                                <a href="assets/#">
								<div class="radio">
                                              <label>
                                                  <input type="radio"    name ="chats"  value="<?php echo $this->encrypt->encode($row['id']); ?>" onclick ="return my_chats();" >
									 <span class="photo"><img alt="avatar" src="<?php  echo base_url();?>assets/img/default.png"></span>
                                    <span class="subject">
                                    <span class="from"><?php echo $row['fname'].' '. $row['lname']; ?></span>
                                     
                                    </span>
                                     </label>
												  </div>
                                </a>
                            </li>
								<?php } } ?>
                            
                             
                        </ul>
                    </li>
					<?php } ?>
                    <!-- inbox notificatoin end -->
                    <!-- alert notification start-->
					
                    <li id="alert_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="assets/#">

                            
                            <span class="label <?php  if((sizeof($all_nots) + sizeof($all_shifts)) > 0){?>label-warning <?php } else {?> label-info <?php } ?>"> <i class="fa fa-bell-o"> <?php  echo (sizeof($all_nots) + sizeof($all_shifts));?></i></span>
                        </a>
                        <ul class="dropdown-menu extended notification">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have <?php  echo (sizeof($all_nots) + sizeof($all_shifts));?> new notifications</p>
                            </li>
                            <li>
                                 <a href="" onclick =  "return Load_notifications();">
                                    <span class="label label-primary"><i class="icon_profile"></i></span> 
                                   Notifications
                                    <span class="small italic pull-right"><?php echo sizeof($all_nots);?></span>
                                </a>
                            </li>
							<?php  if($this->session->bio_role  <1) {?>
							<li>
                                 <a href="" onclick =  "return Load_notifications();">
                                    <span class="label label-primary"><i class="icon_profile"></i></span> 
                                   Jobs shifted to you
                                    <span class="small italic pull-right"><?php echo sizeof($all_shifts);?></span>
                                </a>
                            </li>
							<?php  } ?>
                            
                             
                        </ul>
                    </li>
                    <!-- alert notification end-->
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
						
                            <span class="profile-ava">
							
                     
                                
                            </span>
                            <i class="fa fa-user"> <span class="username label">     <?php   echo $this->session->bio_name; //echo $this->session->has_userdata('bio_name'); // print_r($this->session->has_userdata());?></span>
                            </i> <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            <li class="eborder-top">
                                <a href="" onclick =  "return Load_form1();"><i class="fa   fa-edit"></i> My Profile</a>
                            </li>
							
							
                            <li>
                                <a href=""  onclick =  "return Load_form11();"><i class="fa fa-unlock-alt  "></i> Change Password</a>
                            </li>
							
							<li>
                                <a href="Home/LogoutUser"><i class="icon_key_alt"></i> Log Out</a>
                            </li>

                           
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <!--header end-->

      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
			  
			  
              
                <ul class="sidebar-menu" id="sidebar-menu">  
			  <li class="active">
                      <a class="" href="">
                          <i class="fa fa-laptop"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
              
                  
				  <li class="sub-menu ">
                      <a href="#" class="">
                          <i class="icon_plus"></i>
                          <span>New</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub"  >
					  <?php if($this->session->bio_role  <1) {?>
                          <li><a   href="" onclick =  "return Load_client_add_form();">Client</a></li> 
                           <li><a   href="" onclick =  "return Add_supplier();">Supplier</a></li> 

                          <li><a   href="" onclick =  "return Add_manufacturer();">Manufacturer</a></li>  
						  
					  
						   <?php } ?>
						   <?php if($this->session->bio_role  >0) {?>
						  <li><a  href="" class="" onclick =  "return Department_addition();"  > Department</a></li>
						   <?php }?>
						   
						    <li><a   href="" onclick =  "return Add_Service_company();">Service Company</a></li> 
							<li><a   href="" onclick =  "return Add_Service_Tech();">Servicing Technician</a></li>
							
                      </ul>
                  </li> 
				  
				  <li class="sub-menu">
                      <a href="#" class="">
                          <i class="icon_document_alt"></i>
                          <span>List</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
					  <?php if($this->session->bio_role  <1) {?>
					  <li><a  href="" class="" onclick =  "return List_my_clients();"  >Clients</a></li>
					   <li><a   href="" onclick =  "return List_machine_suppliers();"> Suppliers</a></li>

						    <li><a   href="" onclick =  "return List_manufactureres();">Manufacturers</a></li>

					       <!-- <li><a   href="" onclick =  "return List_states();">Device States</a></li> 
						   
						   --> <?php if($this->session->bio_role  =='**') {?>
                           <li><a   href="" onclick =  "return List_users();">System Users</a></li>
						   <?php } ?>
						 <li><a  href="" class="" onclick =  "return Service_companies();"  >Service Companies </a></li>
						 
					   
						  
					  <?php } ?>
					  
					   <?php if($this->session->bio_role  >0) {?>
					   
                          <li><a   href="" onclick =  "return List_machine_suppliers();">Suppliers</a></li> 

                          <li><a   href="" onclick =  "return List_manufactureres();"> Manufacturers</a></li>
						  <li><a  href="" class="" onclick =  "return List_my_Machines();"  >Inventory</a></li>
						  
						   
						  
						  
						  
					  <?php } ?>
						  
                          
                      </ul>
                  </li> 
   
				  
				  <li class="sub-menu">
                      <a href="#" class="">
                          <i class="fa  fa-wrench"></i>
                          <span>Manage</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
					  <?php if($this->session->bio_role  <1) {?>
					  
					  <li><a  href="" class="" onclick =  "return List_client();"  >Clients</a></li>
					  
                          
						  <li><a   href="" onclick =  "return Get_machine_suppliers();">Suppliers</a></li>

						    <li><a   href="" onclick =  "return Get_machine_manufactureres();">Manufacturers</a></li>
							<li><a  href="" class="" onclick =  "return Load_my_hospitals();"  >Client's Inventory</a></li>

					  <!-- <li><a   href="" onclick =  "return Get_machine_states();">Device States</a></li> -->
					  <li><a  href="" class="" onclick =  "return Manage_companies();"  >  Service Companies</a></li>

					   
					   <?php if($this->session->bio_role  =='**') {?>
                      
					  
						  
					  <?php } } ?>
					  
					   <?php if($this->session->bio_role  >0) {?>
					   
						  <li><a  href="" class="" onclick =  "return Load_my_departments();"  >Departments</a></li>
						  <li><a  href="" class="" onclick =  "return Load_Alocations();"  >Allocate</a></li>
						   <li><a  href="" class="" onclick =  "return Load_Transfers();"  >Transfer</a></li>
						  
                          <li><a   href="" onclick =  "return Get_machine_suppliers();">Suppliers</a></li> 

                          <li><a   href="" onclick =  "return Get_machine_manufactureres();"> Manufacturers</a></li> 
						    <li><a  href="" class="" onclick =  "return Load_my_Machines();"  >Inventory</a></li>
						   
					  <?php } ?>
					  
					  
					   <li><a  href="" class="" onclick =  "return Load_my_Machines_reports();"  >Device  States</a></li>
						  <?php if($this->session->bio_role  <1) {?>
						   <li><a  href="" class="" onclick =  "return Manage_Cat();"  >Cat Items</a></li>
						  
						  <?php  } ?>
						  
                          
                      </ul>
                  </li> 
				  
				    
				  
				  
				  
				  <!--  <li class="sub-menu">
                      <a href="#" class="">
                          <i class="icon_genius"></i>
                          <span> Managex </span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">

					  <?php if($this->session->bio_role  >0) {?>
						  <li><a  href="" class="" onclick =  "return Load_my_departments();"  >Departments</a></li>
						  <li><a  href="" class="" onclick =  "return Load_my_Machines();"  >Machines</a></li>
						   <?php } else {?>
						   <li><a  href="" class="" onclick =  "return Load_my_hospitals();"  >Clients</a></li>
						   
						  <li><a   href="" onclick =  "return Get_machine_suppliers();"> Suppliers</a></li>

						    <li><a   href="" onclick =  "return Get_machine_manufactureres();"> Manufacturers</a></li>
						   
						   
						   
						   <?php }?>


					   <li><a  href="" class="" onclick =  "return Load_my_Machines_reports();"  >Device  States</a></li>
					  <?php if($this->session->bio_role  >0) {?>
						 
						  <li><a  href="" class="" onclick =  "return Load_my_Machines();"  >My Inventory</a></li>
						   <?php } else {?>
						   <li><a  href="" class="" onclick =  "return Load_my_hospitals();"  >Client's Inventory</a></li>
						   
						   
						   
						   <?php }?>


						    <?php if($this->session->bio_role  >0) {?>
						  <li><a  href="" class="" onclick =  "return Load_my_departments();"  >My Departments</a></li>
						  <li><a  href="" class="" onclick =  "return Load_my_Machines();"  >My Inventory</a></li>
						   <?php } ?> 
                        
                      </ul>
                  </li> -->
				    
                   <li class="sub-menu">
                      <a href="#" class="">
                          <i class="fa fa-tags"></i>
                          <span> Reports </span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
					      
					   <li><a   href="" onclick =  "return List_problems();">All Jobs</a></li> 
					   <li><a   href="" onclick =  "return List_Pending();">Tech Pending</a></li>
					   <li><a   href="" onclick =  "return Load_search();">Search</a></li>
					   <li><a   href="" onclick =  "return Load_reports();">Reports</a></li>
                         
						
			 
					     
                      </ul>
                  </li>
				   
                  
				  
				  <li>                     
                      <a class="" href="" onclick =  "return Load_machine_lyfe_data();">
                          <i class="icon_piechart"></i>
                          <span>Machine life</span>
                          
                      </a>
                                         
                  </li>
				  
				  
				  
				   <li class="sub-menu">
                      <a href="#" class="">
                          <i class="fa   fa-shopping-cart"></i>
                          <span> Catalogue </span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
					  <?php if($this->session->bio_role  <1) {?>
					  
							
							
							
							<li class="eborder-top">
                                <a href="" onclick =  "return Load_Item_addition_form();">  Add Single Item</a>
                            </li>
							 
					   <li><a  href="upload" class=""   >Upload Items</a></li>
					  <?php } ?>
					  
					  
						  <li><a  href="" class="" onclick =  "return Load_Cat();"  >Recommended Items</a></li>
						   <li><a  href="" class="" onclick =  "return Load_Cat_fet();"  >Featured</a></li>
						    <li><a  href="" class="" onclick =  "return Load_Cat_All();"  >All Machines</a></li>
							 <?php if($this->session->bio_role  >0) {?>
							<li><a  href="" class="" onclick =  "return Load_Cart();"  >My Cart items</a></li>
							
							 <?php  } ?>
							 <li><a  href="" class="" onclick =  "return Load_Cart_Hist();"  >Shopping History</a></li>
						 
                        
                      </ul>
                  </li>
				  <?php if($this->session->bio_role  =='**' ) { //=='**'?> 
				  
				  <li class="sub-menu">
                      <a href="#" class="">
                          <i class="fa fa-user"></i>
                          <span> User </span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
					   <li class="eborder-top">
                                <a href="" onclick =  "return Load_Create_acc();">  New User</a>
                      </li>
					  <li><a   href="" onclick =  "return Sys_users();"> Users</a></li> 
					  <li><a   href="" onclick =  "return Active_users();">Active Users</a></li> 
					  <li><a   href="" onclick =  "return Idle_users();">Idle Users</a></li> 
					  
					  
					     
                      </ul>
                  </li>
				  
				  
				  <li class="sub-menu">
                      <a href="#" class="">
                          <i class="fa fa-cogs"></i>
                          <span> Database </span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
					    
					  <li><a   href="" onclick =  "return System_backup();"> Backup</a></li> 
					  <li><a   href="" onclick =  "return List_backup_files();">List Obsolete</a></li> 
					  <li><a   href="" onclick =  "return List_backup_file_deletion();">Delete Obsolete </a></li> 
					     
                      </ul>
                  </li>
				  
				    <li class="sub-menu">
                      <a href="#" class="">
                          <i class="fa fa-asterisk"></i>
                          <span> Settings </span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
					     
					  <li><a   href="" onclick =  "return List_Settings();">List Settings</a></li>   
                     
						
			 
					     
                      </ul>
                  </li>
				   
				  <?php  } ?>
				  
				  
                  
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->

      <!--main content start-->
	  
	  
	     <div class=" col-lg-12"      id="Confirm1"  > </div><br />
		      <div class=" row"   align="center"   id="Loader"  style=" padding : 10px;   
   
    overflow: hidden;
    position: relative;
    margin: 0 auto;
    color: #ececec;" > </div>
			  
 
      <section id="main-content" class=" row " style=" padding : 20px;  padding-top :60px; min-height:700px;  overflow-y:scroll;      overflow-x:scroll ; overflow: hidden;    ">
          <section class="wrapper">
		 

			  
               
				 
					 
					<ol class="breadcrumb">
					 
						  <li><i class="fa fa-home"></i><a href="">Home</a></li>
						 
						 
					</ol>
					</ol>
				 
			 
              <div class="col-lg-12"  id="Content_loader"  >
			  
					 
<?php 
$role  =   $this->session->bio_role;
if($role > 0){
$problem =  $this->bio->Get_machine_prob_by_hospital($role , 0);
//print_r($problem);//
}




if($this->session->bio_role  <1) {
					  $missing = $this-> bio-> Missing_depreciation_rates(0);
					
					  
					  
					  ?>
				 
				<div class="col-lg-3 col-md-3  ">
					<div class="info-box green-bg">
						<i class="fa fa-shopping-cart"></i>
						<div class="count"><?php echo $this->bio-> Orders( 0 , '');?></div>
						<div class="title">New Orders</div>							
					</div><!--/.info-box-->			
				</div><!--/.col-->
				
				
				<div class="col-lg-3 col-md-3  ">
					<div class="info-box dark-bg">
						<i class="fa fa-check-square-o"></i>
						<div class="count"><?php echo $this->bio-> Orders( 1 , '');?></div>
						<div class="title"> Orders Reviewed</div>						
					</div><!--/.info-box-->			
				</div><!--/.col-->
				
				<div class="col-lg-3    ">
					<div class="info-box green-bg">
						<i class="fa fa-cubes"></i>
						<div class="count"><?php  echo $this->bio-> Cat_summaries( 1 , '' , '');?></div>
						<div class="title">Stock</div>						
					</div><!--/.info-box-->			
				</div><!--/.col-->
				  <?php } ?>
				
				<div class="col-lg-3  col-md-3  ">
					<div class="info-box green-bg">
						<i class="fa  fa-thumbs-o-up"></i>
						<div class="count"><?php  echo $this->bio-> Cat_summaries( '' , '' , 1);?></div>
						<div class="title">Recommended</div>						
					</div> 			
				</div>
				<?php if($this->session->bio_role  >0) { ?>
				<div class="col-lg-3  col-md-3  ">
					<div class="info-box green-bg">
						<i class="fa  fa-thumbs-o-up"></i>
						<div class="count"><?php  echo  $this->bio-> Count_machines($this->session->bio_role , 1);?></div>
						<div class="title">Functional</div>						
					</div> 			
				</div>
				<div class="col-lg-3  col-md-3  ">
					<div class="info-box orange-bg">
						<i class="fa  fa-thumbs-o-up"></i>
						<div class="count" style="font-size:12px;" > <?php  echo ($this->bio-> Count_machines($this->session->bio_role , 2) + $this->bio-> Count_machines($this->session->bio_role , 3));?>
						
						</div>
						<div class="title" style="font-size:12px;" > Faulty but repairable <?php  echo $this->bio-> Count_machines($this->session->bio_role , 2);?> <br /><br />
						Functional But Need service <?php  echo $this->bio-> Count_machines($this->session->bio_role , 3);?></div>						
					</div> 			
				</div>
				<div class="col-lg-3  col-md-3  ">
					<div class="info-box red-bg">
						<i class="fa  fa-thumbs-o-up"></i>
						<div class="count"><?php  echo $this->bio-> Count_machines($this->session->bio_role , 7);?></div>
						<div class="title">Non Functional</div>						
					</div> 			
				</div>
				 
				<?php }  if($this->session->bio_role  <1) {?>
				


				  <?php } ?>


				 
				</div>
				
				</div> 
				<div class="row">
                  <div class="col-lg-6" style="  padding:10px;   ">
				  
				  
				  <!--collapse start-->
                      

				  
				   <div class="panel-body">
                        <div class="panel panel-primary">
                           <div class="panel-heading"> Service Details</div>
						   <div class="panel-content" style="  padding:10px; "> 
			<?php 
			 
			
			         $this->load->helper('validate');
					 
			
			 
			
			?>   
                            <div class="row-fluid" style=" padding : 20px;     max-height: 350px;
  overflow: auto; " >
							 
                           <ul class="metro_tmtimeline"             >
				 <?php 
				 
				  $machines =$this->bio-> get_departmental_machines('' , $this->session->bio_role );
				   $machine_datax =$this->bio->  compute_machine_lyfe($machines);
				  
				 
				 $dated = $this->bio-> service_dates($this->session->bio_role , '*') ;
				 // print_r($dated);
				 if(sizeof($dated) < 1){
				 	echo 'No Date found';

				 }else {
				 
				 
				 foreach ($dated as $row){ 
				  $next_date  = AddMonths($row['dates'] , 6);
				  $interval  = dateDiff(timeCurrent2(), $next_date);
				  $hfacility =  $row['hf'];
				 
				  
				  if( $interval > 30){
					  echo '<li class="green">';
					  
				  }
				  else if( $interval > 15 and $interval < 31){
					  echo '<li class="yellow">';
					  
				  }
				  
				  
				   else if( $interval > 5 and $interval < 16){
					  echo '<li class="orange">';
					  
				  }
				  
				  
				   else if(   $interval < 5){
					  echo '<li class="blue">';
					  
				  }
				 ?>
                        
                                               <div class="metro_tmtime"  >
                                                   <span class="date"> Date: </span>
                                                    <span class="time" ><?php echo $row['dates']; ?></span>
                                                  </div>
                                                 <div class="metro_tmicon">
                                                      <i class="icon-bell"></i>
                                                  </div>
                                               <div class="metro_tmlabel">
                                                   <h2>Next Date of service  <?php    echo  $next_date;?></h2>
								                    <h2>Days Remaining  : <?php    echo  $interval;?></h2>
								                   <p>  <?Php 
								                    IF($this->session->bio_role < 1){
														 if(sizeof( $hfacility) > 0){
															// print_r($hfacility);
					  
				  
								
								
								                    echo 'CLIENT NAME: '.$hfacility[0]['name'].' '.$hfacility[0]['ln'];
														 }
								                    }								
								
								
								           ?></p>
                                
								                     <a class="btn" href="#"> Read more <i class="icon-circle-arrow-right"></i>  </a>
                                                       </div>
                                                   </li>
				 <?php } }  ?>
                        
                         
                                          </ul>
                                 </div>
			
			               </div>
                          </div>
						</DIV>
				  
				  
                  </div> 
              <div class="col-lg-6">
			  
		<!--service details in a row-->
		<?php  $this->bio->scheduler(0); ?> 
		 <!--machine life from here--> 
				  
				  
				   <?php if($this->session->bio_role  <1) {?>
                      <section class="panel">
                          <header class="panel-heading tab-bg-primary">
                              <ul class="nav nav-tabs">
                                  
                                  <li class="active">
                                      <a data-toggle="tab" href="#about-2">
                                          <i class="icon-user"></i>
                                          Machine Life
                                      </a>
                                  </li>
                                  <li class="">
                                      <a data-toggle="tab" href="#contact-2">
                                          <i class="icon-envelope"></i>
                                          Jobs In Queue
                                      </a>
                                  </li>
                              </ul>
                          </header>
                          <div class="panel-body">
                              <div class="tab-content">
                                  
                                  <div id="about-2" class="tab-pane active">
								  	  
			     <?php  $list_pie  =''; $list_bar  =''; ?>
			 
			        <div class="panel-body" >
                        <div class="panel panel-primary" style="   padding-bottom:2px;">
                           <div class="panel-heading"> Machine Life <a class="btn" href="" onclick =  "return Load_machine_lyfe_data();"> Read more <i class="icon-circle-arrow-right"></i>  </a></div>
                               
			                     <div id="piechart" style="height:310px; padding-top:2px; padding-bottom:2px;"></div>
					        
                          </div>
						</DIV>
								  
								  
								  </div>
                                  <div id="contact-2" class="tab-pane ">
								  
								  <section class="panel">
                          <header class="panel-heading">
                            New Jobs
                          </header>
                          <div class="panel-body" style=" padding : 20px;     max-height: 350px;
  overflow: auto; ">
						  
						  <?php $problems =  $this->bio-> Get_machine_problems_states( 0);
						   
						  for($i =0; $i<sizeof( $problems); $i++){
							  if($i <6){
							
							 if($problems[$i]['date_shifted'] > 0){
								echo ' <div class="alert alert-warning fade in">'; 
							 }
							 else   if($problems[$i]['diff'] > 0){
								echo ' <div class="alert alert-warning fade in">'; 
							 }
							 else echo ' <div class="alert alert-info fade in">';
						  
						  ?>
                           
                                  <button data-dismiss="alert" class="close close-sm" type="button">
                                      <i class="icon-remove"></i>
                                  </button>
                                  <strong> <?php  echo $problems[$i]['machine'];?>  </strong> Date: <?php  echo ucfirst($problems[$i]['reported']);?> <br />
								  <?php  echo $problems[$i]['prob'];?> <br />
								  
								   <?php $tech  =  $problems[$i]['tech'];
								   if(sizeof($tech) > 0){
									   
									   echo $tech[0]['fname'].' '.$tech[0]['lname']; 
								   }
								   
								   
								   ?>
                              </div> 
						  <?php  } }?>							  
                                                            
                               

                          </div>
                      </section>
					  
					 
								  
								  
								  
								  </div>
                              </div>
                          </div>
                      </section><?php }  
					  
					  $role  =   $this->session->bio_role;
 
$problem =  $this->bio->Get_machine_prob_by_hospital($role , 0);
$missingx =  $this->bio->Update_department_types();
 

 


?>
 <section class="panel panel-primary">
                          <header class="panel-heading tab-bg-primary ">
                              <ul class="nav nav-tabs">
                                  
                                  <li class="active">
                                      <a data-toggle="tab" href="#about-3">
                                          <i class="icon-user"></i>
                                          Reported Problem.
                                      </a>
                                  </li>
                                  
                              </ul>
                          </header>
                          <div class="panel-body">
                              <div class="tab-content">
                                  
                                  <div id="about-3" class="tab-pane active">
								  	  
			     <?php   ?>
			 
			        <div class="panel-body" >
                     
						<?php   ?>
						 <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr>  <th> Device</th>   <?php if($this->session->bio_role  <1) {?> <th>Client</th> <?php } ?>  <th> Department</th>  <th>  Problem</th>         </tr>
                                   </thead>
                                    <tbody>
									<?php // print_r($problem); 
									foreach($problem as $prob){
										$department = $this->bio->get_my_department( $prob['dpt']);
										$dp_name  = '';
										$hosp_name  = '';
										if(sizeof($department) > 0){
											$dp_name  = $department['dname'];
											
										}
										
										 
									?>
									<tr> <td> <?php echo $prob['machine'] ?></td> <?php if($this->session->bio_role  <1) {?> <td>  <?php echo $prob['client'].' , '.$prob['location'].' , '.$prob['email'].' , '.$prob['phone']; ?></td> <?php } ?><td>  <?php  echo $dp_name; ?></td> <td> <?php echo $prob['prob'] ?></td></tr>
									<?php } ?>
									</tbody>
									</table>
                                 
					        
                         
						</DIV>
								  
								  
								  </div>
                                  <div id="contact-2" class="tab-pane ">
								  
								  <section class="panel">
                          <header class="panel-heading">
                            New Jobs
                          </header>
                          <div class="panel-body">
						  
						                                  
                               

                          </div>
                      </section>
					  
					 
								  
								  
								  
								  </div>
                              </div>
                          </div>
                      </section>
					  

 
					   </div>
				  
				  <!--machine life from here-->
                      
					 
			  
			  <br><br>


		
		
                      
					  </div>

					  
			  
			  
               </div>
          </div> 
				 

 
				 


                   </div>
          </section>
      </section>
	  <div class="widget-foot" style="  
    position: bottom;
     text-align: center;
    padding: 30px 0;
    margin-top: 70px;
    border-top: 1px solid #e5e5e5;
    background-color: #000000;
">  BIOMEDICAL EQUIPMENT EVENTRIRY MANAGEMENT SOFTWARE (BEIMS) powered by Joint Medical Store and developt by PiVillage uganda limited.
                  </div>
      <!--main content end-->
  </section>
  <!-- container section end -->

    <!-- javascripts -->
   <script src="<?php  echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
   
	 <script src="<?php  echo base_url();?>assets/js/bootstrap.min.js"></script>
	  <script src="<?php  echo base_url();?>assets/js/biomedical.js"></script>
   
    <!-- nice scroll --> 
    <script src="<?php  echo base_url();?>assets/js/jquery.nicescroll.js" type="text/javascript"></script>
	
    <!-- gritter -->
   
    <!-- custom gritter script for this page only-->
    <script src="<?php  echo base_url();?>assets/js/gritter.js" type="text/javascript"></script>
    <!--custome script for all page-->
    <script src="<?php  echo base_url();?>assets/js/scripts.js"></script>
	
	
	 <!-- chart libraries start --> 
<script src="<?php  echo base_url();?>assets/charts/bower_components/flot/jquery.flot.js"></script>
<script src="<?php  echo base_url();?>assets/charts/bower_components/flot/jquery.flot.pie.js"></script> 
  
<!-- chart libraries end --> 

  
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script>

	
	
	<script>
	$("#sidebar-menu > li > a").click(function () {
    $('ul.sub').not($(this).siblings()).slideUp();
    //$(this).siblings("ul.sub").slideToggle();
});


 


//chart with points
if ($("#sincos").length) {
    var sin = [], cos = [];

    for (var i = 0; i < 14; i += 0.5) {
        sin.push([i, Math.sin(i) / i]);
        cos.push([i, Math.cos(i)]);
    }

    var plot = $.plot($("#sincos"),
        [
            { data: sin, label: "sin(x)/x"},
            { data: cos, label: "cos(x)" }
        ], {
            series: {
                lines: { show: true  },
                points: { show: true }
            },
            grid: { hoverable: true, clickable: true, backgroundColor: { colors: ["#fff", "#eee"] } },
            yaxis: { min: -1.2, max: 1.2 },
            colors: ["#539F2E", "#3C67A5"]
        });

    function showTooltip(x, y, contents) {
        $('<div id="tooltip">' + contents + '</div>').css({
            position: 'absolute',
            display: 'none',
            top: y + 5,
            left: x + 5,
            border: '1px solid #fdd',
            padding: '2px',
            'background-color': '#dfeffc',
            opacity: 0.80
        }).appendTo("body").fadeIn(200);
    }

    var previousPoint = null;
    $("#sincos").bind("plothover", function (event, pos, item) {
        $("#x").text(pos.x.toFixed(2));
        $("#y").text(pos.y.toFixed(2));

        if (item) {
            if (previousPoint != item.dataIndex) {
                previousPoint = item.dataIndex;

                $("#tooltip").remove();
                var x = item.datapoint[0].toFixed(2),
                    y = item.datapoint[1].toFixed(2);

                showTooltip(item.pageX, item.pageY,
                    item.series.label + " of " + x + " = " + y);
            }
        }
        else {
            $("#tooltip").remove();
            previousPoint = null;
        }
    });


    $("#sincos").bind("plotclick", function (event, pos, item) {
        if (item) {
            $("#clickdata").text("You clicked point " + item.dataIndex + " in " + item.series.label + ".");
            plot.highlight(item.series, item.datapoint);
        }
    });
}
 

//pie chart
var data = [ <?php echo $machine_datax['pie_chart_data']; ?>
 
];

if ($("#piechart").length) {
    $.plot($("#piechart"), data,
        {
            series: {
                pie: {
                    show: true
                }
            },
            grid: {
                hoverable: true,
                clickable: true
            },
            legend: {
                show: false
            }
        });

    function pieHover(event, pos, obj) {
        if (!obj)
            return;
        percent = parseFloat(obj.series.percent).toFixed(2);
        $("#hover").html('<span style="font-weight: bold; color: ' + obj.series.color + '">' + obj.series.label + ' (' + percent + '%)</span>');
    }

    $("#piechart").bind("plothover", pieHover);
}


 

 


</script>  
	<script>
	
	setInterval("my_function();",250);
    function my_function(){
		TestRefresh();
		 
      
	   $('#refreshx').load(location.href + ' #refreshy');
	   
    }
				
    
	function TestRefresh(){//my search function
   // var ba = $('#base').val();
 
	var url2 = <?php echo base_url();?>+"index.php/Form_loader/";
	 
	   var request = $.ajax({ url: url2+'Loading', type: "POST", data: { check : 1  ,  check2: 2  },    dataType: "html"               });
//analyse response 
               request.done(function( reply ) {if(reply){
				   if(reply!=2){   window.location.href =  url2; }else {
					  
					 
						 
				   } 
			      
				 
			   
			  
			   } });
	 
 
 return false;
	 
 }
 
                </script>
				<input id="pi_url"  value ="<?php echo base_url();?>index.php/"  type="hidden">
				
                
                 <h1> <div id="refreshx"> <div id="refreshy">   </div>  </div> </h1>
    
 

  </body>
</html>
