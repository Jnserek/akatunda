
<?php 
$id = $this->encrypt->decode($_SESSION['mcn_field_id']);
$machine = $this->bio->Specific_machine_problems($id);
if(sizeof($machine) <1){ exit('Invalid data supplied');}
 $attributes = array('class' => 'form-horizontal', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>' return machine_problem();' );

     if($action >0) { echo form_open('System_controls/Edit_machine_problem', $attributes);
	 }
	 else {
		 echo form_open('System_controls/Delete_machine_problem', $attributes);
		 
	 }
	  

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel"> 
									<?php if($action >0) {?>
									
                                          <div class="panel-body bio-graph-info">
                                              <h4> Machine problem</h4>
                                              <form class="form-horizontal" role="form">                                                  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Problem description</label>
													  <div class="col-lg-6">
													  <textarea  class="form-control" name="f-name"    required >
													  <?php  if(set_value('f-name')) { echo set_value('f-name');} else echo  trim($machine[0]['prob']); ?>
													  </textarea>
                                                          
													  </div>
													   
													  <br /> <?php echo form_error('f-name'); ?>
                                                  </div>
                                                  
									<?php } else {?>
									 <div class="col-lg-12">
									 <h4> Click submit to finish this action. </h4>
									 
									 </div>
									
									<?php } ?>
												  
												  <?php  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									  </form>
									  
									   