
<?php 
  $attributes = array('class' => 'form-horizontal', 'id' => 'new_machine', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );

      echo form_open('System_controls/Service_entry', $attributes);

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h4> Service Report</h4>
                                            
											  
											    <div class="form-group">
                                                      <label class="col-lg-2 control-label">Current State </label>
                                                      <div class="col-lg-6">
                                                          
														   
										  
										                <select class="form-control" name ="state1"  required >
											               <option value ="">Select</option>
											               <?php  
											                $mstates  =$this->bio->All_machine_states();
											
											
											                for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
                                                 
                                                           </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('state1'); ?>
                                                  </div>
												  
												  

											  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Comment</label>
													  <div class="col-lg-6">
													  <textarea  class="form-control" name="comment"    >
													  <?php echo set_value('comment'); ?>
													  </textarea>
                                                           
                                                         
													  </div>
													   
													  <br /> <?php echo form_error('comment'); ?>
                                                  </div>
												  
												  
												  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Way forward</label>
													  <div class="col-lg-6">
													  <textarea  class="form-control" name="way_foward"    >
													  <?php echo set_value('way_foward'); ?>
													  </textarea>
                                                           
                                                         
													  </div>
													   
													  <br /> <?php echo form_error('way_foward'); ?>
                                                  </div>
												  
												  
                                                  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">New State </label>
                                                      <div class="col-lg-6">
                                                          
														   
										  
										                <select class="form-control" name ="state"  >
											               <option value ="">Select</option>
											               <?php  
											                $mstates  =$this->bio->All_machine_states();
											
											
											                for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
                                                 
                                                           </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('state'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Name of Technician</label>
													  <div class="col-lg-6">
													     <select class="form-control" name ="technician_name"  >
											               <option value ="0" > Free lancer</option>  
											                
											                <?php  
											                $mstates  =$this->bio->Servicing_techs('');
															 
											               ?>
											             
											               <?php  
											                  for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
														   
														   
                                                 
                                                           </select>    
                                                         
													  </div>
													   
													  <br /> <?php echo form_error('tech'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Service company.</label>
													  <div class="col-lg-6">
													    <select class="form-control" name ="comp"  >
											               <option value ="0" > Free lancer</option>  
											                
											                <?php  
											                $mstates  =$this->bio->Servicing_company('');
															 
											               ?>
											             
											               <?php  
											                  for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
														   
														   
                                                 
                                                           </select>
                                                           
                                                         
													  </div>
													   
													  <br /> <?php echo form_error('comp'); ?>
                                                  </div>
												  
												 
												  
												  
												   
												  
												   
												  
												  <?php  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									  </form>
									  
									   