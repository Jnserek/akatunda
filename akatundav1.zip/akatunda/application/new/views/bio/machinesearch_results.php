<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			    //$machines1  =$this->bio->Machines_search();
				$supliers   =$this->bio->Supplier_search();
				$manuf   =$this->bio->Manufacturer_Search();//machinesearch_results.php
				$hosp   =$this->bio-> All_Hospitals();
				$sup_loop   = $this->bio-> Suppliers_All ();
				$machines_loop   = $this->bio-> Machines_bank_All();
				$man_loop   = $this->bio->Manufacturers_All();
				
			//	print_r($machines1);
		 

?>     
<div class="panel panel-default table-responsive">
                        <div class="panel-heading  ">
                               <h4> Search Results </h4>
                        </div>
                          
						  <?php 
						 //value of machines is determined in the controller
					 

						  if (sizeof( $machines) > 0){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal ', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_new_machines_to_dpts();' );

                              echo form_open('Form_loader/machine_entry_one', $attributes);
							  
					                ?>	
									  
                            <div class="table-responsive">
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Model</th> <th> Sno</th><th> Manufa -<BR/>cturer</th><th> Mfgd: Yr</th><th> Country</th><th> Supplier</th><th> Department</th> <?php if($role< 1)  echo '<th> Client</th> ';?><th> Status</th>     <th> REPORT  <BR />A PROBLEM</th><th> #SERVICE REPORT</th> <th> #SERVICE</th> <th> #DETAILS</th>      </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php

								//for($k=0; $k<sizeof($machines); $k++){ 
								$k =-1;
								foreach( $machines as $mac){ 
								
								//$mac  = $machines[$k];
								if(sizeof($mac) <1){print_r($mac); exit();}
								$display = 1;
							      if($role >  0){ //if this is normal user
									  if($mac['hf'] !=$role ){ //check his hf against role
										$display = 0;
										 
										
									  }
									  
								  }
								  
								  	if($display >0){
$k +=1;							
								
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufacturers and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1;?>  </td>
								 <td>  <?php  echo ucfirst($macn_name);?></td>
								 
								 <td>  <?php  
								   IF($mac['mod'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['mod']));
								   
								   ?> 
								   </td>
								 <td>  <?php  
								   IF($mac['sn'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['sn']));
								   
								   ?> 
								   </td>
								 <td>   <?php  echo ucfirst($man_name);?> </td>
								
								  <td>  <?php  echo $mac['yr'];?> </td>
								   
								   <td>  <?php  
								   IF($mac['cou'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['cou']));
								   
								   ?> 
								   </td>
								   <td>   <?php  echo $sup_name;?> </td>
								  <?PHP  
								
								 
												    for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														    echo ' <td>'.  ucfirst(strtolower($item['dname'])) .' </td>'; 
														   }															
												        }
														
														 if($role <  1){ echo '<td>';
														 
															
															for($d=0; $d<sizeof($hosp ); $d++ ){
													 
													       $item = $hosp[$d];
														   if($mac['hf'] == $item['id'] ){
														    echo '  '.  ucfirst(strtolower($item['name'])) .'  '; 
														   }															
												        }
														echo '</td>';
														 }	
															
														 
								
								
							 ?>
								  
								 <td>   
								 
											<?php 
 										
											$mstates  =  $this->bio->All_machine_states();
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($mac['ms'] ==  $dt['id']){
												echo  ucfirst(strtolower($dt['name']));
												}
											}?>
                                                 
                                         

								 </td>
								 
								    
								   <?php     ?>
								  <td>   <input type ="radio" name ='report' value ="<?php echo $mac['mid'] ?>" onclick="return Report_problem();"  />  </td>
								   <td>  <?php   
								   
								    $mstates  =  $this->bio-> pending_requests($this->encrypt->decode($mac['mid']));
								  if($mstates  < 1){
									  echo 'N/A';
								  }
									  
								  
								  else { ?>
								   <input type ="radio" name ='service' value ="<?php echo $mac['mid'] ?>" onclick="return Service_report();"  />  </td>
								 
								  <?php
									  
								  }
								   
								   
								   ?> 
								      
								   
								   
								   </td>
								    <td>   <input type ="radio" name ='do_service' value ="<?php echo $mac['mid'] ?>" onclick="return Field_service();"  /> </td>
									 <td>   <input type ="radio" name ='do_hist' value ="<?php echo $mac['mid'] ?>" onclick="return Machine_hisory();"  />  </td>
                                
                                    								 
								   <?php    ?>								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php  } }?>
                 
                                </tbody>
                                </table>
                           
                             
						</DIV>
						<hr />
                  
                   <?php    bio_footer();?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No data found </strong></h5>
                             
						
						  

								
							 <?php  }
							  
						
						?>

           
	
	 
	</DIV>
	
	<script src="<?php echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php echo base_url();?>assets/metro/js/dynamic-table.js"></script
	 
                                