
              <?php 
			  	 $role = $this->session->userdata('bio_role');
											 
                       
                 $departments  =$this->bio->get_hospital_departments($role);
											 if(sizeof($departments) <1){
												 
												 warning('no departments found, PLease first add departments then you will add machines to them to continue');
												 exit();
											 } 					   

?>			    <div class="panel panel-default"  >
                        <div class="panel-heading">
                            <h4> My Departments.</h4>
                        </div>
                        
 
						<div class="panel-body"  >  
								 <div class="table-responsive stretch"   >
                          
                          <table class="table table-striped table-advance table-hover" id="sample_1">
                           <thead>
                              <tr>
                                 <th><i class="fa fa-folder-open"></i> Name</th>
								 <th><i class="fa fa-folder-open"></i> Department Type</th>
                                 <th><i class="fa fa-stethoscope"></i> #Machines</th>
                                 <th><i class="fa fa-thumbs-o-up"></i> #Functional</th>
                                 <th><i class="fa fa-warning"></i> #Outdated</th>
                                 <th><i class="fa  fa-plus-circle"></i>Add New</th>
                                 <th><i class="fa  fa-folder-open-o"></i> Inventory</th>
								   <th><i class="fa fa-pencil"></i> Edit</th>
                              </tr>
							  </thead>
							   <tbody>
							  
							   <?php 
							   	$dep_types =  $this->bio-> department_types();
										
											 
											 
											  $department_type       = 'Unknown';
											 for($k=0; $k<sizeof($departments); $k++ ){
												 
											 
													 
													       $item = $departments[$k];
														   $dtype = $item['dtype'];
														   
															   $department_type       = 'Unknown';
															   
														   
															   foreach($dep_types as $row){
										                            if($row['id'] ==$dtype){
											                          $department_type       =$row['name'];
										                                 }
															   }
										
									                      
														   
													         
												       
											        
													 
													       $item = $departments[$k];
														 $id  =  $this->encrypt->encode($item['id']);
														  $dpt_mcn_count  =  $this->bio->machone_count($item['id'] , '' , 1);
														  $flt_mcn_count  =  $this->bio->machone_count($item['id'] , '' , 6);
														  $fcn_mcn_count  = ( $this->bio->machone_count($item['id'] , '' , 1) + $this->bio->machone_count($item['id'] , '' , 2));
													        echo ' <tr>  
                                 <td>'.$item['dname'].'</td>
								 <td>'.$department_type .'</td>
                                 <td>'.$dpt_mcn_count.'</td>
                                 <td>'.$fcn_mcn_count.'</td>
                                 <td>'.$flt_mcn_count.'</td>
                                 <td>
								 <label class ="  btn btn-success btn-sm" href ="">
                                                  <input type="radio"  class ="radio label label-success"   name ="new_machine"  onclick ="return add_machine(); " value="'.$id.'" />
                                                  New 
                                              </label>
								 </td>
                                  
								  <td>
								 <label class ="  btn btn-sm btn-info" href ="">
                                                   <input type="radio"  class =" label label-info" name ="more_machine"  onclick ="return department_info();" value="'.$id.'" />
                                                 
                                                  Details 
                                              </label>
								</td>
                                 <td>
                                    <label class ="btn btn-sm btn-warning" href ="">
                                            <input type="radio"  class =" label "  name ="alt_machine_info"  onclick ="return alt_departmental_info(); " value="'.$id.'" />
                                                 
                                                  Edit 
                                              </label>
											  
                                 
                                  </td>
                              </tr> ';
												        }
														
														if($role > 0){
													  
														 $id  =  0;;
														  $dpt_mcn_count  =  $this->bio->machone_count($id , $role , 1);
														  $flt_mcn_count  =  $this->bio->machone_count($id , $role , 6);
														  $fcn_mcn_count  = ( $this->bio->machone_count($id , $role , 1) + $this->bio->machone_count($id , $role , 2));
														   $id  =  $this->encrypt->encode($id);
													        echo ' <tr>  
                                 <td>New Machines</td>
								  <td>N/A</td>
                                 <td>'.$dpt_mcn_count.'</td>
                                 <td>'.$fcn_mcn_count.'</td>
                                 <td>'.$flt_mcn_count.'</td>
                                 <td>
								 <label class ="  btn btn-success btn-sm" href ="">
                                                    N/A 
                                              </label>
								 </td>
                                  
								  <td>
								 <label class ="  btn btn-info btn-sm" href ="">
                                                   
                                                  Give out 
                                              </label>
								</td>
                                 <td>
                                    <label class ="btn-sm btn btn-warning" href ="">
                                                  
                                                 N/A
                                              </label>
											  
                                 
                                  </td>
														</tr> '; 
														//old machines // phased out
														
														
														$dpt_mcn_count  =  $this->bio->machone_count($id , $role , 0);
														  $flt_mcn_count  =  0;
														  $fcn_mcn_count  = 0;
														   $id  =  $this->encrypt->encode($id);
													        echo ' <tr>  
                                 <td>Phased Out</td>
								  <td>N/A</td>
                                 <td>'.$dpt_mcn_count.'</td>
                                 <td>'.$fcn_mcn_count.'</td>
                                 <td>'.$flt_mcn_count.'</td>
                                 <td>
								 <label class ="  btn btn-success btn-sm" href ="">
                                                   <i class = "fa fa-ban"> </i>  N/A 
                                              </label>
								 </td>
                                  
								  <td>
								 <label class ="  btn btn-info btn-sm" href ="">
                                                   
                                                  <i class = "fa fa-ban"> </i> N/A 
                                              </label>
								</td>
                                 <td>
                                    <label class ="btn-sm btn btn-warning" href =""> <i class = "fa fa-ban"> </i>
                                                  
                                                 N/A
                                              </label>
											  
                                 
                                  </td>
														</tr> '; 
														
														
														}
												       
											        
											 
											 
											   ?>
                              
                               
							  </tbody>
							  </table>
							 
							  </div>
							   </div>
							 
							    </div>
							    
								
									<script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
							  
