<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
        <title>BEAS</title>
        <link href="<?php echo $base; ?>assets/upload/bootstrap.css" type="text/css" rel="stylesheet" />
        <link href="<?php   echo $base; ?>assets/upload/styles.css" type="text/css" rel="stylesheet" />
        


        <!-- Ionicons -->
        <link href="<?php echo $base; ?>assets/upload/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- DATA TABLES -->
        <link href="<?php echo $base; ?>assets/upload/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />

       
    </head> 

    <body>

        <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a><a href="HOME"> HOME </a>
                     <h2 align="center" style="color:rgb(255,255,255);">Device upload form.</h2>
                     
                </div>
            </div>
        </div>


        <div class="container" style="margin-top:50px">    
             <br>
             
             <?php  if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if ($this->session->flashdata('success') == TRUE): ?>
                <div class="alert alert-success"><?php echo $this->session->flashdata('success'); ?></div>
            <?php endif; ?>
             
            <h2 align="center">Select Device file in excel (CSV, comma delimited) format to upload </h2>
            <h4  align="center"> Always use updated template to avoid errors (In case of failed uploads please use contact system administrator for help)</h4>
                <div class="col" > <form method="post" action="importcsv" enctype="multipart/form-data" >
                    <div class="col-xs-3" ><input type="file" name="userfile"  required="required" class="btn btn-info"></div>
                    <div class="col-xs-5" >
					<?php  $cats = $this -> bio-> All_Machines_cats(0 , 1 );
					if(sizeof($cats) > 0){
					
					?>
                                <select class="form-control" name="cat"  required="required"  style=" height:40px; font-size:18px;" >
								 <option value=""> Select Machine Category / type</option>
								<?php for ($i = 0; $i<sizeof( $cats); $i ++){
									
									?>
                                   
                                    <option value="<?php  echo $cats[$i]['id'];?>"> <?php  echo $cats[$i]['name'];?> </option>
								<?php } ?>
                                </select>
					<?php }  else exit('No machine categories found please contact your administrator');?>
                            </div>
                             
                             <div class="col-xs-" >
                    <input type="submit" name="submit" value="UPLOAD" class="btn btn-primary "></div>
                </form>
                </div>  <hr /><br />
            
            
          <div class="box-body table-responsive">
                                          <table id="example1" class="table table-bordered table-striped">
                 
                <thead>
                    <tr>
                    <th>Device Name</th>
                    <th>Scientific  Name</th>
                        
                        <th> Specification</th>
                        <th>Description</th>
                        

                        <th>Price</th>
						
						<th>Mark As New?</th>
                        
                        <th>Discount</th>
						<th>Date</th>
						
                        <th>New up to ?</th>
                        <th>Type</th>
                        
                         
                         <th>Picture</th>
                         
                          
                    </tr>
                </thead>
                <tbody>
                    <?php $addressbook = $this->bio->All_Machines_in_catelogue(0 , 1 );
 				
			 	
					if ($addressbook == FALSE): ?>
                        
                    <?php else:   ?>
                        <?php foreach ($addressbook as $row): ?>
                            <tr>

                                 
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['sname']; ?></td>
                                <td><?php echo   $row['spec'] ; ?></td>
                                <td><?php echo   $row['desc'] ; ?></td>
                               
                                <td><?php echo   $row['price'] ; ?></td>
                                <td><?php echo $row['New']; ?></td>
                                 
                                <td><?php echo   $row['discount'] ; ?></td>
                                <td><?php echo   $row['date'] ; ?></td>
                                <td><?php echo   $row['run'] ; ?></td>
                                <td> 
								<?php 
								$name1  = ' Known type';
								
								for ($k = 0; $k<sizeof( $cats); $k++){
									if($row['cat'] == $cats[$k]['id'] ){
										
										$name1  =  $cats[$k]['name'];
									}
								}
									echo $name1 ;
									
									?>
								
								
								</td>
								<td><?php echo   $row['pic'] ; ?></td>
                                 

                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>


            <hr>
            <footer>
                <p>&copy;BEAS</p>
            </footer>

        </div>



 <script src="<?php echo $base; ?>assets/js/jquery-2.0.3.min.js"  type="text/javascript"> </script>
        <script src="<?php echo $base; ?>assets/upload/js/bootstrap.min.js"></script>
 
        <!-- Bootstrap --> 
        <!-- DATA TABES SCRIPT -->
        <script src="<?php echo $base; ?>assets/upload/js/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="<?php echo $base; ?>assets/upload/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
        
        <!-- page script -->
        <script type="text/javascript">
            $(function() {
                $("#example1").dataTable();
                $('#example2').dataTable({
                    "bPaginate": true,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bSort": true,
                    "bInfo": true,
                    "bAutoWidth": false
                });
            });
        </script>



    </body>
</html>
