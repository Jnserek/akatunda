


<section id="panel"> 

 <section class="panel">  <?php 


 $user = $this->session->userdata('bio_id'); 
 $files = array();
 
 if($action >0 ){
	                            if($action == 1  ){
								$files =   $this->bio->Get_machine_problems_states(0);
								}
								else if($action == 2  ){ 
								
								$files =   $this->bio->Get_tech_prob_status($user , 0 );
								}
	 
								
								
								  
							 }
							 else  bio_error('No supplier was found, it may not be existing on the database');
							 
							 if($files < 1){ bio_error('No supplier data was found');}
							 $techs = $this->bio->All_techs('' );


							 ?>
                               
<div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Settings</h4>
                        </div>  
									    
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Device</th><th> Problem </th><th>Date Reported</th> <th>Date Shifted</th><th> Days Elapsed </th><th> Days in Queue </th><th>Technician</th>            </tr>
                                   </thead>
                                    <tbody> 
									

                 
                                <?php
								
								//print_r($files);
								 
								$k = 0;
			 if(sizeof($files) > 0){
				 
				  	foreach($files as $mcn_data){ 
								
								   
								 ?>
                                <tr> 
								
								 <td>  <?PHP echo $k +=1; // $all_machines?>   </td>
								 
								 
								 <td> 
								 <?php 
								 
									  echo $mcn_data['machine'];
									 
								  ?>
								 </td> 
								 
								  <td>   <?php   echo $mcn_data['prob'];  ?> </td> 
								 
								  <td>  <?php  echo $mcn_data['reported'];  ?>  </td> 
								  <td>  <?php  echo $mcn_data['date_shifted'];  ?>  </td> 
								  <td>  <?php echo  $mcn_data['diff'];   ?>  </td>
								    <td>  <?php echo  $mcn_data['shift'];   ?>  </td>
								   <td>  <?php   
								   //$techs
								   $name = 'N/A'; 
								   foreach($techs as $tech){
									   if($mcn_data['receiver'] == $tech['id']){
										    $name = $tech['fname'].' '.$tech['lname'];
										   
										   
									   }
									   
								   }
								   echo  $name;
								   


								   ?>  </td> 
								 
								   
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								<br /><br /><br />
								   
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No Setting was found </strong></h5>
                            
						
						  

								
							 <?php  }   
						
						?>
			 
	</DIV>
	
	
	
	<script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   <script>
   $('.download_back_up').click(function() {
            var item = $(this).attr("value");
			BioCustom2( 'Form_loader' , 'Download_machine' ,    item , 4 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
   </script>

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
	
 
	 
                                
                                