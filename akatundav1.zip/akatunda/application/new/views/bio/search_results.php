<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			    //$machines1  =$this->bio->Machines_search();
				$supliers   =$this->bio->Supplier_search();
				$manuf   =$this->bio->Manufacturer_Search();
				$hosp   =$this->bio-> specific_hospital($role);
				$sup_loop   = $this->bio-> Suppliers_All ();
				$machines_loop   = $this->bio-> Machines_bank_All();
				$man_loop   = $this->bio->Manufacturers_All();
				$dep_types   = $this->bio->department_types();//department types //$dep_types
				
			//	print_r($machines1);
		 

?>     
<div class="panel panel-primary table-responsive">
                        <div class="panel-heading  ">
                              <h4> Search Results</h4>
                        </div>
                          
						  <?php 
						 //value of machines is determined in the controller
					 

						  if (sizeof( $machines) > 0){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal ', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_new_machines_to_dpts();' );

                              echo form_open('Form_loader/machine_entry_one', $attributes);
							  
					                ?>	
									  
                            <div class="table-responsive">
							 
                                <table class="sample_1 table table-striped table-bordered table-hover" id="sample_1x">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Model</th> <th> Sno</th><th> Manufa -<BR/>cturer</th><th> Mfgd: Yr</th><th> Country</th><th> Supplier</th> <?php if($role < 1)  echo '<th> Department</th>';?><th> Status</th>      </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php
								$total_machines  =  sizeof($machines);
								$total_devices  =  0;

								for($k=0; $k<sizeof($machines); $k++){ 
								 
								$mac  = $machines[$k];
							 $macn_id   = $mac['name'];// $this->encrypt->decode($mac['mid']);
								 
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufactureres and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									 
									if($sup_data['id'] ==$macn_id   ){
										  $macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1;?>  </td>
								 <td>  <?php  echo ucfirst($macn_name);?></td>
								 
								 <td>  <?php  
								   IF($mac['mod'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['mod']));
								   
								   ?> 
								   </td>
								 <td>  <?php  
								   IF($mac['sn'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['sn']));
								   
								   ?> 
								   </td>
								 <td>   <?php  echo ucfirst($man_name);?> </td>
								
								  <td>  <?php  echo $mac['yr'];?> </td>
								   
								   <td>  <?php  
								   IF($mac['cou'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['cou']));
								   
								   ?> 
								   </td>
								   <td>   <?php  echo $sup_name;?> </td>
								  <?PHP  if($role < 1){
								
								  echo ' <td>'; 
												    for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														    echo ' '.  ucfirst(strtolower($item['dname'])) .' '; 
														   }															
												        }
														 echo ' </td>'; 
												   
											  
								
								
							} ?>
								  
								 <td>   
								 
											<?php 
 										
											$mstates  =  $this->bio->All_machine_states();
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($mac['ms'] ==  $dt['id']){
												echo  ucfirst(strtolower($dt['name']));
												}
											}?>
                                                 
                                            </select>

								 </td>
								  <?php if($action <1){ ?>
								   <td>  <?php if($action <1){   
								   IF($mac['comment'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['comment']));
								   
								   } ?>
								   </td>
								   <?php } if($action > 0){ ?>
								   							 
								   <?php  }  ?>								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								
								<hr />  
								<?php
								$man_array = $mcn_array = $state_array = $sup_array = $sup_array_hosp = $departmental_states = $dpt_array_hosp = $diff_hosp_departments = $states_in_departments = $dpt_array_sup = array(); 
								for($s=0; $s<sizeof($sup_loop); $s++){
									$count_no =0;
									$count_name ='';
									
									$sup_data =$sup_loop[$s]; //local variable
									
									for($k=0; $k<sizeof($machines); $k++){ 
								 
								$mac  = $machines[$k];
								
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										$count_no +=1;
										
									}
									}
									
									if( $count_no > 0){
										array_push( $sup_array , array('name'=>$sup_data['name'] , 'no'=>$count_no ));
									 
									}
									
								}
								
							 // print_r($hosp);
						 // print_r($machines);
							 
								//gat supliers in different hospitals
								foreach($hosp as $row){
									 
									$temp_suplier = array();
									foreach($sup_loop as $sup){
										 $count_no =0;
										 
										foreach($machines as $rowm){
											if( ($sup['id'] ==$rowm['sup'])  and  ($row['id'] == $rowm['hf']) ){
												$sup_name =$sup['name'];
										        $count_no +=1;
											 
											}
											
										}
										 
										if( $count_no > 0){
										array_push( $temp_suplier  , array('name'=>$sup_name , 'no'=>$count_no ));
									 
									}
										
									}
									if( sizeof($temp_suplier) > 0){
									 array_push( $sup_array_hosp , array('hospital' => $row['name'] , 'lcn' => $row['ln']   ,   'details' =>  $temp_suplier ));
									
								}
								}
								
								foreach($dep_types as $dpt ){
									$dpt['id'];//dtype
									 $count_no =0;
									
									foreach($machines as $rowm){
											if(  ($dpt['id'] == $rowm['dtype']) ){
												$dpt_name =$dpt['name'];
										        $count_no +=1;
											 
											}
											
										}
										 
										if( $count_no > 0){
										array_push( $dpt_array_hosp  , array('name'=>$dpt_name , 'no'=>$count_no ));
									 
									
									
									
								}
								}
								 
								
								foreach($dep_types as $dpt ){
									//echo $dpt['id'];//dtype
									 $count_no =0;
									 $supl_name = '';
									 $temp_suplier = array(); 
									 foreach($sup_loop as $sup){
										 $count_no =0;
										
									
									foreach($machines as $rowm){
										 
											if(  ($dpt['id'] == $rowm['dtype'])  and  ($sup['id'] == $rowm['sup']) ){
												$supl_name =$sup['name'];
										        $count_no +=1;
											 
											}
											
										}
										if( $count_no > 0){
										array_push( $temp_suplier  , array('name'=>$supl_name , 'no'=>$count_no ));
										
									 }
										 
									
								}
								if( sizeof($temp_suplier) > 0 ){
										 array_push( $dpt_array_sup  , array('department'=>$dpt['name'] , 'details'=>$temp_suplier ));
									 
									
								 }
								
									
								}
								 
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									$count_no =0;
									$count_name ='';
									
									for($k=0; $k<sizeof($machines); $k++){ 
								 
								     $mac  = $machines[$k];
								
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										$count_no +=1;
										 
										
									}
									
									}
									
									if( $count_no > 0){  
										array_push($man_array , array('name'=>$man_name , 'no'=>$count_no ));
										$count_no =0;
										 
									}$count_no =0;
									
								}
								
								//machine type summary from here
								
								
									for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									
									$count_no =0;
									$count_name ='';
									
									for($k=0; $k<sizeof($machines); $k++){ 
								 
								$mac  = $machines[$k];
								$macn_id   = $mac['name'];
								 
									if($sup_data['id'] ==$macn_id  ){
										$macn_name =$sup_data['name'];
										$count_no +=1;
										
									}
									}
									
									if( $count_no > 0){
										array_push($mcn_array , array('name'=>$sup_data['name'] , 'no'=>$count_no ));
										 
									}
									
								}
								
								//machine States summary
								
								
											$mstates  =  $this->bio->All_machine_states();
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
											
												  $dt =  $mstates[$i];
												  
												  $count_no =0;
									$count_name ='';
									
									for($k=0; $k<sizeof($machines); $k++){ 
								 
								               $mac  = $machines[$k];
											   
												if($mac['ms'] ==  $dt['id']){
													 
												 
												$count_no +=1;
												 }
									            }
												 
										 array_push($state_array ,array('name'=>$dt['name'] , 'no'=>$count_no ));
										
									 
								 
									
									
											}//for($i=0; $i<sizeof($mstates) ; $i++){
											
											foreach($hosp as $row){
									 $hosp_name = '';
									 $total =0;
									$temp_suplier = array();
									foreach($mstates as $state){
										 $count_no =0;
										  $state_name = '';
										 
										foreach($machines as $rowm){
											if( ($state['id'] ==$rowm['ms'])  and  ($row['id'] == $rowm['hf']) ){
												$state_name =$state['name'];
										        $count_no +=1;
												$total +=1;
											 
											}
											
										}
										 
										if( $count_no > 0){
										array_push( $temp_suplier  , array('name'=>$state_name , 'no'=>$count_no ));
									 
									}
										
									}
									if( sizeof($temp_suplier) > 0){
									 array_push( $departmental_states , array('hospital' => $row['name'] , 'lcn' => $row['ln']  , 'total' =>  $total,   'details' =>  $temp_suplier ));
									
								}
								}
								//states in different departments
								
								foreach($dep_types as $dpt ){
									//echo $dpt['id'];//dtype
									 
									 $supl_name = '';
									 $temp_suplier = array(); 
									  $total =0;
									 
									foreach($mstates as $state){
										 
										  $state_name = ''; 
										 $count_no =0;
										
									
									foreach($machines as $rowm){
										 
											if(  ($dpt['id'] == $rowm['dtype'])  and  ($state['id'] == $rowm['ms']) ){
												$supl_name =$state['name'];
										        $count_no +=1;
												$total +=1;
											 
											}
											
										}
										if( $count_no > 0){
										array_push( $temp_suplier  , array('name'=>$supl_name , 'no'=>$count_no ));
										
									 }
										 
									
								}
								if( sizeof($temp_suplier) > 0 ){
										 array_push( $states_in_departments  , array('department'=>$dpt['name'] ,'total'=>$total , 'details'=>$temp_suplier ));
									 
									
								 }
								
									
								}
								
								foreach($hosp as $row){
									 $hosp_name = '';
									 $totalh =0;
								 $temp_suplier = array(); 
								foreach($dep_types as $dpt ){
									//echo $dpt['id'];//dtype
									 
									 $supl_name = '';
									
									 
									  $total =0;
									  $temp_state = array();
									 
									foreach($mstates as $state){
										 //$temp_state = array(); 
										 
										  $state_name = ''; 
										 $count_no =0;
										
									
									foreach($machines as $rowm){
										 
											if(  ($dpt['id'] == $rowm['dtype'])  and  ($state['id'] == $rowm['ms'])  and  ($row['id'] == $rowm['hf']) ){
												$supl_name =$state['name'];
										        $count_no +=1;
												$total +=1;
												$totalh +=1;
											 
											}
											
										}
										if( $count_no > 0){
										array_push( $temp_state  , array('name'=>$supl_name , 'no'=>$count_no ));
										
									 }
										 
									
								}
								if(sizeof($temp_state) > 0){
									 array_push( $temp_suplier  , array('department'=>$dpt['name'] ,'total'=>$total , 'details'=>$temp_state ));
									
									
								}
								}
								if( sizeof($temp_suplier) > 0 ){
										 array_push( $diff_hosp_departments  , array('hospital' => $row['name'] , 'lcn' => $row['ln'] ,'totalh'=>$totalh , 'detailsh'=>$temp_suplier ));
									 
									
								 }
								
									
								}
								
							  
								 
								$_SESSION['search_results'] = array(
								'man_array' =>$man_array,
								'state_array' =>$state_array,
								'sup_array' =>$sup_array,
								'sup_array_hosp' =>$sup_array_hosp,
								'departmental_states' =>$departmental_states,
								'dpt_array_hosp' =>$dpt_array_hosp,
								'diff_hosp_departments' =>$diff_hosp_departments,
								'states_in_departments' =>$states_in_departments,
								'dpt_array_sup' =>$dpt_array_sup,
								'mcn_array' => $mcn_array
								 
								
								);
								 
                             ?>
							  <section class="panel panel-primary col-lg-12">
                          <header class="panel-heading">
                           <h4>  Search Summary</h4>
                          </header>
                          <div class="panel-body ">

						  
							 
							   <table class="table table-striped table-bordered table-hover " >
							   <tr><td class ="col-lg-6"> </td><td > </td></tr>
							   <tr> <td> 
							   <header class="panel-heading">
                           <h4>  Device distribution</h4>
                          </header>

 <table class="table table-striped table-bordered table-hover" id="sample_3">
                                    <thead>
                                    <tr> <th>Name</th><th> No</th>  <th>Percentage</th>     </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($mcn_array as $row){?>
									<tr><td> <?php  echo $row['name'];?></td><td> <?php  echo $row['no'];?></td><td> <?php  echo round(( ($row['no'])/ $total_machines )*100 , 1);?></td></tr>
								   <?php }  ?>
									</tbody>
									</table>
									
							   
									
							   
							   </td> <td> 
							    <header class="panel-heading">
                           <h4>  Distribution by suppliers</h4>
                          </header>
							    <table class="sample_1 table table-striped table-bordered table-hover" id="sample_2xx">
                                    <thead>
                                    <tr> <th> Name</th><th> No of Machines</th> <th>Percentage</th>      </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($sup_array as $row){?>
									<tr><td> <?php  echo $row['name'];?></td><td> <?php  echo $row['no'];?></td> <td> <?php  echo round(( ($row['no'])/ $total_machines )*100 , 1);?> </td></tr>
								   <?php }  ?>
								   
								    
									</tbody>
									</table>
									
									
									
							   
							   </td> 
							 
							   
							   </tr>
							   <tr> <td>
							   
							   
									<header class="panel-heading">
                           <h4> Disrtibution by  suppliers in general department types.</h4>
                          </header>
							   
							    <table class="table table-striped table-bordered table-hover" id="sample_2">
                                    <thead>
                                    <tr> <th> Name</th><th> No</th><th>Percentage</th></tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($dpt_array_hosp as $row){?>
									<tr><td> <?php  echo $row['name'];?></td><td> <?php  echo $row['no'];?></td><td> <?php  echo round(($row['no'] /sizeof($machines)) *100 , 1);?></td></tr>
								   <?php }  ?>
								  
								   
								   <tr><td> Total</td><td> <?php echo  sizeof($machines);?></td> <td>100/=</td></tr>
								  
								  
									</tbody>
									</table>

							   </td><td>
							    <header class="panel-heading">
                           <h4>  Distribution by device states</h4>
                          </header>
							   <table class="sample_1 table table-striped table-bordered table-hover"  >
                                    <thead>
                                    <tr> <th> Name</th><th> No</th>  <th>Percentage</th>     </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($state_array as $row){?>
									<tr><td> <?php  echo $row['name'];?></td><td> <?php  echo $row['no'];?></td> <td>  <?php  echo round(( $row['no'] /sizeof($machines))*100 , 1);?></td></tr>
								   <?php } //$mstates  ?>
								    
								   <tr><td> Total</td><td> <?php echo  sizeof($machines);?></td><td>100/=</td></tr>
								  
								  
									</tbody>
									</table>
									

							   </td> </tr>
							   
							   
							    <tr>   <td> 
								 <header class="panel-heading">
                           <h4> Distribution by  manufacturers</h4>
                          </header>
							   
							    <table class="sample_1 table table-striped table-bordered table-hover"  >
                                    <thead>
                                    <tr> <th> Name</th><th> No</th><th>Percentage</th></tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($man_array as $row){?>
									<tr><td> <?php  echo $row['name'];?></td><td> <?php  echo $row['no'];?></td><td> <?php  echo round(($row['no'] /sizeof($machines)) *100 , 1);?></td></tr>
								   <?php }  ?>
								  
								   
								   <tr><td> Total</td><td> <?php echo  sizeof($machines);?></td> <td>100/=</td></tr>
								  
								  
									</tbody>
									</table>
									</td><td>
									
									<?php  if(sizeof($states_in_departments ) > 0){?>
									
									<header class="panel-heading">
                           <h4> Distribution by  device states in different departments</h4>
                          </header>
							    
							    <table class=" table table-striped table-bordered table-hover"  >
                                    <thead>
                                    <tr>  <th> Department</th><th> State</th><th> No of Machines</th> <th>Percentage</th>      </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($states_in_departments as $row){?>
									<tr> <td  > <?php  echo $row['department'];?></td><td></td><td> </td> <td>  </td></tr>
									<?php foreach($row['details'] as $details ) {?>
									<tr> <td></td><td> <?php  echo $details['name'];?></td> <td> <?php  echo $details['no'];?></td> <td> <?php  echo round(( ($details['no'])/ $row['total'] )*100 , 1);?> %</td></tr>
								   
									<?php } ?>
									<tr> <td> </td><td>Total</td><td> <?php  echo $row['total'];?> </td> <td>  100%</td></tr>
									
									<?php }  ?>
								   
								    
									</tbody>
									</table>
									<?php } ?>
									</td> </tr>
									<tr> 
							   <td>
							   
									
									
									
									<?php  if(sizeof($departmental_states ) > 0){?>
									
									<header class="panel-heading">
                           <h4>  Distribution by device states in different hospitals</h4>
                          </header>
							    
							    <table class="  table table-striped table-bordered table-hover"  >
                                    <thead>
                                    <tr>  <th> Hospital</th><th> State</th><th> No of Machines</th> <th>Percentage</th>      </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($departmental_states as $row){?>
									<tr> <td> <?php  echo $row['hospital'];?></td><td></td><td> </td> <td>  </td></tr>
									<?php foreach($row['details'] as $details ) {?>
									<tr> <td></td><td> <?php  echo $details['name'];?></td> <td> <?php  echo $details['no'];?></td> <td> <?php  echo round(( ($details['no'])/ $row['total'] )*100 , 1);?> %</td></tr>
								   
									<?php } ?>
									<tr> <td> </td><td>Total</td><td> <?php  echo $row['total'];?> </td> <td>  100%</td></tr>
									
									<?php }  ?>
								   
								    
									</tbody>
									</table>
									<?php } ?>
									 
							   </td>
							   <td>
									
									<?php  if(sizeof($states_in_departments ) > 0){?>
									
									<header class="panel-heading">
                           <h4> Distribution by  device states in different hospital departments</h4>
                          </header>
							    
							    <table class="  table table-striped table-bordered table-hover" >
                                    <thead>
                                    <tr>  <th> Department</th><th> State</th><th> No of Machines</th> <th>Percentage</th>      </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($states_in_departments as $row){?>
									<tr> <td> <?php  echo $row['department'];?></td><td></td><td> </td> <td>  </td></tr>
									<?php foreach($row['details'] as $details ) {?>
									<tr> <td></td><td> <?php  echo $details['name'];?></td> <td> <?php  echo $details['no'];?></td> <td> <?php  echo round(( ($details['no'])/ $row['total'] )*100 , 1);?> %</td></tr>
								   
									<?php } ?>
									<tr> <td> </td><td>Total</td><td> <?php  echo $row['total'];?> </td> <td>  100%</td></tr>
									
									<?php }  ?>
								   
								    
									</tbody>
									</table>
									<?php } ?>
							   
							   
							   </td>
								
								</tr>
								<tr> <td>
								<br /><br />
									<?php  if(sizeof($sup_array_hosp ) > 1){?>
									
									   <header class="panel-heading">
                           <h4>  Disrtibution by suppliers in hospitals </h4>
                          </header>
							    <table class=" table table-striped table-bordered table-hover"  >
                                    <thead>
                                    <tr>  <th> Hospital</th><th> Supplier</th><th> No of Machines</th> <th>Percentage</th>      </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($sup_array_hosp as $row){?>
									<tr> <td> <?php  echo $row['hospital'];?></td><td></td><td> </td> <td>  </td></tr>
									<?php foreach($row['details'] as $details ) {?>
									<tr> <td></td><td> <?php  echo $details['name'];?></td> <td> <?php  echo $details['no'];?></td> <td> <?php  echo round(( ($details['no'])/ $total_machines )*100 , 1);?> </td></tr>
								   
									<?php } }  ?>
								   
								    
									</tbody>
									</table>
									<?php } ?>
								
								</td> <td>
							   <br /><br />
									<?php  if(sizeof($dpt_array_sup ) > 1){?>
									
									   <header class="panel-heading">
                           <h4>  Suppliers in different departments. </h4>
                          </header>
							    <table class="  table table-striped table-bordered table-hover"  >
                                    <thead>
                                    <tr>  <th> #</th><th> Department</th><th> Supplier</th><th> No of Machines</th> <th>Percentage</th>      </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  $count =0;  foreach ($dpt_array_sup as $row){ $count +=1;?>
									<tr> <td> <?php  echo $count;?> </td><td> <?php  echo $row['department'];?></td><td></td><td> </td> <td>  </td></tr>
									<?php foreach($row['details'] as $details ) {?>
									<tr> <td> </td><td> </td><td> <?php  echo $details['name'];?></td> <td> <?php  echo $details['no'];?></td> <td> <?php  echo round(( ($details['no'])/ $total_machines )*100 , 1);?> </td></tr>
								   
									<?php } }  ?>
								   
								    
									</tbody>
									</table>
									<?php } ?>

							   </td></tr>
							   </table>
							   </div> 
							   
							   </section>
							 
							 
									
									
									 
									
									
									
									
									 

						</DIV>
						<hr />
                   
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<a class="btn btn-info colspan3" href="reports/search_report" target="_blank"> Get report in PDF </a>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No data found </strong></h5>
                             
						
						  

								
							 <?php  }
							 
						
						?>

           
	
					  
	 
	</DIV>
	
	<script src="<?php echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php echo base_url();?>assets/metro/js/dynamic-table.js"></script
	 
                                