
 
      <?php   $idm =   $this->encrypt->decode($mac_data['mid']) ;
	  
	     $prob =  $this->bio->Get_machine_problems($idm);
									   $service =  $this->bio->Get_service_info($idm);
									   $repair =  $this->bio->Get_machine_repair_info($idm);
									   	 $mstates  =  $this->bio->All_machine_states();
											
											
											
								 	 
	  
	  
	  ?>       
                <!-- profile-widget -->
                <div class="col-lg-12">
                    <div class="profile-widget profile-widget-info">
                          <div class="panel-body">
                             
                            <div class="col-lg-5 col-sm-5 follow-info">
							<h4> Machine Log. For <?php  echo ucfirst(strtolower( $this->bio->Machine_name_bank($mac_data['name'] ))) ; ?></h4> 
							 
							
                                 
                            </div>
                           
							 
							 
                          </div>
                    </div>
                </div>
              
              <!-- page start-->
             
                 <div class="col-lg-12">
                    <section class="panel">
                          <header class="panel-heading tab-bg-info">
                              <ul class="nav nav-tabs">
                                  <li class="active">
                                      <a data-toggle="tab" href="#recent-activity">
                                          <i class="icon-home"></i>
                                          Machine Inventory
                                      </a>
                                  </li>
                                  <li>
                                      <a data-toggle="tab" href="#profile">
                                          <i class="icon-user"></i>
                                          Machine Details.
                                      </a>
                                  </li>
                                   
                              </ul>
                          </header>
                          <div class="panel-body">
                              <div class="tab-content">
                                  <div id="recent-activity" class="tab-pane active">
                                      <div class="profile-activity"> 

                                     									  
                                           
										  
										  <div class="col-lg-12">
                      <section class="panel">
					  <?php  if(sizeof($prob) > 0){ ?>
                          <header class="panel-heading">  <hr />
                             Device Problems Logged.
                          </header>
										  <div class="table-responsive">
                            <table class="table">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Complain</th>
                                  <th>Date</th>
                             
                                  <th>Status</th>
                                  <th>Worked on?</th>
								  <th>Edit</th>
								  <th>Delete</th>
                                  
                                </tr>
                              </thead>
                              <tbody>
							  
							  <?php    					  
									  
		  for($i = 0; $i<sizeof($prob); $i++){
								  $pro = $prob[$i];
								  $state  = '';
								   $state_w  = 'No';
								  for($j=0; $j<sizeof($mstates) ; $j++){
												  $dt =  $mstates[$j];
												  
												 if($pro['new_state'] ==  $dt['id']){
												 $state  =  ucfirst(strtolower($dt['name']));
												 }
												 if($pro['worked_on'] == 1 ){ $state_w  = 'Yes'; }
											 }
											
                                echo '<tr>
								<td>'. ($i +1) .'</td>
                                  <td>'.$pro['prob'].'</td>
								  <td>'.$pro['dt'].'</td>
                                  <td>'.$state.'</td>
								  <td>'.$state_w.'</td>'; ?>
								  <td>
								   
								  <button  class  ="device_edit_problem  btn btn-info btn-mini "   value ="<?php echo $pro['mid'];?>" >  Edit Device</button>
								  </td><td>
									<?php   $role = $this->session->userdata('bio_role');  if($role  !='**'){  ?>
									<button  class  =" device_alt_problem btn btn-warning btn-mini "   value ="<?php echo $pro['mid'];?>">  Delete Device</button> 
								 </td>
									<?php }  
								 echo  ' 
                                </tr>';  
								  }?>
								</tbody>
								</table>
								</div>
								
					  <?php   } else {bio_warning(  'No data was found');}  						   
									  
		 	?>
								</section>
                                          
                                          

                                      </div>
									  
									  			  <div class="col-lg-12">
                      <section class="panel">
					  <?php  if(sizeof($service) > 0){?>
                           
						 <div class="table-responsive">
						    Service Information.
                            <table class="table">
                              <thead>
                                <tr>
                                  <th>#</th>
								   <th>Status</th>
                                  <th>Comment</th>
                                  <th>Way Forward</th>
                                 <th>New Status</th>
								  <th>Date</th>
								  <th>Edit</th>
								  <th>Delete</th>
								  </tr>
                              </thead>
                              <tbody>
							  
							  <?php 
							  for($i = 0; $i<sizeof($service); $i++){
								  $pro = $service[$i];
								  
								  
								    $state  = '';
									$state_n  = '';
								   $state_w  = 'No';
								  for($j=0; $j<sizeof($mstates) ; $j++){
												  $dt =  $mstates[$j];
												if($pro['new_st'] ==  $dt['id']){
												$state_n  = ucfirst(strtolower($dt['name']));
												}
												
												if($pro['state'] ==  $dt['id']){
												$state  =  ucfirst(strtolower($dt['name']));
												}
											}
											
                                echo '<tr>
								<td>'. ($i +1) .'</td>
								 <td>'.$state.'</td>
                                  <td>'.$pro['com'].'</td>
								  <td>'.$pro['wf'].'</td>
                                  <td>'.$state_n .'</td>
								 
								  <td>'.$pro['period'].'</td>';
								  ?> 
                                   <td>
								   
								  <button  class  ="device_service_info_edit  btn btn-info btn-mini "   value ="<?php echo $pro['mid'];?>" >  Edit Device</button>
								  </td><td>
									<?php   $role = $this->session->userdata('bio_role');  if($role  !='**'){  ?>
									<button  class  ="device_alt_service_info btn btn-warning btn-mini "   value ="<?php echo $pro['mid'];?>">  Delete Device</button> 
								 </td>								  
								  
									<?php }
								  
                                  
                                  
                               echo ' </tr>';
								  }?>
								</tbody>
								</table>
								</div>
					  <?php } else bio_warning( 'No service information is available for this machine');?>
								</section>
								</div>
									  </div>
									  
									  
									  
                                  </div>
                                  <!-- profile -->
                                  <div id="profile" class="tab-pane">
                                    
                                      <div class="panel-body bio-graph-info">
									  <hr />
                                          <h1>Detailed Information About : <?php  echo ucfirst(strtolower( $this->bio->Machine_name_bank($mac_data['name'] ))) ;?> 
									<button  class  ="device_edit  btn btn-info " onclick ="return edit_device();" value ="<?php echo $mac_data['mid'];?>" >  Edit Device</button>
									<?php $role = $this->session->userdata('bio_role');  if($role  !='*'){?>
									<button  class  =" device_alt btn btn-warning " onclick ="return delete_device();" value ="<?php echo $mac_data['mid'];?>">  Delete Device</button> 
								 
									<?php } ?></h1>
                                          <div class="row">
                                              <div class="bio-row">
											  	 
								 
                                                  <p><span>Serial No:  </span>: <?php  echo $mac_data['sn'];?> </p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Made in </span>: <?php  echo $mac_data['cou'];?></p>
                                              </div>                                              
                                              <div class="bio-row">
                                                  <p><span>Model</span>:  <?php  echo $mac_data['mod'];?></p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Year </span>:<?php  echo $mac_data['yr'];?> </p>
                                              </div>
                                               
                                              <div class="bio-row">
                                                  <p><span>supplier </span>:<?php $sup = $this->bio-> Specific_machine_supplier($mac_data['sup']);  if(sizeof($sup)) { echo $sup['name']; }?></p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Date installed </span>: <?php  echo $mac_data['installed'];?> </p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Department </span>:  <?php   $dpt = $this->bio-> get_my_department( $mac_data['dep']);  if(sizeof($dpt) >0){ echo $dpt['dname']; }?></p>
                                              </div>
											  
											  
											   <div class="bio-row">
                                                  <p><span>Health facility </span>: <?php $hf = $this->bio->  specific_hospital($mac_data['hf']);  if(sizeof($hf) >0){echo $hf[0]['name']; }?> </p>
                                              </div>
											  
											   <div class="bio-row">
                                                  <p><span>Current State</span>: <?php  
												  
												    $state_w  = 'No';
								  for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($mac_data['ms'] ==  $dt['id']){
												echo ucfirst(strtolower($dt['name']));
												}
												
												 
											}
												  
												  ?> </p>
                                              </div>
											   <div class="bio-row">
                                                  <p><span>Last Date of service </span>:  <?php echo    $mac_data['period'];   ?></p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Next Date of Service </span>:  <?php  if($mac_data['ms'] ==4 || $mac_data['ms'] ==6  ) { echo 'N/A';} else {     echo $next  =  AddMonths($mac_data['period'] , 6); }  ?></p>
                                              </div>
											  
											   <div class="bio-row">
                                                  <p><span>Days Left To Next Date of service </span>:  <?php    if($mac_data['ms'] ==4 || $mac_data['ms'] ==6  ) { echo 'N/A';} else {   echo  dateDiff(  timeCurrent2() , $next); } ?></p>
                                              </div>
                                          </div>
										  
                                      </div>
									  <?php  if(sizeof($repair) > 0){?>
                          
                          <div class="table-responsive">
						   Machine Repair History.
                            <table class="table">
                              <thead>
                                <tr>
                                  <th>#</th>
								   
                                  <th>Company</th>
                                  <th>Job NO</th>
                                  <th>Diagnosis</th>
                                  <th>Remedy</th>
								  <th>Technician's comment </th>
                                  <th>User comment</th>
								  
								  <th>New state</th>
                                  <th>Cost</th>
								  
								  <th>Edit</th>
                                  <th>Delete</th>
                                </tr>
                              </thead>
                              <tbody>
							  <?php
							  
							  for($i= 0; $i<sizeof($repair); $i++ ){
								  $rep = $repair[$i];
								  
								  $state  = '';
								   $state_w  = 'No';
								  for($j=0; $j<sizeof($mstates) ; $j++){
												  $dt =  $mstates[$j];
												if($rep['new_s'] ==  $dt['id']){
												$state  = ucfirst(strtolower($dt['name']));
												}
												 
											}
							    

							  
							  echo '
                                <tr>
                                  <td>'.($i +1).'</td>
                                  <td>'.$rep['comp'].'</td>
                                  <td>'.$rep['no'].'</td>
                                  <td>'.$rep['diag'].'</td>
                                  <td>'.$rep['remedy'].'</td>
                                  <td>'.$rep['tech'].'</td>
                                  <td>'.$rep['user_com'].'</td> 
								  <td>'.$state.'</td>
								  <td>'.$rep['charge'].'</td>';
								  ?> 
                                   <td>
								   
								  <button  class  ="device_edit_repair  btn btn-info btn-mini "   value ="<?php echo $rep['id'];?>" >  Edit Device</button>
								  </td><td>
									<?php   $role = $this->session->userdata('bio_role');  if($role  !='**'){  ?>
									<button  class  ="device_alt_repair btn btn-warning btn-mini "   value ="<?php echo $rep['id'];?>">  Delete Device</button> 
								 </td>								  
								  
									<?php }
								  
                               echo ' </tr>';
							  }
								?>
								</tbody>
								</table>
								</div>
					  <?php } else bio_warning( 'No repair information');?>
                                   
                                      
                                  </div>
								  
								 
                      </section>
                 
              </div>
			  
			   
                                   
                          </div>

              <!-- page end-->
          </section>
       			 
			<script>					
			 $('.device_edit').click(function() {
            var item = $(this).attr("value");
			 
			
			 BioCustom2( 'Form_loader' , 'Edit_device' ,    item , 1 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
		
		$('.device_edit_problem').click(function() {
            var item = $(this).attr("value");
			 
			 
			  BioCustom2( 'Form_loader' , 'Edit_Problem' ,    item , 1 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
		
		$('.device_edit_repair').click(function() {
            var item = $(this).attr("value");
			 
			 
			  BioCustom2( 'Form_loader' , 'Edit_repair' ,    item , 1 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
		
		$('.device_alt_repair').click(function() {
            var item = $(this).attr("value");
			 
			 
			  BioCustom2( 'Form_loader' , 'Edit_repair' ,    item , 0 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
		
		//device_edit_problem 
		
		 $('.device_alt').click(function() {
            var item = $(this).attr("value");
			BioCustom2( 'Form_loader' , 'Edit_device' ,    item , 0 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
		
		//new changes 
		 
		$('.device_alt_service_info').click(function() {
            var item = $(this).attr("value");
			BioCustom2( 'Form_loader' , 'Edit_Service_Report' ,    item , 0 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        }); 
		
		$('.device_service_info_edit').click(function() {
            var item = $(this).attr("value");
			BioCustom2( 'Form_loader' , 'Edit_Service_Report' ,    item , 1 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
		
		
		$('.device_alt_problem').click(function() {
            var item = $(this).attr("value");
			BioCustom2( 'Form_loader' , 'Edit_Problem' ,    item , 0 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });

</script>		
