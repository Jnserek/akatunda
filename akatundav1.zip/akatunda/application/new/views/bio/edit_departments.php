


<section id="panel"> 

 <section class="panel">  <?php  if(isset($_SESSION['dept_edit']) ){
								$dpts  =$this->bio-> get_my_department( $this->encrypt->decode($_SESSION['dept_edit'] )); 
							 }
							 else  bio_error('No data was found for this department, it may not be existing on the database');
							 
							 if(sizeof($dpts) < 1){ bio_error('No department data was found');}


							 ?>
                          <header class="panel-heading">
                             You are editing  <?php   echo  strtoupper($dpts['dname']); ?>
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12" >
							 
                             <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'new_machine', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );

                              echo form_open('System_controls/Update_departments', $attributes);
					  
					  

?>			                     
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">Enter new name for your department</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name" placeholder="" value ='<?php   echo  strtoupper($dpts['dname']); ?>' required>
                                          <p class="help-block"><?php echo form_error('name'); ?> </p>
                                      </div>
									  
									   
                                  </div>
								  
								     <div class="form-group">
                                      <label class="col-lg-2 control-label">Department type</label>
                                      
									  
									   <div class="col-lg-7"> 
										  
										  <select class="dep_type form-control" name="dtype"  required  >
									 
									
									<?php

									$dep_types =  $this->bio-> department_types();
									foreach($dep_types as $row){
										if($dpts['dtype'] == $row['id'] ){
										  echo ' <option value ="'.$row['id'].'" >'.$row['name'].'</option>';
										}
										
									}
									echo ' <option value ="" >Select</option> ';
									
									foreach($dep_types as $row){
										  echo ' <option value ="'.$row['id'].'" >'.$row['name'].'</option>';
										
									}
									
									?>
									
									 
														   
                                                 
                                    </select> 
                                          <p class="help-block"><?php echo form_error('dtype'); ?> </p>
                                      </div>
                                  </div>
								  
								   <?php    bio_footer();?>
                        </form>

                                 
    </div>
	</div>
	
	</div>
	</section></section>
                                