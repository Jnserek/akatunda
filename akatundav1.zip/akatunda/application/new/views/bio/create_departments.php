


<section id="panel"> 

 <section class="panel">
                          <header class="panel-heading">
                            Enter department name . <?PHP 
							
							  $role = $this->session->userdata('bio_role');
							
							if($role < 1 ){
								exit('Operation is failed: It seems you are not attached to any client');
								
							}
							  $hosp = $this->bio->specific_hospital($role);
							
							
							
							
							  echo element('name', $hosp).str_repeat('&nbsp;', 3);  
							   echo element('ln', $hosp);
							?>
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                            <div class="row">
                                <div class="col-md-8 " >
								
								<?php 
							 
							   $dpts =$_SESSION['no_of_departments']; 
							  //if( $dpts < 1 ){exit('Operation is failed,  invalid data supplied ');}
                                $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_departments_form();' );

                              echo form_open('Form_loader/Departments_entry_form', $attributes);
							  
					                ?>	
									   <table class="table table-striped table-bordered table-hover"  >
                                    <thead>
                 <tr> <th> #</th><th> NAME</th> </th><th> Department Type</th>      </tr>
                 </thead>
                 <tbody>
							 
                             <?php  
							 
							  
							  for($i =0; $i<$dpts ; $i++){
					                ?>			                   
								<tr> 
								    <td> 
									     <?PHP echo $i+1;?>  
									</td>
								    <td> 
								        <input  type="text"   class='Nm form-control'           /> 
								    </td>
									<td> 
									<select class="dep_type form-control" name ="state"  >
									 <option value ="" >Select</option> 
									
									<?php

									$dep_types =  $this->bio-> department_types();
									foreach($dep_types as $row){
										  echo ' <option value ="'.$row['id'].'" >'.$row['name'].'</option>';
										
									}
									
									?>
									
									 
														   
                                                 
                                    </select> 
								    </td>
								</tr>
								

                                  <?php }   ?> 
                                    
								</tbody>
								</table> 
 <?php   bio_footer();?>								
							 
                        </form>

                                 
    </div>
	                   <div class="col-md-4 " >
					    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              
                                              
												  <section class="panel">
                                                       <header class="panel-heading">
                                                           <h4> My departments</h4>
                                                        </header>
                                   
                                   
                                             
											 
                                             <?php 
											 $role = $this->session->userdata('bio_role');
											 
											 
											 $departments  =$this->bio->get_hospital_departments($role);
											 if(sizeof($departments) <1){
												 echo 'no departments found';
											 } 
											 
											 else { ?>
											            <div class="list-group">
											 
										<table class="table table-responsive" >
														<thead> <th>Name</th><th>Department Type</th> </thead>
														<tbody>
														
											 
											 
											 <?php
												 
												       for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   $dtype = $item['dtype'];
														   $name      = '';
														   if( $dtype <1){
															   $name      = 'Unknown';
															   
														   }
														   else {
															   foreach($dep_types as $row){
										                            if($row['id'] ==$dtype){
											                          $name      =$row['name'];
										                                 }
										
									                                }
														   }
														   
													        echo ' <tr><td>'.$item['dname'].'</td><td>'.$name.'</td></tr>';//dtype
												        }
											        }
											 

                                                 ?>  
												 </tbody>
												 </table>     </div>
                                                </section>
	                    </div>
	
	</div>
	</section></section>
	
	
                                