
<?php 
 $attributes = array('class' => 'form-horizontal', 'id' => 'profile'  , 'method'=>"post"  ,  'onSubmit'=>' return update_acc_profile();' );

      echo form_open('System_controls/acc_alt_profile', $attributes);

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h1> Change user password</h1>
                                              <form class="form-horizontal" role="form"> 
											<!--   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Enter Old Password</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="passo" placeholder=" "   auto-complete  ="off"  required>
                                                      </div>
													  
													  <br /> <?php// echo form_error('passo'); ?>
                                                  </div> -->
											  
                                                  
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Password</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="pass1" placeholder=" "   auto-complete  ="off"  required>
                                                      </div>
													  
													  <br /> <?php echo form_error('pass1'); ?>
                                                  </div>
												 
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label"> Retype Password</label>
                                                      <div class="col-lg-6">
                                                          <input type="password" class="form-control" name="password" placeholder=" "  required>
                                                      </div>
													    <br /> <?php echo form_error('password'); ?>
                                                  </div>
												  
												   
												  
												   
												  
												  <?php  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									  </form>
									  
									 