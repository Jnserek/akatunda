
<?php 
 $attributes = array('class' => 'form-horizontal', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>' return create_user_acc();' );

      echo form_open('System_controls/new_price_item', $attributes);

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h4> New Cat Item</h4>
											   
                                              <form class="form-horizontal" role="form">                                                  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">	 Name</label>
													  
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="m_name" placeholder=" "  value="<?php echo set_value('m_name'); ?>"required >
                                                         
													  </div>
													  <br /> <?php echo form_error('m_name'); ?>
                                                  </div>
                                                  
                                                   
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Scientific Name</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="scie_name" placeholder=" " required value="<?php echo set_value('scie_name'); ?>">
                                                      </div>
													  <br /> <?php echo form_error('scie_name'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Category </label>
                                                      <div class="col-lg-6">
                                                          
														  
														  <select class="form-control m-bot15" name ="category"  required>
										  
										  
										  <?PHP 
										
										$cat = $this->bio-> All_Machines_cats('' , 1 );
										if(sizeof($cat) > 0){
											for($i =0; $i<sizeof($cat); $i++){
												$catg = $cat[$i];
											echo '<option value ="'.$catg['id'].'" >'.$catg['name'].'</option>';
												
												
											}
										  
										}
										
										?>
										  </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('hosp'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label"> Specification</label>
                                                      <div class="col-lg-6">
													  
                                                          <input type="text" class="form-control" name="spec"  placeholder=" " value="<?php echo set_value('spec'); ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('spec'); ?>
                                                  </div>
												  
												    <div class="form-group">
                                                      <label class="col-lg-2 control-label"> Description</label>
                                                      <div class="col-lg-6">
													  
                                                          <input type="text" class="form-control" name="descption"    placeholder=" " value="<?php echo set_value('descption'); ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('descption'); ?>
                                                  </div>
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">  Price</label>
                                                      <div class="col-lg-6">
												 
                                                          <input type="number" class="form-control" name="price"    placeholder=" " value="<?php echo set_value('price'); ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('price'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Discount</label>
                                                      <div class="col-lg-6">
												 
                                                          <input type="number" class="form-control" name="discount"    placeholder=" " value="<?php echo set_value('discount'); ?>" >
                                                      </div>
													  <br /> <?php echo form_error('discount'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Mark as new arrival</label>
                                                      <div class="col-lg-6">
													  <select class="form-control m-bot15" name ="new_arrival"  >
										  <option value ="">Select </option>
										  <option value ="0">No </option>
										    <option value ="1">Yes </option>
										  
										  </select>
												 
                                                       </div>
													  <br /> <?php echo form_error('new_arrival'); ?>
                                                  </div>
												  
												    <div class="form-group">
                                                      <label class="col-lg-2 control-label">Mark as featured</label>
                                                      <div class="col-lg-6">
													  
										  <select class="form-control m-bot15" name ="featured"  >
										  <option value ="">Select </option>
										  <option value ="0">No </option>
										    <option value ="1">Yes </option>
										  
										  </select>
													  </div>
													  
                                                  </div>
												  
												 
												  
												   
												  
												   
												  
												  <?php  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									  </form>
									  
									   <script src="assets/js/jquery-2.0.3.min.js"></script> 
	
	  <script src="assets/js/biomedical.js"></script>