 <!--main content start-->
      
         
		  
              <div class="row" id="Acc_Loader">
                 
              <!-- page start-->
              <div class="row">
                 <div class="col-lg-12">
                    <section class="panel">
                          <header class="panel-heading tab-bg-info">
                              <ul class="nav nav-tabs">
                                    <li <?php  if( $_SESSION['profile'] ==0 ) { echo 'class="active"'; }  ?> >
                                  
                                  
                                      <a data-toggle="tab" href="#profile">
                                          <i class="icon-user"></i>
                                          Profile
                                      </a>
                                  </li>
                                   <li <?php  if( $_SESSION['profile'] ==1 ) { echo 'class="active"'; }  ?> >
                                  
                                  
                                      <a data-toggle="tab" href="#edit-profile">
                                          <i class="icon-envelope"></i>
                                          Edit Profile
                                      </a>
                                  </li>
                              </ul>
                          </header>
                          <div class="panel-body">
                              <div class="tab-content">
                                   
                                  <!-- profile -->
								  <div <?php  if( $_SESSION['profile'] ==1 ) { echo 'id="profile" class="tab-pane"'; } else echo 'id="profile"  class="tab-pane active"'; ?> >
                                  
                                  
                                       <div class="bio-graph-heading">
									  <?php 
									 // print_r($this->session->userdata() );
									  $id = $this->session->userdata('bio_id');

									   $profile  =   $this->bio->Get_user_profile_info($id);
									   if(sizeof($profile) < 1){
										   exit('no  profile data found for this user');
									   }
									   
									  // print_r($profile);
									
									  ?>
                                                Hello    <?php  echo $this->session->userdata('bio_name');?>  This is your profile information
                                      </div>
                                      <div class="panel-body bio-graph-info">
                                          <h4>Bio Graph</h4>
                                          <div class="row">
                                              <div class="bio-row">
                                                  <p><span>First Name </span>: <?php  echo  strtoupper($profile['fname']);?></p>
                                              </div>
                                              <div class="bio-row">
                                                  <p><span>Last Name </span>: <?php  echo  strtoupper($profile['lname']);?></p>
                                              </div>                                              
                                               
                                              <div class="bio-row">
                                                  <p><span>Email </span>:<?php  echo  strtolower($profile['email']);?></p>
                                              </div>
                                              
                                              <div class="bio-row">
                                                  <p><span>Phone </span>:  <?php  echo  strtoupper($profile['fon']);?></p>
                                              </div>
                                          </div>
                                      </div>
                                 
                                      
                                  </div>
                                  <!-- edit-profile -->
                                 <div <?php  if( $_SESSION['profile'] ==0 ) { echo 'id="edit-profile" class="tab-pane"'; } else echo 'id="edit-profile"  class="tab-pane active"'; ?> >
                                   
                                   
                                              <h4> Edit Profile Info</h4>
                                             <?php 
 $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt'  , 'method'=>"post"  ,  'onSubmit'=>' return create_user_acc_alt();' );

      echo form_open('System_controls/acc_update_profile', $attributes);

?>
                               <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              
                                              <form class="form-horizontal" role="form">                                                  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">First Name</label>
													  
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="f-name" placeholder=" "  value="<?php    if(set_value('f-name') ) { echo set_value('f-name');} else  echo  strtoupper($profile['fname']);?>"required >
                                                         
													  </div>
													  <br /> <?php echo form_error('f-name'); ?>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Last Name</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="l-name" placeholder=" " value="<?php if( set_value('l-name') ){ echo set_value('l-name'); }else echo  strtoupper($profile['lname']); ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('l-name'); ?>
                                                  </div>
                                                   
                                                 
                                                   
                                                 
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Email</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="email" placeholder=" "  value="<?php if( set_value('email')){echo set_value('email');} else strtolower($profile['email']);  ?>">
                                                      </div>
													  <br /> <?php echo form_error('email'); ?>
                                                  </div>
												  
												  
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Mobile</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="mobile" placeholder=" " required value="<?php if( set_value('mobile')) { echo set_value('mobile');} else  strtolower($profile['fon']);  ?>">
                                                      </div>
													  <br /> <?php echo form_error('mobile'); ?>
                                                  </div>
												   
												  
												  
												  
												   
												  
												   
												  
												  <?php  bio_footer();?>
                                              </form>
                                          </div>
                                       
                      </section>
					  
					   </div>
                        
                     
                 
                 

         