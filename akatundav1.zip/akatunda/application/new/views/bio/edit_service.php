
<?php 

$id = $this->encrypt->decode($_SESSION['mcn_field_id']);
$machine = $this->bio->Get_specific_repair_info($id);
if(sizeof($machine) <1){ exit('Invalid data supplied');}


 $attributes = array('class' => 'form-horizontal', 'id' => 'log'  , 'method'=>"post"  ,  'onSubmit'=>' return service_report_entry();' );
  if($action >0) { echo form_open('System_controls/service_report', $attributes);
	 }
	 else {

      echo form_open('System_controls/service_report', $attributes);
	 }

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h4> Repair Report</h4>
                                              <form class="form-horizontal" role="form">                                                  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Company name</label>
													  
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="c-name" placeholder=" "  value="<?php echo set_value('f-name'); ?>"required >
                                                         
													  </div>
													  <br /> <?php echo form_error('c-name'); ?>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Job No</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="job" placeholder=" " value="<?php echo set_value('job'); ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('job'); ?>
                                                  </div>
                                                   
                                                 
                                                    
												  
												  
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">DIAGNOSIS</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="Diagnosis" placeholder=" " required value="<?php echo set_value('Diagnosis'); ?>">
                                                      </div>
													  <br /> <?php echo form_error('Diagnosis'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">REMEDY</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="remedy" placeholder=" " required value="<?php echo set_value('remedy'); ?>">
                                                      </div>
													  <br /> <?php echo form_error('remedy'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">ADDED APARES</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="Spare" placeholder=" " required value="<?php echo set_value('Spare'); ?>">
                                                      </div>
													  <br /> <?php echo form_error('Spare'); ?>
                                                  </div>
												  
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Technician's comment</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="tech" placeholder=" " required value="<?php echo set_value('tech'); ?>">
                                                      </div>
													  <br /> <?php echo form_error('tech'); ?>
                                                  </div>
												  
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">User's comment</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="user" placeholder=" " required value="<?php echo set_value('user'); ?>">
                                                      </div>
													  <br /> <?php echo form_error('user'); ?>
                                                  </div>
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">New State </label>
                                                      <div class="col-lg-6">
                                                          
														   
										  
										   <select class="form-control" name ="state"  >
											  <option value ="">Select</option>
											<?php  
											$mstates  =$this->bio->All_machine_states();
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											}?>
                                                 
                                            </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('state'); ?>
                                                  </div>
												  
												  
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Total charges</label>
                                                      <div class="col-lg-6">
													  <p  id="check_user"> </p>
                                                          <input type="number" min ="0" class="form-control" name="charge"    placeholder=" " value="<?php echo set_value('charge'); ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('charge'); ?>
                                                  </div>
												  
												   
												  <?php  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									  </form>
									   