
<?php 
 $role = $this->session->userdata('bio_role');
$departments  =$this->bio->get_hospital_departments($role);
 

  $attributes = array('class' => 'form-horizontal', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>' return create_user_acc();' );
      echo form_open('System_controls/Allocation', $attributes);
	  

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h4> Allocate a device</h4>
                                            
											  
											    <div class="form-group">
                                                      <label class="col-lg-2 control-label">Department Name </label>
                                                      <div class="col-lg-6">
                                                          
														   
										  
										                <select class="form-control" name ="state"  required >
											               <option value ="">Select</option>
											               <?php  
											                
											
											
											                for($i=0; $i<sizeof($departments) ; $i++){
												                 $dt =  $departments[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['dname'].'</option>';
											               }?>
                                                 
                                                           </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('state'); ?>
                                                  </div>
												  
											 
												  
												   
												  
												  
												 
												  
												  
												   
												  
												   
												  
												  <?php  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									  </form>
									  
									   