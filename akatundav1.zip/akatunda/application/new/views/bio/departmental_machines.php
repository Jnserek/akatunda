<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			    //$machines1  =$this->bio->Machines_search();
				$supliers   =$this->bio->Supplier_search();
				$manuf   =$this->bio->Manufacturer_Search();
				$hosp   =$this->bio-> specific_hospital($role);
				$sup_loop   = $this->bio-> Suppliers_All ();
				$machines_loop   = $this->bio-> Machines_bank_All();
				$man_loop   = $this->bio->Manufacturers_All();
				
			//	print_r($machines1);
		 

?>     
<div class="panel panel-default table-responsive">
                        <div class="panel-heading  ">
                               <?php 
							  
							   if(sizeof($hosp) > 0 ) {  
							echo $hosp[0]['name'] .' , '.$hosp[0]['ln'] ;
							if($dp > 0){
								
								 
												    for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   if($dp == $item['id'] ){
														    echo '  , '.$item['dname'] .' '; 
														   }															
												        }
												   
											  
								
								
							}
							
							}
							
							?>
                        </div>
                          
						  <?php 
						 //value of machines is determined in the controller
					 

						  if (sizeof( $machines) > 0){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal ', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_new_machines_to_dpts();' );

                              echo form_open('Form_loader/machine_entry_one', $attributes);
							  
					                ?>	
									  
                            <div class="table-responsive">
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Model</th> <th> Sno</th><th> Manufa -<BR/>cturer</th><th> Mfgd: Yr</th><th> Country</th><th> Supplier</th> <?php if($dp < 1) { echo '<th> Department</th>'; }?><th> Status</th> <?php if($action <1){ ?> <th>Comment </th> <?php } if($action > 0){ ?><th> Report  <BR />A Problem</th><th> #Repair Report</th> <th> #Service</th> <th> #Details</th> <?php } ?>     </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php

								for($k=0; $k<sizeof($machines); $k++){ 
								$new = true; 
								//exit('mmmmmmmmmmmm');
								$mac  = $machines[$k];
								$sup_name ="Unknown";  $man_name ="Unknown"; $macn_name ="Unknown"; 
								//check for manufactureres and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 //print_r($machines_loop);
								  
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									if($sup_data['id'] ==$mac['name']  ){
										 $macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1;?>  </td>
								 <td>  <?php  echo   ucfirst($macn_name);?></td>
								 
								 <td>  <?php  
								   IF($mac['mod'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['mod']));
								   
								   ?> 
								   </td>
								 <td>  <?php  
								   IF($mac['sn'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['sn']));
								   
								   ?> 
								   </td>
								 <td>   <?php  echo ucfirst($man_name);?> </td>
								
								  <td>  <?php  echo $mac['yr'];?> </td>
								   
								   <td>  <?php  
								   IF($mac['cou'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['cou']));
								   
								   ?> 
								   </td>
								   <td>   <?php  echo $sup_name;?> </td>
								  <?PHP  if($dp  <  1){
								
								                  if($mac['dep'] ==0 ){  $new = false; echo ' <td>  New Machine </td>'; }
												  else {
												    for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														    echo ' <td>'.  ucfirst(strtolower($item['dname'])) .' </td>'; 
														   }															
												        }
												  }
												   
											  
								
								
							} ?>
								  
								 <td>   
								 
											<?php 
 										
											$mstates  =  $this->bio->All_machine_states();
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($mac['ms'] ==  $dt['id']){
												echo  ucfirst(strtolower($dt['name']));
												}
											}?>
                                                 
                                            </select>

								 </td>
								  <?php if($action <1){ ?>
								   <td>  <?php if($action <1){   
								   IF($mac['comment'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['comment']));
								   
								   } ?>
								   </td>
								   <?php } if($action > 0){ ?>
								  <td>  
								  <label class ="   btn btn-success btn-sm" href =""> <?php  if($new) {?>

								  <input type ="radio"  class ="  label " name ='report' value ="<?php echo $mac['mid'] ?>" onclick="return Report_problem();"  />  
								  <i class ="fa fa-pencil"> Add</i> <?php } ELSE echo '<i class = "fa fa-ban"> </i> N/A'; ?>
								   </label>
								  </td>
								   <td>  <?php   
								   
								    $mstates  =  $this->bio-> pending_requests($this->encrypt->decode($mac['mid']));
								  if($mstates  < 1){
									  echo 'N/A';
								  }
									  
								  
								  else { ?>
								  <label class ="   btn btn-success btn-sm" href =""> <?php  if($new) {?>
								  
								   <input type ="radio"  class ="  label " name ='service' value ="<?php echo $mac['mid'] ?>" onclick="return Service_report();"  />  
								    <i class ="fa fa-pencil"> Add</i>
								  <?php } ELSE echo '<i class = "fa fa-ban"> </i>N/A'; ?>
								   </label>
								   </td>
								 
								  <?php
									  
								  }
								   
								   
								   ?> 
								      
								   
								   
								   </td>
								    <td>  
									<label class ="   btn btn-success btn-sm" href =""> <?php  if($new) {?>
 
									<input type ="radio" class ="  label "  name ='do_service' value ="<?php echo $mac['mid'] ?>" onclick="return Field_service();"  /> 
									 <i class ="fa fa-pencil"> Add</i>
									<?PHP } ELSE echo '<i class = "fa fa-ban"> </i>N/A'; ?>
								   </label>
									
									</td>
									 <td>   
									  <label class ="   btn btn-info btn-sm" href ="">	 <?php // if($new) {?>
									 
									 <input type ="radio" class ="  label "  name ='do_hist' value ="<?php echo $mac['mid'] ?>" onclick="return Machine_hisory();"  /> 
									  <i class ="fa fa-folder-open-o"> View</i> <?PHP //} ELSE echo '<i class = "fa fa-ban"> N/A</i>'; ?>
								   </label>

									 </td>
                                
                                    								 
								   <?php  }  ?>								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
                           
                             
						</DIV>
						<hr />
                  
                   <?php    //bio_footer();?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No data found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                No departments found for this health facility, first add some to continue 
                       .
                            </div>
						
						  

								
							 <?php  }
							   
						
						?>

           
	
	 
	</DIV>
	
	<script src="<?php echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php echo base_url();?>assets/metro/js/dynamic-table.js"></script
	 
                                