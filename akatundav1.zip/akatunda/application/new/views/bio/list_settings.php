      
<div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Settings</h4>
                        </div>  
									    
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Description </th><th> State </th><th> Measurement</th>       <?php  if($this->session->bio_role  <1) {?>  <th>Edit</th>   <?php  } ?>     </tr>
                                   </thead>
                                    <tbody> 
									

                 
                                <?php
								$files = $this->bio->Settings_system('');
								 
								$k = 0;
			 if(sizeof($files) > 0){
				 
				  	foreach($files as $mcn_data){ 
								
								   
								 ?>
                                <tr> 
								
								 <td>  <?PHP echo $k +=1; // $all_machines?>   </td>
								 </td>
								 
								 <td> 
								 <?php 
								 
									  echo $mcn_data['name'];
									 
								  ?>
								 </td> 
								 
								  <td> 
								 <?php 
								 
									   if( $mcn_data['state'] ==0  ){
										 echo 'Not Active'; 
										  
									  }
									  else if(  $mcn_data['state'] ==1 ){
										  echo 'Active';
									  }
									  else echo $mcn_data['state'];
									 
								  ?>
								 </td> 
								 
								  <td> 
								 <?php 
								 
									 if( $mcn_data['state'] ==0 ||$mcn_data['state'] ==1 ){
										  
										  echo 'True / False';
									  }
									  else echo 'Days';
									 
								  ?>
								 </td> 
								 
								 
								  
								  
								 

								 <?php   if($this->session->bio_role  =="**") {?>
								 
								 <td><?php
								 
								 ?>
								 
								 <button  class  ="download_back_up btn btn-warning "   value ="<?php echo $mcn_data['id'];?>">  Edit</button> 
								 
                                    
                                  </td>
								   
								 <?php }  ?>
								 	
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								   
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No Setting was found </strong></h5>
                            
						
						  

								
							 <?php  }   
						
						?>
			 
	</DIV>
	
	
	
	<script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   <script>
   $('.download_back_up').click(function() {
            var item = $(this).attr("value");
			BioCustom2( 'Form_loader' , 'Download_machine' ,    item , 4 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
   </script>

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
	
 
	 
                                