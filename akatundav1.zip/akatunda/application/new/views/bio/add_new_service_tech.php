


<section id="panel"> 

 <section class="panel">
                          <header class="panel-heading">
                              <h4>  Technician</h4>
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                          
                                <div class="col-md-12" >
							 
                             <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'new_machine', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );

                              echo form_open('System_controls/Add_new_service_technician', $attributes);
					   
?>			                     
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label"> Name</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name" placeholder=""  value = "<?php echo set_value('name') ?>" required>
                                          <p class="help-block"><?php echo form_error('name');  ?> </p>
                                      </div>
                                  </div>
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="contact"  value = "<?php echo set_value('contact') ?>" placeholder=""  >
                                          <p class="help-block"><?php echo form_error('contact'); ?> </p>
                                      </div>
                                  </div>
								  
								  
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Email Address</label>
                                      <div class="col-lg-7">
                                          <input type="email" class="form-control" name="email" placeholder="" value = "<?php echo set_value('email') ?>"  >
                                          <p class="help-block"><?php echo form_error('email'); ?> </p>
                                      </div>
                                  </div>
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Company</label>
                                      <div class="col-lg-7">
                                          
										  
										    <select class="form-control" name ="tech_comp"  >
											               <option value ="" > Free lancer</option>  
											                
											                <?php  
											                $mstates  =$this->bio->Servicing_company('');
															 
											               ?>
											             
											               <?php  
											                  for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
														   
														   
                                                 
                                                           </select>
                                      </div>
                                  </div>
								  
								  
								   <?php    bio_footer();?>
                        </form>

                                 
    </div>
	</div>
	
	</div>
	</section></section>
                                