 <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Get Report
                          </header>
                          <div class="panel-body">
						  <?php 
						                        $attributes = array('class' => 'form-inline', 'role' => 'form', 'id' => 'new_client',   'method'=>"post"  ,  'onSubmit'=>' return Seacrh_system();' );

                              echo form_open('System_controls/Get_Reports', $attributes);
							  $role  = $this->session->bio_role;
							  $departments  = $this->bio->get_hospital_departments($role); 
							  
					   
?>		
						  
                               
                                    
								   <div class=" col-lg-12">
								   <div class="form-group col-lg-2" style ="width:125px;">
								    <?php $machines = $this->bio-> All_Hospitals();  
									
									

									?>
                                     
                                          <select class="form-control m-bot15" name="client" style ="width:120px;" >
										  <?php if($role > 0){
											   foreach($machines as $mcn){
												   if($role == $mcn['id']){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['name'].'</option>';
												   }
											  }
										
									} else { ?>
										   <option value ="-1">Client</option>
										     <option value ="0">All Clients</option>
                                               <?php 
											   //if($this->session->bio_role  < 1){ }
											   
											  foreach($machines as $mcn){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['name'].'</option>';
											  }
									} 
											  ?>
                                          </select>
										  <?php echo form_error('client'); ?> 
    
                                  </div>
								  <div class="form-group col-lg-2" style ="width:155px;">
									 
									<?php $machinesx = $this->bio-> Machines_bank_All(); 
																				 
									?>
                                    
                                          <select id="many"  name="machine"  class="form-control m-bot15" style ="width:150px;" >
										  <option value=""  >  All DEVICES</option>
										     
                                              
											  <?php  
											  foreach($machinesx as $mcn){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['name'].'</option>';
											  }
											  
											  ?> 
                                          </select>
										  <?php echo form_error('machine'); ?>   
    
                                  </div>
								  
								  <div class="form-group col-lg-2" style ="width:120px;">
								    <?php    ?>
                                     
                                          <select class="form-control m-bot15" name="department" style ="width:120px;" >
										   <option value ="-1">Department</option>
										     <option value ="0"> All Departments</option>
                                               <?php  
											  foreach($departments  as $mcn){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['dname'].'</option>';
											  }
											  
											  ?>
                                          </select>
										  <?php echo form_error('department'); ?> 
    
                                  </div>
								   
								   <div class="form-group col-lg-2">
								  
                                     
                                          <select class="form-control m-bot15" name="type" style ="width:150px;" >
										      <option value ="-1">Report Type Select </option>
										     <option value ="0">General </option>
											 <option value ="1">Service </option>
											 <option value ="2">Device Problems </option>
											 <option value ="3">Repair </option>
                                               
                                          </select>
										  <?php echo form_error('type'); ?>
    
                                  </div>
								 
								   
								   
								   <div class=" col-lg-2" style ="width:170px;">
                                       
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar">From</i>
                                            </div>
                                            <input type="text"  style ="width:160px;" name  ="p1" class="form-control m-bot15" data-inputmask="&#39;alias&#39;: &#39;dd-mm-yyyy&#39;" data-mask="">
                                        </div><!-- /.input group -->
                                    </div><!-- /.form group -->
									
									
									<div class=" col-lg-2" style ="width:150px;">
                                       
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar">To</i>
                                            </div>
                                            <input type="text"  style ="width:140px;" name  ="p2"  class="form-control m-bot15" data-inputmask="&#39;alias&#39;: &#39;dd-mm-yyyy&#39;" data-mask="">
                                        </div><!-- /.input group -->
                                    </div><!-- /.form group -->
									<div class=" col-lg-2" style ="width:120px;">

								  
								  
                                  <button type="submit" class="btn btn-primary "  > Search</button>
								  </div>
                              </form>
							  
                          </div>
						  </div>
                      </section>

                  </div>
              </div>
			    <div class="col-lg-12"  id="Content_loader"  > </div>
				
				
				  <script src="<?php echo base_url();?>assets/js/date/jquery.inputmask.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/js/date/jquery.inputmask.date.extensions.js" type="text/javascript"></script> 
        

        <!-- Page script -->
        <script type="text/javascript">
            $(function() {
                //Datemask dd/mm/yyyy
                $("#datemask").inputmask("dd-mm-yyyy", {"placeholder": "dd-mm-yyyy"});
                //Datemask2 mm/dd/yyyy
               // $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
                //Money Euro
                $("[data-mask]").inputmask();

                 
                 
            });
        </script>

		  