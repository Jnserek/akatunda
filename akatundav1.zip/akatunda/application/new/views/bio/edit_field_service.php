

<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
										  
										  <?php 
//edit_field_service

$id = $this->encrypt->decode($_SESSION['mcn_field_id']);
$machine = $this->bio->Specific_service_info($id);
if(sizeof($machine) <1){ exit('Invalid data supplied');}

 $attributes = array('class' => 'form-horizontal', 'id' => 'log'  , 'method'=>"post"  ,  'onSubmit'=>' return service_report_entry();' );

      $machine =$machine[0];
	  if($action >0) { 
	   echo form_open('System_controls/Field_report_edit', $attributes);
	 
	 }
	 else {

      echo form_open('System_controls/Delete_Field_report', $attributes);
	 }

	   

?>
										  <?php  if($action >0) { ?>
                                              <h4> Service Report</h4>
                                            
											  
											    <div class="form-group">
                                                      <label class="col-lg-2 control-label">Current State </label>
                                                      <div class="col-lg-6">
                                                          
														   
										  
										                <select class="form-control" name ="state1"  required >
														 <?php  
											                $mstates  =$this->bio->All_machine_states();
											                 for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
																 if($dt['id']  == $machine['state'] ){
												                  echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
																 }
											               }?>
											               <option value ="">Select</option>
											               <?php  
											                  for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
                                                 
                                                           </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('state1'); ?>
                                                  </div>
												  
												  

											  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Comment</label>
													  <div class="col-lg-6">
													  <textarea  class="form-control" name="comment"    >
													  <?php if(set_value('comment')) { echo set_value('comment'); } else echo  $machine['com']; ?>
													  </textarea>
                                                           
                                                         
													  </div>
													   
													  <br /> <?php echo form_error('comment'); ?>
                                                  </div>
												  
												  
												  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Way forward</label>
													  <div class="col-lg-6">
													  <textarea  class="form-control" name="way_foward"     >
													  <?php if(set_value('way_foward')) { echo set_value('way_foward');}  else echo $machine['wf']; ?>
													  </textarea>
                                                           
                                                         
													  </div>
													   
													  <br /> <?php echo form_error('way_foward'); ?>
                                                  </div>
                                                  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">New State </label>
                                                      <div class="col-lg-6">
                                                          
														   
										  
										                <select class="form-control" name ="state"  >
											               
											                
											                <?php  
											                $mstates  =$this->bio->All_machine_states();
											                 for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
																 if($dt['id']  == $machine['new_st'] ){
												                  echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
																 }
											               }?>
											               <option value ="">Select</option>
											               <?php  
											                  for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
														   
														   
                                                 
                                                           </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('state'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Name of Technician</label>
													  <div class="col-lg-6">
													     <select class="form-control" name ="technician_name"  >
											                 
											                
											                <?php  
											                $mstates  =$this->bio->Servicing_techs('');
															   for($i=0; $i<sizeof($mstates) ; $i++){
																   
												                 $dt =  $mstates[$i];
																 if($dt['id'] ==$machine['technician'] ){
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
																 }
											               }
															 
											               ?>
											             <option value ="0" > Free lancer</option>
											               <?php  
											                  for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
														   
														   
                                                 
                                                           </select>    
                                                         
													  </div>
													   
													  <br /> <?php echo form_error('technician_name'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Service company.</label>
													  <div class="col-lg-6">
													    <select class="form-control" name ="comp"  >
											                
											                
											                <?php  
											                $mstates  =$this->bio->Servicing_company('');
															  for($i=0; $i<sizeof($mstates) ; $i++){
																   
												                 $dt =  $mstates[$i];
																 if($dt['id'] ==$machine['tech_company'] ){
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
																 }
											               }
															 
											               ?>
														   <option value ="0" > Free lancer</option> 
											             
											               <?php  
											                  for($i=0; $i<sizeof($mstates) ; $i++){
												                 $dt =  $mstates[$i];
												               echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											               }?>
														   
														   
                                                 
                                                           </select>
                                                           
                                                         
													  </div>
													   
													  <br /> <?php echo form_error('comp'); ?>
                                                  </div>
												  
										  <?php } else {?>
										  <div class="col-lg-12">
									 <h4> Click submit to finish this action. </h4>
									 
									 </div>
												  
										  <?php }  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									    </div>
									   
									  
									   