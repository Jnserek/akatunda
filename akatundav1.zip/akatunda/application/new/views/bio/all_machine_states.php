<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			 $role = $this->session->userdata('bio_role');
			 
			 
			  $all_machines  =$this->bio->All_machine_states();
			   

?>     
<div class="panel panel-default">
                        <div class="panel-heading">
                            <h4> Device States. </h4>
                        </div>
                        
  
						  <?php  if (sizeof( $all_machines) > 0){  
							 
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"    );

                              echo form_open('Form_loader/Update_depreciation_rates', $attributes);
							  
					                ?>	
									  
							 
                                 <table class="table table-striped table-bordered" id="sample_1">

                                    <thead>
                                    <tr> <th> No</th><th> Name</th>   <?php  if($action > 0) { if($this->session->bio_role  <1) {?> <th>Edit</th>  <?php } } ?>     </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php for($k=0; $k<sizeof( $all_machines); $k++){ 
								
								$mcn_data =$all_machines[$k];  
								 ?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1; // $all_machines?>   </td>
								 </td>
								 <td> 
								 <?php 
								 
									 echo $mcn_data['name'];
									 
								  ?>
								 </td> <?php  if($action > 0) { if($this->session->bio_role  <1) {?>
								 
								 <td>
                                   
                                            <input type="radio"  name ="alt_machine_info"  class='form-control'  onclick ="return alt_machine_state_info(); " value="<?php   echo $this->encrypt->encode($mcn_data['id']); ?>">
                               
                                  </td>
								 <?php } } ?>
								 	
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								<br /><br />
                           
                             <?php if($this->session->bio_role  <1) { //  bio_footer();
						
						}?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No Machine was found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                No departments found for this health facility, first add some to continue  <a class="btn btn-primary btn-lg" role="button"  href="" onClick="return   more_hfs_form()">Add Departments</a>
                       .
                            </div>
						
						  

								
							 <?php  }
							 
							
						
						?> 
                                 
    </div>
	   
  
  
      
	 
	 
                                