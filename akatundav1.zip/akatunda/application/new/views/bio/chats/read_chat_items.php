<div class="row" style="padding:40px;" >
            <div class="col-md-10 portlets">
              <!-- Widget -->
              <div class="panel panel-default">
				<div class="panel-heading">
                  <div class="pull-left">Message</div>
                  <div class="widget-icons pull-right">
                    <a href="" class="wminimize"><i class="fa fa-chevron-up"></i></a> 
                    <a href="" class="wclose"><i class="fa fa-times"></i></a>
                  </div>  
                  <div class="clearfix"></div>
                </div>

                <div class="panel-body">
                  <!-- Widget content -->
                  <div class="padd sscroll">
                    
                    <ul class="chats"> 
					<?php //chat shd be 0.
					   $receiver = $this->encrypt->decode( $_SESSION['chat_receiver']);
					   $sender  =  $this->session->bio_id; 
					  $chats = $this->bio-> Load_Chats($sender , 0 ,$receiver , 6); 
					  $count =0;
					    foreach($chats as $row){ 
						
						
					   
					  
					if($count <8){
					
					 
				 
							  $log_time =  substr($row['log'] ,0 ,  10);  
						 
					   $time_diff= dateDiff( $log_time , timeCurrent2());
					   
					 $read = $row['read'];
					 $flag = ''; 
					 $Sender = 'Me';
					 $Phone_no = ''; 
					 
						if($sender ==$row['sender'] ){
						 
					    ?> 

                      <!-- Chat by us. Use the class "by-me". -->
                      <li class="by-me">
                        <!-- Use the class "pull-left" in avatar -->
                        <div class="avatar pull-left">
                          <img src="../assets/img/user.jpg" alt=""/>
						  <?php
						}
else 						{
	       $techx = array();
	 if($row['sender'] >0){
		 $techx = $this->bio->Tech_name($row['sender'] );
		 
	 }
	
	if(sizeof($techx ) > 0){
		$Sender =  $techx[0]['fname'].',  '.$techx[0]['lname']; 
$Phone_no =  '<span  class=" icon icon-phone">'.$techx[0]['fon'].$Phone_no.'</span>';		
		
		
	}
		if($read  <1){
						 $flag = '<span class="badge bg-warning">NEW </span>';
						 
					 }
							
							?>
							 <li class="by-other">
                        <!-- Use the class "pull-right" in avatar -->
                         <div class="avatar pull-right">
							
							<?php
						}
			
						?>
                        </div>

                        <div class="chat-content">
                          <!-- In meta area, first include "name" and then "time" -->
                          <div class="chat-meta"> <?php echo $flag;?> <br />  <?php  echo $Sender;  echo ' , '; echo  $Phone_no ; //echo  $row['id'];?> <span class="pull-right"><?php if( $time_diff >0){ echo 'Today';} else { echo  $time_diff.' Days ago';}?></span></div>
                          <?php echo  $row['msg'];?>
                          <div class="clearfix"></div>
                        </div>
                      </li> 
				 <?php 
					}
					$count +=1;
					
					}
					?>

					 
                                                                                     

                    </ul>

                  </div>
                  <!-- Widget footer -->
                  <div class="widget-foot">
				  <?php 
				  if($this->session->tempdata()){
				  //message
				   echo '<span class="badge bg-success">'.
$this->session->tempdata('message').'</span>';
				  }
 $attributes = array('class' => 'form-inline', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>' return create_user_acc();' );

      echo form_open('System_controls/new_chat_item', $attributes);

?>
                       
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Type your message here..." name="chat_message">
						</div>
                        <button type="submit" class="btn btn-info">Send</button>
                      </form>


                  </div>
				  <?php //mark as read
				   $this->bio->   Mark_as_read($sender , 0 ,$receiver , 6);
				  
				  
				  ?>
                </div>


              </div> 
            </div>

                   
                  </div> 
				
						
						
			       </div>
				      
					 
					 
	<script src="assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="assets/metro/js/dynamic-table.js"></script