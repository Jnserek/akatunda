 
            <div class="col-md-8 portlets"  >
              <!-- Widget -->
              <div class="panel panel-default">
				<div class="panel-heading">
                  <div class="pull-left">System notifications</div>
                  <div class="widget-icons pull-right">
                    <a href="" class="wminimize"><i class="fa fa-chevron-up"></i></a> 
                    <a href="" class="wclose"><i class="fa fa-times"></i></a>
                  </div>  
                  
                </div>

                <div class="panel-body"> 
                  <div class="padd sscroll">
                    
                    <ul class="chats">
					 
					<?php  
					  $receiver = $sender  =  $this->session->bio_id; 
					 $chat = $this->bio-> Load_Notifucations($sender , 1);//load notifications where I am the sender
					 
					 $chats = $this->bio->sort_descending($chat, 'id');
					 $count =0;
					  
					  foreach($chats as $row){ 
					  
					if($count <8){
					 $log_time =  substr($row['log'] ,0 ,  10);  //get time portion
				     $time_diff= dateDiff( $log_time , timeCurrent2()); //compute time difference
					 
					   
					 $read = $row['read'];
					 $flag = ''; 
					 $Sender = 'Me';
					 $Phone_no = ''; 
					 
						if($sender ==$row['sender'] ){
							  
						}
else 			{
	$techx = array();
	if($row['sender'] < 1){
		$Sender = 'From , System '; 
		
	}
	
	 if($row['sender'] > 0){
	    $techx = $this->bio->Tech_name($row['sender'] );
	 }
	if(sizeof($techx ) > 0){
		$Sender = ' From '.$techx[0]['fname'].' '.$techx[0]['lname']; 
        $Phone_no =  '<span  class=" icon icon-phone">'.$techx[0]['fon'].$Phone_no.'</span>';		
		
		
	}
		if($read  <1){
						 $flag = '<span class="badge bg-warning">NEW </span>';
						 
					 }
							
							?>
							 <li class="by-other">
                        <!-- Use the class "pull-right" in avatar -->
                        <div class="avatar pull-right">
							
							<?php
						}
			
						?>
                        </div>

                        <div class="chat-content">
                          <!-- In meta area, first include "name" and then "time" -->
                          <div class="chat-meta"> <?php echo $flag;?> <br />  <?php  echo $Sender;  echo ' , '.$row['log']; echo  $Phone_no ; //echo  $row['id'];?> <span class="pull-right"><?php if( $time_diff <1){ echo 'Today';} else { echo  $time_diff.' Days ago';}?></span>
						  </div>
                          <?php echo  $row['msg'];?>
                          <div class="clearfix"></div>
                        </div>
                      </li> 
					<?php 
					 
					
					}
					$count +=1;
					}//$receiver = $sender
$this->bio->   Mark_as_read($sender , 0 ,$receiver , 6);
					?>,,,,,,,,,,,,,,,,,,,,,,,
   
  </tbody>

                     </table>                                                                                  

                    </ul>

                  </div>
                  
                </div>


              </div> 
            </div> 
					 
					 
	<script src="<?php echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php echo base_url();?>assets/metro/js/dynamic-table.js"></script