     
<div class="panel panel-default" style  ="min-height:400px">
                         
						  <?php 
						                        $attributes = array('class' => 'form-inline', 'role' => 'form', 'id' => 'new_client',   'method'=>"post"  ,  'onSubmit'=>' return Seacrh_system();' );

                              echo form_open('System_controls/Search_data', $attributes);
					   
?>		
		
 
 
                        
                                    <div class="form-group">
									<input type="hidden" name ="machines"  id ="machines"  >
									<?php $machines = $this->bio-> Machines_bank_All(); 
																				 
									?>
                                     
                                          <select class="form-control m-bot14 col-lg-1" id="many"  name="machinex[]"  multiple>
										     
                                              
											  <?php  
											  foreach($machines as $mcn){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['name'].'</option>';
											  }
											  
											  ?> 
                                          </select>
										  <?php echo form_error('machine'); ?>   
    
                                  </div>
								  
								   <div class="form-group">
								    <?php $machines = $this->bio-> All_Hospitals();  
									$role  = $this->session->bio_role;
									

									?>
                                     
                                          <select class="form-control m-bot15" name="client" >
										  <?php if($role > 0){
											   foreach($machines as $mcn){
												   if($role == $mcn['id']){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['name'].'</option>';
												   }
											  }
										
									} else { ?>
										   <option value ="-1">Client</option>
										     <option value ="0">All Clients</option>
                                               <?php 
											   //if($this->session->bio_role  < 1){ }
											   
											  foreach($machines as $mcn){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['name'].'</option>';
											  }
									} 
											  ?>
                                          </select>
										  <?php echo form_error('client'); ?> 
    
                                  </div>
								  
								  <div class="form-group">  
								  <input type="hidden" name ="dpt"  id ="dpt"  >
										  
										  <select class="form-control m-bot15" name="dtype"   id="dpt_type"    multiple > 
										  
										  
									 
									
									<?php

									$dep_types =  $this->bio-> department_types();
								 
										 
									
									foreach($dep_types as $row){
										  echo ' <option value ="'.$row['id'].'" >'.$row['name'].'</option>';
										
									}
									
									?>
									
									 
														   
                                                 
                                    </select> 
                                          <?php echo form_error('dtype'); ?> 
                                      </div>
								  
								  <div class="form-group">
								  <input type="hidden" name ="manf"  id ="manf"  >
								    <?php $machines = $this->bio-> Manufacturers_All();    ?>
                                     
                                          <select class="form-control m-bot15" name="manuf"  id="many_man"  multiple >
										   
										    
										    
                                               <?php  
											  foreach($machines as $mcn){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['name'].'</option>';
											  }
											  
											  ?>
                                          </select>
										  <?php echo form_error('manuf'); ?> 
    
                                  </div>
								  
								  <div class="form-group">
								    <?php $machines = $this->bio-> All_machine_suppliers();  ?>
                                     
                                          <select class="form-control m-bot15" name="sup" >
										   <option value ="-1">Suppliers</option>
										     <option value ="0">All Suppliers</option>
                                               <?php  
											  foreach($machines as $mcn){
												  
												  echo ' <option value="'.$mcn['mid'].'" >'.$mcn['m_name'].'</option>';
											  }
											  
											  ?>
                                          </select>
										  <?php echo form_error('sup'); ?>
    
                                  </div>
								  
                                   
								   
								   <div class="form-group">
								    <?php $machines = $this->bio-> All_machine_states();    ?>
                                     
                                          <select class="form-control m-bot15" name="state" >
										   <option value ="-1">States</option>
										     <option value ="0">All States </option>
                                               <?php  
											  foreach($machines as $mcn){
												  
												  echo ' <option value="'.$mcn['id'].'" >'.$mcn['name'].'</option>';
											  }
											  
											  ?>
                                          </select>
										  <?php echo form_error('state'); ?>
    
                                  </div>
								 
								  
								   
								  
								  
								  
								   <div class="form-group">
                                     
                                          <select class="form-control m-bot15" name="y1" >
                                               
                                               <option value ="1">From </option> 
                                          </select>
										  <?php echo form_error('y1'); ?>
    
                                  </div>
								  
								  
								  <div class="form-group">
                                     
                                          <select class="form-control m-bot15" name="y2" >
                                              <option value ="1">To </option>
											    
                                              
                                          </select>
										  <?php echo form_error('y2'); ?>
    
                                  </div>
								  
								  
                                  <button type="submit" class="btn btn-primary ">Search</button>
                              </form>
					  <div class="col-lg-12"  id="Content_loader"  ></div>

              </div>
			  
			  				  
			   
				
				 
 
<!-- Include the plugin's CSS and JS: -->
<script type="text/javascript" src="<?php echo base_url();?>assets/mult/js/bootstrap-multiselect.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>assets/mult/css/bootstrap-multiselect.css" type="text/css"/>
				
								  <script type="text/javascript">
    $(document).ready(function() {
          
      
            $('#many').multiselect({
				  maxWidth: 50,
				 maxHeight: 200,
            includeSelectAllOption: true,
            enableFiltering: true
			
			
        });
		//
		
		  $('#dpt_type').multiselect({
				 
			maxHeight: 200,	
			 maxWidth: 50,
            includeSelectAllOption: true,
            enableFiltering: true
			 
			
        });
		
		 $('#many_man').multiselect({
				 maxWidth: 50,
                maxHeight: 200,					 
				
            includeSelectAllOption: true,
            enableFiltering: true
			 
			
        });
        
    });
</script>
    

		  