
<?php 
 $attributes = array('class' => 'form-horizontal', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>' return machine_problem();' );

    




	echo form_open('System_controls/machine_problem', $attributes);

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h4> Machine Problem</h4>
                                          
											  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Description</label>
													  <div class="col-lg-6">
													  <textarea  class="form-control" name="f-name"  required >
													  <?php echo set_value('f-name'); ?>
													  </textarea>
                                                       </div>
													   <br /> <?php echo form_error('f-name'); ?>
                                                  </div>
												   <div class="form-group">
												  <label class="col-lg-2 control-label">Notify JMS</label>
												   <div class="col-lg-6">
												   <input type="radio"  name ="notify_jms"  value ="11"  checked  /> YES (Message will be sent automcatically to Jms Technician)<br />
												   <input type="radio" name ="notify_jms"     value ="0"  /> NO
												   
													  
                                                       </div>
													    </div>
                                                   
													   <input type ="hidden" name ="state" value  ="7"  />
                                                          
												   
												  
												  <?php  bio_footer();?>
                                              
                                          </div>
                                      </section>
									  </form>
									  
									   