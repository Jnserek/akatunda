


<section id="panel"> 

 <section class="panel">
                          <header class="panel-heading">
                              <h4>  Servicing Company</h4>
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                          
                                <div class="col-md-12" >
							 
                             <?php 
							 $files =   $this->bio->List_Companies($_SESSION['service_company_id']);
							 
							 if(sizeof($files) < 1){
								 exit('No data is found about this company');
							 }
							 $company = $files[0]; 
                               $attributes = array('class' => 'form-horizontal', 'id' => 'new_client',   'method'=>"post"  ,  'onSubmit'=>' return create_new_hosp_acc();' );

                              echo form_open('System_controls/Edit_service_company', $attributes);
					   
?>			                     
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">Company Name</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name" placeholder=""  value = "<?php if(set_value('name') ) { echo set_value('name');} else echo  $company['name'];  ?>" required>
                                          <p class="help-block"><?php echo form_error('name');  ?> </p>
                                      </div>
                                  </div>
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="contact"  value = "<?php   if(set_value('contact') ) { echo set_value('contact');} else echo  $company['phone'];  ?>" placeholder=""  >
                                          <p class="help-block"><?php echo form_error('contact'); ?> </p>
                                      </div>
                                  </div>
								  
								  
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Email Address</label>
                                      <div class="col-lg-7">
                                          <input type="email" class="form-control" name="email" placeholder="" value = "<?php if(set_value('email') ) { echo set_value('email');} else echo  $company['email'];  ?>"  >
                                          <p class="help-block"><?php echo form_error('email'); ?> </p>
                                      </div>
                                  </div>
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Location</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="loc" placeholder=""  value = "<?php if(set_value('loc') ) { echo set_value('loc');} else echo  $company['location'];  ?>" >
                                          <p class="help-block"><?php echo form_error('loc'); ?> </p>
                                      </div>
                                  </div>
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact Person</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="contactp" placeholder=""  value = "<?php if(set_value('contactp') ) { echo set_value('contactp');} else echo  $company['agent'];  ?>" >
                                          <p class="help-block"><?php echo form_error('contactp'); ?> </p>
                                      </div>
                                  </div>
								  
								   <?php    bio_footer();?>
                        </form>

                                 
    </div>
	</div>
	
	</div>
	</section></section>
                                