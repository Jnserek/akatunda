
<?php 
if(!isset($_SESSION['cat_item_alt'])) { bio_error('No item was found');}
$item =  $_SESSION['cat_item_alt'];

 $attributes = array('class' => 'form-horizontal', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>' return create_user_acc();' );

     

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
										  <?php  if($action > 0) {echo form_open('System_controls/Edit_cat_item', $attributes);?>
                                              <h4> Edit Cat Item</h4>
											   
                                              <form class="form-horizontal" role="form">                                                  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">	 Name</label>
													  
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="m_name" placeholder=" "  value="<?php if( set_value('m_name') ) { echo set_value('m_name');} else echo $item['name']; ?>"required >
                                                         
													  </div>
													  <br /> <?php echo form_error('m_name'); ?>
                                                  </div>
                                                  
                                                   
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Scientific Name</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="scie_name" placeholder=" " required value="<?php if( set_value('scie_name')  ) { echo set_value('scie_name');} else echo $item['sname']; ?>">
                                                      </div>
													  <br /> <?php echo form_error('scie_name'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Category </label>
                                                      <div class="col-lg-6">
                                                          
														  
														  <select class="form-control m-bot15" name ="category"  required>
										  
										  
										  <?PHP 
										
										$cat = $this->bio-> All_Machines_cats('' , 1 );
										if(sizeof($cat) > 0){
											for($i =0; $i<sizeof($cat); $i++){
												$catg = $cat[$i];
												if($catg['id'] ==$item['cat'] ){
											echo '<option value ="'.$catg['id'].'" >'.$catg['name'].'</option>';
												}
												
												
											}
											
											for($i =0; $i<sizeof($cat); $i++){
												$catg = $cat[$i];
											echo '<option value ="'.$catg['id'].'" >'.$catg['name'].'</option>';
												
												
											}
										  
										}
										
										?>
										  </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('hosp'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label"> Specification</label>
                                                      <div class="col-lg-6">
													  
                                                          <input type="text" class="form-control" name="spec"  placeholder=" " value="<?php if( set_value('spec') ){ echo set_value('spec');} else echo $item['spec'] ; ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('spec'); ?>
                                                  </div>
												  
												    <div class="form-group">
                                                      <label class="col-lg-2 control-label"> Description</label>
                                                      <div class="col-lg-6">
													  
                                                          <input type="text" class="form-control" name="descption"    placeholder=" " value="<?php if( set_value('descption') ) { echo set_value('descption');} else echo $item['desc']; ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('descption'); ?>
                                                  </div>
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">  Price</label>
                                                      <div class="col-lg-6">
												 
                                                          <input type="number" class="form-control" name="price"    placeholder=" " value="<?php if(set_value('price')) {echo set_value('price');} else echo $item['price']; ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('price'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Discount</label>
                                                      <div class="col-lg-6">
												 
                                                          <input type="number" class="form-control" name="discount"    placeholder=" " value="<?php if(set_value('discount')) {echo set_value('discount'); } else { echo $item['discount'];}; ?>" >
                                                      </div>
													  <br /> <?php echo form_error('discount'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Mark as new arrival</label>
                                                      <div class="col-lg-6">
													  <select class="form-control m-bot15" name ="new_arrival"  >
													  <?php if($item['New'] ==0 ){ ?>
													  
													  <option value ="0">No </option>
													  <?php } else {?>
										               <option value ="1">Yes </option>
													  
													  <?php } ?>
													  
										  <option value ="">Select </option>
										  <option value ="0">No </option>
										    <option value ="1">Yes </option>
										  
										  </select>
												 
                                                       </div>
													  <br /> <?php echo form_error('new_arrival'); ?>
                                                  </div>
												  
												    <div class="form-group">
                                                      <label class="col-lg-2 control-label">Mark as featured</label>
                                                      <div class="col-lg-6">
													  
										  <select class="form-control m-bot15" name ="featured"  >
										  <?php if($item['fet'] ==0 ){ ?>
													  
													  <option value ="0">No </option>
													  <?php } else {?>
										               <option value ="1">Yes </option>
													  
													  <?php } ?>
										  <option value ="">Select </option>
										  <option value ="0">No </option>
										    <option value ="1">Yes </option>
										  
										  </select>
													  </div>
													  
                                                  </div>
												  
												 
												  
												  <?php bio_footer(); } else  if($action < 1) {
													  
													  echo form_open('System_controls/Delete_catlog_item', $attributes);//
		 
		                warning('Are you sure you want to delete this item ?');
delete();						
  			
		 
	 }?> 
												  
												   
												  
												  <?php // bio_footer();?>
                                              </form>
	 
                                          </div>
                                      </section>
									  </form>
									  
									   <script src="assets/js/jquery-2.0.3.min.js"></script> 
	
	  <script src="assets/js/biomedical.js"></script>