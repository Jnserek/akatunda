



	
	 <!--main content start-->
      
         
		  
              <div class="row" id="Acc_Loader">
                 
              <!-- page start-->
              <div class="row">
                 <div class="col-lg-12">
                    <section class="panel">
                          <header class="panel-heading tab-bg-info">
                              <ul class="nav nav-tabs">
                                    <li  class="active"  >
                                  
                                  
                                      <a data-toggle="tab" href="#profile">
                                          <i class="icon-user"></i>
                                        <h4> New departments. </h4>
                                      </a>
                                  </li>
                                   <li    >
                                  
                                  
                                      <a data-toggle="tab" href="#edit-profile">
                                          <i class="icon-envelope"></i>
                                          My departments.
                                      </a>
                                  </li>
                              </ul>
                          </header>
                          <div class="panel-body">
                              <div class="tab-content">
                                   
                                  <!-- profile -->
								  <div  id="profile"  class="tab-pane active"  >
                                  
                                  
                            <section class="panel">
                            <section id="panel"> 
 
                          <header class="panel-heading">
                             <h4> How many departments do you want to add ? </h4>
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                                <div class="row">
                                  <div class="col-md-12" >
							 
                             <?php 
							 $dep_types =  $this->bio-> department_types();
									
                                $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return Department_numbers();' );

                              echo form_open('System_controls/get_department_numbers', $attributes);
					  
					  

?>			                     
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">Number of departments to be added</label>
                                         <div class="col-lg-7">
                                          <input type="number" class="form-control" name="dpts" placeholder="" required>
                                          <p class="help-block"><?php echo form_error('dpts'); ?> </p>
                                         </div>
                                     </div>
								  
								         <?php    bio_footer();?>
                                      </form>
                                   </div>
	                               </div>
	
	                              </div>
	                            </section>
	                            </section>
                                       
                                  </div>
                                  <!-- edit-profile -->
                                 <div  id="edit-profile" class="tab-pane" class="tab-pane active" >
								 
								  <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              
                                              
												  <section class="panel">
                                                       <header class="panel-heading">
                                                           <h4> My Departments</h4>
                                                        </header>
                                   
                                   
                                             
											 
                                             <?php 
											 $role = $this->session->userdata('bio_role');
											 
											 
											 $departments  =$this->bio->get_hospital_departments($role);
											 if(sizeof($departments) <1){
												 echo 'no departments found';
											 } 
											 
											 else { ?>
											            <div class="list-group">
														<table class="table table-responsive" >
														<thead> <th>Name</th><th>Department Type</th> </thead>
														<tbody>
														
											 
											 
											 <?php
												 
												       for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   $dtype = $item['dtype'];
														   $name      = '';
														   if( $dtype <1){
															   $name      = 'Unknown';
															   
														   }
														   else {
															   foreach($dep_types as $row){
										                            if($row['id'] ==$dtype){
											                          $name      =$row['name'];
										                                 }
										
									                                }
														   }
														   
													        echo ' <tr><td>'.$item['dname'].'</td><td>'.$name.'</td></tr>';//dtype
												        }
											        }
											 

                                                 ?>  
												 </tbody>
												 </table>
											              </div>
                                                </section>
											 </div>
                                       
                                     </section>
					  
					               </div>
                        
                     
                 
                 

         
                                