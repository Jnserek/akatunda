<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			 $role = $this->session->userdata('bio_role');
			 
			 
			  $all_machines  =$this->bio->Manufacturers_All();
			    $machines1  =$this->bio->Machines_search();
				 
			//	print_r($machines1);
		 

?>     
<div class="panel panel-default">
                        <div class="panel-heading">
                            <h4> Device Manufacturers. </h4>
                        </div>
                         
						  <?php  if (sizeof( $all_machines) > 0){  
								//	 print_r($departments);
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"    );

                              echo form_open('Form_loader/Update_depreciation_rates', $attributes);
							  
					                ?>	
									  
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th> <th> Contact Person</th><th> Email Address</th> <th> Phone Number</th> <th> Location</th>    <?php  if($action > 0) { if($this->session->bio_role  <1) {?> <th>Edit</th> <?php if($this->session->bio_role  =="**") {?> <th>Delete</th>  <?php } } } ?>     </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php for($k=0; $k<sizeof( $all_machines); $k++){ 
								
								$mcn_data =$all_machines[$k];  
								 ?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1; // $all_machines?>   </td>
								 </td>
								 <td> 
								 <?php 
								 
									 echo $mcn_data['name'];
									 
								  ?>
								 </td> 
								 
								 <td> 
								 <?php 
								 
									 echo $mcn_data['agent'];
									 
								  ?>
								 </td> 
								 
								 <td> 
								 <?php 
								 
									 echo $mcn_data['email'];
									 
								  ?>
								 </td>
								 
								 
								 <td> 
								 <?php 
								 
									 echo $mcn_data['phone_number'];
									 
								  ?>
								 </td>
								 <td> 
								 <?php 
								 
									 echo $mcn_data['name'];
									 
								  ?>
								 </td> <?php  if($action > 0) { if($this->session->bio_role  <1) {?>
								 
								 <td>
								   <label class ="label label-warning" href  ="">
                                   
                                            <input type="radio"  name ="alt_machine_info"  class='btn btn-info label label-info '  onclick ="return alt_manufacturer_info(); " value="<?php   echo $this->encrypt->encode($mcn_data['id']); ?>">
                              Edit
							  </label>
                                  </td>
								  <?php if($this->session->bio_role  =="**") {?> 
								  
								   <td>
								     <label class ="label label-danger" href  ="">
                                   
                                            <input type="radio"  name ="machine_info"  class='btn btn-info label label-danger '  onclick ="return del_manufacturer_info(); " value="<?php   echo $this->encrypt->encode($mcn_data['id']); ?>">
                               Delete
							   </label>
                                  </td>
								 <?php } } } ?>
								 	
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								<br /><br /><br />
                             <?php if($this->session->bio_role  <1) {    
						
						}?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No Information was found </strong></h5>
                            
						
						  

								
							 <?php  }
						
						?>
						</DIV>
 
	  
	
	
	
	<script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
	 
                                