
<?php 

  $id = $this->encrypt->decode($_SESSION['mcn_field_id']);
$machine = $this->bio->Get_specific_repair_info($id);
if(sizeof($machine) <1){ exit('Invalid data supplied');}


 $attributes = array('class' => 'form-horizontal', 'id' => 'log'  , 'method'=>"post"  ,  'onSubmit'=>' return service_report_entry();' );
  if($action >0) { echo form_open('System_controls/Edit_repair_report', $attributes);
	 }
	 else {

       echo form_open('System_controls/Delete_repair_report', $attributes);
	 }
	 
	 $machine  = $machine[0];

?>
<div id="edit-profile" class="tab-pane">

                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">  <?php  if($action >0) {?>
                                              <h4> Repair Report</h4>
											
                                              <form class="form-horizontal" role="form">                                                  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Company Name</label>
													  
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="c-name" placeholder=" "  value="<?php  if(set_value('f-name')) { echo set_value('f-name'); } else echo $machine['comp']; ?>"required >
                                                         
													  </div>
													  <br /> <?php echo form_error('c-name'); ?>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Job No</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="job" placeholder=" " value="<?php if(set_value('job')) { echo set_value('job'); } else echo $machine['no'];   ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('job'); ?>
                                                  </div>
                                                   
                                                 
                                                    
												  
												  
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Diagnosis</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="Diagnosis" placeholder=" " required value="<?php if(set_value('Diagnosis')) { echo set_value('Diagnosis'); } else echo $machine['diag'];?>">
                                                      </div>
													  <br /> <?php echo form_error('Diagnosis'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Remedy</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="remedy" placeholder=" "  value="<?php if(set_value('remedy')) { echo set_value('remedy'); } else echo $machine['remedy'];  ?>">
                                                      </div>
													  <br /> <?php echo form_error('remedy'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Added Spares</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="Spare" placeholder=" "  value="<?php if(set_value('Spares')) { echo set_value('Spares'); } else echo $machine['spares']; ?>">
                                                      </div>
													  <br /> <?php echo form_error('Spare'); ?>
                                                  </div>
												  
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Technician's comment</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="tech" placeholder=" "   value="<?php if(set_value('tech')) { echo set_value('tech'); } else echo $machine['tech']; ?>">
                                                      </div>
													  <br /> <?php echo form_error('tech'); ?>
                                                  </div>
												  
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">User's comment</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="user" placeholder=" "   value="<?php if(set_value('user')) { echo set_value('user'); } else echo $machine['user_com']; ?>">
                                                      </div>
													  <br /> <?php echo form_error('user'); ?>
                                                  </div>
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">New State </label>
                                                      <div class="col-lg-6">
                                                          
														   
										  
										   <select class="form-control" name ="state"  >
											 
											<?php  
											$mstates  =$this->bio->All_machine_states();
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												if($dt['id'] == $dt['new_s'] ) {
												echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
												}
											}
											echo ' <option value =""> Select</option>';
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											}?>
                                                 
                                            </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('state'); ?>
                                                  </div>
												  
												  
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Total charges</label>
                                                      <div class="col-lg-6">
													 
                                                          <input type="number" min ="0" class="form-control" name="charge"    placeholder=" " value="<?php if(set_value('charge')) { echo set_value('charge'); } else echo $machine['charge']; ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('charge'); ?>
											  </div>  <?php } else { //echo bio_succes('Information About  ');?>
											  
											  <div class="form-group" align ="center" >
                                                      
                                                      <div class="col-lg-12"> Click submit to delete this information. 
													 </div>
													   
											  </div> 
											  
											  
											  
												  
												   
											  <?php }  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									  </form>
									   