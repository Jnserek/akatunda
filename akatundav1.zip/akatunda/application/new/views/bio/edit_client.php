

 

 <section class="panel">
                          <header class="panel-heading">
                            <h4> Edit Client. </h4>
                          </header>
                                <div class="panel-body bio-graph-info"> 
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                            <?php 
							if( $action  > 0 and isset( $_SESSION['dept_edit'] )){
								$this->encrypt->decode( $_SESSION['dept_edit']);
								 $hospital = $this->bio->specific_hospital($this->encrypt->decode( $_SESSION['dept_edit']));
								 
                      $attributes = array('class' => 'form-horizontal', 'id' => 'new_client',   'method'=>"post"  ,  'onSubmit'=>' return create_new_hosp_acc();' );

                      echo form_open('System_controls/edit_client', $attributes);

?>			 
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">Name of health facility</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name"   value="<?php  if(set_value('name')) { echo set_value('name'); }else { echo $hospital['name']; } ?>" placeholder="" required>
                                          <p class="help-block"><?php echo form_error('name'); ?> </p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Phone number</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name = "fon"  value="<?php  if(set_value('fon')) { echo set_value('fon'); }else { echo $hospital['fon']; } ?>"  placeholder="Enter phone number">
                                          <p class="help-block"><?php echo form_error('fon'); ?> </p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Email Address</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="email" placeholder="Email"  value="<?php  if(set_value('email')) { echo set_value('email'); }else { echo $hospital['mail']; } ?>" >
                                          <p class="help-block"> <?php echo form_error('email'); ?></p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Location / District / City</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="locn" placeholder="Enter Location"    value="<?php  if(set_value('locn')) { echo set_value('locn'); }else { echo $hospital['ln']; } ?>" >
                                          <p class="help-block"> <?php echo form_error('locn'); ?> </p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Client Category</label>
                                      <div class="col-lg-7">
                                          <select class="form-control m-bot15" name ="type"  required>
										  
										  <?PHP 
										
										$cat = $this->bio-> All_Hospital_Type();
										if(sizeof($cat) > 0){
											for($i =0; $i<sizeof($cat); $i++){
												$catg = $cat[$i];
												if($catg['id'] ==$hospital['id'] ){
											echo '<option value ="'.$catg['id'].'" >'.$catg['name'].'</option>';
												}
												
												
											} 
											for($i =0; $i<sizeof($cat); $i++){
												$catg = $cat[$i];
											echo '<option value ="'.$catg['id'].'" >'.$catg['name'].'</option>';
												
												
											}
											
											
											 
										}
										
										?>
										  </select>
                                          <p class="help-block"> <?php echo form_error('type'); ?> </p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact Person</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="person" placeholder="Contact Person"  value="<?php  if(set_value('person')) { echo set_value('person'); }else { echo $hospital['person']; } ?>"  required>
                                          <p class="help-block"> <?php echo form_error('person'); ?> </p>
                                      </div>
                                  </div>
								  
								   
										 <?php    bio_footer();?>
                        </form>
							<?php } else { 
							   $attributes = array('class' => 'form-horizontal', 'id' => 'new_client',   'method'=>"post"  ,  'onSubmit'=>' return create_new_hosp_acc();' );

                      echo form_open('System_controls/Delete_client', $attributes);

?>			 
                <div class="form-group">
                                        <div class="col-lg-12">
										<?php  warning('All Information About this client will be lost'); ?>
                                   
                                          <input type="hidden" class="form-control" name="locn" placeholder="Enter Location"    value="" >
                                          <p class="help-block"> <?php echo form_error('locn'); ?> </p>
                                      </div>
                                  </div>
							   
										 <?php    delete();?>
                        </form>
							<?php } ?>

                                 
    </div>
	</div>
	
	</div>
	</section> 
                                