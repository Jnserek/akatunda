<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			   // $machines1  =$this->bio->Machines_search();
				//$supliers   =$this->bio->Supplier_search();
				//$manuf   =$this->bio->Manufacturer_Search();
				$machines_back   =$this->bio->Machines_bank_All();
				$manufacturere_back   =$this->bio->Manufacturers_All();
				$supliers_back   = $this->bio->Suppliers_All ();
				
			//	print_r($machines1);
		 

?>  
   
  <div class="panel panel-default"  >
                        <div class="panel-heading">
                            <h4> New Machines.</h4>
                        </div>
                        
 
						<div class="panel-body"  >  
								<div class="panel panel-default scroll"   >
						  <?php  if (sizeof( $departments) > 0){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>'return add_new_machines_to_dpts();' );

                             echo form_open('Form_loader/machine_entry_one', $attributes);
							 		
							  
					                ?>	
									
									
                                        
                            <div class="table-responsive stretch"   >
							<div class=" col-md-1  ">  </div>
							<div class=" col-md-8 form-group">
                                            <label  >Select a department</label>
											<select class="form-control" id='dpt'    >
											
											 <?php
											   if(isset($_SESSION['my_depat'])){
												   
												    for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   if($_SESSION['my_depat'] ==$item['id'] ){
														    echo ' <option value ="'.$item['id'].'" >'.$item['dname'].'</option>'; 
														   }															
												        }
														 
												   
											   }
											   else  echo '<option value ="" > SELECT  </option>';
												      echo '<option value ="0" > New Device  </option>';
												       for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														    echo ' <option value ="'.$item['id'].'" >'.$item['dname'].'</option>';  
												        }
														
											         ?>
													
                                                 
                                            </select>
											<div  style =""  id ="Error_code"> </div>
                                             
                                        </div>
                                  										
										 
							 
                                <table class="table table-striped table-bordered table-hover"    >
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Model</th><th> Manufat -<BR/>rer</th><th> Serial</th><th> Code</th>
									<th> Price /=</th><th> MFGD: Year</th><th> Country</th><th> Year Installed</th><th> Supplier</th><th> Status</th>
									<th> comment</th> <th> Acton</th><th> Way forward</th><th> #No</th>     </tr>
                                   </thead>
                                    <tbody>  

                 
                                <?php for($k=1; $k<6; $k++){ 
								//exit('mmmmmmmmmmmm');?>
                                <tr> 
								
								 <td>  <?PHP echo $k;?>  </td>
								 <td> 
								  

								<!--  <input  type="text"   class='Nm'    style ="margin: 0 auto; width : 100px;"  data-provide="typeahead" data-items="10" data-source='<?php echo $machines1; ?>' />  -->
								 <select class='Nm form-control' style ="margin: 0 auto; width : 100px;"  > 
								 <option value ="" > Select</option> 
								 <?php  foreach($machines_back as $row){
									 echo '<option value ="'.$row['id'].'" > '.$row['name'].'</option>';
								 }
									 
									 ?>
								 </select>

								 </td>
								 <td>  <input  type="text"   class='mdl'    style =" width : 80px;"  />  </td>
								 <td> 
								  <select class='manf form-control' style ="margin: 0 auto; width : 100px;"  > 
								 <option value ="" > Select</option>
								  
								 <?php  foreach($manufacturere_back as $row){
									 echo '<option value ="'.$row['id'].'" > '.$row['name'].'</option>';
								 }
									 
									 ?>
								 </select>
								 
								<!-- <input  type="text"   class='manf'    style =" margin: 0 auto;  width : 80px;"   data-provide="typeahead" data-items="10" data-source='<?php echo $manuf; ?>' /> 
-->

								 </td>
								
								
								<td>  <input  type="text"   class='sno'    style =" width : 60px;"  />  </td>
								 
								 <td>  <input  type="text"   class='dev_no'    style =" width : 60px;"  />  </td>
								  <td>  <input  type="text"   class='price'    style =" width : 60px;"  />  </td>
								 
								 
								 
								 <td> 
  										
								  <select class="yr form-control"   style =" width : 80px;" >
											  <option value ="">Select </option>
											  
											<?php for($i=date('Y'); $i>(1985) ; $i--){
												echo ' <option value ="'.$i.'" >'.$i.'</option>';
											}?>
                                                 
                                            </select>

								 </td>
								 <td>   
								  <select class="ctr form-control"   style =" width : 90px;" ><?php echo Countries(); ?>
								  </select>

								 </td>
								 
								  <td> 
  										
								  <select class="yri form-control"   style =" width : 80px;" >
											  <option value ="">Select </option>
											  
											<?php for($i=date('Y'); $i>(1985) ; $i--){
												echo ' <option value ="'.$i.'" >'.$i.'</option>';
											}?>
                                                 
                                            </select>

								 </td>
								 
								 

								 <td> 
								 
								  <select class='sply form-control' style ="margin: 0 auto; width : 100px;"  > 
								 <option value ="" > Select</option>
								  
								 <?php  foreach($supliers_back as $row){
									 echo '<option value ="'.$row['id'].'" > '.$row['name'].'</option>';
								 }
									 
									 ?>
								 </select>
								 <!--
								 <input  type="text"   class='sply'    style ="margin: 0 auto; width : 80px;"   data-provide="typeahead" data-items="10" data-source='<?php echo $supliers;  ?>' />  </td>
                                -->
								<td>   
								 <select class="statx form-control"  style =" width : 80px;" >
											  <option value ="">Select</option>
											<?php  
											$mstates  =$this->bio->All_machine_states();
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											}?>
                                                 
                                            </select>

								 </td>
								 
								 <td>  <input  type="text"   class='comment'    style ="margin: 0 auto; width : 120px;"    />  </td>
								 
								 <td>  <input  type="text"   class='Action'    style ="margin: 0 auto; width : 120px;"    />  </td>
											
											<td>  <input  type="text"   class='Way_foward'    style ="margin: 0 auto; width : 120px;"    />  </td>
                                
                                    			
                                 
								  <td>  <select class="noz form-control"  style =" width : 60px;" >
											 
											<?php  
											//$mstates  =$this->bio->All_machine_states();
											
											
											for($i=1; $i<100; $i++){
												 
												echo ' <option value ="'.$i.'" >'.$i.'</option>';
											}?>
                                                 
                                            </select> </td>
											
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
                            </div>
                            
                        </div>
						
						<div class="col-sm-6" > 
					    <div class="panel-body">
                              <button type="cancel" class="btn btn-danger btn-block" onclick="return Home();"> <span class="fa fa-times"></span> CANCEL</button>
							   </div>
							   </div>
							  <div class="col-sm-6 " >
							  <div class="panel-body">
                             <button  class = "btn btn-success  btn-block"  onclick ="return add_new_machines_to_dpts();" type= "submit"  > SUBMIT</button> 
                  
						   </div>
						  </div>
						
                   <?php    //bio_footer();?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No Departments found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                No departments found for this health facility, first add some to continue  <a class="btn btn-primary btn-lg" role="button"  href="" onClick="return   more_hfs_form()">Add Departments</a>
                       .
                            </div>
						
						  

								
							 <?php  }
						
						?>
						</DIV>

                                 
    </div>
	 
	</div>
	 
	 
	<script src="<?php echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
	
	  <script src="<?php echo base_url();?>assets/js/biomedical.js"></script>
  
      
	
	 <script src="<?php echo base_url(); ?>assets/js/dataTables/jq.js"></script>
	 
                                