<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			 $role = $this->session->userdata('bio_role');
			 
			 
			  $all_machines  =$this->bio->Missing_depreciation_rates(2);
			    $machines1  =$this->bio->Machines_search();
				 
			//	print_r($machines1);
		 

?>     
<div class="panel panel-default">
                        <div class="panel-heading">
                            A  table showing all machines.
                        </div>
                        
 
						<div class="panel-body">
                            <div class="row">
                                <div class="col-md-12" >
								<div class="panel panel-default">
						  <?php  if (sizeof( $all_machines) > 0){  
								//	 print_r($departments);
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return update_depreciation_rates();' );

                              echo form_open('Form_loader/Update_depreciation_rates', $attributes);
							  
					                ?>	
									 
						 <div class="panel-body"> 
						<h4 align ="center" > A table showing all machines </h4>
                            <div class="table-responsive">
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Depreciation rate</th>         </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php for($k=0; $k<sizeof( $all_machines); $k++){ 
								
								$mcn_data =$all_machines[$k];  
								 ?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1; // $all_machines?>  <input  type="hidden"   class='mcn_id form-control'      value="  <?php   echo $mcn_data['mid']; ?>"   />  </td>
								 </td>
								 <td> 
								 <?php 
								 if($this->session->bio_role  >0){
									 echo $mcn_data['m_name'];
									 
								 }
								 else {
								 
								 ?>
								  

								 <input  type="text"   class='Nm form-control'      value="  <?php   echo $mcn_data['m_name']; ?>" data-provide="typeahead" data-items="10" data-source='<?php echo $machines1; ?>' />  </td>
								 <?php } ?>
								 <td> 
								 <?php 
								 if($this->session->bio_role  >0){
									 echo $mcn_data['dep_rate'];
									 
								 }
								 else {
								 
								 ?>

								 <input  type="number"   class='Rate form-control'      value="<?php  echo $mcn_data['dep_rate']; ?>"  max="100"    />   </td>
								    	 
								 <?php } ?>		
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
                            </div>
                            
                        </div> <?php if($this->session->bio_role  <1) {   bio_footer();
						
						}?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No Machine was found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                No departments found for this health facility, first add some to continue  <a class="btn btn-primary btn-lg" role="button"  href="" onClick="return   more_hfs_form()">Add Departments</a>
                       .
                            </div>
						
						  

								
							 <?php  }
						
						?>
						</DIV>

                                 
    </div>
	 
	</div>
	
	
	</div>
	</DIV>
	
	<script src="assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="assets/metro/js/dynamic-table.js"></script
	 
                                