<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			    //$machines1  =$this->bio->Machines_search();
				$supliers   =$this->bio->Supplier_search();
				$manuf   =$this->bio->Manufacturer_Search();
				$hosp   =$this->bio-> specific_hospital($role);
				$sup_loop   = $this->bio-> Suppliers_All ();
				$machines_loop   = $this->bio-> Machines_bank_All();
				$man_loop   = $this->bio->Manufacturers_All();
				
			//	print_r($machines1);
		 

?>     
<div class="panel panel-default">
                        <div class="panel-heading">
                            TABLE SHOWING MACHINES FOR  <?php  if(sizeof($hosp) > 0 ) {  
							echo $hosp['name'] .' , '.$hosp['ln'] ;
							if($dp > 0){
								
								 
												    for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   if($dp == $item['id'] ){
														    echo ' Under '.$item['dname'] .' Department'; 
														   }															
												        }
												   
											  
								
								
							}
							
							}
							
							?>
                        </div>
                        
 
						<div class="panel-body">
                            <div class="row">
                                <div class="col-md-12" >
								<div class="panel panel-default">
						  <?php 
						 //value of machines is determined in the controller
					 

						  if (sizeof( $machines) > 0){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_new_machines_to_dpts();' );

                              echo form_open('Form_loader/machine_entry_one', $attributes);
							  
					                ?>	
									 
						 <div class="panel-body">  
                            <div class="table-responsive">
							 
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                    <tr> <th> #</th><th> NAME</th><th> MODEL</th> <th> SNO</th><th> MANFACTU -<BR/>RER</th><th> MFGD: YEAR</th><th> COUNTRY</th><th> SUPPLIER</th> <?php if($dp < 1)  echo '<th> DEPARTMENT</th>';?><th> STATUS</th> <th>COMMENT </th><th> REPORT  <BR />A PROBLEM</th><th> #SERVICE REPORT</th> <th> #SERVICE</th> <th> #DETAILS</th>     </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php
									$mstates  =  $this->bio->All_machine_states();
											
										$states_summary =  array(); 
 									
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dts =  $mstates[$i];
												  
												  $machines_name = 0; 
												//if($mac['ms'] ==  $dts['id']){
												/*echo  ucfirst(strtolower($dt['name']));
												}
											}*/

								for($k=0; $k<sizeof($machines); $k++){ 
								
												 
											
								$mac  = $machines[$k];
								if($mac['ms'] ==  $dts['id']){
									  $machines_name += 1; 
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufactureres and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1;?>  </td>
								 <td>  <?php  echo ucfirst($macn_name);?></td>
								 
								 <td>  <?php  
								   IF($mac['mod'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['mod']));
								   
								   ?> 
								   </td>
								 <td>  <?php  
								   IF($mac['sn'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['sn']));
								   
								   ?> 
								   </td>
								 <td>   <?php  echo ucfirst($man_name);?> </td>
								
								  <td>  <?php  echo $mac['yr'];?> </td>
								   
								   <td>  <?php  
								   IF($mac['cou'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['cou']));
								   
								   ?> 
								   </td>
								   <td>   <?php  echo $sup_name;?> </td>
								  <?PHP  if($dp  <  1){
								
								 
												    for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														    echo ' <td>'.  ucfirst(strtolower($item['dname'])) .' </td>'; 
														   }															
												        }
												   
											  
								
								
							} ?>
								  
								 <td>   
								 
											<?php 
 										
												echo  ucfirst(strtolower($dts['name']));
											?>
                                                 
                                            </select>

								 </td>
								 
								   <td>  <?php  
								   IF($mac['comment'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['comment']));
								   
								   ?> 
								   </td>
								  <td>   <input type ="radio" name ='report' value ="<?php echo $mac['mid'] ?>" onclick="return Report_problem();"  />  </td>
								   <td>  <?php   
								   
								    $mstatesx  =  $this->bio-> pending_requests($this->encrypt->decode($mac['mid']));
								  if($mstatesx  < 1){
									  echo 'N/A';
								  }
									  
								  
								  else { ?>
								   <input type ="radio" name ='service' value ="<?php echo $mac['mid'] ?>" onclick="return Service_report();"  />  </td>
								 
								  <?php
									  
								  }
								   
								   
								   ?> 
								      
								   
								   
								   </td>
								    <td>   <input type ="radio" name ='do_service' value ="<?php echo $mac['mid'] ?>" onclick="return Field_service();"  /> </td>
									 <td>   <input type ="radio" name ='do_hist' value ="<?php echo $mac['mid'] ?>" onclick="return Machine_hisory();"  />  </td>
                                
                                    								 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
						  <?php } 	
						  }
						  
						 $temp_data =  array('state' => $dts['id'] ,'state_name' => ucfirst(strtolower($dts['name'])) ,   'no_machines' =>$machines_name );
						  array_push($states_summary , $temp_data  );
						  }
						  
						  ?>
                 
                                </tbody>
                                </table>
								
								 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                    <tr>  <th> NAME</th>   <th> #DETAILS</th>     </tr>
                                   </thead>
                                    <tbody>
									<?php 
									 
									foreach($states_summary as $row){
										
										echo '<tr> <td>'.$row['state_name'].'</td><td>'.$row['no_machines'].'</td>  </tr>';
									}
									?>
									
									 </tbody> 
									 </table>
                            </div>
                            
                        </div>
                  
                   <?php    bio_footer();?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No data found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                No departments found for this health facility, first add some to continue 
                       .
                            </div>
						
						  

								
							 <?php  }
						
						?>
						</DIV>

                                 
    </div>
	 
	</div>
	
	
	</div>
	</DIV>
	
	<script src="assets/js/jquery-2.0.3.min.js"></script> 
	 <script src="assets/js/biomedical.js"></script>
				
   
 
   <!-- 
	 <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script> -->
  
  
      
	
	 <script src="assets/js/dataTables/jq.js"></script>
	 
                                