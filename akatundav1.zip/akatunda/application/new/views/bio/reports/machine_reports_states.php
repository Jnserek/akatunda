<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			    //$machines1  =$this->bio->Machines_search();
				$supliers   =$this->bio->Supplier_search();
				$manuf   =$this->bio->Manufacturer_Search();
				$hosp   =$this->bio-> specific_hospital($role);
				$sup_loop   = $this->bio-> Suppliers_All ();
				$machines_loop   = $this->bio-> Machines_bank_All();
				$man_loop   = $this->bio->Manufacturers_All();
				
			//	print_r($machines1);
		 

?>     
<div class="panel panel-default">
                        <div class="panel-heading">
                            <h4> <?php  if(sizeof($hosp) > 0 ) {  
							echo $hosp[0]['name'] .' , '.$hosp[0]['ln'] ;
							if($dp > 0){
								
								 
												    for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   if($dp == $item['id'] ){
														    echo ' Under '.$item['dname'] .' Department'; 
														   }															
												        }
												   
											  
								
								
							}
							
							}
							
							?>
							</h4>
                        </div>
                        
  
						  <?php 
						 //value of machines is determined in the controller
					 

						  if (sizeof( $machines) > 0){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_new_machines_to_dpts();' );

                              echo form_open('Form_loader/machine_entry_one', $attributes);
							  
					                ?>	
									 
						 <div class="panel-body">  
                            <div class="table-responsive">
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Model</th> <th> Sno</th><th> Manufact-<BR/>rer</th><th> MFGD: Year</th><th> Supplier</th> <?php if($dp < 1) { echo '<th> Department</th>';}?><th> Status</th> <th>Comment </th><th> Report  <BR />A problem</th><th> #Repair Report</th> <th> #Service</th> <th> #Details</th>     </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php
									$mstates  =  $this->bio->All_machine_states();
											
										$states_summary =  array(); 
 									
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dts =  $mstates[$i];
												  
												  $machines_name = 0; 
												//if($mac['ms'] ==  $dts['id']){
												/*echo  ucfirst(strtolower($dt['name']));
												}
											}*/

								for($k=0; $k<sizeof($machines); $k++){ 
								
												 
											
								$mac  = $machines[$k];
							 
								if($mac['ms'] ==  $dts['id']){
									  $machines_name += 1; 
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufactureres and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									 
									if($sup_data['id'] ==$mac['man']  ){
										$macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1;?>  </td>
								 <td>  <?php  echo ucfirst($macn_name);?></td>
								 
								 <td>  <?php  
								   IF($mac['mod'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['mod']));
								   
								   ?> 
								   </td>
								 <td>  <?php  
								   IF($mac['sn'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['sn']));
								   
								   ?> 
								   </td>
								 <td>   <?php  echo ucfirst($man_name);?> </td>
								
								  <td>  <?php  echo $mac['yr'];?> </td>
								   
								   
								   <td>   <?php  echo $sup_name;?> </td>
								  <?PHP  if($dp  <  1){
								 echo ' <td>';// print_r($departments);
								 
												     
														 $dpt = $this->bio-> get_my_department( $mac['dep']);  if(sizeof($dpt) >0){ echo $dpt['dname']; }
														 echo ' </td>';
												   
											  
								
								
							} ?>
								  
								 <td>   
								 
											<?php 
 										
												echo  ucfirst(strtolower($dts['name']));
											?>
                                                 
                                            </select>

								 </td>
								 
								   <td>  <?php  
								   IF($mac['comment'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['comment']));
								   
								   ?> 
								   </td>
								  <td>    <label class ="  label  label-success" href ="">
								  <input type ="radio" class ='label' name ='report' value ="<?php echo $mac['mid'] ?>" onclick="return Report_problem();"  /> 
								   <i class ="fa fa-pencil"> Add</i>
								   </label>
								   </td>
								   <td>  <?php   
								   
								    $mstatesx  =  $this->bio-> pending_requests($this->encrypt->decode($mac['mid']));
								  if($mstatesx  < 1){
									  echo 'N/A';
								  }
									  
								  
								  else { ?> <label class ="  label  label-success" href ="">
								   <input type ="radio"  class ='label' name ='service' value ="<?php echo $mac['mid'] ?>" onclick="return Service_report();"  />  
								 <i class ="fa fa-pencil"> Add</i>
								   </label>
								   </td>
								  <?php
									  
								  }
								   
								   
								   ?> 
								      
								   
								   
								   </td>
								    <td>   
									<label class ="  label label-success" href ="">
									<input type ="radio"  class =" radio  label label-info"  name ='do_service' value ="<?php echo $mac['mid'] ?>" onclick="return Field_service();"  /> 
									 <i class ="fa fa-pencil"> Add</i>
								   </label>
								   </td>
									 <td> 
                                      <label class ="  label label-info" href ="">									 
									 <input type ="radio" class =" radio  label label-info" name ='do_hist' value ="<?php echo $mac['mid'] ?>" onclick="return Machine_hisory();"  />  
									  <i class ="fa fa-folder-open-o"> View</i>
								   </label>
								   </td>
                                
                                    								 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
						  <?php } 	
						  }
						  
						 $temp_data =  array('state' => $dts['id'] ,'state_name' => ucfirst(strtolower($dts['name'])) ,   'no_machines' =>$machines_name );
						  array_push($states_summary , $temp_data  );
						  }
						  
						  ?>
                 
                                </tbody>
                                </table>
								<h4> Summary</h4>
								
								 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                    <tr>  <th> State</th>   <th> #No</th>     </tr>
                                   </thead>
                                    <tbody>
									<?php 
									 
									 $total =0; 
									foreach($states_summary as $row){
										
										echo '<tr> <td>'.$row['state_name'].'</td><td>'.$row['no_machines'].'</td>  </tr>';
										 $total +=$row['no_machines'];
									}
									
										
										echo '<tr> <td>Total</td><td>'.$total.'</td>  </tr>';
								
									?>
									
									 </tbody> 
									 </table>
                            </div>
                             
                  
                   <?php    bio_footer();?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No data found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                No departments found for this health facility, first add some to continue 
                       .
                            </div>
						
						  

								
							 <?php  }
						
						?>
						</DIV>

                                 
    </div>
	 
	</div>
	
	
	</div>
	</DIV>
		
	<script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
	 
                                