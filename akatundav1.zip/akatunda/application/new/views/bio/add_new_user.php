
<?php 
 $attributes = array('class' => 'form-horizontal', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>' return create_user_acc();' );

      echo form_open('System_controls/new_user', $attributes);

?>
<div id="edit-profile" class="tab-pane">
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h1> New User Information</h1>
											  <?php  if(isset( $_SESSION['error'])){
												  if( $_SESSION['error'] == ''){
													
													  
													  
												  }
												  else {
echo   bio_warning($_SESSION['error']);
												  }
												  
											  }  ?>
                                              <form class="form-horizontal" role="form">                                                  
                                                  <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">First Name</label>
													  
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="f-name" placeholder=" "  value="<?php echo set_value('f-name'); ?>"required >
                                                         
													  </div>
													  <br /> <?php echo form_error('f-name'); ?>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Last Name</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="l-name" placeholder=" " value="<?php echo set_value('l-name'); ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('l-name'); ?>
                                                  </div>
                                                   
                                                 
                                                   
                                                 
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Email</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="email" placeholder=" "  value="<?php echo set_value('email'); ?>">
                                                      </div>
													  <br /> <?php echo form_error('email'); ?>
                                                  </div>
												  
												  
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Mobile</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="mobile" placeholder=" " required value="<?php echo set_value('mobile'); ?>">
                                                      </div>
													  <br /> <?php echo form_error('mobile'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Hospital </label>
                                                      <div class="col-lg-6">
                                                          
														  
														  <select class="form-control m-bot15" name ="hosp"  required>
										  <option value ="">SELECT </option>
										  <option value ="*">SYSTEM ADMIN </option>
										  <?PHP 
										
										$cat = $this->bio-> All_Hospitals();
										if(sizeof($cat) > 0){
											for($i =0; $i<sizeof($cat); $i++){
												$catg = $cat[$i];
											echo '<option value ="'.$catg['id'].'" >'.$catg['name'].' >> '.$catg['ln'].'</option>';
												
												
											}
											
											
											 
										}
										
										?>
										  </select>
                                                      </div>
													  
													  
													  <br /> <?php echo form_error('hosp'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">User Name</label>
                                                      <div class="col-lg-6">
													  <p  id="check_user"> </p>
                                                          <input type="text" class="form-control" name="username" id ="check"  placeholder=" " value="<?php echo set_value('username'); ?>" required>
                                                      </div>
													  <br /> <?php echo form_error('username'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Password</label>
                                                      <div class="col-lg-6">
                                                          <input type="password" class="form-control" name="pass1" placeholder=" "    required>
                                                      </div>
													  
													  <br /> <?php echo form_error('pass1'); ?>
                                                  </div>
												  <?php //echo form_error('passconf'); ?>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label"> Confirm Password</label>
                                                      <div class="col-lg-6">
                                                          <input type="password" class="form-control" name="password" placeholder=" "  required>
                                                      </div>
													    <br /> <?php echo form_error('password'); ?>
                                                  </div>
												  
												   
												  
												   
												  
												  <?php  bio_footer();?>
                                              </form>
                                          </div>
                                      </section>
									  </form>
									  
									   <script src="assets/js/jquery-2.0.3.min.js"></script> 
	
	  <script src="assets/js/biomedical.js"></script>