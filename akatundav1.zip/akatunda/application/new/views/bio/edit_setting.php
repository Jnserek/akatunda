


<section id="panel"> 

 <section class="panel">  <?php  if(isset($_SESSION['edit_settings']) ){
								
								
								$dpts  =$this->bio-> Settings_system(  $_SESSION['edit_settings'] ); 
							 }
							 else  bio_error('No supplier was found, it may not be existing on the database');
							 
							 if($dpts < 1){ bio_error('No supplier data was found');}


							 ?>
                          <header class="panel-heading">
                             <h4>System Setting. </h4>
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                            
							 
                             <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'new_machine', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );

                              echo form_open('System_controls/Update_system_settinngs', $attributes);
					  
					  

?>			                     
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">Units</label>
                                      <div class="col-lg-7">
									  <select name ="name" required class="form-control" > 
									  <?php 
									  $state_value = 50;
									   $units = 'Days';
									   $state =1;
									  if($dpts[0]['id'] <3  ){
										  $state_value =2;
										   $units = 'True / False';
										   $state =0;
										  
									  }

									  for ($i = 0; $i< $state_value; $i++ ){
										  if($state < 1){
											   
											  if($state == 0){ $units = 'False / Deactivate';   }
											  if($state == 1){ $units = 'True / Activate';  }
											  $state = $units; 
											// $units= $i.' '.$units; 
											  
										  }
                     										  
										  ?>
									  
									  <option value  = "<?php  echo $i;?>" > <?php echo $i.' '.$units ; ?> </option>
									  
										  <?php   
										  
										  
										  } ?>
                                        </select>
                                      </div>
                                  </div>
								  
								   <?php    bio_footer();?>
                        </form>

                                 
    </div>
	</div>
	
	</div>
	</section> 
                                