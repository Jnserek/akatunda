


<section id="panel"> 

 <section class="panel">  <?php  if(isset($_SESSION['dept_edit']) ){
								
								
								$dpts  =$this->bio-> Specific_machine_manufacturer( $this->encrypt->decode($_SESSION['dept_edit'] )); 
								 
							 }
							 else  bio_error('No supplier was found, it may not be existing on the database');
							 
							 if(sizeof($dpts) < 1){ bio_error('No supplier data was found');}


							 ?>
                          <header class="panel-heading">
                          <h4> <?php  if($action > 0) {  echo 'You are editing'; } else echo 'Delete ';?>  <?php   echo  ucfirst(strtolower($dpts['name'])); ?>
                          </h4></header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                            
							 
                             <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'new_machine', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );
if($action > 0) {
                              echo form_open('System_controls/Update_manufactureres', $attributes);
}else  echo form_open('System_controls/Delete_manufacturere', $attributes);
					  
					  

?>			                     <?php  if($action > 0) {  ?>

<div class="form-group">
                                      <label class="col-lg-2 control-label">Manufacturer's name</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name" value="<?php  if(set_value('name')) { echo set_value('name'); }else { echo $dpts['name']; } ?>"  placeholder="" required>
                                          <p class="help-block"><?php echo form_error('name'); ?> </p>
                                      </div>
                                  </div>
								  
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="contact" placeholder=""  value="<?php  if(set_value('contact')) { echo set_value('contact'); }else { echo $dpts['phone_number']; } ?>" >
                                          <p class="help-block"><?php echo form_error('contact'); ?> </p>
                                      </div>
                                  </div>
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact Person</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="contactp" placeholder="" value="<?php  if(set_value('contactp')) { echo set_value('contactp'); }else { echo $dpts['agent']; } ?>"  >
                                          <p class="help-block"><?php echo form_error('contactp'); ?> </p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Email Address</label>
                                      <div class="col-lg-7">
                                          <input type="email" class="form-control" name="email" placeholder="" value="<?php  if(set_value('email')) { echo set_value('email'); }else { echo $dpts['email']; } ?>"  >
                                          <p class="help-block"><?php echo form_error('email'); ?> </p>
                                      </div>
                                  </div>
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Location</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="loc" placeholder=""  value="<?php  if(set_value('loc')) { echo set_value('loc'); }else { echo $dpts['location']; } ?>" >
                                          <p class="help-block"><?php echo form_error('loc'); ?> </p>
                                      </div>
                                  </div>
								  
								  
							 <?php  bio_footer(); } else {?>

<div class="form-group">
                                      
                                        <?php  warning('All Information about this Manufacturer will be lost'); ?>
                                      
								  
								  
								  
								   <?php  delete();}    ?>
                        </form>

                                 
     
	
	</div>
	</section></section>
                                