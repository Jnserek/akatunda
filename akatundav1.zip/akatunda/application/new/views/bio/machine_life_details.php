<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			     <?php 
				 	$this->load->helper('validate');

				 $list_pie  =''; $list_bar  =''; 
			  $this->session->bio_role;
				 
				  $machines =$this->bio-> get_departmental_machines(  '' , $this->session->bio_role);
				  //print_r($machines);
				  
				  $machine_datax = $this->bio-> compute_machine_lyfe($machines);
				  
			 
				 
				 
				 ?>
			 
			        <div class="panel-body">
					     <div class="panel panel-primary">
                           <div class="panel-heading"> Machine Life Details <a class="btn" href="" onclick =  "return Load_machine_lyfe_data();">  <i class="icon-circle-arrow-right"></i>  </a></div>
                              <div class="panel-content" style="  padding:2px;"> 
							  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">   
							   
							<H4>  Machine life</H4>
							<table class= "table col-lg-6 "  >
							 
							<?php
							$my_keyx  =  $machine_datax['list_data'];
							 
							for( $i= 0; $i<sizeof($my_keyx); $i++){
								$datax = $my_keyx[$i];
								
								echo '<tr ><td>'.$datax[0].' ('.$datax[1].') 	  
</td></tr>';
								
							}

							?>
							</table>
							  </div>
							  
							    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6"> 
								
								<div id="piechart" style="height:310px; padding-top:2px;"></div>
								 
							
							<H4>  Key</H4>
							<table class= "table col-lg-6 "  >
							 
							<?php
							$my_keyx  =  $machine_datax['list_data'];
							 
							for( $i= 0; $i<sizeof($my_keyx); $i++){
								$datax = $my_keyx[$i];
								
								echo '<tr ><td>'.$datax[0].'</td>  <td>'.$datax[1].'</td><td>'.$datax[3].'</td></tr>';
								
							}

							?>
							</table>
								
								</div>
								<hr />
								
								
							<H4>  Machine life details.</H4>
							<table class= "table" >
							<tr> <th>#</th> <th> Machine Name</th> <th>Serial No </th><th>State Description </th><th></th>  </tr>
							<?php
						    $my_key  =  $machine_datax['details'];
							//print_r($my_key);
							 
							 
							 $my_keyx  =  $my_results_data  = $this->bio->columnSort($my_key, 'color');
							 
							
							for( $i= 0; $i<sizeof($my_keyx); $i++){//
								$datax = $my_keyx[$i];// <td style=" background-color:'.$datax['color'].'">  </td><td>'. round($datax['Machine_rating'] , 1).'</td>
								
								echo '<tr ><td>'.($i +1) .'</td><td>'.ucfirst($datax['name']).'</td> <td  >  '.$datax['sno'].'</td><td  >  '.$datax['state_name'].'</td><td style=" background-color:'.$datax['color'].'">  </td></tr>';
								
							}

							?>
							</table>	
                   
			                     
								 
					        </div>
							
							 
							
							
                          </div>
						</DIV>
			       </div>
				   
				   
				   
				    <script src="assets/js/jquery-2.0.3.min.js"></script> 
	 
	
	 <!-- chart libraries start --> 
<script src="assets/charts/bower_components/flot/jquery.flot.js"></script>
<script src="assets/charts/bower_components/flot/jquery.flot.pie.js"></script>  
<!-- chart libraries end --> 
	
	<script>
/*=============================================================
    Authour URI: www.binarycart.com
    License: Commons Attribution 3.0

    http://creativecommons.org/licenses/by/3.0/

    100% To use For Personal And Commercial Use.
    IN EXCHANGE JUST GIVE US CREDITS AND TELL YOUR FRIENDS ABOUT US
   
    ========================================================  */


(function ($) {
    "use strict";
    var mainApp = {

        main_fun: function () {
            /*====================================
            BIOTECH MENU 
            ======================================*/
            $('#main-menu').metisMenu();

            /*====================================
              LOAD APPROPRIATE MENU BAR
           ======================================*/
            $(window).bind("load resize", function () {
                if ($(this).width() < 168) {
                    $('div.sidebar-collapse').addClass('collapse')
                } else {
                    $('div.sidebar-collapse').removeClass('collapse')
                }
            });

              
        },

        initialization: function () {
            mainApp.main_fun();

        }

    }
    // Initializing ///

    $(document).ready(function () {
        mainApp.main_fun();
    });

}(jQuery));

//pie charts here


//chart with points
if ($("#sincos").length) {
    var sin = [], cos = [];

    for (var i = 0; i < 14; i += 0.5) {
        sin.push([i, Math.sin(i) / i]);
        cos.push([i, Math.cos(i)]);
    }

    var plot = $.plot($("#sincos"),
        [
            { data: sin, label: "sin(x)/x"},
            { data: cos, label: "cos(x)" }
        ], {
            series: {
                lines: { show: true  },
                points: { show: true }
            },
            grid: { hoverable: true, clickable: true, backgroundColor: { colors: ["#fff", "#eee"] } },
            yaxis: { min: -1.2, max: 1.2 },
            colors: ["#539F2E", "#3C67A5"]
        });

    function showTooltip(x, y, contents) {
        $('<div id="tooltip">' + contents + '</div>').css({
            position: 'absolute',
            display: 'none',
            top: y + 5,
            left: x + 5,
            border: '1px solid #fdd',
            padding: '2px',
            'background-color': '#dfeffc',
            opacity: 0.80
        }).appendTo("body").fadeIn(200);
    }

    var previousPoint = null;
    $("#sincos").bind("plothover", function (event, pos, item) {
        $("#x").text(pos.x.toFixed(2));
        $("#y").text(pos.y.toFixed(2));

        if (item) {
            if (previousPoint != item.dataIndex) {
                previousPoint = item.dataIndex;

                $("#tooltip").remove();
                var x = item.datapoint[0].toFixed(2),
                    y = item.datapoint[1].toFixed(2);

                showTooltip(item.pageX, item.pageY,
                    item.series.label + " of " + x + " = " + y);
            }
        }
        else {
            $("#tooltip").remove();
            previousPoint = null;
        }
    });


    $("#sincos").bind("plotclick", function (event, pos, item) {
        if (item) {
            $("#clickdata").text("You clicked point " + item.dataIndex + " in " + item.series.label + ".");
            plot.highlight(item.series, item.datapoint);
        }
    });
}
 

//pie chart
var data = [ <?php echo $machine_datax['pie_chart_data']; ?>
 
];

if ($("#piechart").length) {
    $.plot($("#piechart"), data,
        {
            series: {
                pie: {
                    show: true
                }
            },
            grid: {
                hoverable: true,
                clickable: true
            },
            legend: {
                show: false
            }
        });

    function pieHover(event, pos, obj) {
        if (!obj)
            return;
        percent = parseFloat(obj.series.percent).toFixed(2);
        $("#hover").html('<span style="font-weight: bold; color: ' + obj.series.color + '">' + obj.series.label + ' (' + percent + '%)</span>');
    }

    $("#piechart").bind("plothover", pieHover);
}


 

 


</script> 