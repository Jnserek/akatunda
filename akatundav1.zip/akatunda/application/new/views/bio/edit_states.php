


<section id="panel"> 

 <section class="panel">  <?php  if(isset($_SESSION['dept_edit']) ){
								
								
								$dpts  =$this->bio-> validate_new_state_two( $this->encrypt->decode($_SESSION['dept_edit'] )); 
							 }
							 else  bio_error('No supplier was found, it may not be existing on the database');
							 
							 if($dpts < 1){ bio_error('No supplier data was found');}


							 ?>
                          <header class="panel-heading">
                             Machine state
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                         
							 
                             <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'new_machine', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );

                              echo form_open('System_controls/Update_machine_states_info', $attributes);
					  
					  

?>			                     
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">New State Name</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name" placeholder="" required>
                                          <p class="help-block"><?php echo form_error('name'); ?> </p>
                                      </div>
                                  </div>
								  
								   <?php    bio_footer();?>
                        </form>

                                 
    </div>
	</div>
	
	</div>
	</section> 
                                