<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			 $role = $this->session->userdata('bio_role');
			 
			 
			   
			   $all_machines  = array();
			  
			  
										if(($this->session->bio_role =="**" ) and $action >1)  {    
										
										if($action == 2) { 
										$all_machines  =$this->bio->All_users_by_states(1);

										}

										if($action == 3) { 
										$all_machines  =$this->bio->All_users_by_states(0);

										} 

										}
										else  $all_machines  = $this->bio->All_users('');
										 
			  
			   

?>     
<div class="panel panel-default">
                        <div class="panel-heading">
                            <h4> System Users. </h4>
                        </div>
                        
                        
  
						  <?php  if (sizeof( $all_machines) > 0){  
							 
							  $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"    );

                              echo form_open('Form_loader/Update_depreciation_rates', $attributes);
							  
					                ?>	
									  
							 
                                 <table class="table table-striped table-bordered" id="sample_1">

                                    <thead>
                                    <tr> <th> #</th><th> Name</th> <th>First Name</th> <th> Last Name</th> <th> Phone</th> <th> Email Address</th><th> User State</th> <th> User Type</th>   

									<?php  if($action > 0) { ?> <th> <?php
										if($this->session->bio_role =="**" ) {   if($action == 1) {  ?>  Deactivate / Deactivate  <?php } if($action == 2) {  ?>   Login State <?php } if($action == 3) {  ?>   Login State  <?php   }  }
										?> </th> <?php  } ?>     </tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php for($k=0; $k<sizeof( $all_machines); $k++){ 
								
								$mcn_data =$all_machines[$k];
 							
								 ?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1; // $all_machines?>   </td>
								 
								 <td> 
								 <?php 
								 
									 echo $mcn_data['name'];
									 
								  ?>
								 </td>
								 <td> 
								 <?php 
								 
									 echo $mcn_data['fname'];
									 
								  ?>
								 </td>
								 <td>

 
								 <?php 
								 
									 echo $mcn_data['lname'];
									 
								  ?>
								 </td>

                                <td>

 
								 <?php 
								 
									 echo $mcn_data['fon'];
									 
								  ?>
								 </td>	

                                 <td>

 
								 <?php 
								 
									 echo $mcn_data['mail'];
									 
								  ?>
								 </td>	

                                <td>

 
								 <?php 
								  
									 if($mcn_data['state'] > 0){echo 'Active ';} else echo 'Not Active';
									 
								  ?>
								 </td>	

                                <td>

 
								 <?php 
								  
									 if($mcn_data['role'] > 0){echo 'General User ';} else echo 'Technician';
									 
								  ?>
								 </td>		

   <?php  if($action > 0) { ?> <td> <label <?php if($mcn_data['state'] >  0 ) {  ?>  class ="label label-danger " <?php } else { ?>   class ="label label-warning "  <?php } ?> href  =""><?php  
										if($this->session->bio_role =="**" ) {   if($action == 1) {  ?>      <input type="radio"  name ="alt_machine_info"  class='btn btn-info label label-danger'  onclick ="return alt_user_info(); " value="<?php   echo $this->encrypt->encode($mcn_data['id']); ?>"> <?php } if($mcn_data['state'] >  0 ) {  ?>   Deactivate <?php } if($mcn_data['state']  == 0) {  ?>   Activate  <?php   }  }
										?>  
										</label></td> <?php  } ?>  

										 
								 	
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								<br /><br /><br />
                           
                            
                        </div> <?php if($this->session->bio_role  <1) {   //bio_footer();
						
						}?>
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<?php   
							
							
						}
						else { bio_error('No data Found'); ?>
						
						 <h5><strong> Error : No data was found </strong></h5>
                            
						
						  

								
							 <?php  }
							 
							
						
						?> 
                                 
    </div>
	  
	
	<script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
	
  
  
      
	 
	 
                                