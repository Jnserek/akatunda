


<section id="panel"> 

 <section class="panel">
                          <header class="panel-heading">
                              <h4>  Servicing Company</h4>
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                          
                                <div class="col-md-12" >
							 
                             <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'new_machine', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );

                              echo form_open('System_controls/Add_new_service_company', $attributes);
					   
?>			                     
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">Company Name</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name" placeholder=""  value = "<?php echo set_value('name') ?>" required>
                                          <p class="help-block"><?php echo form_error('name');  ?> </p>
                                      </div>
                                  </div>
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="contact"  value = "<?php echo set_value('contact') ?>" placeholder=""  >
                                          <p class="help-block"><?php echo form_error('contact'); ?> </p>
                                      </div>
                                  </div>
								  
								  
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Email Address</label>
                                      <div class="col-lg-7">
                                          <input type="email" class="form-control" name="email" placeholder="" value = "<?php echo set_value('email') ?>"  >
                                          <p class="help-block"><?php echo form_error('email'); ?> </p>
                                      </div>
                                  </div>
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Location</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="loc" placeholder=""  value = "<?php echo set_value('loc') ?>" >
                                          <p class="help-block"><?php echo form_error('loc'); ?> </p>
                                      </div>
                                  </div>
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact Person</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="contactp" placeholder=""  value = "<?php echo set_value('contactp') ?>" >
                                          <p class="help-block"><?php echo form_error('contactp'); ?> </p>
                                      </div>
                                  </div>
								  
								   <?php    bio_footer();?>
                        </form>

                                 
    </div>
	</div>
	
	</div>
	</section></section>
                                