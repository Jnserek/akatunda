


<section id="panel"> 

 <section class="panel">
                          <header class="panel-heading">
                            <h4> New Client. </h4>
                          </header>
                                <div class="panel-body bio-graph-info">
								
								 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                          
                                <div class="col-md-12" >
                            <?php 
                      $attributes = array('class' => 'form-horizontal', 'id' => 'new_client',   'method'=>"post"  ,  'onSubmit'=>' return create_new_hosp_acc();' );

                      echo form_open('System_controls/create_hospital', $attributes);

?>			 
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">Name  </label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name" placeholder="" required>
                                          <p class="help-block"><?php echo form_error('name'); ?> </p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Phone Number</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name = "fon" value="<?php echo set_value('fon'); ?>" placeholder="Enter phone number">
                                          <p class="help-block"><?php echo form_error('fon'); ?> </p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Email Address</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="email" placeholder="Email"  value="<?php echo set_value('email'); ?>" >
                                          <p class="help-block"> <?php echo form_error('email'); ?></p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Location / District / City</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="locn" placeholder="Enter Location"  value="<?php echo set_value('locn'); ?>"  required>
                                          <p class="help-block"> <?php echo form_error('locn'); ?> </p>
                                      </div>
                                  </div>
								  
								  <div class="form-group">
                                      <label class="col-lg-2 control-label">Client Category</label>
                                      <div class="col-lg-7">
                                          <select class="form-control m-bot15" name ="type"  required>
										  <option value ="">SELECT </option> 
										  <?PHP 
										
										$cat = $this->bio-> All_Hospital_Type();
										if(sizeof($cat) > 0){
											for($i =0; $i<sizeof($cat); $i++){
												$catg = $cat[$i];
											echo '<option value ="'.$catg['id'].'" >'.$catg['name'].'</option>';
												
												
											}
											
											
											 
										}
										
										?>
										  </select>
                                          <p class="help-block"> <?php echo form_error('type'); ?> </p>
                                      </div>
                                  </div>
								  
								  
								   <div class="form-group">
                                      <label class="col-lg-2 control-label">Contact Person</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="person" placeholder="Contact Person"  value="<?php echo set_value('person'); ?>"  required>
                                          <p class="help-block"> <?php echo form_error('person'); ?> </p>
                                      </div>
                                  </div>
								  
								   
										 <?php    bio_footer();?>
                        </form>

                                 
    </div>
	</div>
	</div>
	
	</div>
	</section></section>
                                