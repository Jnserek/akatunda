      
<div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Service  Companies.</h4>
                        </div>  
									    
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Location</th><th> Email </th><th> Phone Number</th>  <th> Contact Person</th>  <th> Technicians</th>      <?php  if($this->session->bio_role  <1 and $action > 0 ) {?>  <th>Edit</th>   <?php  } ?>     </tr>
                                   </thead>
                                    <tbody> 
									

                 
                                <?php
								$files =   $this->bio->List_Companies('');
								 
								 
								$k = 0;
			 if(sizeof($files) > 0){
				 
				  	foreach($files as $mcn_data){ 
								
								   
								 ?>
                                <tr> 
								
								 <td>  <?PHP echo $k +=1; // $all_machines?>   </td>
								 </td>
								 
								 <td> 
								 <?php 
								 
									  echo $mcn_data['name'];
									 
								  ?>
								 </td> 
								  <td> 
								 <?php 
								 
									  echo $mcn_data['location'];
									 
								  ?>
								 </td>
								  <td> 
								 <?php 
								 
									  echo $mcn_data['email'];
									 
								  ?>
								 </td> 
								 
								  <td> 
								 <?php 
								 
									  echo $mcn_data['phone'];
									 
								  ?>
								 </td> 
								 <td> 
								 <?php 
								 
									  echo $mcn_data['agent'];
									 
								  ?>
								 </td> 
								 
								 <td> 
								 <?php  $techs =   $this->bio->service_techs($mcn_data['id']);
								 if(sizeof($techs) > 0){
								 
								 ?>
								  <table class="table table-striped table-bordered  "  >
                                    <thead>
                                    <tr>  <th> Name</th><th> Email </th><th> Phone Number</th>    </tr>
                                   </thead>
                                    <tbody>
								 <?php 
								 
								 
									  echo $mcn_data['agent'];
									  foreach($techs as $tech){
										 
											  echo '<tr><td>'. $tech['name'].'</td> <td> '.$tech['phone'].'</td> <td> '.$tech['email'].'</td> </tr>';
										 
										  
									  }
									  
									 
								  ?>
								  </tbody>
								 </table><?php } ?>
								 </td> 
								 
								 
								  

								 <?php   if($this->session->bio_role  <1 and $action > 0 ) {?>
								 
								 <td><?php
								 
								 ?>
								 
								 <button  class  ="download_back_up btn btn-warning "   value ="<?php echo $mcn_data['id'];?>">  Edit</button> 
								 
                                    
                                  </td>
								   
								 <?php }  ?>
								 	
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
								
								<tr> 
								
								 <td>  <?PHP echo $k +=1; // $all_machines?>   </td>
								 </td>
								 
								 <td> 
								 Free Lancer
								 </td> 
								  <td> 
								 N/A
								 </td> 
								  <td> 
								 N/A
								 </td> 
								 
								  <td> 
								  N/A
								 </td> 
								 <td> 
								  N/A
								 </td> 
								 
								 <td> 
								 <?php  $techs =   $this->bio->service_techs(0);
								 if(sizeof($techs) > 0){
								 
								 ?>
								  <table class="table table-striped table-bordered  "  >
                                    <thead>
                                    <tr>  <th> Name</th><th> Email </th><th> Phone Number</th>    </tr>
                                   </thead>
                                    <tbody>
								 <?php 
								 
								 
									 
									  foreach($techs as $tech){
										 
											  echo '<tr><td>'. $tech['name'].'</td> <td> '.$tech['phone'].'</td> <td> '.$tech['email'].'</td> </tr>';
										 
										  
									  }
									  
									 
								  ?>
								  </tbody>
								 </table><?php } ?>
								 </td> 
								 <td></td>
								 
								  
								 	
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                </tbody>
                                </table>
								   
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No Setting was found </strong></h5>
                            
						
						  

								
							 <?php  }   
						
						?>
			 
	</DIV>
	
	
	
	<script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   <script>
   $('.download_back_up').click(function() {
            var item = $(this).attr("value");
			BioCustom2( 'Form_loader' , 'Edit_service_company' ,    item , 0 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
   </script>

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
	
 
	 
                                