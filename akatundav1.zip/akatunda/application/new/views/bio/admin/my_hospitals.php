
              <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"   );

                              echo form_open('System_controls/create_new_states', $attributes);
					  
					  

?>			      <div class="panel panel-default">
                         

                          

                          <header class="panel-heading">
                              <h4> Client's Information </h4>
                          </header>
                          
                          <table class="table table-striped table-advance table-hover" style="font-size:12px;" id="sample_1">
                           <thead>
                              <tr>
                                 <th><i class="fa fa-folder-open"></i> Name</th>
								 <th><i class="fa fa-folder-open"></i> Location</th>
                                 <th><i class="fa fa-stethoscope"></i> #Machines</th>
								 <?php  
											  $role = $this->session->userdata('bio_role');
											 
											 
											$mstates  =$this->bio->All_machine_states();
											
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												echo ' <th>'.$dt['name'].'</th>';
											} if($action > 0) { ?>
                                  
                                 <th><i class="fa  fa-folder-open-o"></i> Inventory</th>
								   <th><i class="fa fa-pencil"></i> Edit</th>
								   <?php  if($role =='**' ){?>
								   <th><i class="fa fa-pencil"></i> Delete</th>
								   <?php } } ?>
                              </tr>
							  </thead>
							  <tbody>
							  
							   <?php 
											 $departments  =$this->bio->All_Hospitals();
										 
											 if(sizeof($departments) <1){
												 echo 'no client found';
											 } 
											 for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   
														   $total1 = $this->bio-> get_departmental_machines_count(0 , $item['id']);
													        echo ' <tr> 
															 
                                 <td>'.$item['name'].'</td>
								 <td>'.$item['ln'].'</td>
                                 <td>'.$total1.'</td>';
								 
								 
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												 
												 $total2 = $this->bio->get_departmental_machines_count_states(0 , $item['id'] , $dt['id']);
												echo ' <td>'.$total2.'</td>';
											}
											if($action > 0) { 
								 
								 
                               echo   ' <td>
                                 
								 <label class ="radio btn btn-info btn-mini" href="">
                                                   <input type="radio"  name ="more_machine"  class ="radio label label-info" onclick ="return department_info();" value="'.$this->encrypt->encode($item['id']).'">
                                                 
                                                  Details 
                                              </label></td>
                                 <td>
                                    <label class ="radio btn btn-warning btn-mini" href="">
                                            <input type="radio"  name ="alt_machine_info"  class ="radio label label-warning" onclick ="return alt_client_info(); " value="'.$this->encrypt->encode($item['id']).'">
                                                 
                                                  Edit 
                                              </label>
											 
											</td>
											
											';
											if($role =='**' ){
											echo '<td>
                                    <label class ="radio btn btn-danger btn-mini" href="">
                                            <input type="radio"  name ="del_machine_info" class ="radio label label-warning "  onclick ="return Delete_client_info(); " value="'.$this->encrypt->encode($item['id']).'">
                                                 
                                                Delete 
                                              </label>
											 
											</td>';} }
								  echo   '  
                              </tr> ';
												        }
											        
											 
											 
											   ?>
                              
                               
							  </tbody>
							  </table>
							  <br /><br /><br />
							  
							  </div>
							   
							   <script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
