
              <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"   );

                              echo form_open('System_controls/create_new_states', $attributes);
					  
					  

?>			      
   <section class="panel ">

                          <header class="panel-heading">
                            <h4> Client's information</h4>
                          </header>
                          
                          <table class="table table-striped table-advance table-hover" style="font-size:12px;">
                           <tbody>
                              <tr>
                                 <th><i class="fa fa-folder-open"></i> Name</th>
								 <th><i class="fa fa-folder-open"></i> Location</th>
                                 <th><i class="fa fa-stethoscope"></i> #Machines</th>
								 <?php  
											$mstates  =$this->bio->All_machine_states();
											
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												echo ' <th>'.$dt['name'].'</th>';
											} if($action > 0) { ?>
                                  
                                 <th><i class="fa  fa-folder-open-o"></i> Inventory</th>
								   <th><i class="fa fa-pencil"></i> Edit</th>
								   <th><i class="fa fa-pencil"></i> Delete</th>
											<?php  } ?>
                              </tr>
							  
							   <?php 
											 $role = $this->session->userdata('bio_role');
											 
											 
											 $departments  =$this->bio->All_Hospitals();
											  print_r( $departments);
											 if(sizeof($departments) <1){
												 echo 'no client found';
											 } 
											 for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   
														   $total1 = $this->bio-> get_departmental_machines_count(0 , $item['id']);
													        echo ' <tr> 
															<tr>
                                 <td>'.$item['name'].'</td>
								 <td>'.$item['ln'].'</td>
                                 <td>'.$total1.'</td>';
								 
								 
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												 
												 $total2 = $this->bio->get_departmental_machines_count_states(0 , $item['id'] , $dt['id']);
												echo ' <td>'.$total2.'</td>';
											}
											if($action > 0) { 
								 
								 
                               echo   ' <td>
                                 
								 <label class ="radio label label-info">
                                                   <input type="radio"  name ="more_machine"  onclick ="return department_info();" value="'.$this->encrypt->encode($item['id']).'">
                                                 
                                                  Details 
                                              </label></td>
                                 <td>
                                    <label class ="radio label label-warning">
                                            <input type="radio"  name ="alt_machine_info"  onclick ="return alt_departmental_info(); " value="'.$this->encrypt->encode($item['id']).'">
                                                 
                                                  Edit 
                                              </label>
											 
											</td>
											
											<td>
                                    <label class ="radio label label-warning">
                                            <input type="radio"  name ="del_machine_info"  onclick ="return Delete_client_info(); " value="'.$this->encrypt->encode($item['id']).'">
                                                 
                                                  Delete
                                              </label>
											 
											</td>'; }
								  echo   ' <td>
                              </tr> ';
												        }
											        
											 
											 
											   ?>
                              
                               
							  </tbody>
							  </table>
							  </section>
							  </div>
							    
