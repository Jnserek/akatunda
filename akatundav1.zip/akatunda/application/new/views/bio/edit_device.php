
<?php 
 $attributes = array('class' => 'form-horizontal', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>' return create_user_acc();' );
 
 if(!isset($_SESSION['mcn_field_id']) ){
	 exit('Incomplete data supplied');
	 
 }
 $idm =   $this->encrypt->decode($_SESSION['mcn_field_id']) ;
   
 $mac_data =   $this->bio->get_my_machines($idm);
  
 
 
 
 if($action > 0){

      echo form_open('System_controls/Update_machine', $attributes);
 }
 else {
	  echo form_open('System_controls/Delete_device', $attributes);
	 
 }

?> 
                                    <section class="panel">                                          
                                          <div class="panel-body bio-graph-info">
                                              <h4> Update Device</h4>
											  <?php  if(isset( $_SESSION['error'])){
												  if( $_SESSION['error'] == ''){
													
													  
													  
												  }
												  else {
echo   bio_warning($_SESSION['error']);
												  }
												  
											  } 

if($action > 0){											  ?>  
 
								 
                                              <div class="form-group">
												 
                                                      <label class="col-lg-2 control-label">Machine Name</label>
													  
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="name" placeholder=" "  value="<?php if( set_value('name')) { echo set_value('name'); } else {  echo ucfirst(strtolower( $this->bio->Machine_name_bank($mac_data['name'] ))) ; } ?>"required >
                                                         
													  </div>
													  <br /> <?php echo form_error('name'); ?>
                                                  </div>
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Model</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="mod" placeholder=" " value="<?php if( set_value('mod')) { echo set_value('mod'); } else echo $mac_data['mod']; ?>" >
                                                      </div>
													  <br /> <?php echo form_error('mod'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Serial</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="sn" placeholder=" " value="<?php if( set_value('sn')) { echo set_value('sn'); } else echo $mac_data['sn']; ?>" >
                                                      </div>
													  <br /> <?php echo form_error('sn'); ?>
                                                  </div>
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Code </label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="code" placeholder=" " value="<?php if( set_value('code')) { echo set_value('code'); } else echo $mac_data['code']; ?>" >
                                                      </div>
													  <br /> <?php echo form_error('code'); ?>
                                                  </div>
												  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Price</label>
                                                      <div class="col-lg-6">
                                                          <input type="text" class="form-control" name="price" placeholder=" " value="<?php if( set_value('price')) { echo set_value('price'); } else echo $mac_data['price']; ?>" >
                                                      </div>
													  <br /> <?php echo form_error('price'); ?>
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Manufacturer</label>
                                                      <div class="col-lg-6">
													  <?php  $manuf = $this->bio->Specific_machine_manufacturer($mac_data['man']);
													   
													  ?>
													   <select class="yr form-control"  name ="man"     >
													  
													  <?php  $manuf = $this->bio->Manufacturers_All($mac_data['man']);
													  
													  $supplier_name ='';
													   
													  //
													  for($k=0; $k<sizeof($manuf); $k++ ){
													 
													       $item = $manuf[$k];
														   if($mac_data['man'] ==$item['id'] ){
														    echo ' <option value ="'.$item['id'].'" >'.$item['name'].'</option>'; 
														   }															
												        }
												   
											   
											    echo '<option value ="" > SELECT  </option>';
												 
												       for($k=0; $k<sizeof($manuf); $k++ ){
													 
													       $item = $manuf[$k];
														    echo ' <option value ="'.$item['id'].'" >'.$item['name'].'</option>';  
												        }
													  
													  ?>
													   </select> <br /><?php echo form_error('man'); ?>
                                                         </div>
													 
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Year of manufacturer</label>
                                                      <div class="col-lg-6">
													   <select class="yr form-control"  name ="yr"     >
													   
                                                           
											<?php 
											echo ' <option value ="'.$mac_data['yr'] .'" >'.$mac_data['yr'].'</option>';
											
											
											for($i=date('Y'); $i>(1985) ; $i--){
												echo ' <option value ="'.$i.'" >'.$i.'</option>';
											}?>
                                                </select>  <br /><?php echo form_error('yr'); ?>
                                                      </div>
													  
                                                  </div>
												  
												   
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Year of installation</label>
                                                      <div class="col-lg-6">
													 
													   <select class="yr form-control"  name ="yri"     >
													  
													  
                                                           
											<?php  
											echo ' <option value ="'.(substr($mac_data['installed'] ,0 ,  4)).'" >'.(substr($mac_data['installed'] ,0 ,  4)).'</option>';
											
											for($i=date('Y'); $i>(1985) ; $i--){
												echo ' <option value ="'.$i.'" >'.$i.'</option>';
											}?>
                                                </select>  <br /><?php echo form_error('yri'); ?>
                                                      </div>
													  
                                                  </div> 
												  
												  
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Department</label>
                                                      <div class="col-lg-6">
									  <select class="statx form-control"   name="dep" >
											   
											<?php 
											$departments  =$this->bio->get_hospital_departments($mac_data['hf']);
											
											 for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														   if($mac_data['hf'] ==$item['id'] ){
														    echo ' <option value ="'.$item['id'].'" >'.$item['dname'].'</option>'; 
														   }															
												        }
												   
											   
											    echo '<option value ="" > SELECT  </option>';
												 
												       for($k=0; $k<sizeof($departments); $k++ ){
													 
													       $item = $departments[$k];
														    echo ' <option value ="'.$item['id'].'" >'.$item['dname'].'</option>';  
												        }
											
											 ?>
                                                 
                                            </select> <?php echo form_error('dep'); ?>
											
                                                              </div>
													  
                                                  </div>
												   
                                                  
                                                  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Machine State</label>
                                                      <div class="col-lg-6">
									  <select class="statx form-control"   name="state" >
											   
											<?php  
											$mstates  =$this->bio->All_machine_states();
											for($i=0; $i<sizeof($mstates) ; $i++){
												
												$dt =  $mstates[$i];
												if($dt['id']  ==$mac_data['ms'] ) {
												echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
												}
											}
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												$dt =  $mstates[$i];
												echo ' <option value ="'.$dt['id'].'" >'.$dt['name'].'</option>';
											}?>
                                                 
                                            </select>  <br /><?php echo form_error('state'); ?>
											
                                                              </div>
													  
                                                  </div>
												  
												  
												   <div class="form-group">
                                                      <label class="col-lg-2 control-label">Country of origin </label>
                                                      <div class="col-lg-6">
                                                          
														   
										             
										          <select class="ctr form-control"   name ="country"   >
												  <option value ="<?php   echo $mac_data['cou'];?>"> <?php   echo $mac_data['cou'];?> </option>
												  <?php echo Countries(); ?>
								                    </select> <br />
													<?php echo form_error('country'); ?>
										    
                                                      </div>
													   
                                                  </div>
												  
												  <div class="form-group">
                                                      <label class="col-lg-2 control-label">Supplier</label>
                                                      <div class="col-lg-6">
													  
													   <select class="statx form-control"   name="sup" > 
													   <?php      
													   $supplier = $this->bio->Specific_machine_supplier($mac_data['sup']);
													  $supplier_name ='Select';
													  if(sizeof($supplier) > 0){
														  
														  $supplier_name = $supplier['name'];
													  }?>
														  <option value ="<?php if( set_value('sup')) { echo set_value('sup'); } else echo $mac_data['sup']; ?> " ><?php if( set_value('sup')) { echo set_value('sup'); } else echo $supplier_name; ?> </option>
                                                     
													  <?php 
													  $supplier_data = $this->bio->Suppliers_All ();
													  
													    for($k=0; $k<sizeof($supplier_data); $k++ ){
													 
													       $item = $supplier_data[$k];
														   if($mac_data['hf'] ==$item['id'] ){
														    echo ' <option value ="'.$item['id'].'" >'.$item['name'].'</option>'; 
														   }															
												        }
												   
											   
											         echo '<option value ="" > SELECT  </option>';
												 
												       for($k=0; $k<sizeof($supplier_data); $k++ ){
													 
													       $item = $supplier_data[$k];
														    echo ' <option value ="'.$item['id'].'" >'.$item['name'].'</option>';  
												        }
													  
													  
													  ?>
													  </select>
                                                         </div>
													  <br /> <?php echo form_error('sup'); ?>
                                                  </div>
												   
<?php  bio_footer(); } else  if($action < 1){  ?>   <div class="form-group">
                                                      
                                                      <div class="col-lg-12">
													  <?php warning('All information about this Device will be lost on deletion'); ?>
													  
                                                  </div>
												   
												  
											<?php  delete(); }?>	   
												  
												  <?php 	?>
												   </section>
                                              </form>
                                          
                                     
									  
									   