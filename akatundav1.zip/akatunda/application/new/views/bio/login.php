
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="biomedical equipment management system">
    <meta name="author" content="kam development partners">
    <meta name="keyword" content="jms biomedical equipment management software">
   <link rel="shortcut icon" href="../assets/img/photonBeta.png">

    <title>lOGOIN | BIOMEDICAL EQIPMENT SOFTWARE V1.0 </title>

    <!-- Bootstrap CSS -->    
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="../assets/css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="../assets/css/elegant-icons-style.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="../assets/css/style.css" rel="stylesheet">
    <link href="../assets/css/style-responsive.css" rel="stylesheet" />
 
</head>

  <body class="login-img3-body">

    <div class="container">
	
	<?php 
	 
	echo validation_errors(); ?>

<?php //echo form_open('form'); ?>

	
			<?php 
			 
  
     $attributes = array('class' => 'login-form', 'id' => 'login'  , 'method'=>"post"  ,  'onSubmit'=>'return validate();' );

      echo form_open('login/validate', $attributes);
?>       
        <div class="login-wrap">
            <p class="login-img"><i class="icon_lock_alt"></i></p>
			 <p id="validate_inputsX">Enter your user name and password  </p>
			
            <div class="input-group">
              <span class="input-group-addon"><i class="icon_profile"></i></span>
              <input type="text" class="form-control" name="username"  id ="uname1"  size="20" placeholder="Username" autofocus required>
            </div>
            <div class="input-group">
                <span class="input-group-addon"><i class="icon_key_alt"></i></span>
                <input type="password"  id ="pass" name="password" class="form-control" size="30" placeholder="Password" required>
            </div>
             
            <button class="btn btn-primary btn-lg btn-block" type="submit">Login</button>
			 <label class="checkbox">
                
                <span class="pull-right"> <a href="Password_recoverly"> Forgot Password?</a></span>
            </label>
            
        </div>
      </form>

    </div>
	
	<script src="../assets/js/jquery-2.0.3.min.js"></script> 

<script src="../assets/js/validate.js"></script>


  </body>
</html>
