      
<div class="panel panel-default">
                        <div class="panel-heading">
                           <h4>Backups</h4>
                        </div>  
									    
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Date created </th>             </tr>
                                   </thead>
                                    <tbody> 
									

                 
                                <?php
								$files = $this->bio->List_file_backups();
			 if(sizeof($files) > 0){
				  	for($k=0; $k<sizeof( $files); $k++){ 
								
								$mcn_data =$files[$k];  
								 ?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1; // $all_machines?>   </td>
								 </td>
								 
								 <td> 
								 <?php 
								 
									 echo substr($mcn_data , 16, -4);
									 
								  ?>
								 </td> 
								 
								  
								  
								 

								 <?php   if($this->session->bio_role  <1) {?>
								 
								 
								  
								  
								 <?php }  ?>
								 	
																 
								 								 
								 
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								   
                        </form>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No Machine was found </strong></h5>
                            <div class="alert alert-info alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                No departments found for this health facility, first add some to continue  <a class="btn btn-primary btn-lg" role="button"  href="" onClick="return   more_hfs_form()">Add Departments</a>
                       .
                            </div>
						
						  

								
							 <?php  }   
						
						?>
			 
	</DIV>
	
	
	
	<script src="<?php  echo base_url(); ?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php  echo base_url(); ?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   <script>
   $('.download_back_up').click(function() {
            var item = $(this).attr("value");
			BioCustom2( 'Form_loader' , 'Download_machine' ,    item , 0 , '#main-content' );
			  $('#result_items').show();
			 $('#result_items').fadeOut(3000); 
			
        });
   </script>

   <!--script for this page only-->
   <script src="<?php  echo base_url(); ?>assets/metro/js/dynamic-table.js"></script
	
 
	 
                                