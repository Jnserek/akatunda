


<section id="panel"> 

 <section class="panel">
                          <header class="panel-heading">
                            <h4> Device State. </h4>
                          </header>
                                <div class="panel-body bio-graph-info">
								
						 <div class="panel panel-default">
                         
                        
                            <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12" >
							 
                             <?php 
                                $attributes = array('class' => 'form-horizontal', 'id' => 'new_machine', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );

                              echo form_open('System_controls/create_new_states', $attributes);
					  
					  

?>			                     
                                  
                                    <div class="form-group">
                                      <label class="col-lg-2 control-label">Add new machine state</label>
                                      <div class="col-lg-7">
                                          <input type="text" class="form-control" name="name" placeholder="" required>
                                          <p class="help-block"><?php echo form_error('name'); ?> </p>
                                      </div>
                                  </div>
								  
								   <?php    bio_footer();?>
                        </form>

                                 
    </div>
	</div>
	
	</div>
	</section></section>
                                