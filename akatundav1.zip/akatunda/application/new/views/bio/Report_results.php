<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			    //$machines1  =$this->bio->Machines_search();
				$supliers   =$this->bio->Supplier_search();
				$manuf   =$this->bio->Manufacturer_Search();
				$hosp   =$this->bio-> specific_hospital($role);
				$sup_loop   = $this->bio-> Suppliers_All ();
				$machines_loop   = $this->bio-> Machines_bank_All();
				$man_loop   = $this->bio->Manufacturers_All();
				$mstates  =  $this->bio->All_machine_states();
								
				
			//	print_r($machines1);
		 

?>     
<div class="panel panel-primary table-responsive">
                        <div class="panel-heading  ">
                              <h4> Search Results</h4>
                        </div>
                          
						  <?php 
						 //value of machines is determined in the controller
					    $report_type = $search[2];
						$lower = $search[3];
						$upper= $search[4];

						  if (sizeof( $machines) > 0){ ?>  
                              
                                    
									 
									 <?php 
							  $attributes = array('class' => 'form-horizontal ', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return add_new_machines_to_dpts();' );

                              echo form_open('Form_loader/machine_entry_one', $attributes);
							  
					                ?>	
									  
                            <div class="table-responsive">
							 
                                <table class="table table-striped table-bordered table-hover" id="sample_1">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Model</th> <th> Sno</th><th> Code</th><th> Price</th>  <th> Supplier</th> <th> Department</th>
									<th> Status</th> 

									<th> Last Service </th> 
									<?php  if($report_type ==1){ ?>
									
									<th> Next Service </th> <th> Days Remaining</th> 
						  <?php } ?>
						  <?php  if($report_type ==2){ ?>
									
									<th> No of complains </th>  
						  <?php } ?>
						  
						  

									</tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php 
						     for($k=0; $k<sizeof($machines); $k++){ 
								 
							 $mac  = $machines[$k];
							 $macn_id   = $mac['name'];// 
							 $mcn_id   =$this->encrypt->decode($mac['mid']);
							 $last_service   ='';
							 $next_dates   ='';
							  
							 
							 $service_details = $this->bio-> Service_details($mcn_id , 0 , '' , '');
							 
							 
							 
							 if(sizeof($service_details) > 0){
								$last_service   = $service_details[0]['dates'];
							 }
							 else {
								 $last_service   =$mac['period'];
								 
							 }
							 
								$next_dates   = AddMonths($last_service , 6);
							  
								 
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufacturers and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									 
									if($sup_data['id'] ==$macn_id   ){
										  $macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1;?>  </td>
								 <td>  <?php  echo ucfirst($macn_name);?></td>
								 
								 <td>  <?php  
								   IF($mac['mod'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['mod']));
								   
								   ?> 
								   </td>
								   <td>  <?php  
								   IF($mac['sn'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['sn']));
								   
								   ?> 
								   </td>
								   
								    <td> 
									<?php  
								     echo ucfirst( strtolower($mac['code']));
								   
								   ?> 
									
									
								   </td>
								   
								    <td>  
									<?php  
								     echo ucfirst( strtolower($mac['price']));
								   
								   ?> 
								   </td>
								 
								   <td>   <?php  echo $sup_name;?> </td>
								    <td>
								  <?PHP  
								
								 
												    for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														    echo ' '.  ucfirst(strtolower($item['dname'])) .' '; 
														   }															
												        }
								 
							           ?>
							  </td>
								  
								 <td>   
								 
											<?php 
 										 
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($mac['ms'] ==  $dt['id']){
												echo  ucfirst(strtolower($dt['name']));
												}
											}?>
                                                 
                                             

								 </td>
								 <td> <?php   echo  $last_service   ;  ?> </td>
								 <?php  if($report_type ==1){ ?>
								 <td> <?php  echo  $next_dates; ?> </td>
								  <td> <?php     $count_dates =   dateDiff(timeCurrent2(), $next_dates);  if($count_dates < 0 ){ echo '<span class="label label-danger">';} else if($count_dates > 0 and  $count_dates< 30  ){ echo '<span class="label label-warning">';} else { echo '<span class="label label-success">'; } echo ' '. $count_dates;   ?>  </span></td>
								  						 
								 <?php  }  ?>
								  <?php  if($report_type ==2){ ?>
								 <td> <?php  echo  $next_dates; ?> </td>
								   						 
								 <?php  }  ?>
								 
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								<br />
								<hr /> 
								<?php  
								
								if($report_type > 0) {
								?>
								<section class="panel panel-primary col-lg-12">
                          
								 <div class="panel-body ">
								
								 <div class="panel-heading  ">
                                      <h4> Search Results</h4>
                                  </div>
								


                                     <table class="table table-striped table-bordered table-hover" id="sample_3">
                                    <thead>
                                    <tr> <th> #</th><th> Name</th> <th> Sno</th><th> Code</th> <th> Department</th>  <th>  
									<table class="table table-striped table-bordered table-hover"> 
									<?php if($report_type == 1) { ?>
									<tr><td>State1 </td><td>State2 </td><td>Comment </td><td>Way forward </td> <td>Date </td><td>Teach</td>    <td  >Tech_company</td> 
									</tr>
									<?php }   else if($report_type == 3) { ?>
									<tr><td>Date</td><td>Invoice</td> <td>Diagnosis </td><td>Remedy </td><td>Spares </td> <td>Company</td><td>Tech Comment </td> <td>New State</td><td>Charges</td>      
									</tr>
									<?php }   else if($report_type == 2) { ?>
									<tr><td>Problem</td><td>Date Reported</td> <td>Results </td><td>Date worked on </td><td>Technician</td>   <td>New State</td>      
									</tr>
									<?php }  ?>
									
									</table>
									</th>
									

									</tr>
                                   </thead>
                                    <tbody> 

                 
                                <?php
											
								 
						for($k=0; $k<sizeof($machines); $k++){ 
								 
							 $mac  = $machines[$k];
							 $macn_id   = $mac['name'];// 
							  $mcn_id   =$this->encrypt->decode($mac['mid']);
							 $last_service   ='';
							 $next_dates   ='';
							 $service_details = array();
							 if($report_type == 1) {
							 
							 $service_details = $this->bio-> Service_details($mcn_id ,2 , $lower , $upper);
							 }
							 
							  elseif($report_type == 3) {
							 
							 $service_details = $this->bio-> Repair_details($mcn_id ,2 , $lower , $upper);
							 }
							 elseif($report_type == 2) {
							 
							 $service_details = $this->bio-> Problem_details($mcn_id ,2 , $lower , $upper);
							 }
							 //Problem_details(
							   
								 
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufactureres and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									 
									if($sup_data['id'] ==$macn_id   ){
										  $macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								?>
                                <tr> 
								
								 <td>  <?PHP echo $k +1;?>  </td>
								 <td>  <?php  echo ucfirst($macn_name);?></td>
								 
								 
								   <td>  <?php  
								   IF($mac['sn'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['sn']));
								   
								   ?> 
								   </td>
								   
								    <td> 
									<?php  
								     echo ucfirst( strtolower($mac['code']));
								   
								   ?> 
									
									
								   </td>
								   <td>
								   
								      
								  <?PHP        for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														    echo ' '.  ucfirst(strtolower($item['dname'])) .' '; 
														   }															
												        }
								 
								
							 ?>
							 </td>
								  
								 <td   > 
								 
								 <?php //colspan='7'
					  

								 if(sizeof($service_details) > 0) {
									
									 ?>
								 <table class="table table-striped table-bordered table-hover"> 
								 <?php 
								  if($report_type == 1) {
									 
								 foreach($service_details as $row){?>
								 
								  <tr>  <td> 
								   
											<?php 
 										
											 
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($row['new'] ==  $dt['id']){
												echo  ucfirst(strtolower($dt['name']));
												}
											}?>
                                                 
                                           </td>
										   <td> 
								  
											<?php 
 										 
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($row['old'] ==  $dt['id']){
												echo  ucfirst(strtolower($dt['name']));
												}
											}?>
                                                 
                                           </td>
										   <td><?PHP  echo $row['com'];?> </td>
										   <td><?PHP  echo $row['wf'];?>  </td>
										   <td><?PHP  echo $row['dates'];?>  </td>
										   <td><?PHP  if($row['tech'] =="" ) { echo 'N/A';} else {$row['tech'];}?> </td> 
										   <td><?PHP  if($row['tech_comp'] =="" ) { echo 'N/A';}  echo $row['tech_comp'];?> </td>
										   </tr>
								 <?php  }}  else  if($report_type == 3) { 
								 
								 foreach($service_details as $row){
								 
								 ?>
									<tr><td><?php echo $row['dates'];?></td><td><?php echo $row['invoice'];?></td> <td><?php echo $row['diag'];?> </td><td><?php echo $row['remedy'];?>  </td><td><?php echo $row['spare'];?>  </td> <td><?php echo $row['comp'];?> </td><td><?php echo $row['tech_comm'];?>  </td>
									<td> 
									
											<?php 
 										 
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($row['state'] ==  $dt['id']){
												echo  ucfirst(strtolower($dt['name']));
												}
											}?>
									
									</td>
									
									
									<td><?php echo $row['cost'];?> </td>      
									</tr>
									<?php
								 }									
								 }
								 else   if($report_type == 2) { 
								 
								 foreach($service_details as $row){ 
								 
								 ?>
									 <tr><td><?php  echo $row['problem'];?></td><td><?php  echo $row['dates'];?></td> <td><?php  echo $row['sorted'];?> </td><td><?php  echo $row['date_worked_on'];?></td>
									 <td><?php  echo $row['tech'];?></td>   
									 
									 <td> 
									 <?php 
 										 
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($row['state'] ==  $dt['id']){
												echo  ucfirst(strtolower($dt['name']));
												}
											}?>
									 
									 </td>      
									</tr>
								<?php  } 
								 }
								?>
										   </table>
								 <?php 
								         }//CHECK ONOTHER 

										 else echo 'No Data found'; ?>

								 </td>
								  
                                 
                                 </tr>
                 
                                
                                <?php }?>
                 
                                </tbody>
                                </table>
								</div>
								</section>
								
								<?php
								}
								
								$man_array = $mcn_array = $state_array = $sup_array = array(); 
							 
								
								 
								
								//machine States summary
								
								
											$mstates  =  $this->bio->All_machine_states();
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
											
												  $dt =  $mstates[$i];
												  
												  $count_no =0;
									$count_name ='';
									
									for($k=0; $k<sizeof($machines); $k++){ 
								 
								               $mac  = $machines[$k];
											   
												if($mac['ms'] ==  $dt['id']){
													 
												 
												$count_no +=1;
												 }
									            }
												 
										 array_push($state_array ,array('name'=>$dt['name'] , 'no'=>$count_no ));
										
									 
								 
									
									
											}
											
											
						 
								
								if($report_type == 1) { 
                             ?>
							 
							 
							  <section class="panel panel-primary col-lg-12">
                          
                          <div class="panel-body ">
						  <?php  //print_r($search);
						  
						 //$details = $this->bio-> Service_details(6 , 0);
					 
						  
						  
						  ?>

						  
							 
							   <table class="table table-striped table-bordered table-hover " >
							    
							    <tr>  <td>
							    <header class="panel-heading">
                           <h4>  Device States</h4>
                          </header>
							   <table class="table table-striped table-bordered table-hover"  >
                                    <thead>
                                    <tr> <th> #</th><th> Name</th>       </tr>
                                   </thead>
								   
                                    <tbody> 
									<?php  foreach ($state_array as $row){?>
									<tr><td> <?php  echo $row['name'];?></td><td> <?php  echo $row['no'];?></td></tr>
								   <?php } //$mstates  ?>
								    
								   <tr><td> Total</td><td> <?php echo  sizeof($machines);?></td></tr>
								  
								  
									</tbody>
									</table>

							   </td>
								
								</tr>
							   </table>
							   </div> 
							   
							   </section>
							   
								<?php  } ?>
							 
							 
									
									
									 
									
									
									
									
									 

						</DIV>
						<hr />
                   
					 
										
										  
                                 
                                        
                                        
                                    
                        </form>
						<a class = "btn btn-info btn-block colspan3" href ="reports" target ="_blank" > Get PDF </a>
						<?php   
							
							
						}
						else { ?>
						
						 <h5><strong> Error : No data found </strong></h5>
                             
						
						  

								
							 <?php  }
							 
						
						?>

           
	
	 
	</DIV>
	
	<script src="<?php echo base_url();?>assets/js/jquery-2.0.3.min.js"></script> 
	 
    
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/jquery.dataTables.js"></script>
   <script type="text/javascript" src="<?php echo base_url();?>assets/metro/assets/data-tables/DT_bootstrap.js"></script>
  
   

   <!--script for this page only-->
   <script src="<?php echo base_url();?>assets/metro/js/dynamic-table.js"></script
	 
                                