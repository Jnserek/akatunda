<?php 
 
			 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			    //$machines1  =$this->bio->Machines_search();
				$supliers   =$this->bio->Supplier_search();
				$manuf   =$this->bio->Manufacturer_Search();
				$hosp   =$this->bio-> specific_hospital($role);
				$sup_loop   = $this->bio-> Suppliers_All ();
				$machines_loop   = $this->bio-> Machines_bank_All();
				$man_loop   = $this->bio->Manufacturers_All();
				$mstates  =  $this->bio->All_machine_states();
											
				
				
			//	print_r($machines1); //Search_pdf.php
			
			 $search =  $_SESSION['search_data_options'] ;
				// print_r($search);// $search =  array($machine , $client   , $man , $sup , $state , $y1 , $y2 , $dtype );
				
				$department_data  = ' Search report for '; 
				

				  if($search[1] > 0){ //client
				 
				  $hospital   =$this->bio-> specific_hospital($search[1]);
				  
				   if(sizeof($hospital) > 0){
						  $department_data  .= ' '.$hospital[0]['name'].' of '.$hospital[0]['ln'];
				   }
					 
					  
				  
					 
				 }
				 
				 if($search[0] > 0){ //machine
				  
				  foreach($machines_loop  as $dpt){
					  if($search[0] ==$dpt['id'] )
					  {
						   $department_data  .= ',  swowing '.$dpt['name'];
					  }
					  
				  }
					 
				 }else {
					   $department_data  .= ',  swowing All machines ';
				 }
				 // print_r($search);
				 // echo '<br /><br /><br />....';
				 // if(sizeof($search[2]) > 0){ //manufacturere
				  // foreach ($man_array as $row){
				  $department_data  .= ' , made by ';//.$search[2][2];
				  // }
					 
				 //}
				  if($search[3] > 0){ //supplier
				  //$department_data  .= ',  Supplierd by  '.$search[3];
				  
				  foreach($sup_loop  as $dpt){
					  if($search[3] ==$dpt['id'] )
					  {
						   $department_data  .= ', as supplierd by '.$dpt['name'];
					  }
					  
				  }
				 
				 
					 
				 }
				  else {
					   $department_data  .= ', suplied by any supplier ';
					  
				  }
				  
				  if($search[5] > 0){ //from 
					 
				 }
				 
				  if($search[6] > 0){//to
					 
				 }
				 
				  if($search[7] > 0){//department type
				     foreach($departments as $dpt){
					  if($search[7] ==$dpt['id'] )
					  {
						   $department_data  .= ' , under '.$dpt['dname'].' , department type '.$dpt['dtype'];
					  }
					  
				  }
					 
				 }
				 else{
				   $department_data  .= ' , irrespective of departent';
				 }
				 
				 if($search[4] > 0){//machine state
				   foreach($mstates as $dpt){
					  if($search[4] ==$dpt['id'] )
					  {
						   $department_data  .= ',  In  '.$dpt['name'].' State';
					  }
					  
				  }
					 
				 }
				 else {
					  $department_data  .= ',  In  any state';
					 
				 }
				 
				 
						  $html  =  '';
						 //value of machines is determined in the controller
					$machines =  $_SESSION['search_data_results'] ;

						  if (sizeof( $machines) > 0){  
							 
                               $html  .=' <div class ="gradient" >  
							   <h2 align ="center" class ="text"  > '.ucfirst(strtolower($department_data)).'</h2>
							   <br />
							   <h4> General Details </h4>
							   
							   <table border="1"   width="100%"  >
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Model</th> <th> Sno</th><th> Manufa -<BR/>cturer</th><th> Mfgd: Yr</th><th> Country</th><th> Supplier</th> <th> Department</th><th> Status</th>      </tr>
                                   </thead>
                                    <tbody>'; 
 
								$total_machines  =  sizeof($machines);
								$total_devices  =  0;

								for($k=0; $k<sizeof($machines); $k++){ 
								 
								$mac  = $machines[$k];
							 $macn_id   = $mac['name'];// $this->encrypt->decode($mac['mid']);
								 
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufactureres and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									 
									if($sup_data['id'] ==$macn_id   ){
										  $macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								 
                                $html  .=' <tr> 
								
								 <td>  '.($k +1).'  </td>
								 <td>  '. ucfirst($macn_name).'</td>
								 
								 <td>   '; 
								   IF($mac['mod'] =="" ){  $html  .='"N/A"';}ELSE  $html  .=''.ucfirst( strtolower($mac['mod'])).'';
								   
								    $html  .=' 
								   </td>
								 <td>  '; 
								   IF($mac['sn'] =="" ){ $html  .=' "N/A"';}ELSE  $html  .=''. ucfirst( strtolower($mac['sn'])).'';
								   
								   $html  .='
								   </td>
								 <td>   '. ucfirst($man_name).' </td>
								
								  <td>  '. $mac['yr'].' </td>
								   
								   <td>  '; 
								   IF($mac['cou'] =="" ){ $html  .=' "N/A"';}ELSE  $html  .=''. ucfirst( strtolower($mac['cou'])).'';
								   
								   $html  .=' 
								   </td>
								   <td>   '. $sup_name.'</td> <td>'; 
												    for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														     $html  .= ' '.  ucfirst(strtolower($item['dname'])) .' '; 
														   }															
												        }
														  $html  .= ' </td>
								  
								 <td>   ';
											$mstates  =  $this->bio->All_machine_states();
											
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($mac['ms'] ==  $dt['id']){
												 $html  .=''. ucfirst(strtolower($dt['name'])).'';
												}
											}
											 $html  .='
                                                 
                                             

								 </td>'; if($action <1){ 
								  $html  .='
								   <td>  ';
								   if($action <1){   
								   IF($mac['comment'] =="" ){ $html  .=' "N/A"';}ELSE  $html  .=''. ucfirst( strtolower($mac['comment'])).'';
								   
								   }  $html  .='
								   </td>'; } if($action > 0){ 
								   }  
								   $html  .='
                                 </tr>';
                 
                                
                                 }
								  $html  .='
                 
                                </tbody>
                                </table>
								
								<h3></h3>';
								//$man_array = $mcn_array = $state_array = $sup_array = array(); 
								 
								
								//count machine manus from here
							 
								 
								//machine States summary
								
								
										 
											
								  
                        
							   $search =  $_SESSION['search_results'];
							   $dpt_array_hosp =  $search['dpt_array_hosp'];
							   $man_array =  $search['man_array'];
							   $states_in_departments  =  $search['states_in_departments'];
							   $departmental_states =  $search['departmental_states'];
							   $sup_array_hosp =  $search['sup_array_hosp'];
							   $dpt_array_sup  =  $search['dpt_array_sup'];
							   $states_in_departments   =  $search['states_in_departments'];
							   $sup_array  =  $search['sup_array'];
							   $state_array =  $search['state_array'];
							   $mcn_array =  $search['mcn_array'];
							   
							   //dpt_array_hosp
							        $html  .=' 
                        
                           <h2> <br /> <br /> Distributon Summary</h2> ';
							      $html  .='<h4>  Distribution by Device States</h4>
                          
							   <table border="1" width="100%">
                                    <thead>
                                  <tr> <th  width="2%"> #</th><th  width="80%">State</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
                                   </thead>
								   
                                    <tbody> '; $count =0;
									   foreach ($state_array as $row){ $count +=1;
									 $html  .='<tr><td> '.$count.'</td><td> '.$row['name'].'</td><td> '. $row['no'].'</td> <td> '. round(( $row['no'] /sizeof($machines))*100 , 1).'</td></tr>';
								   } //$mstates //general department type 
								    
								   $html  .=' <tr><td> </td><td> Total</td><td> '. sizeof($machines).'</td><td>100/=</td></tr>
								  
								  
									</tbody>
									</table>';
									
									    $html  .='<h4>  Distribution by devices</h4>
                           

                                   <table border="1"  width="100%">
                                    <thead>
                                    <tr> <th  width="2%">#</th><th  width="80%">Name</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
                                   </thead>
								   
                                    <tbody> ';
									 $count =0;
									  foreach ($mcn_array as $row){  $count +=1;
									 $html  .='	  
									<tr><td> '.$count.'</td><td> '.ucfirst($row['name']).'</td><td> '. $row['no'].'</td><td> '. round(( ($row['no'])/ $total_machines )*100 , 1).'</td></tr>';
								    }   $html  .='
									</tbody>
									</table>';
									
									
							    $html  .=' <h4>  Distribution by Suppliers</h4>
                        
							    <table border="1" width="100%">
                                    <thead>
									 <tr> <th  width="2%">#</th><th  width="80%">Name</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
                                     
                                   </thead>
								   
                                    <tbody>';   $count =0;
									   foreach ($sup_array as $row){   $count +=1;
									    $html  .='
									<tr><td> '.$count.'</td><td> '.ucfirst($row['name']).'</td><td> '. $row['no'].'</td> <td> '. round(( ($row['no'])/ $total_machines )*100 , 1).' </td></tr>';
								    } 
								   
								    $html  .=' 
									</tbody>
									</table>';
							   
							    
							   
							     $html  .='<h4>  Disrtibution by  suppliers in general department types.</h4>
								 <table border="1" width="100%">
                                    <thead>
                                  <tr> <th  width="2%">#</th><th  width="80%">Name</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
                                   </thead>
								   
                                    <tbody> ';  $count =0;
									   foreach ($dpt_array_hosp as $row){  $count +=1;
									 $html  .='<tr><td> '.$count.'</td><td> '.$row['name'].'</td><td> '. $row['no'].'</td> <td> '. round(( $row['no'] /sizeof($machines))*100 , 1).'</td></tr>';
								   } //$mstates //general department type 
								    
								   $html  .=' <tr><td> </td><td> Total</td><td> '. sizeof($machines).'</td><td>100/=</td></tr>
								  
								  
									</tbody>
									</table>';
									
									
									 $html  .='<h4>  Disrtibution by  Manufacturers.</h4>
								 <table border="1" width="100%">
                                    <thead>
                                  <tr> <th  width="2%">#</th><th  width="80%">Name</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
                                   </thead>
								   
                                    <tbody> '; $count =0;
									   foreach ($man_array as $row){ $count +=1;
									 $html  .='<tr><td> '.$count.'</td><td> '.$row['name'].'</td><td> '. $row['no'].'</td> <td> '. round(( $row['no'] /sizeof($machines))*100 , 1).'</td></tr>';
								   } //$mstates //general department type 
								    
								   $html  .=' <tr><td>  </td><td> Total</td><td> '. sizeof($machines).'</td><td>100/=</td></tr>
								  
								  
									</tbody>
									</table>
									';
									
									
									 $html  .='<h4>  Distribution by device states in different departments</h4>
								 <table border="1" width="100%">
                                    <thead>
                                  <tr> <th  width="2%">#</th><th  width="40%">Department</th> <th width="40%"> State</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
								  
                                   </thead>
								   
                                    <tbody> '; $count =0;
									  foreach ($states_in_departments as $row){ $count +=1;
									 $html  .='<tr> <td  > '. $count.'</td><td  > '. $row['department'].'</td><td></td><td> </td> <td>  </td></tr>';
									  foreach($row['details'] as $details ) { 
									 $html  .='<tr> <td></td><td></td><td> '. $details['name'].'</td> <td> '. $details['no'].'</td> <td> '. round(( ($details['no'])/ $row['total'] )*100 , 1).'%</td></tr>';
								   
									  }  
									 $html  .='<tr><td></td> <td> </td><td>Total</td><td> '. $row['total'].' </td> <td>  100%</td></tr>';
									
									  }   
								  
								  $html  .='
									</tbody>
									</table>
									';
									
									
									 $html  .='<h4>  Distribution by device states in different hospitals</h4>
								 <table border="1" width="100%">
                                    <thead>
                                  <tr> <th  width="2%">#</th><th  width="40%">Hospital</th> <th width="40%"> State</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
								  
                                   </thead>
								   
                                    <tbody> '; $count =0;
									  foreach ($departmental_states as $row){  $count +=1;
									 $html  .='<tr> <td> '. $count.'</td><td> '. $row['hospital'].'</td><td></td><td> </td> <td>  </td></tr>';
									  foreach($row['details'] as $details ) { 
									 $html  .='<tr> <td></td><td></td><td> '. $details['name'].'</td> <td> '. $details['no'].'</td> <td> '. round(( ($details['no'])/ $row['total'] )*100 , 1).' %</td></tr>';
								   
									  }  
									 $html  .='<tr> <td> </td><td>Total</td><td> '. $row['total'].' </td> <td>  100%</td></tr>';
									
									  }   
								    
								  
								  $html  .='
									</tbody>
									</table>
									';
									
									
									
									 $html  .='<h4>  Distribution by device states in different hospitals</h4>
								 <table border="1" width="100%">
                                    <thead>
                                  <tr> <th  width="2%">#</th><th  width="40%">Department</th> <th width="40%"> State</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
								  
                                   </thead>
								   
                                    <tbody> ';$count =0; 
									  foreach ($states_in_departments as $row){ $count +=1; 
									 $html  .='<tr> <td> '. $count.'</td><td> '. $row['department'].'</td><td></td><td> </td> <td>  </td></tr>';
									  foreach($row['details'] as $details ) { 
									 $html  .='<tr> <td></td><td></td><td> '. $details['name'].'</td> <td> '.$details['no'].'</td> <td> '. round(( ($details['no'])/ $row['total'] )*100 , 1).' %</td></tr>';
								   
									  }  
									 $html  .='<tr> <td></td><td> </td><td>Total</td><td> '. $row['total'].' </td> <td>  100%</td></tr>';
									
									  }  
								  
								  $html  .='
									</tbody>
									</table>
									';
									
									
									 $html  .='<h4>  Disrtibution by Suppliers in Hospitals </h4>
								 <table border="1" width="100%">
                                    <thead>
                                  <tr> <th width="2%"># </th><th  width="40%">Hospital</th> <th width="40%"> Supplier</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
								  
                                   </thead>
								   
                                    <tbody> ';  $count =0; 
									  foreach ($sup_array_hosp as $row){  $count +=1;  
									 $html  .='<tr> <td>'.$count.' </td><td> '. $row['hospital'].'</td><td></td><td> </td> <td>  </td></tr>';
									  foreach($row['details'] as $details ) { 
									 $html  .='<tr> <td></td><td></td><td> '. $details['name'].'</td> <td> '. $details['no'].'</td> <td> '.  round(( ($details['no'])/ $total_machines )*100 , 1).' </td></tr>';
								   
									  } }  
								   
								  
								  $html  .='
									</tbody>
									</table>
									';
									
									
									 $html  .='<h4>  Suppliers in different departments. </h4>
								 <table border="1" width="100%">
                                    <thead>
                                  <tr> <TH width="2%">#</TH><th  width="40%">Department</th> <th width="40%"> Supplier</th><th  width="10%"> No</th>  <th  width="10%">Percentage</th>     </tr>
								  
                                   </thead>
								   
                                    <tbody> ';
									  $count =0;  foreach ($dpt_array_sup as $row){ $count +=1; 
									 $html  .='<tr> <td> '. $count.'</td><td> '. $row['department'].'</td><td></td><td> </td> <td>  </td></tr>';
									 foreach($row['details'] as $details ) { 
									 $html  .='<tr> <td> </td><td> </td><td> '.$details['name'].'</td> <td> '.$details['no'].'</td> <td> '.round(( ($details['no'])/ $total_machines )*100 , 1).' </td></tr>';
								   
									 } }  
								  
								  $html  .='
									</tbody>
									</table>
									
									


							   </div>';
							   		  
                                 
                            
							
						}
						else {  
						 
							 }
							 
						
 					 
 
 
include("assets/MPDF56/mpdf.php");

$mpdf=new mPDF('c','A4'); 

$mpdf->SetDisplayMode('fullpage');

$mpdf->list_indent_first_level = 0;	// 1 or 0 - whether to indent the first level of a list

// LOAD a stylesheet
//stylesheet = file_get_contents('mpdfstyletables.css');
$stylesheet = file_get_contents('assets/MPDF56/examples/mpdfstyletables.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html,2);

$mpdf->Output('Search_report.pdf','I');
exit; 
           
	 
	 
                                