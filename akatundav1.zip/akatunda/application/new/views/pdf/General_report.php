<?php
	 date_default_timezone_set('Africa/Nairobi');
			   
			$Year =date('Y');
			
			
			 $role = $this->session->userdata('bio_role');
			  $departments  =$this->bio->get_hospital_departments($role);
			    //$machines1  =$this->bio->Machines_search();
				$supliers   =$this->bio->Supplier_search();
				$manuf   =$this->bio->Manufacturer_Search();
				$hosp   =$this->bio-> specific_hospital($role);
				$sup_loop   = $this->bio-> Suppliers_All ();
				$machines_loop   = $this->bio-> Machines_bank_All();
				$man_loop   = $this->bio->Manufacturers_All();
				$mstates  =  $this->bio->All_machine_states();
				

$html = '';
$tittle = 'General Report Details'; 
 $report_type = $search[2];
   if($report_type ==2 ){
	   $tittle = 'Device Problem Report '; 
	 
 }
  else if($report_type ==3 ){
	  $tittle = 'Repair Report Details '; 
	 
 }
						
	
 
 else if($report_type ==1 ){
	  $tittle = 'Service Report Details '; 
	 
 }
 $period  = '';
						$lower = $search[3];
						$upper= $search[4];
						 
						if($lower != "" and $upper!= "" ){
							$period  = ' From  '.$lower.' To  '.$upper;
							
						}
						else if($lower != ""  ){
							$period  = ' Dated '.$lower;
							
						}

						  if (sizeof( $machines) > 0){
$html .= '
<div style="width:1000px;      border: 5px double  #591823;"   >
 
<h2>'.$tittle.$period.'</h2>
 


<h4>ColSpan & Rowspan</h4>
<table class="bpmTopnTail" style="   padding-bottom:15px; 	empty-cells: show; "    border="1"  ><tbody>
 
                                    <thead>
                                    <tr> <th> #</th><th> Name</th><th> Model</th> <th> Sno</th><th> Code</th><th> Price</th>  <th> Supplier</th> <th> Department</th>
									<th> Status</th> 

									<th> Last Service </th>'; 
									   if($report_type ==1){  
									
									$html .= '<th> Next Service </th> <th> Days Remaining</th>'; 
						   } 
						    if($report_type ==2){  
									
									$html .= '<th> No of complains </th>';  
						   }  
						  
						  
$html .= '
									</tr>
                                   </thead>
                                    <tbody> ';
 
						     for($k=0; $k<sizeof($machines); $k++){ 
								 
							 $mac  = $machines[$k];
							 $macn_id   = $mac['name'];// 
							 $mcn_id   =$this->encrypt->decode($mac['mid']);
							 $last_service   ='';
							 $next_dates   ='';
							  
							 
							 $service_details = $this->bio-> Service_details($mcn_id , 0 , '' , '');
							 
							 
							 
							 if(sizeof($service_details) > 0){
								$last_service   = $service_details[0]['dates'];
							 }
							 else {
								 $last_service   =$mac['period'];
								 
							 }
							 
								$next_dates   = AddMonths($last_service , 6);
							  
								 
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufacturers and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									 
									if($sup_data['id'] ==$macn_id   ){
										  $macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								 
                               $html .= ' <tr> 
								
								 <td>  '.( $k +1).'  </td>
								 <td>  '. (ucfirst($macn_name)).'</td>
								 
								 <td>  '; 
								   IF($mac['mod'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['mod']));
								   
								   
								   $html .= '</td>
								   <td>  '; 
								   IF($mac['sn'] =="" ){echo "N/A";}ELSE echo ucfirst( strtolower($mac['sn']));
								   
								  $html .= ' 
								   </td>
								   
								    <td>'. ucfirst( strtolower($mac['code'])).'
									
								   </td>
								   
								    <td>'. ucfirst( strtolower($mac['price'])).'
								   </td>
								 
								   <td>   '. $sup_name.' </td>
								    <td>';
								 
												    for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														    $html .=  ' '.  ucfirst(strtolower($item['dname'])) .' '; 
														   }															
												        }
								 
							          $html .= '
							  </td>
								  
								 <td>   ';
 										 
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($mac['ms'] ==  $dt['id']){
												$html .= ''.  ucfirst(strtolower($dt['name'])).'';
												}
											}
											
											$html .= '

								 </td>
								 <td> '. $last_service   .' </td>
								'; if($report_type ==1){ $html .= '
								 <td> '. $next_dates; $html .= '</td>
								  <td> ';    $count_dates =   dateDiff(timeCurrent2(), $next_dates);  if($count_dates < 0 ){ $html .= ' <span class="label label-danger">';} else if($count_dates > 0 and  $count_dates< 30  ){ $html .=  '<span class="label label-warning">';} else { $html .=  '<span class="label label-success">'; } $html .=  ' '. $count_dates.' </span></td>';
								  						 
								  }  
								  if($report_type ==2){ $html .= '
								 <td> '.  $next_dates.'</td>';
								   						 
								  }  $html .= '
								 
                                 
                                 </tr>
                 
                                
                                ';} 
                 
 $html .= '                               
 
  
 
</tbody></table>
 
<p>&nbsp;</p>

';
						  }
						  
						  
						  
								
								if($report_type > 0) {
								 
								 


                                      $html .= ' <table   class="bpmTopnTail"  style="   padding-bottom:15px; 	empty-cells: show; "    border="1"  >
                                     <tbody> 
                                    <tr> <td> #</td><td> Name</td> <td> Sno</td><td> Code</td> <td> Department</td>     
									 '; 
									 if($report_type == 1) {  $html .= ' 
									 <td >State1 </td><td >State2 </td><td >Comment </td><td >Way forward </td> <td >Date </td><td >Teach</td>    <td   >Tech_company</td> 
									 ';
									 }   else if($report_type == 3) {  $html .= ' 
									 <td >Date</td><td >Invoice</td> <td> Diagnosis </td><td >Remedy </td><td >Spares </td> <td >Company</td><td >Tech Comment </td> <td >New State</td><td >Charges</td>      
									 ';}   else if($report_type == 2) {  $html .= ' 
									 <td >Problem</td><td >Date Reported</td> <td >Results </td><td >Date worked on </td><td >Technician</td>   <td >New State</td>      
									 ';}   $html .= ' 
									</tr>
									  
                                    ';

                 
                                
											
								 
						for($k=0; $k<sizeof($machines); $k++){ 
								 
							 $mac  = $machines[$k];
							 $macn_id   = $mac['name'];// 
							  $mcn_id   =$this->encrypt->decode($mac['mid']);
							 $last_service   ='';
							 $next_dates   ='';
							 $service_details = array();
							 if($report_type == 1) {
							 
							 $service_details = $this->bio-> Service_details($mcn_id ,2 , $lower , $upper);
							 }
							 
							  elseif($report_type == 3) {
							 
							 $service_details = $this->bio-> Repair_details($mcn_id ,2 , $lower , $upper);
							 }
							 elseif($report_type == 2) {
							 
							 $service_details = $this->bio-> Problem_details($mcn_id ,2 , $lower , $upper);
							 }
							 //Problem_details(
							   
								 
								$sup_name ="N/A";  $man_name ="N/A"; $macn_name ="N/A"; 
								//check for manufactureres and suppliers and machine names from the database from here
								
								
								for($s=0; $s<sizeof($sup_loop); $s++){
									$sup_data =$sup_loop[$s]; //local variable
									if($sup_data['id'] ==$mac['sup']  ){
										$sup_name =$sup_data['name'];
										
									}
									
								}
								//check for the manufacturer name
								
								for($s=0; $s<sizeof($man_loop); $s++){
									$sup_data =$man_loop[$s];
									if($sup_data['id'] ==$mac['man']  ){
										$man_name =$sup_data['name'];
										
									}
									
								}
								// check for machine  name
								
								 
								for($s=0; $s<sizeof($machines_loop); $s++){
									$sup_data =$machines_loop[$s];
									 
									if($sup_data['id'] ==$macn_id   ){
										  $macn_name =$sup_data['name'];
										
									}
									
								}
									
 
								 $html .= ' 
                                <tr> 
								
								 <td >  '. ( $k +1).' </td>
								 <td>  '.ucfirst($macn_name).'</td>
								 
								 
								   <td>  ';  
								   IF($mac['sn'] =="" ){ $html .= "N/A";}ELSE  $html .= ''.ucfirst( strtolower($mac['sn'])).'';
								   
								    $html .= ' 
								   </td>
								   
								    <td> '. ucfirst( strtolower($mac['code'])).'
								   
								   
								   </td>
								   <td>';       for($d=0; $d<sizeof($departments); $d++ ){
													 
													       $item = $departments[$d];
														   if($mac['dep'] == $item['id'] ){
														     $html .=  ' '.  ucfirst(strtolower($item['dname'])) .' '; 
														   }															
												        }
														$span  = 0;
								  if($report_type == 1) {
									  $span  = 7;
								  }
								  if($report_type == 2) {
									  $span  = 6;
								  }
								  if($report_type == 3) {
									  $span  = 9;
								  }
								
							 $html .= ' 
							 </td>
								  
								 <td    colspan ="'.$span.'" > ';
								 
									
									 
								  
								 
								  if($report_type == 1) {
									  if(sizeof($service_details) > 0) {
									  $html .= ' <table class="bpmTopnTail"  style="   padding-bottom:15px; 	empty-cells: show; "    border="1"  >  ';
									 
								 foreach($service_details as $row){ 
								 
								  $html .= '  <tr  >   <td  > ';
 										
											 
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($row['new'] ==  $dt['id']){
												 $html .= ' '. ucfirst(strtolower($dt['name'])).'';
												}
											}
											 $html .= ' </td> <td > ';
 										 
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($row['old'] ==  $dt['id']){
												 $html .= ' '.  ucfirst(strtolower($dt['name'])).'';
												}
											} 
                                             $html .= ' </td>
										   <td>'. $row['com'].' </td>
										   <td>'.   $row['wf'].'  </td>
										   <td>'. $row['dates'].'  </td>
										   <td>';  if($row['tech'] =="" ) {  $html .=  'N/A';} else {  $html .= ' '.$row['tech'].'';}  
										    $html .= ' </td> 
										   <td>'; if($row['tech_comp'] =="" ) {  $html .=  'N/A';}   $html .= ''. $row['tech_comp'].' </td>
										   </tr>';
								    }
									$html .= ' </table>';
									
									
									}
									else { $html .= ' No Data found ';}
									
								  }								

								  else  if($report_type == 3) { 
								   $html .= ' <table class="bpmTopnTail"  style="   padding-bottom:15px; 	empty-cells: show; "    border="1"  >  ';
								 
								 foreach($service_details as $row){
								 
								  $html .= ' 
									<tr><td>'. $row['dates'].'</td><td>'. $row['invoice'].'</td> <td>'. $row['diag'].'</td><td>'. $row['remedy'].'  </td><td>'. $row['spare'].'  </td> <td>'. $row['comp'].'</td><td>'. $row['tech_comm'].'  </td>
									<td> '; 
 										 
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($row['state'] ==  $dt['id']){
												 $html .= ' '.  ucfirst(strtolower($dt['name'])).'';
												}
											} $html .= ' 
									
									</td>
									
									
									<td>'. $row['cost'].' </td>      
									</tr>';
									 
								 }	 $html .= ' </table  >  ';
								 
								 }
								 else   if($report_type == 2) { 
								  $html .= ' <table class="bpmTopnTail"  style="   padding-bottom:15px; 	empty-cells: show; "    border="1"  >  ';
								 
								 foreach($service_details as $row){ 
								 
								 $html .= ' 
									 <tr ><td >'. $row['problem'].'</td><td>'. $row['dates'].'</td> <td>'. $row['sorted'].' </td><td>'. $row['date_worked_on'].'</td>
									 <td>'.$row['tech'].'</td>   
									 
									 <td> ';
 										 
											
											for($i=0; $i<sizeof($mstates) ; $i++){
												  $dt =  $mstates[$i];
												if($row['state'] ==  $dt['id']){
												 $html .= ' '. ucfirst(strtolower($dt['name'])).'';
												}
											}
									 
									 $html .= '  </td>      
									</tr>'; } 
									 $html .= ' </table >  ';
								 }
								 else $html .= '  No Data found';
							 

								 $html .= '</td>
								  
                                 
                                 </tr>';
                 
                                
                                  }
                  $html .= ' 
                                </tbody>
                                </table>
								</div>
								 ';
							 
								
								 
								}
								 

//==============================================================
//==============================================================
//==============================================================
include("assets/MPDF56/mpdf.php");

$mpdf=new mPDF('c','A4'); 

$mpdf->SetDisplayMode('fullpage');

$mpdf->list_indent_first_level = 0;	// 1 or 0 - whether to indent the first level of a list

// LOAD a stylesheet
$stylesheet = file_get_contents('assets/MPDF56/examples/mpdfstyletables.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($html,2);

$mpdf->Output('mpdf.pdf','I');
exit;
//==============================================================
//==============================================================
//==============================================================


?>