 

	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="">Home</a></li>
				  <li class="active">Check out</li>
				</ol>
			</div><!--/breadcrums-->
 
    		 
			<div class="shopper-informations">
				<div class="row">
					 
					<div class="col-sm-12 clearfix">
						<div class="bill-to">
							<p>Bill To</p>
							<div class="form-one">
								     <?php 
                     // $attributes = array('class' => 'form-horizontal', 'id' => 'prof_alt', 'role' => 'form'  , 'method'=>"post"  ,  'onSubmit'=>' return create_hosp_acc();' );

                      echo form_open('System_controls/create_hospital', '');

?>	
									<input type="text" name  ="company" placeholder="Company Name" required >
									<input type="email" name  ="email" placeholder="Email*" required>
									 
									<input type="text" name  ="fname" placeholder="Full Name *" required>
									 
									<input type="text" name  ="address" placeholder="Address 1 *" required> 
									
									<input type="text" name  ="phone" placeholder="Phone *" >
									<input type="text" name  ="mobile"  placeholder="Mobile Phone"> 
									<select required name  ="country" >
										<option value="" >-- Country --</option>
										<option value="Uganda">Uganda</option>
										<option value="Kenya">Kenya</option>
										<option value="Tanzania">Tanzania</option>
										<option value="Rwanda">Rwanda</option>
										<option value="Burundi">Burundi</option>
										<option value="Southern Sudan">Southern Sudan</option>
										<option value="DRC Congo">DRC Congo</option>
										<option value="Other">Other</option>
									</select>
									 
								
							</div>
							<div class="form-two">
								<div class="order-message">
							<p>Additional Information</p>
							<textarea name="message"  placeholder="Notes about your order, Special Notes for Delivery" rows="16"></textarea>
							 
						</div>	
							</div></form>
						</div>
					</div>
					 				
				</div>
			</div>
			<div class="review-payment">
				<h2>Review & Payment</h2>
			</div>

			<div class="table-responsive cart_info">
				<table class="table table-condensed"   id="tblProducts">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
					<?php $cart =  $search['scores'] ;
					$total = 0; 
					 for($i =1; $i<(sizeof($cart) +1); $i++ ){
						
						  $std  =  $cart[$i];
										  if(sizeof($std) > 0){
											  
                                           $item_id =  $std['Name'] ;
										 $item_id1 =  $this->encrypt->decode($std['Name'] );
										  $item =$this->bio->get_machine_in_cart(  $item_id1  );
						
					 
						 
						 if(sizeof( $item) > 0){
							  $total += $item[0]['price']; 
							 
						 
					?>
					<tr>
					<td class="cart_product">
								<a href=""><img src="images/cart/one.png" alt=""></a>
							</td>
        
		                   <td class="pnm cart_description">
						   <input type="hidden"  readonly class="item_type cart_quantity_input "   value="<?php echo $item_id ;?>" name="price" />
								<h4><a href="#"><?php echo $item[0]['name'] ;?></a></h4>
								<p><?php echo $item[0]['sname'] ;?></p>
								<p><?php echo $item[0]['spec'] ;?></p>
								<p><?php echo $item[0]['desc'] ;?></p>
							</td>
                            <td  ><input type="number"  readonly class="price cart_quantity_input "   value="<?php echo $item[0]['price'] ;?>" name="price" /></td>
                            <td><input type="number"  readonly class="qty cart_quantity_input"  max="5" min="0" value="<?php echo $std['Qty'];?>" maxlength="5" name="qty"/></td>
                            <td class="cart_price"><input readonly type="text" class="subtot cart_total_price"  readonly value="<?php echo $std['Qty'] * $item[0]['price'] ;?>" name="subtot"/></td>
                               
						  </tr>
					 
						<?php
						   }
										 
											  
										  }
											     
													 
					 }
					
					
						 
					 
						?>

						 <tr>
						  
    <td colspan="4" >TOTAL PRICE</td>
     
    <td><input type="text" class="grdtot cart_total_price "  readonly value = "<?php echo  $total;?>"  name=""/></td>
    </tr>
	
					</tbody>
					
				</table>
				
			</div>
			 
	</section> <!--/#cart_items-->

	 