
<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Search Results</h2>
						</div>
<?php  
						foreach($search as $feature){
						
						?>
						<div class="col-sm-3">
							<div class="product-image-wrapper">
							 
									
								  <div class="single-products">
										<div class="productinfo text-center">
											<img src="assets/Eshop/images/home/product1.jpg" alt="" />
											<h2><?php  echo $feature['price'] ;?></h2>
											<p><?php  echo $feature['name'] ;?></p>
													<button     class="my_button2 btn btn-default get" value="<?php  echo $this->encrypt->encode( $feature['id']) ;?>">Add to chat</button>
									</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>$<?php  echo $feature['price'] ;?></h2>
												<p><?php  echo $feature['spec'] ;?></p>
												<p><?php  echo $feature['desc'] ;?></p>
												<button     class="my_button2 btn btn-default get" value="<?php  echo $this->encrypt->encode( $feature['id']) ;?>">Add to chat</button>
									</div>
										</div>
										<img src="assets/Eshop/images/home/sale.png" class="sale" alt="" />
								</div> 
								 
							</div>
						</div>
						<?php } ?>
						
					<script>	
					 $('.my_button2').click(function() {
            var item = $(this).attr("value");
			 
	BetaCustom4('Eshop/chat_items' ,  item , '#result_items' );
			
        });
		</script>
						 