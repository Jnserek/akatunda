 
<?php $cart =  $_SESSION['cat_items'] ;
					
					if(sizeof($cart) <1) {
						bio_error('No item on the cart');
					}
					?>
	<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="">Home</a></li>
				  <li class="active">Shopping Cart</li>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed"   id="tblProducts">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
					<?php $cart =  $_SESSION['cat_items'] ;
					$total = 0; 
					if(sizeof($cart) > 0) {
						foreach ($cart as $cat ){
							  
                         $item =$this->bio->get_machine_in_cart($cat );
						
					 
						 
						 if(sizeof( $item) > 0){
							  $total += $item[0]['price']; 
							  $item_id =  $this->encrypt->encode($cat );
						 
					?>
					<tr>
					<td class="cart_product">
								<a href=""><img src="images/cart/one.png" alt=""></a>
							</td>
        
		                   <td class="pnm cart_description">
						   <input type="hidden"  readonly class="item_type cart_quantity_input "   value="<?php echo $item_id ;?>"   />
								<h4><a href="#"><?php echo $item[0]['name'] ;?></a></h4>
								<p><?php echo $item[0]['sname'] ;?></p>
								<p><?php echo $item[0]['spec'] ;?></p>
								<p><?php echo $item[0]['desc'] ;?></p>
							</td>
                            <td  ><input type="number"  readonly class="price cart_quantity_input "   value="<?php echo $item[0]['price'] ;?>" name="price" /></td>
                            <td><input type="number" class="qty cart_quantity_input"  max="5" min="0" value="1" maxlength="5" name="qty"/></td>
                            <td class="cart_price"><input type="text" readonly class=" subtot cart_total_price" value="<?php echo $item[0]['price'] ;?>" name="subtot"/></td>
                             <td class="cart_delete"><?php  //echo $this->encrypt->encode($cat ) ;?> 
							 <button class="my_button3  cart_quantity_delete btn btn-default get" value="<?php  echo $item_id ;?>"  > <i class="fa fa-times"></i>Remove from cart </button> 
											
								 
							</td>
						  </tr>
					 
						<?php
						   }					
						  } 
						 }
						?>

						 <tr>
						  
    <td colspan="4" >TOTAL PRICE</td>
     
    <td><input type="text" class="grdtot cart_total_price " readonly  value = "<?php echo  $total;?>"  name=""/></td>
    </tr>
	
					</tbody>
					
				</table>
				
				<button class="   cart_quantity_delete btn btn-default get"  onclick  = "return Check_out();"   > <i class="fa fa-times"></i>CONTINUE </button> 
							
				 
			</div>
		</div>
		
	 
</body>
</html>
	</section> <!--/#cart_items-->

	 
	<script src="assets/Eshop/js/jquery.js"></script>
	
	<script type="text/javascript">
	
			 $('.my_button3').click(function() {
            var item = $(this).attr("value");
			 
	BetaCustom4('Eshop/remove_cat_item' ,  item , '#result_items' );
	FormLoader( 'Eshop/chat' );
	        // $('#result_items').show();
			//$('#result_items').fadeOut(3000); 
			
        });
		
        $(function () {
            $('.pnm, .price, .subtot, .grdtot').keyup('readonly', true);
            var $tblrows = $("#tblProducts tbody tr");

            $tblrows.each(function (index) {
                var $tblrow = $(this);

                $tblrow.find('.qty').on('keyup , click', function () {

                    var qty = $tblrow.find("[name=qty]").val();
                    var price = $tblrow.find("[name=price]").val();
                    var subTotal = parseInt(qty, 10) * parseFloat(price);

                    if (!isNaN(subTotal)) {

                        $tblrow.find('.subtot').val(subTotal.toFixed(2));
                        var grandTotal = 0;

                        $(".subtot").each(function () {
                            var stval = parseFloat($(this).val());
                            grandTotal += isNaN(stval) ? 0 : stval;
                        });

                        $('.grdtot').val(grandTotal.toFixed(2));
                    }
                });
            });
        });
    </script>
	
	<script>
	 /*$(document).ready(function () {
       $(".txtMult input").click(multInputs);

       function multInputs() {
           var mult = 0;
           // for each row:
           $("tr.txtMult").each(function () {
               // get the values from this row:
               var $val1 = $('.val1', this).val();
               var $val2 = $('.val2', this).val();
               var $total = ($val1 * 1) * ($val2 * 1);
               // set total for the row
               $('.multTotal', this).text($total);
               mult += $total;
           });
           $("#totals").text(mult);
       }
  });
	
	 $(document).ready(function () {
       $(".txtMult input").keyup(multInputs);

       function multInputs() {
           var mult = 0;
		   
		   var sum = 0; var quantity = 0;
           // for each row:
           $("tr.txtMult").each(function () {
               // get the values from this row:
               var $val1 = $('.val1', this).val();
               var $val2 = $('.val2', this).val();
               var $total = ($val1 * 1) * ($val2 * 1);
               // set total for the row
               $('.multTotal', this).text($total);
               mult += $total;
           });
             
	 
	
       }
	   
  });
  
  $(document).ready(function() {
    var sum = 0;
    var quantity = 0;
    $('.price').each(function() {
        var price = $('.price', this).val();
		alert();
       // var q = price.closest('tr').find('.quantity').val();
        sum += parseInt(price.val()) * 1;
        //quantity += parseInt(q);
    });
	
alert(sum);
    //$('#totals2').html(sum);
   // $('#total_quantity').html(quantity);
});
  
  */
	
	</script>
	
	

 