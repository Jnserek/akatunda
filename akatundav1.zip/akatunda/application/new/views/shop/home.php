
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>BEAS|| E-Shopper</title>
    <link href="assets/Eshop/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/Eshop/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/Eshop/css/prettyPhoto.css" rel="stylesheet">
    <link href="assets/Eshop/css/price-range.css" rel="stylesheet">
    <link href="assets/Eshop/css/animate.css" rel="stylesheet">
	<link href="assets/Eshop/css/main.css" rel="stylesheet">
	<link href="assets/Eshop/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="assets/Eshop/js/html5shiv.js"></script>
    <script src="assets/Eshop/js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="assets/Eshop/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/Eshop/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/Eshop/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/Eshop/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/Eshop/images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
<?php 
$this->load->view('shop/header');
$header = $this->bio-> All_Machines_cats('' , 1 );

?>
	<div class="col-sm-12" id="result_items" >   </div>
	<section id="slider"><!--slider this is my slider-->
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div id="slider-carousel" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
							<?php 
							  $featured  =  $this-> bio->All_featured('' );
							  for($x =0; $x<sizeof($featured); $x++ ){
								  $feat =$featured[$x];  
								  echo '<li data-target="#slider-carousel" data-slide-to="'. ($x +1).'"></li>';
							  }
							
							?> 
						</ol>
						<?php  ?>
						
						<div class="carousel-inner">
							
						
						<div class="carousel-inner">
						<?php    
							for($i=0; $i<1 ; $i++){
								$feature =$featured[0];  
							 ?> 
							<div class="item active">
								<div class="col-sm-6">
									<h1><span>E</span><?php echo  $feature['name'];?></h1>
									<h2><?php  echo $feature['price'];?></h2>
									<p> <?php  echo $feature['spec'];?></p>
									<p> <?php echo  $feature['desc'];?></p>
									<button   class="my_button11 btn btn-default get" value="<?php  echo $this->encrypt->encode($feature['id']) ;?>">Get it nowxx</button>
										 			
									 		
								</div>
								<div class="col-sm-6">
									<img src="assets/Eshop/images/home/girl2.jpg" class="girl img-responsive" alt="" />
									<img src="assets/Eshop/images/home/pricing.png"  class="pricing" alt="" />
								</div>
							</div>
							
							<?php }  
							foreach($featured as $feature){
							 ?>
							<div class="item">
								<div class="col-sm-6">
									<h1><span>E</span><?php echo  $feature['name'];?></h1>
									<h2><?php  echo $feature['price'];?></h2>
									<p> <?php  echo $feature['spec'];?></p>
									<p> <?php echo  $feature['desc'];?></p>
									<button   class="my_button11 btn btn-default get" value="<?php  echo $this->encrypt->encode($feature['id']) ;?>">Get it nowxx</button>
										 			
									 		
								</div>
								<div class="col-sm-6">
									<img src="assets/Eshop/images/home/girl2.jpg" class="girl img-responsive" alt="" />
									<img src="assets/Eshop/images/home/pricing.png"  class="pricing" alt="" />
								</div>
							</div>
							<?php }  ?>
							
							 
						</div>
						
						<a href="assets/Eshop/#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
							<i class="fa fa-angle-left"></i>
						</a>
						<a href="assets/Eshop/#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
							<i class="fa fa-angle-right"></i>
						</a>
					</div>
					
				</div>
			</div>
		</div>
	</section><!--/slider-->
	
	<section>
	 
		<div class="container"> <div class="col-sm-12" id="result_item" > </div>
		
		<?php
$arr = array(5 , 1, 12 , 2);
//print_r($arr);

//$arr[] = 56;    // This is the same as $arr[13] = 56;
  //print_r($arr);              // at this point of the script

//$arr["x"] = 42; // This adds a new element to
                // the array with key "x"
   // print_r($arr);  
  // $key = array_search(12, $arr);         
//unset($arr[$key]); // This removes the element from the array
//print_r($arr);
    // This deletes the whole array
	
	 
$search_array = array('first' => 1, 'second' => 4);
if (array_key_exists('first', $search_array)) {
   // echo "The 'first' element is in the array";
}

$search_array = array('first' => null, 'second' => 4);

// returns false
isset($search_array['first']);

// returns true
array_key_exists('first', $search_array);


?>
			<div class="row" id="form_loader" >
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							 <?php foreach($header as $head){?>
								 
								<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href=""><?php echo $head['name']; ?> </a></h4>
								</div>
							</div>
							 <?php } ?>
							  
						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<!-- <h2>Brands</h2>
							<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
									<li><a href="assets/Eshop/#"> <span class="pull-right">(50)</span>Acne</a></li>
									<li><a href="assets/Eshop/#"> <span class="pull-right">(56)</span>Grüne Erde</a></li>
									<li><a href="assets/Eshop/#"> <span class="pull-right">(27)</span>Albiro</a></li>
									<li><a href="assets/Eshop/#"> <span class="pull-right">(32)</span>Ronhill</a></li>
									<li><a href="assets/Eshop/#"> <span class="pull-right">(5)</span>Oddmolly</a></li>
									<li><a href="assets/Eshop/#"> <span class="pull-right">(9)</span>Boudestijn</a></li>
									<li><a href="assets/Eshop/#"> <span class="pull-right">(4)</span>Rösch creative culture</a></li>
								</ul>
							</div>
							-->
						</div><!--/brands_products-->
						
						 
						
						<div class="shipping text-center"><!--shipping-->
							<img src="assets/Eshop/images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->
					
					</div>
				</div>
				
				
				<div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Features Items</h2>
						<?php
 					
						foreach($featured as $feature){
						
						?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="assets/Eshop/images/home/product1.jpg" alt="" />
											<h2><?php  echo $feature['price'] ;?></h2>
											<p><?php  echo $feature['name'] ;?></p>
											<a href="assets/Eshop/#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart  </a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>$<?php  echo $feature['price'] ;?></h2>
												<p><?php  echo $feature['spec'] ;?></p>
												<p><?php  echo $feature['desc'] ;?></p>
												<button class="my_button11 btn btn-default add-to-cart" value="<?php  echo $this->encrypt->encode($feature['id']) ;?> " onclick="return test();" > <i class="fa fa-shopping-cart"></i>Add to cart </button> 
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="assets/Eshop/#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
										<li><a href="assets/Eshop/#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
									</ul>
								</div>
							</div>
						</div>
						<?php }  
						
						$as_new    =  $this-> bio->All_featured('' );
						foreach($as_new as $feature){
						
						?>
						<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="assets/Eshop/images/home/product1.jpg" alt="" />
											<h2><?php  echo $feature['price'] ;?></h2>
											<p><?php  echo $feature['name'] ;?></p>
											<a href="assets/Eshop/#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart  </a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>$<?php  echo $feature['price'] ;?></h2>
												<p><?php  echo $feature['spec'] ;?></p>
												<p><?php  echo $feature['desc'] ;?></p>
												<button class="my_button11 btn btn-default add-to-cart" value="<?php  echo $this->encrypt->encode($feature['id']) ;?> "   > <i class="fa fa-shopping-cart"></i>Add to cart </button> 
											</div>
										</div>
										<img src="assets/Eshop/images/home/new.png" class="new" alt="" />
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="assets/Eshop/#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
										<li><a href="assets/Eshop/#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
									</ul>
								</div>
							</div>
						</div>
						<?php } ?>
						
						 
						
					</div><!--features_items-->
					
					<div class="category-tab"><!--category-tab-->
						<div class="col-sm-12"><?php $cats = $this->bio-> All_Machines_cats(0 , 1 ); ?>
							<ul class="nav nav-tabs">
							<?php
							//$cat_tabs = $cats
							$count =0; 
							foreach($cats as $cat){
								$count +=1;
								if($count <1){
								 
								echo '<li class="active"><a href=" #'.$cat['id'].'" data-toggle="tab">'.$cat['name'].'</a></li>';
								}
								else echo '<li  ><a href=" #'.$cat['id'].'" data-toggle="tab">'.$cat['name'].'</a></li>'; 
								
							}
							
							?>  
							</ul>
						</div>
						<div class="tab-content">
						
						<?php foreach($cats as $cat){
							$cat_data   =  $this-> bio->All_machines_by_cat($cat['id'] );
						//}
						?>
						
						<div class="tab-pane fade active in" id="<?php echo $cat['id'];?>" >
						<?php foreach($cat_data as $catd){
							 
						?>
								 
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="assets/Eshop/images/home/gallery<?php echo $catd['id'];?>.jpg" alt="" />
												<h2><?php  echo $catd['price'];?>/= </h2>
												<p><?php  echo $catd['name'];?></p>
												<p><?php  echo $catd['sname'];?></p>
												<p><?php  echo $catd['spec'];?></p>
												<p><?php  echo $catd['desc'];?></p>
												<button class="my_button11 btn btn-default add-to-cart" value="<?php  echo $catd['id'] ;?> "   > <i class="fa fa-shopping-cart"></i>Add to cart </button> 
													</div>
											
										</div>
									</div>
								</div>
								<?php } ?>
								 
							 
							</div>
							<?php } ?>
						
						<?php ?>
							 
							
							 
							 
						</div>
					</div><!--/category-tab-->
					
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">recommended items</h2>
						
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<div class="item active">	
								
									 <?php  
								$recome    =  $this-> bio->All_recomended(''  );
								 
						for($k=0; $k<sizeof($recome) ; $k++ ){
							$recom= $recome[$k];
							if($k <3){
								
								?>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="assets/Eshop/images/home/recommend1.jpg" alt="" />
													<h2><?php  echo $recom['price'];?> /=<?php // echo $this->encrypt->encode($recom['id']) ;?></h2>
													<p><?php  echo $recom['name'];?></p>
												 
													<button class="my_button11 btn btn-default add-to-cart" value="<?php  echo $this->encrypt->encode($recom['id']) ;?> " onclick="return test();" > <i class="fa fa-shopping-cart"></i>Add to cart </button> 
												</div>
												
											</div>
										</div>
									</div>
							<?php } } ?>
									 
									 
								</div>
								<div class="item">	
									<?php for($k=3; $k<sizeof($recome) ; $k++ ){
							$recom= $recome[$k];
							 
								
								?>
									<div class="col-sm-4">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="assets/Eshop/images/home/recommend1.jpg" alt="" />
													<h2><?php  echo $recom['price'];?> /=</h2>
													<p><?php  echo $recom['name'];?></p>
												 
													<button class="my_button11 btn btn-default add-to-cart" value="<?php  echo $this->encrypt->encode($recom['id']) ;?> " onclick="return test();" > <i class="fa fa-shopping-cart"></i>Add to cart </button> 
												</div>
												
											</div>
										</div>
									</div>
							<?php }  ?>
							
									  
								</div>
							</div>
							 <a class="left recommended-item-control" href="assets/Eshop/#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="assets/Eshop/#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>			
						</div>
					</div><!--/recommended_items-->
					
				</div>
			</div>
		</div>
	</section>
	<input type="hidden"  value ="<?php  echo base_url();?>"  id ="shop_base"   />
	<?php
 
	$this->load->view('shop/footer');
	?>
	

  
    <script src="assets/Eshop/js/jquery.js"></script>
	<script src="assets/Eshop/js/bootstrap.min.js"></script>
	<script src="assets/Eshop/js/jquery.scrollUp.min.js"></script>
	<script src="assets/Eshop/js/price-range.js"></script>
    <script src="assets/Eshop/js/jquery.prettyPhoto.js"></script>
    <script src="assets/Eshop/js/main.js"></script>
	<script src="assets/Eshop/js/E_shop.js"></script>
	
</body>
</html>