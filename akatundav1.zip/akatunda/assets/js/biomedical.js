	  $('html, body').animate({ scrollTop: $('#container').offset().top }, 'slow');
	var bio =[];
	function Load_form1(){
		 
		FormLoader( 'Form_loader', 'create_profile' );
		
		return false;
	}

	function Continue_to_cat(){ 
		
			
		var  marks = { scores: []};
		var checker = 0;
		 
	 
	   $('table tr').each(function() {
	 
			if($('.quantity', this).val() > 0  ) {
				 
				 checker +=1;
				if(checker > 0) {
					
			  marks.scores.push({ 
			"Item" : $('.cat_item', this).val(), 
			"Qty"  : $('.quantity', this).val() 
		 
			   
			});
					   }
					}
					
					
					
		}); 
		
			  var act = $('#prof_alt').attr('action');
			  
		  
		   if(checker < 1){
			 
			 alert('Please enter atleast one machine to continue');
			 return false;
		 }
		//order_info
		bio =[];
		 var info = $('#order_info').val();
		bio.push(marks , info )
			 
			  BioCustom( act ,  bio , 2 , '#main-content' );
			//  BioCustom2( 'Form_loader' , 'machine_entry_one' ,    marks , dpt , '#main-content' );
		return false;
		 
		
	}

	function Home(){
		window.location.href =  "";
		return false;
		
	}

	function my_chats(){
		var dt = $('[name="chats"]:checked').map( function(){ return $(this).val(); }).toArray();
		BioCustom2( 'Form_loader' , 'My_chats' ,    dt[0] , 1 , '#main-content' );
		 
		
		return false;
	}
	//cat images
	function Cat_images(){
		var dt = $('[name="cat_images"]:checked').map( function(){ return $(this).val(); }).toArray();
		BioCustom2( 'Form_loader' , 'Cat_images' ,    dt[0] , 1 , '#main-content' );
		 
		
		return false;
	}
	//manage service companies
	function Manage_companies(){
		
		FormLoader( 'Form_loader', 'Manage_Service_companies' );
		
		return false;
		
		
	}

	//list service companies

	function Service_companies(){
		
		FormLoader( 'Form_loader', 'Service_companies' );
		
		return false;
		
		
	}

	function Load_notifications(){
		
		FormLoader( 'Form_loader', 'My_notifications' );
		
		return false;
		
		
	}

	//Load add new clientInformation

	function Load_machine_lyfe_data(){
		
		FormLoader( 'Form_loader', 'machine_life' );
		
		return false;
		
		
	}
	function Load_client_add_form(){
		 
		FormLoader( 'Form_loader', 'Client_form_addition' );
		
		return false;
	}

	function Get_machine_dep_rates(){
		 
		FormLoader( 'Form_loader', 'Machine_depreciation_rates' );
		
		return false;
	}
	function Load_installation_form(){
		 FormLoader( 'Form_loader', 'Instalation_form' );
		
		return false;
	}

	//add new servicing tech
	function Add_Service_Tech(){
		 
		FormLoader( 'Form_loader', 'Service_tech_entry_form' );
		
		return false;
	}

	function Add_event(){
		 
		FormLoader( 'Form_loader', 'Add_new_event' );
		
		return false;
	}

	function Manage_events(){
		 
		 BioCustom2( 'Form_loader' , 'List_events' ,    2 , 2 , '#main-content' );
		
		return false;
	}



	function List_events(){
		 
		 BioCustom2( 'Form_loader' , 'List_events' ,    1 , 1 , '#main-content' );
		
		return false;
	}


	//load new  service company addition from 


	function Add_Service_company(){
		 
		FormLoader( 'Form_loader', 'Service_company_entry_form' );
		
		return false;
	}


	//add suplier

	function Add_supplier(){
		 
		FormLoader( 'Form_loader', 'Supplier_entry_form' );
		
		return false;
	}

	//add manufacturere

	function Add_manufacturer(){
		 
		FormLoader( 'Form_loader', 'Manufacturer_entry_form' );
		
		return false;
	}

	//get my suppliers

	function Get_machine_suppliers(){
		 
		FormLoader( 'Form_loader', 'Machine_suppliers' );
		
		return false;
	}

	//list data
	function List_machine_suppliers(){
		 
		FormLoader( 'Form_loader', 'List_suppliers' );
		
		return false;
	}


	//my manufacturers

	function Get_machine_manufactureres(){
		 
		FormLoader( 'Form_loader', 'Machine_manufactureres' );
		
		return false;
	}

	//list machine manufactureres


	function List_manufactureres(){
		 
		FormLoader( 'Form_loader', 'List_manufactureres' );
		
		return false;
	}

	//get machine problems
	function List_problems(){
		 
		FormLoader( 'Form_loader', 'Device_problems' );
		
		return false;
	}

	//pending problems
	function List_Pending(){
		 
		FormLoader( 'Form_loader', 'Tech_pending_probs' );
		
		return false;
	}

	//NOTIFICATION
	function List_Settings(){
		 
		FormLoader( 'Form_loader', 'System_settings' );
		
		return false;
	}

	$('.them_option').click(function() {
				var item = $(this).attr("value");
				 
				 BioCustom2( 'Form_loader' , 'System_themes' ,    item , 0 , '#main-content' );
				//  $('#result_items').show();
				 //$('#result_items').fadeOut(3000); 
				 Home();
				
			});
	function List_Themes(){
		 
		//FormLoader( 'Form_loader', 'System_themes' );
		
		return false;
	}

	//list files for backup

	function List_backup_files(){
		 
		FormLoader( 'Form_loader', 'List_file_backup' );
		
		return false;
	}

	//list files for deletion

	function List_backup_file_deletion(){
		 
		FormLoader( 'Form_loader', 'List_file_backup_deletion' );
		
		return false;
	}

	//perform system backup

	function System_backup(){
		 
		FormLoader( 'Form_loader', 'System_back_up' );
		
		return false;
	}
	//load stste addition form from here

	//get machine states


	function Get_machine_states(){
		 
		FormLoader( 'Form_loader', 'Machine_states' );
		
		return false;
	}

	//list states


	function List_states(){
		 
		FormLoader( 'Form_loader', 'List_states' );
		
		return false;
	}

	function List_users(){
		 
		FormLoader( 'Form_loader', 'List_users' );
		
		return false;
	}

	function Sys_users(){
		 
		FormLoader( 'Form_loader', 'Manage_users' );
		
		return false;
	}

	function Active_users(){
		 
		FormLoader( 'Form_loader', 'List_Acive_users' );
		
		return false;
	}

	function Idle_users(){
		 
		FormLoader( 'Form_loader', 'List_Idle_users' );
		
		return false;
	}



	function Load_states_add_form(){
	 
		FormLoader( 'Form_loader', 'state_additin_form' );
		
		return false;
	}

	function Report_problem(){
		 var dt = $('[name="report"]:checked').map( function(){ return $(this).val(); }).toArray();
		  
		  BioCustom2( 'Form_loader' , 'New_machine_Report' ,    dt[0] , 1 , '#main-content' );
		return false;
	}

	function Repair_report(){
		 var dt = $('[name="service"]:checked').map( function(){ return $(this).val(); }).toArray();
		  
		  BioCustom2( 'Form_loader' , 'Repair_report' ,    dt[0] , 1 , '#main-content' );
		return false;
	}


	function Service_report(){
		 var dt = $('[name="service"]:checked').map( function(){ return $(this).val(); }).toArray();
		  
		  BioCustom2( 'Form_loader' , 'Repair_report' ,    dt[0] , 1 , '#main-content' );
		return false;
	}
	//give outerHeight
	function Allocate(){
		 var dt = $('[name="do_service"]:checked').map( function(){ return $(this).val(); }).toArray();
		  
		  BioCustom2( 'Form_loader' , 'Allocate' ,    dt[0] , 1 , '#main-content' );
		return false;
	}

	//transfer

	function Transfer(){
		 var dt = $('[name="do_service2"]:checked').map( function(){ return $(this).val(); }).toArray();
		  
		  BioCustom2( 'Form_loader' , 'Transfer' ,    dt[0] , 1 , '#main-content' );
		return false;
	}


	function Field_service(){
		 var dt = $('[name="do_service"]:checked').map( function(){ return $(this).val(); }).toArray();
		  
		  BioCustom2( 'Form_loader' , 'Field_service' ,    dt[0] , 1 , '#main-content' );
		return false;
	}

	// GET THE MACHINE SEFIVE HISTORY 

	function Machine_hisory(){
		 var dt = $('[name="do_hist"]:checked').map( function(){ return $(this).val(); }).toArray();
		  
		  BioCustom2( 'Form_loader' , 'Machine_history' ,    dt[0] , 1 , '#main-content' );
		return false;
	}

	function Machine_list(){
		 var dt = $('[name="do_hist"]:checked').map( function(){ return $(this).val(); }).toArray();
		  
		  BioCustom2( 'Form_loader' , 'Machine_history' ,    dt[0] , 0 , '#main-content' );
		return false;
	}

	function Load_my_Machines(){
	 
		FormLoader( 'Form_loader', 'My_machines' );
		
		return false;
	}

	function List_my_Machines(){
	 
		FormLoader( 'Form_loader', 'List_machines' );
		
		return false;
	}





	//get my departments 

	function add_machine(){
		 var dt = $('[name="new_machine"]:checked').map( function(){ return $(this).val(); }).toArray();
	   BioCustom2( 'Form_loader' , 'New_machine_form' ,    dt[0] , 1 , '#main-content' );
		return false;
	}

	//
	function department_info(){
		var dt = $('[name="more_machine"]:checked').map( function(){ return $(this).val(); }).toArray();
		 
		  BioCustom2( 'Form_loader' , 'department_info_form' ,    dt[0] , 1 , '#main-content' );
		
		return false;
	}
	 function alt_departmental_info(){
		  var dt = $('[name="alt_machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		  BioCustom2( 'Form_loader' , 'Edit_depart_form' ,    dt[0] , 1 , '#main-content' );
		 
		 
		 return false;
	 }
	 
	  function alt_client_info(){
		  var dt = $('[name="alt_machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		 
		  BioCustom2( 'Form_loader' , 'Edit_client_form' ,    dt[0] , 1 , '#main-content' );
		 
		 
		 return false;
	 }
	 
	 //delete 
	 
	 function Delete_client_info(){
		  var dt = $('[name="del_machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		  BioCustom2( 'Form_loader' , 'Edit_client_form' ,    dt[0] , 0 , '#main-content' );
		 
		 
		 return false;
	 }
	 
	 //update machine
	  function alt_supplier_info(){
		  var dt = $('[name="alt_machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		  BioCustom2( 'Form_loader' , 'Edit_supplier_info_form' ,    dt[0] , 1 , '#main-content' );
		 
		 
		 return false;
	 }
	  function del_supplier_info(){
		  var dt = $('[name="machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		  BioCustom2( 'Form_loader' , 'Edit_supplier_info_form' ,    dt[0] , 0 , '#main-content' );
		 
		 
		 return false;
	 }
	 
	 //update manufacturers
	 
	   function alt_manufacturer_info(){
		  var dt = $('[name="alt_machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		  BioCustom2( 'Form_loader' , 'Edit_maufacturer_info_form' ,    dt[0] , 1 , '#main-content' );
		 
		 
		 return false;
	 }
	 
	 //del manufacturer
	 
	  function del_manufacturer_info(){
		  var dt = $('[name="machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		  BioCustom2( 'Form_loader' , 'Edit_maufacturer_info_form' ,    dt[0] , 0 , '#main-content' );
		 
		 
		 return false;
	 }
	 
	   function alt_machine_state_info(){
		 
		  var dt = $('[name="alt_machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		  BioCustom2( 'Form_loader' , 'Edit_machine_states_info_form' ,    dt[0] , 1 , '#main-content' );
		 
		 
		 return false;
	 }
	 
	 //alt user
	 function alt_user_info(){
		 
		  var dt = $('[name="alt_machine_info"]:checked').map( function(){ return $(this).val(); }).toArray();
		  BioCustom2( 'Form_loader' , 'Edit_system_user_state' ,    dt[0] , 0 , '#main-content' );
		 
		 
		 return false;
	 }

	//service report form


	function Service_report(){
	 
		 FormLoader( 'Form_loader', 'Service_reports' );
		
		
		return false;
	}
	 

	 


	function Load_my_departments(){
	 
		FormLoader( 'Form_loader', 'My_dpts' );
		
		return false;
	}
	//load machine repo

	function Load_my_Machines_reports(){
		 BioCustom2( 'Form_loader' , 'My_Reports' ,    1 , 1 , '#main-content' );
	  
		
		return false;
	}

	function Manage_Cat(){
		 BioCustom2( 'Form_loader' , 'Catalogue' ,    0 , 0 , '#main-content' );
		
		return false;
	}




	function Load_Cat(){
		 BioCustom2( 'Form_loader' , 'Catalogue' ,    1 , 1 , '#main-content' );
		
		return false;
	}


	function Load_Cat_fet(){
		 BioCustom2( 'Form_loader' , 'Catalogue' ,    2 , 2 , '#main-content' );
		
		return false;
	}

	function Load_Cat_All(){
		 BioCustom2( 'Form_loader' , 'Catalogue' ,    3, 3 , '#main-content' );
		
		return false;
	}


	function Load_Cart(){
		 BioCustom2( 'Form_loader' , 'Catalogue' ,    4, 4, '#main-content' );
		
		return false;
	}


	function Load_Cart_Hist(){
		 BioCustom2( 'Form_loader' , 'Catalogue' ,    5, 5, '#main-content' );
		
		return false;
	}
	//my repoets


	function Load_reports(){
	 
		FormLoader( 'Form_loader', 'Load_Reports' );
		
		return false;
	}


	function Load_search(){
	 
		FormLoader( 'Form_loader', 'Load_search' );
		
		return false;
	}
	//hospitals

	//order line search

	function Order_Line(){
	 BioCustom2( 'Form_loader' , 'Order_line_search' ,    1 , 1 , '#main-content' );
		 
		
		return false;
	}

	function Order_Items(){
	 BioCustom2( 'Form_loader' , 'Order_line_search' ,    2 , 2 , '#main-content' );
		 
		
		return false;
	}

	function Custom_services(){
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    2 , 1 , '#main-content' );
		 
		
		return false;
	}
	//
	function Custom_repairs(){ 
		
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    3 , 1 , '#main-content' );
		
		return false;
	}

	 
	function Custom_breakdowns(){
	  
		
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    1 , 1 , '#main-content' );
		
		return false;
	}


	//list

	function List_services(){
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    2 , 2 , '#main-content' );
		 
		
		return false;
	}
	//
	function List_repairs(){ 
		
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    3 , 2 , '#main-content' );
		
		return false;
	}

	 
	function List_breakdowns(){
	  
		
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    1 , 2 , '#main-content' );
		
		return false;
	}
	//manage

	function Manage_services(){
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    2 , 3 , '#main-content' );
		 
		
		return false;
	}
	//
	function Manage_repairs(){ 
		
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    3 , 3 , '#main-content' );
		
		return false;
	}

	 
	function Manage_breakdowns(){
	  
		
	 BioCustom2( 'Form_loader' , 'Custom_search' ,    1 , 3 , '#main-content' );
		
		return false;
	}


	function Load_my_hospitals(){
	 
		FormLoader( 'Form_loader', 'My_hosp_machines' );
		
		return false;
	}


	function List_clients(){
	 
		FormLoader( 'Form_loader', 'List_clients' );
		
		return false;
	}
	//
	function Load_installations(){
	 
		FormLoader( 'Form_loader', 'Load_Installations' );
		
		return false;
	}


	function List_client(){
	 
		FormLoader( 'Form_loader', 'My_clients' );
		
		return false;
	}
	//just list my clients


	function List_my_clients(){
	 
		FormLoader( 'Form_loader', 'List_my_client' );
		
		return false;
	}

	// load my machines

	function Load_my_Machines(){
	 
		FormLoader( 'Form_loader', 'My_machines' );
		
		return false;
	}
	//Alocate machines

	function Load_Alocations(){
	 
		FormLoader( 'Form_loader', 'Allocate_machines' );
		
		return false;
	}

	function Load_Transfers(){
	 
		FormLoader( 'Form_loader', 'Load_Transfer' );
		
		return false;
	}

	//load department addition from from here

	function Department_addition(){
		bio =[];
	 
		//FormLoader( 'Form_loader', 'Departments_form' );
		//bio.push(1);
		 //confrimAction1('ARE YOU SURE YOU WANT TO ADD A NEW DEPARTMENT' , 500);
		// $('#myModal').modal('show');
		 FormLoader( 'Form_loader', 'Departments_form' );
		  
		
		return false;
	}

	function confrimAction1(com , no){
		
		 var Modal ='<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">  <div class="modal-dialog"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>  <h4 class="modal-title">  CONFIRM NEW  YOUR ACTION</h4> </div>  <div class="modal-body alert alert-info"> <label class="label label-info" id="reportInfo"  ></label>  <label class="label label-info" id="reportInfocUSTOMM"  ></label> '+com+' </div>   <div class="modal-footer clearfix">   <button type="button" class="btn btn-danger" data-dismiss="modal"> Discard</button> <button type="submit" class="btn btn-success" onclick="return TakeAction();" >OK</button>  </form> </div><!-- /.modal-content --> </div><!-- /.modal-dialog -->  </div><!-- /.modal -->';
	 
		  
	 $('#Confirm1').html(Modal);

	}

	function TakeAction(){
		$('#myModal').modal('hide');
		var action1  = bio[0];
		  if(action1 == 1){
			  FormLoader( 'Form_loader', 'Departments_form' );
			  
			  
		  }
		  else {
			  alert('un known action to be performed');
		  }
		 
		
		return false;
	}



	function Load_form11(){
		//alert();
		FormLoader( 'Form_loader', 'alt_user_credentials' );
		
		return false;
	}


	function Load_Create_acc(){
		
		
		
		FormLoader( 'Form_loader', 'create_new_profile' );
		
		 
		
		return false;
	}

	//create new category


	function Load_Item_addition_form(){
		
		
		
		FormLoader( 'Form_loader', 'create_new_category_item' );
		
		 
		
		return false;
	}





	// add new sevice report

	function service_report_entry(){
			  var frmd = $('form').serialize();
		
			  var act = $('#log').attr('action');
			  BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	}
	//service my machine


	function service_machine_entry(){
			  var frmd = $('form').serialize();
		
			  var act = $('#log').attr('action');
			  BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	}

	function create_user_acc(){
			  var frmd = $('form').serialize();
		
			  var act = $('#login').attr('action');
			  BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	}

	//report machine problem


	function machine_problem(){
			  var frmd = $('form').serialize();
		
			  var act = $('#login').attr('action');
			  BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	}

	//add machines 

	function field_service_report(){
			  var frmd = $('form').serialize();
		
			  var act = $('#field').attr('action');
			  BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	}

	//update my profile info


	function update_acc_profile(){
			  var frmd = $('form').serialize();
		
			  var act = $('#profile').attr('action');
			   
			 
			  BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	}

	//acc_updates

	function create_user_acc_alt(){
			  var frmd = $('form').serialize();
		
			  var act = $('#prof_alt').attr('action');
			  
			// var check  =   BetaCustom5(scpt ,  com  );
			 
			  BetaCustom4(act ,  frmd, '#Acc_Loader' );
		 
		
		return false;
		
		
	}

	function Order_search(){ //create new hospital account
			  var frmd = $('form').serialize();

		
			  var act = $('#search').attr('action');
			   var act1 = $('#search_Order').val();
			  if(act1  =='' ){ alert('No data was found'); return false;}// =search_inventory
			  else {

			 BetaCustom4(act ,  frmd, '#main-content' );
			  }
		 
		
		return false;
		
		
	}


	function My_search(){ //create new hospital account
			  var frmd = $('form').serialize();

		
			  var act = $('#search').attr('action');
			   var act1 = $('#search_inventory').val();
			  if(act1  =='' ){ alert('No data was found'); return false;}// =search_inventory
			  else {

			 BetaCustom4(act ,  frmd, '#main-content' );
			  }
		 
		
		return false;
		
		
	}

	function create_hosp_acc(){ //create new hospital account
			  var frmd = $('form').serialize();

		
			  var act = $('#new_machine').attr('action');
			  

			   BetaCustom4(act ,  frmd, '#main-content' );
			 
		 
		
		return false;
		
		
	}

	function Seacrh_system(){
			  var frmd = $('form').serialize();

		
			  var act = $('#new_client').attr('action');

			   BetaCustom4(act ,  frmd, '#Content_loader' );
		 
		
		return false;
		
		
	} 



	function create_new_hosp_acc(){
			  var frmd = $('form').serialize();

		
			  var act = $('#new_client').attr('action');

			   BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	} 

	//create departments

	function Department_numbers(){
			  var frmd = $('form').serialize();
		
			  var act = $('#prof_alt').attr('action');
			  
			   BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	}
	 

	function add_departments_form(){
		
		//var  marks =  [];
		var checker = 0;
		var  marks = { scores: []};
	 
	 
	   $('table tr').each(function() {
	 
			if($('.Nm', this).val() != ""  ) {
				checker +=1;
				if(checker > 0) {
					 /*marks.push( // $('.Nm', this).val() ,
					  
					"Name"  : $('.Nm', this).val()
					 , 
					"Model"  : $('.dep_type', this).val()

					 ); */
					 
					 marks.scores.push({ 
			"Name" : $('.Nm', this).val(), 
			"Dep_type" : $('.dep_type', this).val()
			 
			
			});
					   }
					}
		});
		 
		
			  var act = $('#prof_alt').attr('action');
			  BioCustom( act ,  marks , 1 , '#main-content' );
		return false;
		 
		
	}
	 
	 

	 
	function add_new_machines_to_dpts(){
		
		var  marks = { scores: []};
		var checker = 0;
		var e_code = 0;
		
		 var dpt = $('#dpt').val();
		 var  error = '';
			  
		
	if(dpt ==''){
			 
			 alert('Please enter atleast one machine to continue');
			 return false;
		 }	
		 
		  
	   $('table tr').each(function() {
			var  error = '';
	 
			if($('.Nm', this).val() != ""    ) {
				 var  error = '';
				  $("#Error_code").html(error).show();
						if($('.statx', this).val()  < 1 ){
							e_code = 1;
							 
							 
							
					  
					return false;
				}
				
				else if(  $('.yri', this).val() < 1980){
					e_code = 2;
					 error +=' , Please indicate the year this machine was installed ' ;
					 
					return false;
				}
					
				else if($('.yr', this).val() > $('.yri', this).val()){
					e_code = 3;
					 error +=',  The year a machine was manufactured should be less than year it was  installed';
					  
					return false;
				}
				  checker +=1; 
				
				
				 
				if(checker > 0) {
								
			 marks.scores.push({ 
			"Name" : $('.Nm', this).val(), 
			"Model"  : $('.mdl', this).val() 
			, 
			"Sno"  : $('.sno', this).val()
			, 
			"Yr"  : $('.yr', this).val()
			 
			, 
			"Cou"  : $('.ctr', this).val()
			, 
			"Sup"  : $('.sply', this).val()
			, 
			"St"  : $('.statx', this).val()
			, 
			"Manuf"  : $('.manf', this).val()
			, 
			"comment"  : $('.comment', this).val() ,
			"noz"  : $('.noz', this).val()
			
			,
			"yri"  : $('.yri', this).val()
			,
			"m_action"  : $('.Action', this).val()
			,
			"way_foward"  : $('.Way_foward', this).val()
			,
			"d_code"  : $('.dev_no', this).val()
			,
			"d_price"  : $('.price', this).val()
			
			});
					   }
					}
					
					
					
		}); 
			 var act = $('#prof_alt').attr('action');
			  if(e_code ==1 ){
				  error =' Please indicate the status of your device';
				  alert(error);
				   $("#Error_code").html(error).show();
					$("#Error_code").css("background-color", "#0FFF00" , 'color' , '#F00' , 'padding' , '10px');
				   return false;
			  
				  
			  }
			  else  if(e_code ==2 ){
					error =' Please indicate the year this machine was installed';
					alert(error);
				   $("#Error_code").html(error).show();
					$("#Error_code").css("background-color", "#0FFF00" , 'color' , '#F00' , 'padding' , '10px');
				   return false;
			  }
			   else  if(e_code ==3 ){
					 error ='The year a machine was manufactured should be less than year it was  installed';
					 alert(error);
				   $("#Error_code").html(error).show();
					$("#Error_code").css("background-color", "#0FFF00" , 'color' , '#F00' , 'padding' , '10px');
				   return false;
			  }
			
		  if(checker < 2  &&  e_code <1 ){
			
			 
			 error +=' Please enter atleast one machine to continue';
			  $("#Error_code").html(error).show();
			  $("#Error_code").css("background-color", "#0FFF00" , 'color' , '#F00' , 'padding' , '10px');
			 alert('Error has occured');
			 return false;
		 }
		$("#Error_code").html('').hide();
			 
			  BioCustom( act ,  marks , dpt , '#main-content' );
			//  BioCustom2( 'Form_loader' , 'machine_entry_one' ,    marks , dpt , '#main-content' );
			 
		return false;
		 
		
	}
	//add service info to  



	function service_information(){
		
		var  marks = { scores: []};
		var checker = 0;
		var e_code = 0;
		
		 
		 var  error = '';
			  
		
		 
		  
	   $('table tr').each(function() {
			var  error = '';
	 
			if($('.Snew', this).val() >0    ) {
				 var  error = '';
				  $("#Error_code").html(error).show();
					 
				
					if($('.Sold', this).val()  < 1 ){
							e_code = 1;
							 
							 
							
					  
					return false;
				}
				
				
				 
				  checker +=1; 
				
				
				 
				if(checker > 0) {
								
			 marks.scores.push({ 
			"Name" : $('.Nm', this).val() //
			,
			"Snew"  : $('.Snew', this).val() ,
			 "Sold"  : $('.Sold', this).val()
			 
			 
			 
			,
			"m_action"  : $('.comment', this).val()
			,
			"way_foward"  : $('.Way_foward', this).val()
			 
			
			});
					   }
					}
					
					
					
		}); 
	 
			 var act = $('#prof_alt').attr('action');
			  if(e_code ==1 ){
				  error =' Please indicate the status of your device';
				  
				   $("#Error_code").html(error).show();
					$("#Error_code").css("background-color", "#0FFF00" , 'color' , '#F00' , 'padding' , '10px');
				   return false;
			  
				  
			  }
			  else if(checker <1 ){
				 
				  error =' Aleast one row of  New state, Way foward and Action fields should be filled';
				   alert(error);
				   $("#Error_code").html(error).show();
					$("#Error_code").css("background-color", "#0FFF00" , 'color' , '#F00' , 'padding' , '10px');
				   return false;
			  
				  
			  } 
			  
				
		   
		$("#Error_code").html('').hide();
		 
			  BioCustom( act ,  marks , 1 , '#main-content' );
				 
		return false;
		 
		
	}


	//add items to the catch
	function add_cat_items(){
		 
		var act = $('#prof_alt').attr('action');
		 
		var dt = $('[name="cat_item"]:checked').map( function(){ return $(this).val(); }).toArray();
		if(dt.length <1){
			alert('No item selected');
			return false;
		}
		 
		  BioCustom( act ,  dt , 1 , '#cat_results' );
		
		return false;
	}

	//machine dereciation rates



	function update_depreciation_rates(){
		
		var  marks = { scores: []};
		var checker = 0;
		 
	 
	   $('table tr').each(function() {
	 
			 if($('.Nm', this).val() != ""  && $('.Rate', this).val() > 0  ) {
				 
						 
				  checker +=1;
				//if(checker > 1) {
					
								
			 marks.scores.push({ 
			"Name" : $('.Nm', this).val(), 
			"Mcn_id"  : $('.mcn_id', this).val() 
			, 
			"Drate"  : $('.Rate', this).val()
			 
			 
			});
					  // }
				}
				
		}); 
		
			 var act = $('#prof_alt').attr('action');
			  if(checker < 1){
			 
			 alert('Please enter atleast a  single depreiation rate');
			 return false;
		 }
		
			 
			  BioCustom( act ,  marks , 1 , '#main-content' ); 
			 
		return false;
		 
		
	}

	//
	 
	 
	function jack(){
		alert();
		
		return false;
	}

	//add new states from here 

	function create_states(){
			  var frmd = $('form').serialize();
		
			  var act = $('#prof_alt').attr('action');
			  
			   BetaCustom4(act ,  frmd, '#main-content' );
		 
		
		return false;
		
		
	}






	/*
		$('#check').keyup(function(){
		 
		var ammount =$('#dpt').val();
		alert();
		 
	 
		//$.post( $('#pi_url').val()+'Form_loader/validate_user_name',{ammount: ammount},function(data){ /*$('#t_tn').html(data);          });
		
		
		
		}); */
		
		
		

	//check user name if exist 

	 

			 $("#check").keyup(function() 
			  {
				 
			 var searchbox = $('#check').val();
			  var dataString =  searchbox;
	 
			if(searchbox=='')
			  {}
			  else
			 {
				$.ajax({
				  type: "POST",
					url:     $('#pi_url').val()+'Form_loader/validate_user_name', 
						data: {'id_search': dataString},
					  cache: false,
						  success: function(html)
						   {
							   
						  $("#check_user").html(html).fadeIn('slow');
							}
						   });
						  }return false; 
						   });
						   
						   
						   
						   //search inventory
						   
						   $("#search_inventory").keyup(function() 
			  {
				 
			 var searchbox = $('#search_inventory').val();
			  var dataString =  searchbox;
			 
	 
			if(searchbox=='')
			  {}
			  else
			 {
				 
				$.ajax({
				  type: "POST",
					url:     $('#pi_url').val()+'Form_loader/Search_Inventories', 
						data: {'search_inventory': dataString},
					  cache: false,
						  success: function(html)
						   {
							   
						  $("#main-content").html(html).fadeIn('slow');
							}
						   });
						  }return false; 
						   });
							   
						   $("#search_Orders").keyup(function() 
			  {
				 
			 var searchbox = $('#search_Orders').val();
			  var dataString =  searchbox;
			 
	 
			if(searchbox=='')
			  {}
			  else
			 {
				 
				$.ajax({
				  type: "POST",
					url:     $('#pi_url').val()+'Form_loader/Search_Orders', 
						data: {'Search_Orders': dataString},
					  cache: false,
						  success: function(html)
						   {
							   
						  $("#main-content").html(html).fadeIn('slow');
							}
						   });
						  }return false; 
						   });
						  
						  




	function BetaCustom4(scpt ,  com , loadHere ){
		
		 

		$(".se-pre-con").fadeIn('slow');
		 var request = $.ajax({ url: scpt, type: "POST", data: com ,  dataType: "html"               });
		  

				   request.done(function(reply ) {       $(loadHere).html(reply);  $(".se-pre-con").fadeOut('slow');
				  

				   });
				   $('html, body').animate({ scrollTop: $('#container').offset().top }, 'slow');
				   
				   return false;
	 
		
	}

	//chek for some data if required from the dataBSSE FRO HERE

	function BetaCustom5(scpt ,  com  ){
	  $(".se-pre-con").fadeIn('slow');
		
		 var request = $.ajax({ url: scpt, type: "POST", data: com ,  dataType: "html"               });
		  

				   request.done(function(reply ) {      return reply;   $(".se-pre-con").fadeOut('slow');  });
				   $('html, body').animate({ scrollTop: $('#container').offset().top }, 'slow');
				   
				   return false;
	 
		
	}


	function PiCustom( ctrler, scpt ,  d1 , d2 , loadHere ){//custom script
		var ba = $('#pi_url').val();
		$(".se-pre-con").fadeIn('slow');
		 
		 
		var Piurl = $('#pi_url').val()+ctrler+'/'+scpt; 
		 
		
		 var request = $.ajax({ url: Piurl, type: "POST", data: { dataset1 : d1 , dataset2:d2 },  dataType: "html"               });

				   request.done(function(reply ) {       $(loadHere).html(reply);    $(".se-pre-con").fadeOut('slow');  });
				   
				   $('html, body').animate({ scrollTop: $('#container').offset().top }, 'slow');
				 
				   
				   return false;
	 
		
	}

	function PiCustom2( ctrler, scpt ,  d1 , d2 , loadHere ){//custom script
		var ba = $('#pi_url').val();
		$(".se-pre-con").fadeIn('slow');
		 
		 
		var Piurl = $('#pi_url').val()+ctrler+'/'+scpt; 
		 
		
		 var request = $.ajax({ url: Piurl, type: "POST", data: { dataset1 : d1 , userfile:d2 },  dataType: "html"               });

				   request.done(function(reply ) {      $(loadHere).html(reply);     $(".se-pre-con").fadeOut('slow');  });
				   $('html, body').animate({ scrollTop: $('#container').offset().top }, 'slow');
				  
				   
				   return false;
	 
		
	}

	//custom crs

	function BioCustom( scpt ,  d1 , d2 , loadHere ){//custom script
		$(".se-pre-con").fadeIn('slow');
		 
		  
		 
		
		 var request = $.ajax({ url: scpt, type: "POST", data: { Bio1 : d1 ,  Bio2 : d2  },  dataType: "html"               });

				   request.done(function(reply ) {      $(loadHere).html(reply);     $(".se-pre-con").fadeOut('slow');  });
				   $('html, body').animate({ scrollTop: $('#container').offset().top }, 'slow');
				  
				   
				   return false;
	 
		
	}

	//biotech option 2

	function BioCustom2( ctrler , scpt ,    d1 , d2 , loadHere ){//custom script
	 
		 $(".se-pre-con").fadeIn('slow');
		   
		   
		   var Piurl = $('#pi_url').val()+ctrler+'/'+scpt; 
		  
		 var request = $.ajax({ url: Piurl, type: "POST", data: { Bio1 : d1 ,  Bio2 : d2  },  dataType: "html"               });

				   request.done(function(reply ) {      $(loadHere).html(reply); 
					
				   
				   $(".se-pre-con").fadeOut('slow');  });
				  
				  $('html, body').animate({ scrollTop: $('#container').offset().top }, 'slow');
				   
				   return false;
	 
		
	} 


	//form loader


	function FormLoader( ctrler, scpt ){
		 
		  
		   $(".se-pre-con").fadeIn("slow");
		 
		
		 var request = $.ajax({ url: $('#pi_url').val()+ctrler+'/'+scpt, type: "POST", data: { comand : 1 , dataSend:1 },  dataType: "html"               });

				   request.done(function(reply ) {      $('#main-content').html(reply);   $(".se-pre-con").fadeOut("slow");  

				   });
				   $('html, body').animate({ scrollTop: $('#container').offset().top }, 'slow');
				 
				   
				   return false;
	 
		
	}