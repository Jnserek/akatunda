 
 function validate(){
	 var frmd = $('form').serialize();//read //
	
	 var act = $('#login').attr('action');

	 
	  $('#uname1').val('');
	 $('#pass').val('');
	
	// alert(act);
	 ////
	  //return false;
	 
	  BetaCustom2(act ,  frmd , '#validate_inputsX' );
     
	   
	 
	 return false;
 }
  



function BetaCustom2(scpt ,  com , loadHere ){

	
	 var request = $.ajax({ url: scpt, type: "POST", data: com ,  dataType: "html"               });
	  

               request.done(function(reply ) {       $(loadHere).html(reply);    });
			   
			   return false;
 
	
}


 
        

 

 
